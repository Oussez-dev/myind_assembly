/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class Effectivities.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class Effectivities implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _effectivityList.
     */
    private java.util.Vector<turbomeca.gamme.assembly.services.model.data.Effectivity> _effectivityList;


      //----------------/
     //- Constructors -/
    //----------------/

    public Effectivities() {
        super();
        this._effectivityList = new java.util.Vector<turbomeca.gamme.assembly.services.model.data.Effectivity>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vEffectivity
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addEffectivity(
            final turbomeca.gamme.assembly.services.model.data.Effectivity vEffectivity)
    throws java.lang.IndexOutOfBoundsException {
        this._effectivityList.addElement(vEffectivity);
    }

    /**
     * 
     * 
     * @param index
     * @param vEffectivity
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addEffectivity(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.Effectivity vEffectivity)
    throws java.lang.IndexOutOfBoundsException {
        this._effectivityList.add(index, vEffectivity);
    }

    /**
     * Method enumerateEffectivity.
     * 
     * @return an Enumeration over all
     * turbomeca.gamme.assembly.services.model.data.Effectivity
     * elements
     */
    public java.util.Enumeration<? extends turbomeca.gamme.assembly.services.model.data.Effectivity> enumerateEffectivity(
    ) {
        return this._effectivityList.elements();
    }

    /**
     * Method getEffectivity.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * turbomeca.gamme.assembly.services.model.data.Effectivity at
     * the given index
     */
    public turbomeca.gamme.assembly.services.model.data.Effectivity getEffectivity(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._effectivityList.size()) {
            throw new IndexOutOfBoundsException("getEffectivity: Index value '" + index + "' not in range [0.." + (this._effectivityList.size() - 1) + "]");
        }

        return (turbomeca.gamme.assembly.services.model.data.Effectivity) _effectivityList.get(index);
    }

    /**
     * Method getEffectivity.Returns the contents of the collection
     * in an Array.  <p>Note:  Just in case the collection contents
     * are changing in another thread, we pass a 0-length Array of
     * the correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public turbomeca.gamme.assembly.services.model.data.Effectivity[] getEffectivity(
    ) {
        turbomeca.gamme.assembly.services.model.data.Effectivity[] array = new turbomeca.gamme.assembly.services.model.data.Effectivity[0];
        return (turbomeca.gamme.assembly.services.model.data.Effectivity[]) this._effectivityList.toArray(array);
    }

    /**
     * Method getEffectivityAsReference.Returns a reference to
     * '_effectivityList'. No type checking is performed on any
     * modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<turbomeca.gamme.assembly.services.model.data.Effectivity> getEffectivityAsReference(
    ) {
        return this._effectivityList;
    }

    /**
     * Method getEffectivityCount.
     * 
     * @return the size of this collection
     */
    public int getEffectivityCount(
    ) {
        return this._effectivityList.size();
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllEffectivity(
    ) {
        this._effectivityList.clear();
    }

    /**
     * Method removeEffectivity.
     * 
     * @param vEffectivity
     * @return true if the object was removed from the collection.
     */
    public boolean removeEffectivity(
            final turbomeca.gamme.assembly.services.model.data.Effectivity vEffectivity) {
        boolean removed = _effectivityList.remove(vEffectivity);
        return removed;
    }

    /**
     * Method removeEffectivityAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public turbomeca.gamme.assembly.services.model.data.Effectivity removeEffectivityAt(
            final int index) {
        java.lang.Object obj = this._effectivityList.remove(index);
        return (turbomeca.gamme.assembly.services.model.data.Effectivity) obj;
    }

    /**
     * 
     * 
     * @param index
     * @param vEffectivity
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setEffectivity(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.Effectivity vEffectivity)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._effectivityList.size()) {
            throw new IndexOutOfBoundsException("setEffectivity: Index value '" + index + "' not in range [0.." + (this._effectivityList.size() - 1) + "]");
        }

        this._effectivityList.set(index, vEffectivity);
    }

    /**
     * 
     * 
     * @param vEffectivityArray
     */
    public void setEffectivity(
            final turbomeca.gamme.assembly.services.model.data.Effectivity[] vEffectivityArray) {
        //-- copy array
        _effectivityList.clear();

        for (int i = 0; i < vEffectivityArray.length; i++) {
                this._effectivityList.add(vEffectivityArray[i]);
        }
    }

    /**
     * Sets the value of '_effectivityList' by copying the given
     * Vector. All elements will be checked for type safety.
     * 
     * @param vEffectivityList the Vector to copy.
     */
    public void setEffectivity(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.Effectivity> vEffectivityList) {
        // copy vector
        this._effectivityList.clear();

        this._effectivityList.addAll(vEffectivityList);
    }

    /**
     * Sets the value of '_effectivityList' by setting it to the
     * given Vector. No type checking is performed.
     * @deprecated
     * 
     * @param effectivityVector the Vector to set.
     */
    public void setEffectivityAsReference(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.Effectivity> effectivityVector) {
        this._effectivityList = effectivityVector;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.Effectivities
     */
    public static turbomeca.gamme.assembly.services.model.data.Effectivities unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.Effectivities) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.Effectivities.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
