/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class InputActionChoice.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class InputActionChoice implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _inputField.
     */
    private turbomeca.gamme.assembly.services.model.data.InputField _inputField;

    /**
     * Field _inputConstant.
     */
    private java.lang.String _inputConstant;

    /**
     * Field _inputChoice.
     */
    private turbomeca.gamme.assembly.services.model.data.InputChoice _inputChoice;

    /**
     * Field _inputComputed.
     */
    private turbomeca.gamme.assembly.services.model.data.InputComputed _inputComputed;

    /**
     * Field _inputDocument.
     */
    private java.lang.Object _inputDocument;

    /**
     * Field _inputPicture.
     */
    private java.lang.Object _inputPicture;

    /**
     * Field _inputSap.
     */
    private turbomeca.gamme.assembly.services.model.data.InputSap _inputSap;

    /**
     * Field _inputControlSap.
     */
    private turbomeca.gamme.assembly.services.model.data.InputControlSap _inputControlSap;

    /**
     * Field _inputButtonPicture.
     */
    private turbomeca.gamme.assembly.services.model.data.InputButtonPicture _inputButtonPicture;


      //----------------/
     //- Constructors -/
    //----------------/

    public InputActionChoice() {
        super();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'inputButtonPicture'.
     * 
     * @return the value of field 'InputButtonPicture'.
     */
    public turbomeca.gamme.assembly.services.model.data.InputButtonPicture getInputButtonPicture(
    ) {
        return this._inputButtonPicture;
    }

    /**
     * Returns the value of field 'inputChoice'.
     * 
     * @return the value of field 'InputChoice'.
     */
    public turbomeca.gamme.assembly.services.model.data.InputChoice getInputChoice(
    ) {
        return this._inputChoice;
    }

    /**
     * Returns the value of field 'inputComputed'.
     * 
     * @return the value of field 'InputComputed'.
     */
    public turbomeca.gamme.assembly.services.model.data.InputComputed getInputComputed(
    ) {
        return this._inputComputed;
    }

    /**
     * Returns the value of field 'inputConstant'.
     * 
     * @return the value of field 'InputConstant'.
     */
    public java.lang.String getInputConstant(
    ) {
        return this._inputConstant;
    }

    /**
     * Returns the value of field 'inputControlSap'.
     * 
     * @return the value of field 'InputControlSap'.
     */
    public turbomeca.gamme.assembly.services.model.data.InputControlSap getInputControlSap(
    ) {
        return this._inputControlSap;
    }

    /**
     * Returns the value of field 'inputDocument'.
     * 
     * @return the value of field 'InputDocument'.
     */
    public java.lang.Object getInputDocument(
    ) {
        return this._inputDocument;
    }

    /**
     * Returns the value of field 'inputField'.
     * 
     * @return the value of field 'InputField'.
     */
    public turbomeca.gamme.assembly.services.model.data.InputField getInputField(
    ) {
        return this._inputField;
    }

    /**
     * Returns the value of field 'inputPicture'.
     * 
     * @return the value of field 'InputPicture'.
     */
    public java.lang.Object getInputPicture(
    ) {
        return this._inputPicture;
    }

    /**
     * Returns the value of field 'inputSap'.
     * 
     * @return the value of field 'InputSap'.
     */
    public turbomeca.gamme.assembly.services.model.data.InputSap getInputSap(
    ) {
        return this._inputSap;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     * Sets the value of field 'inputButtonPicture'.
     * 
     * @param inputButtonPicture the value of field
     * 'inputButtonPicture'.
     */
    public void setInputButtonPicture(
            final turbomeca.gamme.assembly.services.model.data.InputButtonPicture inputButtonPicture) {
        this._inputButtonPicture = inputButtonPicture;
    }

    /**
     * Sets the value of field 'inputChoice'.
     * 
     * @param inputChoice the value of field 'inputChoice'.
     */
    public void setInputChoice(
            final turbomeca.gamme.assembly.services.model.data.InputChoice inputChoice) {
        this._inputChoice = inputChoice;
    }

    /**
     * Sets the value of field 'inputComputed'.
     * 
     * @param inputComputed the value of field 'inputComputed'.
     */
    public void setInputComputed(
            final turbomeca.gamme.assembly.services.model.data.InputComputed inputComputed) {
        this._inputComputed = inputComputed;
    }

    /**
     * Sets the value of field 'inputConstant'.
     * 
     * @param inputConstant the value of field 'inputConstant'.
     */
    public void setInputConstant(
            final java.lang.String inputConstant) {
        this._inputConstant = inputConstant;
    }

    /**
     * Sets the value of field 'inputControlSap'.
     * 
     * @param inputControlSap the value of field 'inputControlSap'.
     */
    public void setInputControlSap(
            final turbomeca.gamme.assembly.services.model.data.InputControlSap inputControlSap) {
        this._inputControlSap = inputControlSap;
    }

    /**
     * Sets the value of field 'inputDocument'.
     * 
     * @param inputDocument the value of field 'inputDocument'.
     */
    public void setInputDocument(
            final java.lang.Object inputDocument) {
        this._inputDocument = inputDocument;
    }

    /**
     * Sets the value of field 'inputField'.
     * 
     * @param inputField the value of field 'inputField'.
     */
    public void setInputField(
            final turbomeca.gamme.assembly.services.model.data.InputField inputField) {
        this._inputField = inputField;
    }

    /**
     * Sets the value of field 'inputPicture'.
     * 
     * @param inputPicture the value of field 'inputPicture'.
     */
    public void setInputPicture(
            final java.lang.Object inputPicture) {
        this._inputPicture = inputPicture;
    }

    /**
     * Sets the value of field 'inputSap'.
     * 
     * @param inputSap the value of field 'inputSap'.
     */
    public void setInputSap(
            final turbomeca.gamme.assembly.services.model.data.InputSap inputSap) {
        this._inputSap = inputSap;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.InputActionChoic
     */
    public static turbomeca.gamme.assembly.services.model.data.InputActionChoice unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.InputActionChoice) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.InputActionChoice.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
