/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class Compounds.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class Compounds implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _compoundList.
     */
    private java.util.Vector<turbomeca.gamme.assembly.services.model.data.Compound> _compoundList;


      //----------------/
     //- Constructors -/
    //----------------/

    public Compounds() {
        super();
        this._compoundList = new java.util.Vector<turbomeca.gamme.assembly.services.model.data.Compound>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vCompound
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addCompound(
            final turbomeca.gamme.assembly.services.model.data.Compound vCompound)
    throws java.lang.IndexOutOfBoundsException {
        this._compoundList.addElement(vCompound);
    }

    /**
     * 
     * 
     * @param index
     * @param vCompound
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addCompound(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.Compound vCompound)
    throws java.lang.IndexOutOfBoundsException {
        this._compoundList.add(index, vCompound);
    }

    /**
     * Method enumerateCompound.
     * 
     * @return an Enumeration over all
     * turbomeca.gamme.assembly.services.model.data.Compound element
     */
    public java.util.Enumeration<? extends turbomeca.gamme.assembly.services.model.data.Compound> enumerateCompound(
    ) {
        return this._compoundList.elements();
    }

    /**
     * Method getCompound.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * turbomeca.gamme.assembly.services.model.data.Compound at the
     * given index
     */
    public turbomeca.gamme.assembly.services.model.data.Compound getCompound(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._compoundList.size()) {
            throw new IndexOutOfBoundsException("getCompound: Index value '" + index + "' not in range [0.." + (this._compoundList.size() - 1) + "]");
        }

        return (turbomeca.gamme.assembly.services.model.data.Compound) _compoundList.get(index);
    }

    /**
     * Method getCompound.Returns the contents of the collection in
     * an Array.  <p>Note:  Just in case the collection contents
     * are changing in another thread, we pass a 0-length Array of
     * the correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public turbomeca.gamme.assembly.services.model.data.Compound[] getCompound(
    ) {
        turbomeca.gamme.assembly.services.model.data.Compound[] array = new turbomeca.gamme.assembly.services.model.data.Compound[0];
        return (turbomeca.gamme.assembly.services.model.data.Compound[]) this._compoundList.toArray(array);
    }

    /**
     * Method getCompoundAsReference.Returns a reference to
     * '_compoundList'. No type checking is performed on any
     * modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<turbomeca.gamme.assembly.services.model.data.Compound> getCompoundAsReference(
    ) {
        return this._compoundList;
    }

    /**
     * Method getCompoundCount.
     * 
     * @return the size of this collection
     */
    public int getCompoundCount(
    ) {
        return this._compoundList.size();
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllCompound(
    ) {
        this._compoundList.clear();
    }

    /**
     * Method removeCompound.
     * 
     * @param vCompound
     * @return true if the object was removed from the collection.
     */
    public boolean removeCompound(
            final turbomeca.gamme.assembly.services.model.data.Compound vCompound) {
        boolean removed = _compoundList.remove(vCompound);
        return removed;
    }

    /**
     * Method removeCompoundAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public turbomeca.gamme.assembly.services.model.data.Compound removeCompoundAt(
            final int index) {
        java.lang.Object obj = this._compoundList.remove(index);
        return (turbomeca.gamme.assembly.services.model.data.Compound) obj;
    }

    /**
     * 
     * 
     * @param index
     * @param vCompound
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setCompound(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.Compound vCompound)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._compoundList.size()) {
            throw new IndexOutOfBoundsException("setCompound: Index value '" + index + "' not in range [0.." + (this._compoundList.size() - 1) + "]");
        }

        this._compoundList.set(index, vCompound);
    }

    /**
     * 
     * 
     * @param vCompoundArray
     */
    public void setCompound(
            final turbomeca.gamme.assembly.services.model.data.Compound[] vCompoundArray) {
        //-- copy array
        _compoundList.clear();

        for (int i = 0; i < vCompoundArray.length; i++) {
                this._compoundList.add(vCompoundArray[i]);
        }
    }

    /**
     * Sets the value of '_compoundList' by copying the given
     * Vector. All elements will be checked for type safety.
     * 
     * @param vCompoundList the Vector to copy.
     */
    public void setCompound(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.Compound> vCompoundList) {
        // copy vector
        this._compoundList.clear();

        this._compoundList.addAll(vCompoundList);
    }

    /**
     * Sets the value of '_compoundList' by setting it to the given
     * Vector. No type checking is performed.
     * @deprecated
     * 
     * @param compoundVector the Vector to set.
     */
    public void setCompoundAsReference(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.Compound> compoundVector) {
        this._compoundList = compoundVector;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.Compounds
     */
    public static turbomeca.gamme.assembly.services.model.data.Compounds unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.Compounds) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.Compounds.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
