/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class InputPicture.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class InputPicture implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _duplicate.
     */
    private boolean _duplicate = true;

    /**
     * keeps track of state for field: _duplicate
     */
    private boolean _has_duplicate;


      //----------------/
     //- Constructors -/
    //----------------/

    public InputPicture() {
        super();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     */
    public void deleteDuplicate(
    ) {
        this._has_duplicate= false;
    }

    /**
     * Returns the value of field 'duplicate'.
     * 
     * @return the value of field 'Duplicate'.
     */
    public boolean getDuplicate(
    ) {
        return this._duplicate;
    }

    /**
     * Method hasDuplicate.
     * 
     * @return true if at least one Duplicate has been added
     */
    public boolean hasDuplicate(
    ) {
        return this._has_duplicate;
    }

    /**
     * Returns the value of field 'duplicate'.
     * 
     * @return the value of field 'Duplicate'.
     */
    public boolean isDuplicate(
    ) {
        return this._duplicate;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     * Sets the value of field 'duplicate'.
     * 
     * @param duplicate the value of field 'duplicate'.
     */
    public void setDuplicate(
            final boolean duplicate) {
        this._duplicate = duplicate;
        this._has_duplicate = true;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.InputPicture
     */
    public static turbomeca.gamme.assembly.services.model.data.InputPicture unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.InputPicture) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.InputPicture.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
