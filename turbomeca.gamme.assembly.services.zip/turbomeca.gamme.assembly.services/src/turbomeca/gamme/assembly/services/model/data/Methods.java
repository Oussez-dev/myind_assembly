/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class Methods.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class Methods implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _methodList.
     */
    private java.util.Vector<turbomeca.gamme.assembly.services.model.data.Method> _methodList;


      //----------------/
     //- Constructors -/
    //----------------/

    public Methods() {
        super();
        this._methodList = new java.util.Vector<turbomeca.gamme.assembly.services.model.data.Method>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vMethod
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addMethod(
            final turbomeca.gamme.assembly.services.model.data.Method vMethod)
    throws java.lang.IndexOutOfBoundsException {
        this._methodList.addElement(vMethod);
    }

    /**
     * 
     * 
     * @param index
     * @param vMethod
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addMethod(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.Method vMethod)
    throws java.lang.IndexOutOfBoundsException {
        this._methodList.add(index, vMethod);
    }

    /**
     * Method enumerateMethod.
     * 
     * @return an Enumeration over all
     * turbomeca.gamme.assembly.services.model.data.Method elements
     */
    public java.util.Enumeration<? extends turbomeca.gamme.assembly.services.model.data.Method> enumerateMethod(
    ) {
        return this._methodList.elements();
    }

    /**
     * Method getMethod.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * turbomeca.gamme.assembly.services.model.data.Method at the
     * given index
     */
    public turbomeca.gamme.assembly.services.model.data.Method getMethod(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._methodList.size()) {
            throw new IndexOutOfBoundsException("getMethod: Index value '" + index + "' not in range [0.." + (this._methodList.size() - 1) + "]");
        }

        return (turbomeca.gamme.assembly.services.model.data.Method) _methodList.get(index);
    }

    /**
     * Method getMethod.Returns the contents of the collection in
     * an Array.  <p>Note:  Just in case the collection contents
     * are changing in another thread, we pass a 0-length Array of
     * the correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public turbomeca.gamme.assembly.services.model.data.Method[] getMethod(
    ) {
        turbomeca.gamme.assembly.services.model.data.Method[] array = new turbomeca.gamme.assembly.services.model.data.Method[0];
        return (turbomeca.gamme.assembly.services.model.data.Method[]) this._methodList.toArray(array);
    }

    /**
     * Method getMethodAsReference.Returns a reference to
     * '_methodList'. No type checking is performed on any
     * modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<turbomeca.gamme.assembly.services.model.data.Method> getMethodAsReference(
    ) {
        return this._methodList;
    }

    /**
     * Method getMethodCount.
     * 
     * @return the size of this collection
     */
    public int getMethodCount(
    ) {
        return this._methodList.size();
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllMethod(
    ) {
        this._methodList.clear();
    }

    /**
     * Method removeMethod.
     * 
     * @param vMethod
     * @return true if the object was removed from the collection.
     */
    public boolean removeMethod(
            final turbomeca.gamme.assembly.services.model.data.Method vMethod) {
        boolean removed = _methodList.remove(vMethod);
        return removed;
    }

    /**
     * Method removeMethodAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public turbomeca.gamme.assembly.services.model.data.Method removeMethodAt(
            final int index) {
        java.lang.Object obj = this._methodList.remove(index);
        return (turbomeca.gamme.assembly.services.model.data.Method) obj;
    }

    /**
     * 
     * 
     * @param index
     * @param vMethod
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setMethod(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.Method vMethod)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._methodList.size()) {
            throw new IndexOutOfBoundsException("setMethod: Index value '" + index + "' not in range [0.." + (this._methodList.size() - 1) + "]");
        }

        this._methodList.set(index, vMethod);
    }

    /**
     * 
     * 
     * @param vMethodArray
     */
    public void setMethod(
            final turbomeca.gamme.assembly.services.model.data.Method[] vMethodArray) {
        //-- copy array
        _methodList.clear();

        for (int i = 0; i < vMethodArray.length; i++) {
                this._methodList.add(vMethodArray[i]);
        }
    }

    /**
     * Sets the value of '_methodList' by copying the given Vector.
     * All elements will be checked for type safety.
     * 
     * @param vMethodList the Vector to copy.
     */
    public void setMethod(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.Method> vMethodList) {
        // copy vector
        this._methodList.clear();

        this._methodList.addAll(vMethodList);
    }

    /**
     * Sets the value of '_methodList' by setting it to the given
     * Vector. No type checking is performed.
     * @deprecated
     * 
     * @param methodVector the Vector to set.
     */
    public void setMethodAsReference(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.Method> methodVector) {
        this._methodList = methodVector;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.Methods
     */
    public static turbomeca.gamme.assembly.services.model.data.Methods unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.Methods) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.Methods.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
