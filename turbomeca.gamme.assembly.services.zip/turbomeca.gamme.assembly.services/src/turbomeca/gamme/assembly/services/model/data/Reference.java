/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class Reference.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class Reference implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _refId.
     */
    private java.lang.Object _refId;

    /**
     * Field _compute.
     */
    private boolean _compute;

    /**
     * keeps track of state for field: _compute
     */
    private boolean _has_compute;


      //----------------/
     //- Constructors -/
    //----------------/

    public Reference() {
        super();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     */
    public void deleteCompute(
    ) {
        this._has_compute= false;
    }

    /**
     * Returns the value of field 'compute'.
     * 
     * @return the value of field 'Compute'.
     */
    public boolean getCompute(
    ) {
        return this._compute;
    }

    /**
     * Returns the value of field 'refId'.
     * 
     * @return the value of field 'RefId'.
     */
    public java.lang.Object getRefId(
    ) {
        return this._refId;
    }

    /**
     * Method hasCompute.
     * 
     * @return true if at least one Compute has been added
     */
    public boolean hasCompute(
    ) {
        return this._has_compute;
    }

    /**
     * Returns the value of field 'compute'.
     * 
     * @return the value of field 'Compute'.
     */
    public boolean isCompute(
    ) {
        return this._compute;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     * Sets the value of field 'compute'.
     * 
     * @param compute the value of field 'compute'.
     */
    public void setCompute(
            final boolean compute) {
        this._compute = compute;
        this._has_compute = true;
    }

    /**
     * Sets the value of field 'refId'.
     * 
     * @param refId the value of field 'refId'.
     */
    public void setRefId(
            final java.lang.Object refId) {
        this._refId = refId;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.Reference
     */
    public static turbomeca.gamme.assembly.services.model.data.Reference unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.Reference) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.Reference.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
