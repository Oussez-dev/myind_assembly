/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class ObjectsToSynchronize.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class ObjectsToSynchronize implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _objectToSynchronizeList.
     */
    private java.util.Vector<turbomeca.gamme.assembly.services.model.data.ObjectToSynchronize> _objectToSynchronizeList;


      //----------------/
     //- Constructors -/
    //----------------/

    public ObjectsToSynchronize() {
        super();
        this._objectToSynchronizeList = new java.util.Vector<turbomeca.gamme.assembly.services.model.data.ObjectToSynchronize>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vObjectToSynchronize
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addObjectToSynchronize(
            final turbomeca.gamme.assembly.services.model.data.ObjectToSynchronize vObjectToSynchronize)
    throws java.lang.IndexOutOfBoundsException {
        this._objectToSynchronizeList.addElement(vObjectToSynchronize);
    }

    /**
     * 
     * 
     * @param index
     * @param vObjectToSynchronize
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addObjectToSynchronize(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.ObjectToSynchronize vObjectToSynchronize)
    throws java.lang.IndexOutOfBoundsException {
        this._objectToSynchronizeList.add(index, vObjectToSynchronize);
    }

    /**
     * Method enumerateObjectToSynchronize.
     * 
     * @return an Enumeration over all
     * turbomeca.gamme.assembly.services.model.data.ObjectToSynchronize
     * elements
     */
    public java.util.Enumeration<? extends turbomeca.gamme.assembly.services.model.data.ObjectToSynchronize> enumerateObjectToSynchronize(
    ) {
        return this._objectToSynchronizeList.elements();
    }

    /**
     * Method getObjectToSynchronize.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * turbomeca.gamme.assembly.services.model.data.ObjectToSynchronize
     * at the given index
     */
    public turbomeca.gamme.assembly.services.model.data.ObjectToSynchronize getObjectToSynchronize(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._objectToSynchronizeList.size()) {
            throw new IndexOutOfBoundsException("getObjectToSynchronize: Index value '" + index + "' not in range [0.." + (this._objectToSynchronizeList.size() - 1) + "]");
        }

        return (turbomeca.gamme.assembly.services.model.data.ObjectToSynchronize) _objectToSynchronizeList.get(index);
    }

    /**
     * Method getObjectToSynchronize.Returns the contents of the
     * collection in an Array.  <p>Note:  Just in case the
     * collection contents are changing in another thread, we pass
     * a 0-length Array of the correct type into the API call. 
     * This way we <i>know</i> that the Array returned is of
     * exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public turbomeca.gamme.assembly.services.model.data.ObjectToSynchronize[] getObjectToSynchronize(
    ) {
        turbomeca.gamme.assembly.services.model.data.ObjectToSynchronize[] array = new turbomeca.gamme.assembly.services.model.data.ObjectToSynchronize[0];
        return (turbomeca.gamme.assembly.services.model.data.ObjectToSynchronize[]) this._objectToSynchronizeList.toArray(array);
    }

    /**
     * Method getObjectToSynchronizeAsReference.Returns a reference
     * to '_objectToSynchronizeList'. No type checking is performed
     * on any modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<turbomeca.gamme.assembly.services.model.data.ObjectToSynchronize> getObjectToSynchronizeAsReference(
    ) {
        return this._objectToSynchronizeList;
    }

    /**
     * Method getObjectToSynchronizeCount.
     * 
     * @return the size of this collection
     */
    public int getObjectToSynchronizeCount(
    ) {
        return this._objectToSynchronizeList.size();
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllObjectToSynchronize(
    ) {
        this._objectToSynchronizeList.clear();
    }

    /**
     * Method removeObjectToSynchronize.
     * 
     * @param vObjectToSynchronize
     * @return true if the object was removed from the collection.
     */
    public boolean removeObjectToSynchronize(
            final turbomeca.gamme.assembly.services.model.data.ObjectToSynchronize vObjectToSynchronize) {
        boolean removed = _objectToSynchronizeList.remove(vObjectToSynchronize);
        return removed;
    }

    /**
     * Method removeObjectToSynchronizeAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public turbomeca.gamme.assembly.services.model.data.ObjectToSynchronize removeObjectToSynchronizeAt(
            final int index) {
        java.lang.Object obj = this._objectToSynchronizeList.remove(index);
        return (turbomeca.gamme.assembly.services.model.data.ObjectToSynchronize) obj;
    }

    /**
     * 
     * 
     * @param index
     * @param vObjectToSynchronize
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setObjectToSynchronize(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.ObjectToSynchronize vObjectToSynchronize)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._objectToSynchronizeList.size()) {
            throw new IndexOutOfBoundsException("setObjectToSynchronize: Index value '" + index + "' not in range [0.." + (this._objectToSynchronizeList.size() - 1) + "]");
        }

        this._objectToSynchronizeList.set(index, vObjectToSynchronize);
    }

    /**
     * 
     * 
     * @param vObjectToSynchronizeArray
     */
    public void setObjectToSynchronize(
            final turbomeca.gamme.assembly.services.model.data.ObjectToSynchronize[] vObjectToSynchronizeArray) {
        //-- copy array
        _objectToSynchronizeList.clear();

        for (int i = 0; i < vObjectToSynchronizeArray.length; i++) {
                this._objectToSynchronizeList.add(vObjectToSynchronizeArray[i]);
        }
    }

    /**
     * Sets the value of '_objectToSynchronizeList' by copying the
     * given Vector. All elements will be checked for type safety.
     * 
     * @param vObjectToSynchronizeList the Vector to copy.
     */
    public void setObjectToSynchronize(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.ObjectToSynchronize> vObjectToSynchronizeList) {
        // copy vector
        this._objectToSynchronizeList.clear();

        this._objectToSynchronizeList.addAll(vObjectToSynchronizeList);
    }

    /**
     * Sets the value of '_objectToSynchronizeList' by setting it
     * to the given Vector. No type checking is performed.
     * @deprecated
     * 
     * @param objectToSynchronizeVector the Vector to set.
     */
    public void setObjectToSynchronizeAsReference(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.ObjectToSynchronize> objectToSynchronizeVector) {
        this._objectToSynchronizeList = objectToSynchronizeVector;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.ObjectsToSynchronize
     */
    public static turbomeca.gamme.assembly.services.model.data.ObjectsToSynchronize unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.ObjectsToSynchronize) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.ObjectsToSynchronize.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
