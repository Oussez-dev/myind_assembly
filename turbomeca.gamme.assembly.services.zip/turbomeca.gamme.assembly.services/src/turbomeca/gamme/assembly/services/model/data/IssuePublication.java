/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class IssuePublication.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class IssuePublication implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _publishedDocumentList.
     */
    private java.util.Vector<turbomeca.gamme.assembly.services.model.data.PublishedDocument> _publishedDocumentList;

    /**
     * Field _commentary.
     */
    private turbomeca.gamme.assembly.services.model.data.Commentary _commentary;


      //----------------/
     //- Constructors -/
    //----------------/

    public IssuePublication() {
        super();
        this._publishedDocumentList = new java.util.Vector<turbomeca.gamme.assembly.services.model.data.PublishedDocument>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vPublishedDocument
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addPublishedDocument(
            final turbomeca.gamme.assembly.services.model.data.PublishedDocument vPublishedDocument)
    throws java.lang.IndexOutOfBoundsException {
        this._publishedDocumentList.addElement(vPublishedDocument);
    }

    /**
     * 
     * 
     * @param index
     * @param vPublishedDocument
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addPublishedDocument(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.PublishedDocument vPublishedDocument)
    throws java.lang.IndexOutOfBoundsException {
        this._publishedDocumentList.add(index, vPublishedDocument);
    }

    /**
     * Method enumeratePublishedDocument.
     * 
     * @return an Enumeration over all
     * turbomeca.gamme.assembly.services.model.data.PublishedDocument
     * elements
     */
    public java.util.Enumeration<? extends turbomeca.gamme.assembly.services.model.data.PublishedDocument> enumeratePublishedDocument(
    ) {
        return this._publishedDocumentList.elements();
    }

    /**
     * Returns the value of field 'commentary'.
     * 
     * @return the value of field 'Commentary'.
     */
    public turbomeca.gamme.assembly.services.model.data.Commentary getCommentary(
    ) {
        return this._commentary;
    }

    /**
     * Method getPublishedDocument.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * turbomeca.gamme.assembly.services.model.data.PublishedDocument
     * at the given index
     */
    public turbomeca.gamme.assembly.services.model.data.PublishedDocument getPublishedDocument(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._publishedDocumentList.size()) {
            throw new IndexOutOfBoundsException("getPublishedDocument: Index value '" + index + "' not in range [0.." + (this._publishedDocumentList.size() - 1) + "]");
        }

        return (turbomeca.gamme.assembly.services.model.data.PublishedDocument) _publishedDocumentList.get(index);
    }

    /**
     * Method getPublishedDocument.Returns the contents of the
     * collection in an Array.  <p>Note:  Just in case the
     * collection contents are changing in another thread, we pass
     * a 0-length Array of the correct type into the API call. 
     * This way we <i>know</i> that the Array returned is of
     * exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public turbomeca.gamme.assembly.services.model.data.PublishedDocument[] getPublishedDocument(
    ) {
        turbomeca.gamme.assembly.services.model.data.PublishedDocument[] array = new turbomeca.gamme.assembly.services.model.data.PublishedDocument[0];
        return (turbomeca.gamme.assembly.services.model.data.PublishedDocument[]) this._publishedDocumentList.toArray(array);
    }

    /**
     * Method getPublishedDocumentAsReference.Returns a reference
     * to '_publishedDocumentList'. No type checking is performed
     * on any modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<turbomeca.gamme.assembly.services.model.data.PublishedDocument> getPublishedDocumentAsReference(
    ) {
        return this._publishedDocumentList;
    }

    /**
     * Method getPublishedDocumentCount.
     * 
     * @return the size of this collection
     */
    public int getPublishedDocumentCount(
    ) {
        return this._publishedDocumentList.size();
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllPublishedDocument(
    ) {
        this._publishedDocumentList.clear();
    }

    /**
     * Method removePublishedDocument.
     * 
     * @param vPublishedDocument
     * @return true if the object was removed from the collection.
     */
    public boolean removePublishedDocument(
            final turbomeca.gamme.assembly.services.model.data.PublishedDocument vPublishedDocument) {
        boolean removed = _publishedDocumentList.remove(vPublishedDocument);
        return removed;
    }

    /**
     * Method removePublishedDocumentAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public turbomeca.gamme.assembly.services.model.data.PublishedDocument removePublishedDocumentAt(
            final int index) {
        java.lang.Object obj = this._publishedDocumentList.remove(index);
        return (turbomeca.gamme.assembly.services.model.data.PublishedDocument) obj;
    }

    /**
     * Sets the value of field 'commentary'.
     * 
     * @param commentary the value of field 'commentary'.
     */
    public void setCommentary(
            final turbomeca.gamme.assembly.services.model.data.Commentary commentary) {
        this._commentary = commentary;
    }

    /**
     * 
     * 
     * @param index
     * @param vPublishedDocument
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setPublishedDocument(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.PublishedDocument vPublishedDocument)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._publishedDocumentList.size()) {
            throw new IndexOutOfBoundsException("setPublishedDocument: Index value '" + index + "' not in range [0.." + (this._publishedDocumentList.size() - 1) + "]");
        }

        this._publishedDocumentList.set(index, vPublishedDocument);
    }

    /**
     * 
     * 
     * @param vPublishedDocumentArray
     */
    public void setPublishedDocument(
            final turbomeca.gamme.assembly.services.model.data.PublishedDocument[] vPublishedDocumentArray) {
        //-- copy array
        _publishedDocumentList.clear();

        for (int i = 0; i < vPublishedDocumentArray.length; i++) {
                this._publishedDocumentList.add(vPublishedDocumentArray[i]);
        }
    }

    /**
     * Sets the value of '_publishedDocumentList' by copying the
     * given Vector. All elements will be checked for type safety.
     * 
     * @param vPublishedDocumentList the Vector to copy.
     */
    public void setPublishedDocument(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.PublishedDocument> vPublishedDocumentList) {
        // copy vector
        this._publishedDocumentList.clear();

        this._publishedDocumentList.addAll(vPublishedDocumentList);
    }

    /**
     * Sets the value of '_publishedDocumentList' by setting it to
     * the given Vector. No type checking is performed.
     * @deprecated
     * 
     * @param publishedDocumentVector the Vector to set.
     */
    public void setPublishedDocumentAsReference(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.PublishedDocument> publishedDocumentVector) {
        this._publishedDocumentList = publishedDocumentVector;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.IssuePublication
     */
    public static turbomeca.gamme.assembly.services.model.data.IssuePublication unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.IssuePublication) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.IssuePublication.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
