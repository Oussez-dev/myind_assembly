/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class DocumentsJoined.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class DocumentsJoined implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _documentJoinedList.
     */
    private java.util.Vector<turbomeca.gamme.assembly.services.model.data.DocumentJoined> _documentJoinedList;


      //----------------/
     //- Constructors -/
    //----------------/

    public DocumentsJoined() {
        super();
        this._documentJoinedList = new java.util.Vector<turbomeca.gamme.assembly.services.model.data.DocumentJoined>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vDocumentJoined
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addDocumentJoined(
            final turbomeca.gamme.assembly.services.model.data.DocumentJoined vDocumentJoined)
    throws java.lang.IndexOutOfBoundsException {
        this._documentJoinedList.addElement(vDocumentJoined);
    }

    /**
     * 
     * 
     * @param index
     * @param vDocumentJoined
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addDocumentJoined(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.DocumentJoined vDocumentJoined)
    throws java.lang.IndexOutOfBoundsException {
        this._documentJoinedList.add(index, vDocumentJoined);
    }

    /**
     * Method enumerateDocumentJoined.
     * 
     * @return an Enumeration over all
     * turbomeca.gamme.assembly.services.model.data.DocumentJoined
     * elements
     */
    public java.util.Enumeration<? extends turbomeca.gamme.assembly.services.model.data.DocumentJoined> enumerateDocumentJoined(
    ) {
        return this._documentJoinedList.elements();
    }

    /**
     * Method getDocumentJoined.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * turbomeca.gamme.assembly.services.model.data.DocumentJoined
     * at the given index
     */
    public turbomeca.gamme.assembly.services.model.data.DocumentJoined getDocumentJoined(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._documentJoinedList.size()) {
            throw new IndexOutOfBoundsException("getDocumentJoined: Index value '" + index + "' not in range [0.." + (this._documentJoinedList.size() - 1) + "]");
        }

        return (turbomeca.gamme.assembly.services.model.data.DocumentJoined) _documentJoinedList.get(index);
    }

    /**
     * Method getDocumentJoined.Returns the contents of the
     * collection in an Array.  <p>Note:  Just in case the
     * collection contents are changing in another thread, we pass
     * a 0-length Array of the correct type into the API call. 
     * This way we <i>know</i> that the Array returned is of
     * exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public turbomeca.gamme.assembly.services.model.data.DocumentJoined[] getDocumentJoined(
    ) {
        turbomeca.gamme.assembly.services.model.data.DocumentJoined[] array = new turbomeca.gamme.assembly.services.model.data.DocumentJoined[0];
        return (turbomeca.gamme.assembly.services.model.data.DocumentJoined[]) this._documentJoinedList.toArray(array);
    }

    /**
     * Method getDocumentJoinedAsReference.Returns a reference to
     * '_documentJoinedList'. No type checking is performed on any
     * modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<turbomeca.gamme.assembly.services.model.data.DocumentJoined> getDocumentJoinedAsReference(
    ) {
        return this._documentJoinedList;
    }

    /**
     * Method getDocumentJoinedCount.
     * 
     * @return the size of this collection
     */
    public int getDocumentJoinedCount(
    ) {
        return this._documentJoinedList.size();
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllDocumentJoined(
    ) {
        this._documentJoinedList.clear();
    }

    /**
     * Method removeDocumentJoined.
     * 
     * @param vDocumentJoined
     * @return true if the object was removed from the collection.
     */
    public boolean removeDocumentJoined(
            final turbomeca.gamme.assembly.services.model.data.DocumentJoined vDocumentJoined) {
        boolean removed = _documentJoinedList.remove(vDocumentJoined);
        return removed;
    }

    /**
     * Method removeDocumentJoinedAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public turbomeca.gamme.assembly.services.model.data.DocumentJoined removeDocumentJoinedAt(
            final int index) {
        java.lang.Object obj = this._documentJoinedList.remove(index);
        return (turbomeca.gamme.assembly.services.model.data.DocumentJoined) obj;
    }

    /**
     * 
     * 
     * @param index
     * @param vDocumentJoined
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setDocumentJoined(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.DocumentJoined vDocumentJoined)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._documentJoinedList.size()) {
            throw new IndexOutOfBoundsException("setDocumentJoined: Index value '" + index + "' not in range [0.." + (this._documentJoinedList.size() - 1) + "]");
        }

        this._documentJoinedList.set(index, vDocumentJoined);
    }

    /**
     * 
     * 
     * @param vDocumentJoinedArray
     */
    public void setDocumentJoined(
            final turbomeca.gamme.assembly.services.model.data.DocumentJoined[] vDocumentJoinedArray) {
        //-- copy array
        _documentJoinedList.clear();

        for (int i = 0; i < vDocumentJoinedArray.length; i++) {
                this._documentJoinedList.add(vDocumentJoinedArray[i]);
        }
    }

    /**
     * Sets the value of '_documentJoinedList' by copying the given
     * Vector. All elements will be checked for type safety.
     * 
     * @param vDocumentJoinedList the Vector to copy.
     */
    public void setDocumentJoined(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.DocumentJoined> vDocumentJoinedList) {
        // copy vector
        this._documentJoinedList.clear();

        this._documentJoinedList.addAll(vDocumentJoinedList);
    }

    /**
     * Sets the value of '_documentJoinedList' by setting it to the
     * given Vector. No type checking is performed.
     * @deprecated
     * 
     * @param documentJoinedVector the Vector to set.
     */
    public void setDocumentJoinedAsReference(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.DocumentJoined> documentJoinedVector) {
        this._documentJoinedList = documentJoinedVector;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.DocumentsJoined
     */
    public static turbomeca.gamme.assembly.services.model.data.DocumentsJoined unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.DocumentsJoined) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.DocumentsJoined.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
