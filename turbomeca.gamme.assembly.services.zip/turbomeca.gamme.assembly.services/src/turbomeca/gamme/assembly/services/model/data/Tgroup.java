/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class Tgroup.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class Tgroup implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _cols.
     */
    private long _cols;

    /**
     * keeps track of state for field: _cols
     */
    private boolean _has_cols;

    /**
     * Field _colsep.
     */
    private turbomeca.gamme.assembly.services.model.data.types.BooleanType _colsep;

    /**
     * Field _rowsep.
     */
    private turbomeca.gamme.assembly.services.model.data.types.BooleanType _rowsep;

    /**
     * Field _align.
     */
    private turbomeca.gamme.assembly.services.model.data.types.Tbl_align_attribAlignType _align;

    /**
     * Field _char.
     */
    private java.lang.String _char;

    /**
     * Field _charoff.
     */
    private java.lang.String _charoff;

    /**
     * Field _tgroupstyle.
     */
    private java.lang.String _tgroupstyle;

    /**
     * Field _colspecList.
     */
    private java.util.Vector<turbomeca.gamme.assembly.services.model.data.Colspec> _colspecList;

    /**
     * Field _spanspecList.
     */
    private java.util.Vector<turbomeca.gamme.assembly.services.model.data.Spanspec> _spanspecList;

    /**
     * Field _thead.
     */
    private turbomeca.gamme.assembly.services.model.data.Thead _thead;

    /**
     * Field _tfoot.
     */
    private turbomeca.gamme.assembly.services.model.data.Tfoot _tfoot;

    /**
     * Field _tbody.
     */
    private turbomeca.gamme.assembly.services.model.data.Tbody _tbody;


      //----------------/
     //- Constructors -/
    //----------------/

    public Tgroup() {
        super();
        this._colspecList = new java.util.Vector<turbomeca.gamme.assembly.services.model.data.Colspec>();
        this._spanspecList = new java.util.Vector<turbomeca.gamme.assembly.services.model.data.Spanspec>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vColspec
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addColspec(
            final turbomeca.gamme.assembly.services.model.data.Colspec vColspec)
    throws java.lang.IndexOutOfBoundsException {
        this._colspecList.addElement(vColspec);
    }

    /**
     * 
     * 
     * @param index
     * @param vColspec
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addColspec(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.Colspec vColspec)
    throws java.lang.IndexOutOfBoundsException {
        this._colspecList.add(index, vColspec);
    }

    /**
     * 
     * 
     * @param vSpanspec
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addSpanspec(
            final turbomeca.gamme.assembly.services.model.data.Spanspec vSpanspec)
    throws java.lang.IndexOutOfBoundsException {
        this._spanspecList.addElement(vSpanspec);
    }

    /**
     * 
     * 
     * @param index
     * @param vSpanspec
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addSpanspec(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.Spanspec vSpanspec)
    throws java.lang.IndexOutOfBoundsException {
        this._spanspecList.add(index, vSpanspec);
    }

    /**
     */
    public void deleteCols(
    ) {
        this._has_cols= false;
    }

    /**
     * Method enumerateColspec.
     * 
     * @return an Enumeration over all
     * turbomeca.gamme.assembly.services.model.data.Colspec elements
     */
    public java.util.Enumeration<? extends turbomeca.gamme.assembly.services.model.data.Colspec> enumerateColspec(
    ) {
        return this._colspecList.elements();
    }

    /**
     * Method enumerateSpanspec.
     * 
     * @return an Enumeration over all
     * turbomeca.gamme.assembly.services.model.data.Spanspec element
     */
    public java.util.Enumeration<? extends turbomeca.gamme.assembly.services.model.data.Spanspec> enumerateSpanspec(
    ) {
        return this._spanspecList.elements();
    }

    /**
     * Returns the value of field 'align'.
     * 
     * @return the value of field 'Align'.
     */
    public turbomeca.gamme.assembly.services.model.data.types.Tbl_align_attribAlignType getAlign(
    ) {
        return this._align;
    }

    /**
     * Returns the value of field 'char'.
     * 
     * @return the value of field 'Char'.
     */
    public java.lang.String getChar(
    ) {
        return this._char;
    }

    /**
     * Returns the value of field 'charoff'.
     * 
     * @return the value of field 'Charoff'.
     */
    public java.lang.String getCharoff(
    ) {
        return this._charoff;
    }

    /**
     * Returns the value of field 'cols'.
     * 
     * @return the value of field 'Cols'.
     */
    public long getCols(
    ) {
        return this._cols;
    }

    /**
     * Returns the value of field 'colsep'.
     * 
     * @return the value of field 'Colsep'.
     */
    public turbomeca.gamme.assembly.services.model.data.types.BooleanType getColsep(
    ) {
        return this._colsep;
    }

    /**
     * Method getColspec.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * turbomeca.gamme.assembly.services.model.data.Colspec at the
     * given index
     */
    public turbomeca.gamme.assembly.services.model.data.Colspec getColspec(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._colspecList.size()) {
            throw new IndexOutOfBoundsException("getColspec: Index value '" + index + "' not in range [0.." + (this._colspecList.size() - 1) + "]");
        }

        return (turbomeca.gamme.assembly.services.model.data.Colspec) _colspecList.get(index);
    }

    /**
     * Method getColspec.Returns the contents of the collection in
     * an Array.  <p>Note:  Just in case the collection contents
     * are changing in another thread, we pass a 0-length Array of
     * the correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public turbomeca.gamme.assembly.services.model.data.Colspec[] getColspec(
    ) {
        turbomeca.gamme.assembly.services.model.data.Colspec[] array = new turbomeca.gamme.assembly.services.model.data.Colspec[0];
        return (turbomeca.gamme.assembly.services.model.data.Colspec[]) this._colspecList.toArray(array);
    }

    /**
     * Method getColspecAsReference.Returns a reference to
     * '_colspecList'. No type checking is performed on any
     * modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<turbomeca.gamme.assembly.services.model.data.Colspec> getColspecAsReference(
    ) {
        return this._colspecList;
    }

    /**
     * Method getColspecCount.
     * 
     * @return the size of this collection
     */
    public int getColspecCount(
    ) {
        return this._colspecList.size();
    }

    /**
     * Returns the value of field 'rowsep'.
     * 
     * @return the value of field 'Rowsep'.
     */
    public turbomeca.gamme.assembly.services.model.data.types.BooleanType getRowsep(
    ) {
        return this._rowsep;
    }

    /**
     * Method getSpanspec.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * turbomeca.gamme.assembly.services.model.data.Spanspec at the
     * given index
     */
    public turbomeca.gamme.assembly.services.model.data.Spanspec getSpanspec(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._spanspecList.size()) {
            throw new IndexOutOfBoundsException("getSpanspec: Index value '" + index + "' not in range [0.." + (this._spanspecList.size() - 1) + "]");
        }

        return (turbomeca.gamme.assembly.services.model.data.Spanspec) _spanspecList.get(index);
    }

    /**
     * Method getSpanspec.Returns the contents of the collection in
     * an Array.  <p>Note:  Just in case the collection contents
     * are changing in another thread, we pass a 0-length Array of
     * the correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public turbomeca.gamme.assembly.services.model.data.Spanspec[] getSpanspec(
    ) {
        turbomeca.gamme.assembly.services.model.data.Spanspec[] array = new turbomeca.gamme.assembly.services.model.data.Spanspec[0];
        return (turbomeca.gamme.assembly.services.model.data.Spanspec[]) this._spanspecList.toArray(array);
    }

    /**
     * Method getSpanspecAsReference.Returns a reference to
     * '_spanspecList'. No type checking is performed on any
     * modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<turbomeca.gamme.assembly.services.model.data.Spanspec> getSpanspecAsReference(
    ) {
        return this._spanspecList;
    }

    /**
     * Method getSpanspecCount.
     * 
     * @return the size of this collection
     */
    public int getSpanspecCount(
    ) {
        return this._spanspecList.size();
    }

    /**
     * Returns the value of field 'tbody'.
     * 
     * @return the value of field 'Tbody'.
     */
    public turbomeca.gamme.assembly.services.model.data.Tbody getTbody(
    ) {
        return this._tbody;
    }

    /**
     * Returns the value of field 'tfoot'.
     * 
     * @return the value of field 'Tfoot'.
     */
    public turbomeca.gamme.assembly.services.model.data.Tfoot getTfoot(
    ) {
        return this._tfoot;
    }

    /**
     * Returns the value of field 'tgroupstyle'.
     * 
     * @return the value of field 'Tgroupstyle'.
     */
    public java.lang.String getTgroupstyle(
    ) {
        return this._tgroupstyle;
    }

    /**
     * Returns the value of field 'thead'.
     * 
     * @return the value of field 'Thead'.
     */
    public turbomeca.gamme.assembly.services.model.data.Thead getThead(
    ) {
        return this._thead;
    }

    /**
     * Method hasCols.
     * 
     * @return true if at least one Cols has been added
     */
    public boolean hasCols(
    ) {
        return this._has_cols;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllColspec(
    ) {
        this._colspecList.clear();
    }

    /**
     */
    public void removeAllSpanspec(
    ) {
        this._spanspecList.clear();
    }

    /**
     * Method removeColspec.
     * 
     * @param vColspec
     * @return true if the object was removed from the collection.
     */
    public boolean removeColspec(
            final turbomeca.gamme.assembly.services.model.data.Colspec vColspec) {
        boolean removed = _colspecList.remove(vColspec);
        return removed;
    }

    /**
     * Method removeColspecAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public turbomeca.gamme.assembly.services.model.data.Colspec removeColspecAt(
            final int index) {
        java.lang.Object obj = this._colspecList.remove(index);
        return (turbomeca.gamme.assembly.services.model.data.Colspec) obj;
    }

    /**
     * Method removeSpanspec.
     * 
     * @param vSpanspec
     * @return true if the object was removed from the collection.
     */
    public boolean removeSpanspec(
            final turbomeca.gamme.assembly.services.model.data.Spanspec vSpanspec) {
        boolean removed = _spanspecList.remove(vSpanspec);
        return removed;
    }

    /**
     * Method removeSpanspecAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public turbomeca.gamme.assembly.services.model.data.Spanspec removeSpanspecAt(
            final int index) {
        java.lang.Object obj = this._spanspecList.remove(index);
        return (turbomeca.gamme.assembly.services.model.data.Spanspec) obj;
    }

    /**
     * Sets the value of field 'align'.
     * 
     * @param align the value of field 'align'.
     */
    public void setAlign(
            final turbomeca.gamme.assembly.services.model.data.types.Tbl_align_attribAlignType align) {
        this._align = align;
    }

    /**
     * Sets the value of field 'char'.
     * 
     * @param _char
     * @param char the value of field 'char'.
     */
    public void setChar(
            final java.lang.String _char) {
        this._char = _char;
    }

    /**
     * Sets the value of field 'charoff'.
     * 
     * @param charoff the value of field 'charoff'.
     */
    public void setCharoff(
            final java.lang.String charoff) {
        this._charoff = charoff;
    }

    /**
     * Sets the value of field 'cols'.
     * 
     * @param cols the value of field 'cols'.
     */
    public void setCols(
            final long cols) {
        this._cols = cols;
        this._has_cols = true;
    }

    /**
     * Sets the value of field 'colsep'.
     * 
     * @param colsep the value of field 'colsep'.
     */
    public void setColsep(
            final turbomeca.gamme.assembly.services.model.data.types.BooleanType colsep) {
        this._colsep = colsep;
    }

    /**
     * 
     * 
     * @param index
     * @param vColspec
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setColspec(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.Colspec vColspec)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._colspecList.size()) {
            throw new IndexOutOfBoundsException("setColspec: Index value '" + index + "' not in range [0.." + (this._colspecList.size() - 1) + "]");
        }

        this._colspecList.set(index, vColspec);
    }

    /**
     * 
     * 
     * @param vColspecArray
     */
    public void setColspec(
            final turbomeca.gamme.assembly.services.model.data.Colspec[] vColspecArray) {
        //-- copy array
        _colspecList.clear();

        for (int i = 0; i < vColspecArray.length; i++) {
                this._colspecList.add(vColspecArray[i]);
        }
    }

    /**
     * Sets the value of '_colspecList' by copying the given
     * Vector. All elements will be checked for type safety.
     * 
     * @param vColspecList the Vector to copy.
     */
    public void setColspec(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.Colspec> vColspecList) {
        // copy vector
        this._colspecList.clear();

        this._colspecList.addAll(vColspecList);
    }

    /**
     * Sets the value of '_colspecList' by setting it to the given
     * Vector. No type checking is performed.
     * @deprecated
     * 
     * @param colspecVector the Vector to set.
     */
    public void setColspecAsReference(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.Colspec> colspecVector) {
        this._colspecList = colspecVector;
    }

    /**
     * Sets the value of field 'rowsep'.
     * 
     * @param rowsep the value of field 'rowsep'.
     */
    public void setRowsep(
            final turbomeca.gamme.assembly.services.model.data.types.BooleanType rowsep) {
        this._rowsep = rowsep;
    }

    /**
     * 
     * 
     * @param index
     * @param vSpanspec
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setSpanspec(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.Spanspec vSpanspec)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._spanspecList.size()) {
            throw new IndexOutOfBoundsException("setSpanspec: Index value '" + index + "' not in range [0.." + (this._spanspecList.size() - 1) + "]");
        }

        this._spanspecList.set(index, vSpanspec);
    }

    /**
     * 
     * 
     * @param vSpanspecArray
     */
    public void setSpanspec(
            final turbomeca.gamme.assembly.services.model.data.Spanspec[] vSpanspecArray) {
        //-- copy array
        _spanspecList.clear();

        for (int i = 0; i < vSpanspecArray.length; i++) {
                this._spanspecList.add(vSpanspecArray[i]);
        }
    }

    /**
     * Sets the value of '_spanspecList' by copying the given
     * Vector. All elements will be checked for type safety.
     * 
     * @param vSpanspecList the Vector to copy.
     */
    public void setSpanspec(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.Spanspec> vSpanspecList) {
        // copy vector
        this._spanspecList.clear();

        this._spanspecList.addAll(vSpanspecList);
    }

    /**
     * Sets the value of '_spanspecList' by setting it to the given
     * Vector. No type checking is performed.
     * @deprecated
     * 
     * @param spanspecVector the Vector to set.
     */
    public void setSpanspecAsReference(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.Spanspec> spanspecVector) {
        this._spanspecList = spanspecVector;
    }

    /**
     * Sets the value of field 'tbody'.
     * 
     * @param tbody the value of field 'tbody'.
     */
    public void setTbody(
            final turbomeca.gamme.assembly.services.model.data.Tbody tbody) {
        this._tbody = tbody;
    }

    /**
     * Sets the value of field 'tfoot'.
     * 
     * @param tfoot the value of field 'tfoot'.
     */
    public void setTfoot(
            final turbomeca.gamme.assembly.services.model.data.Tfoot tfoot) {
        this._tfoot = tfoot;
    }

    /**
     * Sets the value of field 'tgroupstyle'.
     * 
     * @param tgroupstyle the value of field 'tgroupstyle'.
     */
    public void setTgroupstyle(
            final java.lang.String tgroupstyle) {
        this._tgroupstyle = tgroupstyle;
    }

    /**
     * Sets the value of field 'thead'.
     * 
     * @param thead the value of field 'thead'.
     */
    public void setThead(
            final turbomeca.gamme.assembly.services.model.data.Thead thead) {
        this._thead = thead;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.Tgroup
     */
    public static turbomeca.gamme.assembly.services.model.data.Tgroup unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.Tgroup) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.Tgroup.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
