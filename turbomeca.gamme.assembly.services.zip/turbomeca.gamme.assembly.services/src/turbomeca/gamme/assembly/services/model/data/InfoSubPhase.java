/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class InfoSubPhase.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class InfoSubPhase implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _standardTime.
     */
    private turbomeca.gamme.assembly.services.model.data.StandardTime _standardTime;

    /**
     * Field _mnemonic.
     */
    private java.lang.String _mnemonic;

    /**
     * Field _autoControl.
     */
    private turbomeca.gamme.assembly.services.model.data.AutoControl _autoControl;

    /**
     * Field _statusInst.
     */
    private turbomeca.gamme.assembly.services.model.data.StatusInst _statusInst;

    /**
     * Field _referentialTaskList.
     */
    private java.util.Vector<turbomeca.gamme.assembly.services.model.data.ReferentialTask> _referentialTaskList;


      //----------------/
     //- Constructors -/
    //----------------/

    public InfoSubPhase() {
        super();
        this._referentialTaskList = new java.util.Vector<turbomeca.gamme.assembly.services.model.data.ReferentialTask>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vReferentialTask
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addReferentialTask(
            final turbomeca.gamme.assembly.services.model.data.ReferentialTask vReferentialTask)
    throws java.lang.IndexOutOfBoundsException {
        this._referentialTaskList.addElement(vReferentialTask);
    }

    /**
     * 
     * 
     * @param index
     * @param vReferentialTask
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addReferentialTask(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.ReferentialTask vReferentialTask)
    throws java.lang.IndexOutOfBoundsException {
        this._referentialTaskList.add(index, vReferentialTask);
    }

    /**
     * Method enumerateReferentialTask.
     * 
     * @return an Enumeration over all
     * turbomeca.gamme.assembly.services.model.data.ReferentialTask
     * elements
     */
    public java.util.Enumeration<? extends turbomeca.gamme.assembly.services.model.data.ReferentialTask> enumerateReferentialTask(
    ) {
        return this._referentialTaskList.elements();
    }

    /**
     * Returns the value of field 'autoControl'.
     * 
     * @return the value of field 'AutoControl'.
     */
    public turbomeca.gamme.assembly.services.model.data.AutoControl getAutoControl(
    ) {
        return this._autoControl;
    }

    /**
     * Returns the value of field 'mnemonic'.
     * 
     * @return the value of field 'Mnemonic'.
     */
    public java.lang.String getMnemonic(
    ) {
        return this._mnemonic;
    }

    /**
     * Method getReferentialTask.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * turbomeca.gamme.assembly.services.model.data.ReferentialTask
     * at the given index
     */
    public turbomeca.gamme.assembly.services.model.data.ReferentialTask getReferentialTask(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._referentialTaskList.size()) {
            throw new IndexOutOfBoundsException("getReferentialTask: Index value '" + index + "' not in range [0.." + (this._referentialTaskList.size() - 1) + "]");
        }

        return (turbomeca.gamme.assembly.services.model.data.ReferentialTask) _referentialTaskList.get(index);
    }

    /**
     * Method getReferentialTask.Returns the contents of the
     * collection in an Array.  <p>Note:  Just in case the
     * collection contents are changing in another thread, we pass
     * a 0-length Array of the correct type into the API call. 
     * This way we <i>know</i> that the Array returned is of
     * exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public turbomeca.gamme.assembly.services.model.data.ReferentialTask[] getReferentialTask(
    ) {
        turbomeca.gamme.assembly.services.model.data.ReferentialTask[] array = new turbomeca.gamme.assembly.services.model.data.ReferentialTask[0];
        return (turbomeca.gamme.assembly.services.model.data.ReferentialTask[]) this._referentialTaskList.toArray(array);
    }

    /**
     * Method getReferentialTaskAsReference.Returns a reference to
     * '_referentialTaskList'. No type checking is performed on any
     * modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<turbomeca.gamme.assembly.services.model.data.ReferentialTask> getReferentialTaskAsReference(
    ) {
        return this._referentialTaskList;
    }

    /**
     * Method getReferentialTaskCount.
     * 
     * @return the size of this collection
     */
    public int getReferentialTaskCount(
    ) {
        return this._referentialTaskList.size();
    }

    /**
     * Returns the value of field 'standardTime'.
     * 
     * @return the value of field 'StandardTime'.
     */
    public turbomeca.gamme.assembly.services.model.data.StandardTime getStandardTime(
    ) {
        return this._standardTime;
    }

    /**
     * Returns the value of field 'statusInst'.
     * 
     * @return the value of field 'StatusInst'.
     */
    public turbomeca.gamme.assembly.services.model.data.StatusInst getStatusInst(
    ) {
        return this._statusInst;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllReferentialTask(
    ) {
        this._referentialTaskList.clear();
    }

    /**
     * Method removeReferentialTask.
     * 
     * @param vReferentialTask
     * @return true if the object was removed from the collection.
     */
    public boolean removeReferentialTask(
            final turbomeca.gamme.assembly.services.model.data.ReferentialTask vReferentialTask) {
        boolean removed = _referentialTaskList.remove(vReferentialTask);
        return removed;
    }

    /**
     * Method removeReferentialTaskAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public turbomeca.gamme.assembly.services.model.data.ReferentialTask removeReferentialTaskAt(
            final int index) {
        java.lang.Object obj = this._referentialTaskList.remove(index);
        return (turbomeca.gamme.assembly.services.model.data.ReferentialTask) obj;
    }

    /**
     * Sets the value of field 'autoControl'.
     * 
     * @param autoControl the value of field 'autoControl'.
     */
    public void setAutoControl(
            final turbomeca.gamme.assembly.services.model.data.AutoControl autoControl) {
        this._autoControl = autoControl;
    }

    /**
     * Sets the value of field 'mnemonic'.
     * 
     * @param mnemonic the value of field 'mnemonic'.
     */
    public void setMnemonic(
            final java.lang.String mnemonic) {
        this._mnemonic = mnemonic;
    }

    /**
     * 
     * 
     * @param index
     * @param vReferentialTask
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setReferentialTask(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.ReferentialTask vReferentialTask)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._referentialTaskList.size()) {
            throw new IndexOutOfBoundsException("setReferentialTask: Index value '" + index + "' not in range [0.." + (this._referentialTaskList.size() - 1) + "]");
        }

        this._referentialTaskList.set(index, vReferentialTask);
    }

    /**
     * 
     * 
     * @param vReferentialTaskArray
     */
    public void setReferentialTask(
            final turbomeca.gamme.assembly.services.model.data.ReferentialTask[] vReferentialTaskArray) {
        //-- copy array
        _referentialTaskList.clear();

        for (int i = 0; i < vReferentialTaskArray.length; i++) {
                this._referentialTaskList.add(vReferentialTaskArray[i]);
        }
    }

    /**
     * Sets the value of '_referentialTaskList' by copying the
     * given Vector. All elements will be checked for type safety.
     * 
     * @param vReferentialTaskList the Vector to copy.
     */
    public void setReferentialTask(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.ReferentialTask> vReferentialTaskList) {
        // copy vector
        this._referentialTaskList.clear();

        this._referentialTaskList.addAll(vReferentialTaskList);
    }

    /**
     * Sets the value of '_referentialTaskList' by setting it to
     * the given Vector. No type checking is performed.
     * @deprecated
     * 
     * @param referentialTaskVector the Vector to set.
     */
    public void setReferentialTaskAsReference(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.ReferentialTask> referentialTaskVector) {
        this._referentialTaskList = referentialTaskVector;
    }

    /**
     * Sets the value of field 'standardTime'.
     * 
     * @param standardTime the value of field 'standardTime'.
     */
    public void setStandardTime(
            final turbomeca.gamme.assembly.services.model.data.StandardTime standardTime) {
        this._standardTime = standardTime;
    }

    /**
     * Sets the value of field 'statusInst'.
     * 
     * @param statusInst the value of field 'statusInst'.
     */
    public void setStatusInst(
            final turbomeca.gamme.assembly.services.model.data.StatusInst statusInst) {
        this._statusInst = statusInst;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.InfoSubPhase
     */
    public static turbomeca.gamme.assembly.services.model.data.InfoSubPhase unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.InfoSubPhase) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.InfoSubPhase.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
