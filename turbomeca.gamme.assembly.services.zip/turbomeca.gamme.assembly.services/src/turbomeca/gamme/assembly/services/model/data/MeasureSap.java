/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class MeasureSap.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class MeasureSap implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _drawingMarker.
     */
    private java.lang.String _drawingMarker;

    /**
     * Field _compound.
     */
    private java.lang.String _compound;

    /**
     * Field _ata.
     */
    private java.lang.String _ata;

    /**
     * Field _subComponent.
     */
    private java.lang.String _subComponent;

    /**
     * Field _state.
     */
    private turbomeca.gamme.assembly.services.model.data.State _state;

    /**
     * Field _caracDefList.
     */
    private java.util.Vector<turbomeca.gamme.assembly.services.model.data.CaracDef> _caracDefList;

    /**
     * Field _PN.
     */
    private turbomeca.gamme.assembly.services.model.data.PN _PN;

    /**
     * Field _SN.
     */
    private turbomeca.gamme.assembly.services.model.data.SN _SN;


      //----------------/
     //- Constructors -/
    //----------------/

    public MeasureSap() {
        super();
        this._caracDefList = new java.util.Vector<turbomeca.gamme.assembly.services.model.data.CaracDef>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vCaracDef
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addCaracDef(
            final turbomeca.gamme.assembly.services.model.data.CaracDef vCaracDef)
    throws java.lang.IndexOutOfBoundsException {
        this._caracDefList.addElement(vCaracDef);
    }

    /**
     * 
     * 
     * @param index
     * @param vCaracDef
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addCaracDef(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.CaracDef vCaracDef)
    throws java.lang.IndexOutOfBoundsException {
        this._caracDefList.add(index, vCaracDef);
    }

    /**
     * Method enumerateCaracDef.
     * 
     * @return an Enumeration over all
     * turbomeca.gamme.assembly.services.model.data.CaracDef element
     */
    public java.util.Enumeration<? extends turbomeca.gamme.assembly.services.model.data.CaracDef> enumerateCaracDef(
    ) {
        return this._caracDefList.elements();
    }

    /**
     * Returns the value of field 'ata'.
     * 
     * @return the value of field 'Ata'.
     */
    public java.lang.String getAta(
    ) {
        return this._ata;
    }

    /**
     * Method getCaracDef.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * turbomeca.gamme.assembly.services.model.data.CaracDef at the
     * given index
     */
    public turbomeca.gamme.assembly.services.model.data.CaracDef getCaracDef(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._caracDefList.size()) {
            throw new IndexOutOfBoundsException("getCaracDef: Index value '" + index + "' not in range [0.." + (this._caracDefList.size() - 1) + "]");
        }

        return (turbomeca.gamme.assembly.services.model.data.CaracDef) _caracDefList.get(index);
    }

    /**
     * Method getCaracDef.Returns the contents of the collection in
     * an Array.  <p>Note:  Just in case the collection contents
     * are changing in another thread, we pass a 0-length Array of
     * the correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public turbomeca.gamme.assembly.services.model.data.CaracDef[] getCaracDef(
    ) {
        turbomeca.gamme.assembly.services.model.data.CaracDef[] array = new turbomeca.gamme.assembly.services.model.data.CaracDef[0];
        return (turbomeca.gamme.assembly.services.model.data.CaracDef[]) this._caracDefList.toArray(array);
    }

    /**
     * Method getCaracDefAsReference.Returns a reference to
     * '_caracDefList'. No type checking is performed on any
     * modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<turbomeca.gamme.assembly.services.model.data.CaracDef> getCaracDefAsReference(
    ) {
        return this._caracDefList;
    }

    /**
     * Method getCaracDefCount.
     * 
     * @return the size of this collection
     */
    public int getCaracDefCount(
    ) {
        return this._caracDefList.size();
    }

    /**
     * Returns the value of field 'compound'.
     * 
     * @return the value of field 'Compound'.
     */
    public java.lang.String getCompound(
    ) {
        return this._compound;
    }

    /**
     * Returns the value of field 'drawingMarker'.
     * 
     * @return the value of field 'DrawingMarker'.
     */
    public java.lang.String getDrawingMarker(
    ) {
        return this._drawingMarker;
    }

    /**
     * Returns the value of field 'PN'.
     * 
     * @return the value of field 'PN'.
     */
    public turbomeca.gamme.assembly.services.model.data.PN getPN(
    ) {
        return this._PN;
    }

    /**
     * Returns the value of field 'SN'.
     * 
     * @return the value of field 'SN'.
     */
    public turbomeca.gamme.assembly.services.model.data.SN getSN(
    ) {
        return this._SN;
    }

    /**
     * Returns the value of field 'state'.
     * 
     * @return the value of field 'State'.
     */
    public turbomeca.gamme.assembly.services.model.data.State getState(
    ) {
        return this._state;
    }

    /**
     * Returns the value of field 'subComponent'.
     * 
     * @return the value of field 'SubComponent'.
     */
    public java.lang.String getSubComponent(
    ) {
        return this._subComponent;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllCaracDef(
    ) {
        this._caracDefList.clear();
    }

    /**
     * Method removeCaracDef.
     * 
     * @param vCaracDef
     * @return true if the object was removed from the collection.
     */
    public boolean removeCaracDef(
            final turbomeca.gamme.assembly.services.model.data.CaracDef vCaracDef) {
        boolean removed = _caracDefList.remove(vCaracDef);
        return removed;
    }

    /**
     * Method removeCaracDefAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public turbomeca.gamme.assembly.services.model.data.CaracDef removeCaracDefAt(
            final int index) {
        java.lang.Object obj = this._caracDefList.remove(index);
        return (turbomeca.gamme.assembly.services.model.data.CaracDef) obj;
    }

    /**
     * Sets the value of field 'ata'.
     * 
     * @param ata the value of field 'ata'.
     */
    public void setAta(
            final java.lang.String ata) {
        this._ata = ata;
    }

    /**
     * 
     * 
     * @param index
     * @param vCaracDef
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setCaracDef(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.CaracDef vCaracDef)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._caracDefList.size()) {
            throw new IndexOutOfBoundsException("setCaracDef: Index value '" + index + "' not in range [0.." + (this._caracDefList.size() - 1) + "]");
        }

        this._caracDefList.set(index, vCaracDef);
    }

    /**
     * 
     * 
     * @param vCaracDefArray
     */
    public void setCaracDef(
            final turbomeca.gamme.assembly.services.model.data.CaracDef[] vCaracDefArray) {
        //-- copy array
        _caracDefList.clear();

        for (int i = 0; i < vCaracDefArray.length; i++) {
                this._caracDefList.add(vCaracDefArray[i]);
        }
    }

    /**
     * Sets the value of '_caracDefList' by copying the given
     * Vector. All elements will be checked for type safety.
     * 
     * @param vCaracDefList the Vector to copy.
     */
    public void setCaracDef(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.CaracDef> vCaracDefList) {
        // copy vector
        this._caracDefList.clear();

        this._caracDefList.addAll(vCaracDefList);
    }

    /**
     * Sets the value of '_caracDefList' by setting it to the given
     * Vector. No type checking is performed.
     * @deprecated
     * 
     * @param caracDefVector the Vector to set.
     */
    public void setCaracDefAsReference(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.CaracDef> caracDefVector) {
        this._caracDefList = caracDefVector;
    }

    /**
     * Sets the value of field 'compound'.
     * 
     * @param compound the value of field 'compound'.
     */
    public void setCompound(
            final java.lang.String compound) {
        this._compound = compound;
    }

    /**
     * Sets the value of field 'drawingMarker'.
     * 
     * @param drawingMarker the value of field 'drawingMarker'.
     */
    public void setDrawingMarker(
            final java.lang.String drawingMarker) {
        this._drawingMarker = drawingMarker;
    }

    /**
     * Sets the value of field 'PN'.
     * 
     * @param PN the value of field 'PN'.
     */
    public void setPN(
            final turbomeca.gamme.assembly.services.model.data.PN PN) {
        this._PN = PN;
    }

    /**
     * Sets the value of field 'SN'.
     * 
     * @param SN the value of field 'SN'.
     */
    public void setSN(
            final turbomeca.gamme.assembly.services.model.data.SN SN) {
        this._SN = SN;
    }

    /**
     * Sets the value of field 'state'.
     * 
     * @param state the value of field 'state'.
     */
    public void setState(
            final turbomeca.gamme.assembly.services.model.data.State state) {
        this._state = state;
    }

    /**
     * Sets the value of field 'subComponent'.
     * 
     * @param subComponent the value of field 'subComponent'.
     */
    public void setSubComponent(
            final java.lang.String subComponent) {
        this._subComponent = subComponent;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.MeasureSap
     */
    public static turbomeca.gamme.assembly.services.model.data.MeasureSap unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.MeasureSap) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.MeasureSap.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
