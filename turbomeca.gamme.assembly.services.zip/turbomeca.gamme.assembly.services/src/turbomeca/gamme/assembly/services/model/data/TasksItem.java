/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class TasksItem.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class TasksItem implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Internal choice value storage
     */
    private java.lang.Object _choiceValue;

    /**
     * Field _taskGroup.
     */
    private turbomeca.gamme.assembly.services.model.data.TaskGroup _taskGroup;

    /**
     * Field _task.
     */
    private turbomeca.gamme.assembly.services.model.data.Task _task;

    /**
     * Field _taskBenchSetting.
     */
    private turbomeca.gamme.assembly.services.model.data.TaskBenchSetting _taskBenchSetting;


      //----------------/
     //- Constructors -/
    //----------------/

    public TasksItem() {
        super();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'choiceValue'. The field
     * 'choiceValue' has the following description: Internal choice
     * value storage
     * 
     * @return the value of field 'ChoiceValue'.
     */
    public java.lang.Object getChoiceValue(
    ) {
        return this._choiceValue;
    }

    /**
     * Returns the value of field 'task'.
     * 
     * @return the value of field 'Task'.
     */
    public turbomeca.gamme.assembly.services.model.data.Task getTask(
    ) {
        return this._task;
    }

    /**
     * Returns the value of field 'taskBenchSetting'.
     * 
     * @return the value of field 'TaskBenchSetting'.
     */
    public turbomeca.gamme.assembly.services.model.data.TaskBenchSetting getTaskBenchSetting(
    ) {
        return this._taskBenchSetting;
    }

    /**
     * Returns the value of field 'taskGroup'.
     * 
     * @return the value of field 'TaskGroup'.
     */
    public turbomeca.gamme.assembly.services.model.data.TaskGroup getTaskGroup(
    ) {
        return this._taskGroup;
    }

    /**
     * Sets the value of field 'task'.
     * 
     * @param task the value of field 'task'.
     */
    public void setTask(
            final turbomeca.gamme.assembly.services.model.data.Task task) {
        this._task = task;
        this._choiceValue = task;
    }

    /**
     * Sets the value of field 'taskBenchSetting'.
     * 
     * @param taskBenchSetting the value of field 'taskBenchSetting'
     */
    public void setTaskBenchSetting(
            final turbomeca.gamme.assembly.services.model.data.TaskBenchSetting taskBenchSetting) {
        this._taskBenchSetting = taskBenchSetting;
        this._choiceValue = taskBenchSetting;
    }

    /**
     * Sets the value of field 'taskGroup'.
     * 
     * @param taskGroup the value of field 'taskGroup'.
     */
    public void setTaskGroup(
            final turbomeca.gamme.assembly.services.model.data.TaskGroup taskGroup) {
        this._taskGroup = taskGroup;
        this._choiceValue = taskGroup;
    }

}
