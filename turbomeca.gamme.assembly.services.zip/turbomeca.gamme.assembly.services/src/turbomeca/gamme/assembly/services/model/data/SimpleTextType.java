/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class SimpleTextType.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class SimpleTextType implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _language.
     */
    private java.lang.String _language;

    /**
     * internal content storage
     */
    private java.lang.String _content = "";

    /**
     * Field _items.
     */
    private java.util.Vector<turbomeca.gamme.assembly.services.model.data.SimpleTextTypeItem> _items;


      //----------------/
     //- Constructors -/
    //----------------/

    public SimpleTextType() {
        super();
        setContent("");
        this._items = new java.util.Vector<turbomeca.gamme.assembly.services.model.data.SimpleTextTypeItem>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vSimpleTextTypeItem
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addSimpleTextTypeItem(
            final turbomeca.gamme.assembly.services.model.data.SimpleTextTypeItem vSimpleTextTypeItem)
    throws java.lang.IndexOutOfBoundsException {
        this._items.addElement(vSimpleTextTypeItem);
    }

    /**
     * 
     * 
     * @param index
     * @param vSimpleTextTypeItem
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addSimpleTextTypeItem(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.SimpleTextTypeItem vSimpleTextTypeItem)
    throws java.lang.IndexOutOfBoundsException {
        this._items.add(index, vSimpleTextTypeItem);
    }

    /**
     * Method enumerateSimpleTextTypeItem.
     * 
     * @return an Enumeration over all
     * turbomeca.gamme.assembly.services.model.data.SimpleTextTypeItem
     * elements
     */
    public java.util.Enumeration<? extends turbomeca.gamme.assembly.services.model.data.SimpleTextTypeItem> enumerateSimpleTextTypeItem(
    ) {
        return this._items.elements();
    }

    /**
     * Returns the value of field 'content'. The field 'content'
     * has the following description: internal content storage
     * 
     * @return the value of field 'Content'.
     */
    public java.lang.String getContent(
    ) {
        return this._content;
    }

    /**
     * Returns the value of field 'language'.
     * 
     * @return the value of field 'Language'.
     */
    public java.lang.String getLanguage(
    ) {
        return this._language;
    }

    /**
     * Method getSimpleTextTypeItem.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * turbomeca.gamme.assembly.services.model.data.SimpleTextTypeItem
     * at the given index
     */
    public turbomeca.gamme.assembly.services.model.data.SimpleTextTypeItem getSimpleTextTypeItem(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._items.size()) {
            throw new IndexOutOfBoundsException("getSimpleTextTypeItem: Index value '" + index + "' not in range [0.." + (this._items.size() - 1) + "]");
        }

        return (turbomeca.gamme.assembly.services.model.data.SimpleTextTypeItem) _items.get(index);
    }

    /**
     * Method getSimpleTextTypeItem.Returns the contents of the
     * collection in an Array.  <p>Note:  Just in case the
     * collection contents are changing in another thread, we pass
     * a 0-length Array of the correct type into the API call. 
     * This way we <i>know</i> that the Array returned is of
     * exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public turbomeca.gamme.assembly.services.model.data.SimpleTextTypeItem[] getSimpleTextTypeItem(
    ) {
        turbomeca.gamme.assembly.services.model.data.SimpleTextTypeItem[] array = new turbomeca.gamme.assembly.services.model.data.SimpleTextTypeItem[0];
        return (turbomeca.gamme.assembly.services.model.data.SimpleTextTypeItem[]) this._items.toArray(array);
    }

    /**
     * Method getSimpleTextTypeItemAsReference.Returns a reference
     * to '_items'. No type checking is performed on any
     * modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<turbomeca.gamme.assembly.services.model.data.SimpleTextTypeItem> getSimpleTextTypeItemAsReference(
    ) {
        return this._items;
    }

    /**
     * Method getSimpleTextTypeItemCount.
     * 
     * @return the size of this collection
     */
    public int getSimpleTextTypeItemCount(
    ) {
        return this._items.size();
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllSimpleTextTypeItem(
    ) {
        this._items.clear();
    }

    /**
     * Method removeSimpleTextTypeItem.
     * 
     * @param vSimpleTextTypeItem
     * @return true if the object was removed from the collection.
     */
    public boolean removeSimpleTextTypeItem(
            final turbomeca.gamme.assembly.services.model.data.SimpleTextTypeItem vSimpleTextTypeItem) {
        boolean removed = _items.remove(vSimpleTextTypeItem);
        return removed;
    }

    /**
     * Method removeSimpleTextTypeItemAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public turbomeca.gamme.assembly.services.model.data.SimpleTextTypeItem removeSimpleTextTypeItemAt(
            final int index) {
        java.lang.Object obj = this._items.remove(index);
        return (turbomeca.gamme.assembly.services.model.data.SimpleTextTypeItem) obj;
    }

    /**
     * Sets the value of field 'content'. The field 'content' has
     * the following description: internal content storage
     * 
     * @param content the value of field 'content'.
     */
    public void setContent(
            final java.lang.String content) {
        this._content = content;
    }

    /**
     * Sets the value of field 'language'.
     * 
     * @param language the value of field 'language'.
     */
    public void setLanguage(
            final java.lang.String language) {
        this._language = language;
    }

    /**
     * 
     * 
     * @param index
     * @param vSimpleTextTypeItem
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setSimpleTextTypeItem(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.SimpleTextTypeItem vSimpleTextTypeItem)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._items.size()) {
            throw new IndexOutOfBoundsException("setSimpleTextTypeItem: Index value '" + index + "' not in range [0.." + (this._items.size() - 1) + "]");
        }

        this._items.set(index, vSimpleTextTypeItem);
    }

    /**
     * 
     * 
     * @param vSimpleTextTypeItemArray
     */
    public void setSimpleTextTypeItem(
            final turbomeca.gamme.assembly.services.model.data.SimpleTextTypeItem[] vSimpleTextTypeItemArray) {
        //-- copy array
        _items.clear();

        for (int i = 0; i < vSimpleTextTypeItemArray.length; i++) {
                this._items.add(vSimpleTextTypeItemArray[i]);
        }
    }

    /**
     * Sets the value of '_items' by copying the given Vector. All
     * elements will be checked for type safety.
     * 
     * @param vSimpleTextTypeItemList the Vector to copy.
     */
    public void setSimpleTextTypeItem(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.SimpleTextTypeItem> vSimpleTextTypeItemList) {
        // copy vector
        this._items.clear();

        this._items.addAll(vSimpleTextTypeItemList);
    }

    /**
     * Sets the value of '_items' by setting it to the given
     * Vector. No type checking is performed.
     * @deprecated
     * 
     * @param simpleTextTypeItemVector the Vector to set.
     */
    public void setSimpleTextTypeItemAsReference(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.SimpleTextTypeItem> simpleTextTypeItemVector) {
        this._items = simpleTextTypeItemVector;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.SimpleTextType
     */
    public static turbomeca.gamme.assembly.services.model.data.SimpleTextType unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.SimpleTextType) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.SimpleTextType.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
