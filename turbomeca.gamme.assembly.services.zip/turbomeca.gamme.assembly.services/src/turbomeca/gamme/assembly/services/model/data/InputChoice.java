/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class InputChoice.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class InputChoice implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _type.
     */
    private turbomeca.gamme.assembly.services.model.data.types.ChoiceType _type = turbomeca.gamme.assembly.services.model.data.types.ChoiceType.fromValue("combo");

    /**
     * Field _manual.
     */
    private boolean _manual = true;

    /**
     * keeps track of state for field: _manual
     */
    private boolean _has_manual;

    /**
     * Internal choice value storage
     */
    private java.lang.Object _choiceValue;

    /**
     * Field _itemParaList.
     */
    private java.util.Vector<turbomeca.gamme.assembly.services.model.data.ItemPara> _itemParaList;

    /**
     * Field _pictureList.
     */
    private java.util.Vector<turbomeca.gamme.assembly.services.model.data.Picture> _pictureList;

    /**
     * Field _stringValueList.
     */
    private java.util.Vector<turbomeca.gamme.assembly.services.model.data.StringValue> _stringValueList;

    /**
     * Field _valList.
     */
    private java.util.Vector<java.math.BigDecimal> _valList;


      //----------------/
     //- Constructors -/
    //----------------/

    public InputChoice() {
        super();
        setType(turbomeca.gamme.assembly.services.model.data.types.ChoiceType.fromValue("combo"));
        this._itemParaList = new java.util.Vector<turbomeca.gamme.assembly.services.model.data.ItemPara>();
        this._pictureList = new java.util.Vector<turbomeca.gamme.assembly.services.model.data.Picture>();
        this._stringValueList = new java.util.Vector<turbomeca.gamme.assembly.services.model.data.StringValue>();
        this._valList = new java.util.Vector<java.math.BigDecimal>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vItemPara
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addItemPara(
            final turbomeca.gamme.assembly.services.model.data.ItemPara vItemPara)
    throws java.lang.IndexOutOfBoundsException {
        this._itemParaList.addElement(vItemPara);
    }

    /**
     * 
     * 
     * @param index
     * @param vItemPara
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addItemPara(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.ItemPara vItemPara)
    throws java.lang.IndexOutOfBoundsException {
        this._itemParaList.add(index, vItemPara);
    }

    /**
     * 
     * 
     * @param vPicture
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addPicture(
            final turbomeca.gamme.assembly.services.model.data.Picture vPicture)
    throws java.lang.IndexOutOfBoundsException {
        this._pictureList.addElement(vPicture);
    }

    /**
     * 
     * 
     * @param index
     * @param vPicture
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addPicture(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.Picture vPicture)
    throws java.lang.IndexOutOfBoundsException {
        this._pictureList.add(index, vPicture);
    }

    /**
     * 
     * 
     * @param vStringValue
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addStringValue(
            final turbomeca.gamme.assembly.services.model.data.StringValue vStringValue)
    throws java.lang.IndexOutOfBoundsException {
        this._stringValueList.addElement(vStringValue);
    }

    /**
     * 
     * 
     * @param index
     * @param vStringValue
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addStringValue(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.StringValue vStringValue)
    throws java.lang.IndexOutOfBoundsException {
        this._stringValueList.add(index, vStringValue);
    }

    /**
     * 
     * 
     * @param vVal
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addVal(
            final java.math.BigDecimal vVal)
    throws java.lang.IndexOutOfBoundsException {
        this._valList.addElement(vVal);
    }

    /**
     * 
     * 
     * @param index
     * @param vVal
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addVal(
            final int index,
            final java.math.BigDecimal vVal)
    throws java.lang.IndexOutOfBoundsException {
        this._valList.add(index, vVal);
    }

    /**
     */
    public void deleteManual(
    ) {
        this._has_manual= false;
    }

    /**
     * Method enumerateItemPara.
     * 
     * @return an Enumeration over all
     * turbomeca.gamme.assembly.services.model.data.ItemPara element
     */
    public java.util.Enumeration<? extends turbomeca.gamme.assembly.services.model.data.ItemPara> enumerateItemPara(
    ) {
        return this._itemParaList.elements();
    }

    /**
     * Method enumeratePicture.
     * 
     * @return an Enumeration over all
     * turbomeca.gamme.assembly.services.model.data.Picture elements
     */
    public java.util.Enumeration<? extends turbomeca.gamme.assembly.services.model.data.Picture> enumeratePicture(
    ) {
        return this._pictureList.elements();
    }

    /**
     * Method enumerateStringValue.
     * 
     * @return an Enumeration over all
     * turbomeca.gamme.assembly.services.model.data.StringValue
     * elements
     */
    public java.util.Enumeration<? extends turbomeca.gamme.assembly.services.model.data.StringValue> enumerateStringValue(
    ) {
        return this._stringValueList.elements();
    }

    /**
     * Method enumerateVal.
     * 
     * @return an Enumeration over all java.math.BigDecimal elements
     */
    public java.util.Enumeration<? extends java.math.BigDecimal> enumerateVal(
    ) {
        return this._valList.elements();
    }

    /**
     * Returns the value of field 'choiceValue'. The field
     * 'choiceValue' has the following description: Internal choice
     * value storage
     * 
     * @return the value of field 'ChoiceValue'.
     */
    public java.lang.Object getChoiceValue(
    ) {
        return this._choiceValue;
    }

    /**
     * Method getItemPara.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * turbomeca.gamme.assembly.services.model.data.ItemPara at the
     * given index
     */
    public turbomeca.gamme.assembly.services.model.data.ItemPara getItemPara(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._itemParaList.size()) {
            throw new IndexOutOfBoundsException("getItemPara: Index value '" + index + "' not in range [0.." + (this._itemParaList.size() - 1) + "]");
        }

        return (turbomeca.gamme.assembly.services.model.data.ItemPara) _itemParaList.get(index);
    }

    /**
     * Method getItemPara.Returns the contents of the collection in
     * an Array.  <p>Note:  Just in case the collection contents
     * are changing in another thread, we pass a 0-length Array of
     * the correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public turbomeca.gamme.assembly.services.model.data.ItemPara[] getItemPara(
    ) {
        turbomeca.gamme.assembly.services.model.data.ItemPara[] array = new turbomeca.gamme.assembly.services.model.data.ItemPara[0];
        return (turbomeca.gamme.assembly.services.model.data.ItemPara[]) this._itemParaList.toArray(array);
    }

    /**
     * Method getItemParaAsReference.Returns a reference to
     * '_itemParaList'. No type checking is performed on any
     * modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<turbomeca.gamme.assembly.services.model.data.ItemPara> getItemParaAsReference(
    ) {
        return this._itemParaList;
    }

    /**
     * Method getItemParaCount.
     * 
     * @return the size of this collection
     */
    public int getItemParaCount(
    ) {
        return this._itemParaList.size();
    }

    /**
     * Returns the value of field 'manual'.
     * 
     * @return the value of field 'Manual'.
     */
    public boolean getManual(
    ) {
        return this._manual;
    }

    /**
     * Method getPicture.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * turbomeca.gamme.assembly.services.model.data.Picture at the
     * given index
     */
    public turbomeca.gamme.assembly.services.model.data.Picture getPicture(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._pictureList.size()) {
            throw new IndexOutOfBoundsException("getPicture: Index value '" + index + "' not in range [0.." + (this._pictureList.size() - 1) + "]");
        }

        return (turbomeca.gamme.assembly.services.model.data.Picture) _pictureList.get(index);
    }

    /**
     * Method getPicture.Returns the contents of the collection in
     * an Array.  <p>Note:  Just in case the collection contents
     * are changing in another thread, we pass a 0-length Array of
     * the correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public turbomeca.gamme.assembly.services.model.data.Picture[] getPicture(
    ) {
        turbomeca.gamme.assembly.services.model.data.Picture[] array = new turbomeca.gamme.assembly.services.model.data.Picture[0];
        return (turbomeca.gamme.assembly.services.model.data.Picture[]) this._pictureList.toArray(array);
    }

    /**
     * Method getPictureAsReference.Returns a reference to
     * '_pictureList'. No type checking is performed on any
     * modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<turbomeca.gamme.assembly.services.model.data.Picture> getPictureAsReference(
    ) {
        return this._pictureList;
    }

    /**
     * Method getPictureCount.
     * 
     * @return the size of this collection
     */
    public int getPictureCount(
    ) {
        return this._pictureList.size();
    }

    /**
     * Method getStringValue.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * turbomeca.gamme.assembly.services.model.data.StringValue at
     * the given index
     */
    public turbomeca.gamme.assembly.services.model.data.StringValue getStringValue(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._stringValueList.size()) {
            throw new IndexOutOfBoundsException("getStringValue: Index value '" + index + "' not in range [0.." + (this._stringValueList.size() - 1) + "]");
        }

        return (turbomeca.gamme.assembly.services.model.data.StringValue) _stringValueList.get(index);
    }

    /**
     * Method getStringValue.Returns the contents of the collection
     * in an Array.  <p>Note:  Just in case the collection contents
     * are changing in another thread, we pass a 0-length Array of
     * the correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public turbomeca.gamme.assembly.services.model.data.StringValue[] getStringValue(
    ) {
        turbomeca.gamme.assembly.services.model.data.StringValue[] array = new turbomeca.gamme.assembly.services.model.data.StringValue[0];
        return (turbomeca.gamme.assembly.services.model.data.StringValue[]) this._stringValueList.toArray(array);
    }

    /**
     * Method getStringValueAsReference.Returns a reference to
     * '_stringValueList'. No type checking is performed on any
     * modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<turbomeca.gamme.assembly.services.model.data.StringValue> getStringValueAsReference(
    ) {
        return this._stringValueList;
    }

    /**
     * Method getStringValueCount.
     * 
     * @return the size of this collection
     */
    public int getStringValueCount(
    ) {
        return this._stringValueList.size();
    }

    /**
     * Returns the value of field 'type'.
     * 
     * @return the value of field 'Type'.
     */
    public turbomeca.gamme.assembly.services.model.data.types.ChoiceType getType(
    ) {
        return this._type;
    }

    /**
     * Method getVal.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the java.math.BigDecimal at the given
     * index
     */
    public java.math.BigDecimal getVal(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._valList.size()) {
            throw new IndexOutOfBoundsException("getVal: Index value '" + index + "' not in range [0.." + (this._valList.size() - 1) + "]");
        }

        return (java.math.BigDecimal) _valList.get(index);
    }

    /**
     * Method getVal.Returns the contents of the collection in an
     * Array.  <p>Note:  Just in case the collection contents are
     * changing in another thread, we pass a 0-length Array of the
     * correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public java.math.BigDecimal[] getVal(
    ) {
        java.math.BigDecimal[] array = new java.math.BigDecimal[0];
        return (java.math.BigDecimal[]) this._valList.toArray(array);
    }

    /**
     * Method getValAsReference.Returns a reference to '_valList'.
     * No type checking is performed on any modifications to the
     * Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<java.math.BigDecimal> getValAsReference(
    ) {
        return this._valList;
    }

    /**
     * Method getValCount.
     * 
     * @return the size of this collection
     */
    public int getValCount(
    ) {
        return this._valList.size();
    }

    /**
     * Method hasManual.
     * 
     * @return true if at least one Manual has been added
     */
    public boolean hasManual(
    ) {
        return this._has_manual;
    }

    /**
     * Returns the value of field 'manual'.
     * 
     * @return the value of field 'Manual'.
     */
    public boolean isManual(
    ) {
        return this._manual;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllItemPara(
    ) {
        this._itemParaList.clear();
    }

    /**
     */
    public void removeAllPicture(
    ) {
        this._pictureList.clear();
    }

    /**
     */
    public void removeAllStringValue(
    ) {
        this._stringValueList.clear();
    }

    /**
     */
    public void removeAllVal(
    ) {
        this._valList.clear();
    }

    /**
     * Method removeItemPara.
     * 
     * @param vItemPara
     * @return true if the object was removed from the collection.
     */
    public boolean removeItemPara(
            final turbomeca.gamme.assembly.services.model.data.ItemPara vItemPara) {
        boolean removed = _itemParaList.remove(vItemPara);
        return removed;
    }

    /**
     * Method removeItemParaAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public turbomeca.gamme.assembly.services.model.data.ItemPara removeItemParaAt(
            final int index) {
        java.lang.Object obj = this._itemParaList.remove(index);
        return (turbomeca.gamme.assembly.services.model.data.ItemPara) obj;
    }

    /**
     * Method removePicture.
     * 
     * @param vPicture
     * @return true if the object was removed from the collection.
     */
    public boolean removePicture(
            final turbomeca.gamme.assembly.services.model.data.Picture vPicture) {
        boolean removed = _pictureList.remove(vPicture);
        return removed;
    }

    /**
     * Method removePictureAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public turbomeca.gamme.assembly.services.model.data.Picture removePictureAt(
            final int index) {
        java.lang.Object obj = this._pictureList.remove(index);
        return (turbomeca.gamme.assembly.services.model.data.Picture) obj;
    }

    /**
     * Method removeStringValue.
     * 
     * @param vStringValue
     * @return true if the object was removed from the collection.
     */
    public boolean removeStringValue(
            final turbomeca.gamme.assembly.services.model.data.StringValue vStringValue) {
        boolean removed = _stringValueList.remove(vStringValue);
        return removed;
    }

    /**
     * Method removeStringValueAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public turbomeca.gamme.assembly.services.model.data.StringValue removeStringValueAt(
            final int index) {
        java.lang.Object obj = this._stringValueList.remove(index);
        return (turbomeca.gamme.assembly.services.model.data.StringValue) obj;
    }

    /**
     * Method removeVal.
     * 
     * @param vVal
     * @return true if the object was removed from the collection.
     */
    public boolean removeVal(
            final java.math.BigDecimal vVal) {
        boolean removed = _valList.remove(vVal);
        return removed;
    }

    /**
     * Method removeValAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public java.math.BigDecimal removeValAt(
            final int index) {
        java.lang.Object obj = this._valList.remove(index);
        return (java.math.BigDecimal) obj;
    }

    /**
     * 
     * 
     * @param index
     * @param vItemPara
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setItemPara(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.ItemPara vItemPara)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._itemParaList.size()) {
            throw new IndexOutOfBoundsException("setItemPara: Index value '" + index + "' not in range [0.." + (this._itemParaList.size() - 1) + "]");
        }

        this._itemParaList.set(index, vItemPara);
    }

    /**
     * 
     * 
     * @param vItemParaArray
     */
    public void setItemPara(
            final turbomeca.gamme.assembly.services.model.data.ItemPara[] vItemParaArray) {
        //-- copy array
        _itemParaList.clear();

        for (int i = 0; i < vItemParaArray.length; i++) {
                this._itemParaList.add(vItemParaArray[i]);
        }
    }

    /**
     * Sets the value of '_itemParaList' by copying the given
     * Vector. All elements will be checked for type safety.
     * 
     * @param vItemParaList the Vector to copy.
     */
    public void setItemPara(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.ItemPara> vItemParaList) {
        // copy vector
        this._itemParaList.clear();

        this._itemParaList.addAll(vItemParaList);
    }

    /**
     * Sets the value of '_itemParaList' by setting it to the given
     * Vector. No type checking is performed.
     * @deprecated
     * 
     * @param itemParaVector the Vector to set.
     */
    public void setItemParaAsReference(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.ItemPara> itemParaVector) {
        this._itemParaList = itemParaVector;
    }

    /**
     * Sets the value of field 'manual'.
     * 
     * @param manual the value of field 'manual'.
     */
    public void setManual(
            final boolean manual) {
        this._manual = manual;
        this._has_manual = true;
    }

    /**
     * 
     * 
     * @param index
     * @param vPicture
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setPicture(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.Picture vPicture)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._pictureList.size()) {
            throw new IndexOutOfBoundsException("setPicture: Index value '" + index + "' not in range [0.." + (this._pictureList.size() - 1) + "]");
        }

        this._pictureList.set(index, vPicture);
    }

    /**
     * 
     * 
     * @param vPictureArray
     */
    public void setPicture(
            final turbomeca.gamme.assembly.services.model.data.Picture[] vPictureArray) {
        //-- copy array
        _pictureList.clear();

        for (int i = 0; i < vPictureArray.length; i++) {
                this._pictureList.add(vPictureArray[i]);
        }
    }

    /**
     * Sets the value of '_pictureList' by copying the given
     * Vector. All elements will be checked for type safety.
     * 
     * @param vPictureList the Vector to copy.
     */
    public void setPicture(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.Picture> vPictureList) {
        // copy vector
        this._pictureList.clear();

        this._pictureList.addAll(vPictureList);
    }

    /**
     * Sets the value of '_pictureList' by setting it to the given
     * Vector. No type checking is performed.
     * @deprecated
     * 
     * @param pictureVector the Vector to set.
     */
    public void setPictureAsReference(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.Picture> pictureVector) {
        this._pictureList = pictureVector;
    }

    /**
     * 
     * 
     * @param index
     * @param vStringValue
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setStringValue(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.StringValue vStringValue)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._stringValueList.size()) {
            throw new IndexOutOfBoundsException("setStringValue: Index value '" + index + "' not in range [0.." + (this._stringValueList.size() - 1) + "]");
        }

        this._stringValueList.set(index, vStringValue);
    }

    /**
     * 
     * 
     * @param vStringValueArray
     */
    public void setStringValue(
            final turbomeca.gamme.assembly.services.model.data.StringValue[] vStringValueArray) {
        //-- copy array
        _stringValueList.clear();

        for (int i = 0; i < vStringValueArray.length; i++) {
                this._stringValueList.add(vStringValueArray[i]);
        }
    }

    /**
     * Sets the value of '_stringValueList' by copying the given
     * Vector. All elements will be checked for type safety.
     * 
     * @param vStringValueList the Vector to copy.
     */
    public void setStringValue(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.StringValue> vStringValueList) {
        // copy vector
        this._stringValueList.clear();

        this._stringValueList.addAll(vStringValueList);
    }

    /**
     * Sets the value of '_stringValueList' by setting it to the
     * given Vector. No type checking is performed.
     * @deprecated
     * 
     * @param stringValueVector the Vector to set.
     */
    public void setStringValueAsReference(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.StringValue> stringValueVector) {
        this._stringValueList = stringValueVector;
    }

    /**
     * Sets the value of field 'type'.
     * 
     * @param type the value of field 'type'.
     */
    public void setType(
            final turbomeca.gamme.assembly.services.model.data.types.ChoiceType type) {
        this._type = type;
    }

    /**
     * 
     * 
     * @param index
     * @param vVal
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setVal(
            final int index,
            final java.math.BigDecimal vVal)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._valList.size()) {
            throw new IndexOutOfBoundsException("setVal: Index value '" + index + "' not in range [0.." + (this._valList.size() - 1) + "]");
        }

        this._valList.set(index, vVal);
    }

    /**
     * 
     * 
     * @param vValArray
     */
    public void setVal(
            final java.math.BigDecimal[] vValArray) {
        //-- copy array
        _valList.clear();

        for (int i = 0; i < vValArray.length; i++) {
                this._valList.add(vValArray[i]);
        }
    }

    /**
     * Sets the value of '_valList' by copying the given Vector.
     * All elements will be checked for type safety.
     * 
     * @param vValList the Vector to copy.
     */
    public void setVal(
            final java.util.Vector<java.math.BigDecimal> vValList) {
        // copy vector
        this._valList.clear();

        this._valList.addAll(vValList);
    }

    /**
     * Sets the value of '_valList' by setting it to the given
     * Vector. No type checking is performed.
     * @deprecated
     * 
     * @param valVector the Vector to set.
     */
    public void setValAsReference(
            final java.util.Vector<java.math.BigDecimal> valVector) {
        this._valList = valVector;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.InputChoice
     */
    public static turbomeca.gamme.assembly.services.model.data.InputChoice unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.InputChoice) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.InputChoice.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
