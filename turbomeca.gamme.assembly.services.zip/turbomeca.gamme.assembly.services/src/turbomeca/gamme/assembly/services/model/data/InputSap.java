/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class InputSap.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class InputSap implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _id.
     */
    private java.lang.String _id;

    /**
     * Field _ata.
     */
    private java.lang.String _ata;

    /**
     * Field _itemDataType.
     */
    private java.lang.String _itemDataType;

    /**
     * Field _instanceId.
     */
    private int _instanceId;

    /**
     * keeps track of state for field: _instanceId
     */
    private boolean _has_instanceId;

    /**
     * Field _completion.
     */
    private boolean _completion;

    /**
     * keeps track of state for field: _completion
     */
    private boolean _has_completion;


      //----------------/
     //- Constructors -/
    //----------------/

    public InputSap() {
        super();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     */
    public void deleteCompletion(
    ) {
        this._has_completion= false;
    }

    /**
     */
    public void deleteInstanceId(
    ) {
        this._has_instanceId= false;
    }

    /**
     * Returns the value of field 'ata'.
     * 
     * @return the value of field 'Ata'.
     */
    public java.lang.String getAta(
    ) {
        return this._ata;
    }

    /**
     * Returns the value of field 'completion'.
     * 
     * @return the value of field 'Completion'.
     */
    public boolean getCompletion(
    ) {
        return this._completion;
    }

    /**
     * Returns the value of field 'id'.
     * 
     * @return the value of field 'Id'.
     */
    public java.lang.String getId(
    ) {
        return this._id;
    }

    /**
     * Returns the value of field 'instanceId'.
     * 
     * @return the value of field 'InstanceId'.
     */
    public int getInstanceId(
    ) {
        return this._instanceId;
    }

    /**
     * Returns the value of field 'itemDataType'.
     * 
     * @return the value of field 'ItemDataType'.
     */
    public java.lang.String getItemDataType(
    ) {
        return this._itemDataType;
    }

    /**
     * Method hasCompletion.
     * 
     * @return true if at least one Completion has been added
     */
    public boolean hasCompletion(
    ) {
        return this._has_completion;
    }

    /**
     * Method hasInstanceId.
     * 
     * @return true if at least one InstanceId has been added
     */
    public boolean hasInstanceId(
    ) {
        return this._has_instanceId;
    }

    /**
     * Returns the value of field 'completion'.
     * 
     * @return the value of field 'Completion'.
     */
    public boolean isCompletion(
    ) {
        return this._completion;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     * Sets the value of field 'ata'.
     * 
     * @param ata the value of field 'ata'.
     */
    public void setAta(
            final java.lang.String ata) {
        this._ata = ata;
    }

    /**
     * Sets the value of field 'completion'.
     * 
     * @param completion the value of field 'completion'.
     */
    public void setCompletion(
            final boolean completion) {
        this._completion = completion;
        this._has_completion = true;
    }

    /**
     * Sets the value of field 'id'.
     * 
     * @param id the value of field 'id'.
     */
    public void setId(
            final java.lang.String id) {
        this._id = id;
    }

    /**
     * Sets the value of field 'instanceId'.
     * 
     * @param instanceId the value of field 'instanceId'.
     */
    public void setInstanceId(
            final int instanceId) {
        this._instanceId = instanceId;
        this._has_instanceId = true;
    }

    /**
     * Sets the value of field 'itemDataType'.
     * 
     * @param itemDataType the value of field 'itemDataType'.
     */
    public void setItemDataType(
            final java.lang.String itemDataType) {
        this._itemDataType = itemDataType;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.InputSap
     */
    public static turbomeca.gamme.assembly.services.model.data.InputSap unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.InputSap) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.InputSap.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
