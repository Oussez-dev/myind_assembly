/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class ModifiedSubPhase.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class ModifiedSubPhase implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _subPhaseRefList.
     */
    private java.util.Vector<turbomeca.gamme.assembly.services.model.data.SubPhaseRef> _subPhaseRefList;


      //----------------/
     //- Constructors -/
    //----------------/

    public ModifiedSubPhase() {
        super();
        this._subPhaseRefList = new java.util.Vector<turbomeca.gamme.assembly.services.model.data.SubPhaseRef>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vSubPhaseRef
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addSubPhaseRef(
            final turbomeca.gamme.assembly.services.model.data.SubPhaseRef vSubPhaseRef)
    throws java.lang.IndexOutOfBoundsException {
        this._subPhaseRefList.addElement(vSubPhaseRef);
    }

    /**
     * 
     * 
     * @param index
     * @param vSubPhaseRef
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addSubPhaseRef(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.SubPhaseRef vSubPhaseRef)
    throws java.lang.IndexOutOfBoundsException {
        this._subPhaseRefList.add(index, vSubPhaseRef);
    }

    /**
     * Method enumerateSubPhaseRef.
     * 
     * @return an Enumeration over all
     * turbomeca.gamme.assembly.services.model.data.SubPhaseRef
     * elements
     */
    public java.util.Enumeration<? extends turbomeca.gamme.assembly.services.model.data.SubPhaseRef> enumerateSubPhaseRef(
    ) {
        return this._subPhaseRefList.elements();
    }

    /**
     * Method getSubPhaseRef.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * turbomeca.gamme.assembly.services.model.data.SubPhaseRef at
     * the given index
     */
    public turbomeca.gamme.assembly.services.model.data.SubPhaseRef getSubPhaseRef(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._subPhaseRefList.size()) {
            throw new IndexOutOfBoundsException("getSubPhaseRef: Index value '" + index + "' not in range [0.." + (this._subPhaseRefList.size() - 1) + "]");
        }

        return (turbomeca.gamme.assembly.services.model.data.SubPhaseRef) _subPhaseRefList.get(index);
    }

    /**
     * Method getSubPhaseRef.Returns the contents of the collection
     * in an Array.  <p>Note:  Just in case the collection contents
     * are changing in another thread, we pass a 0-length Array of
     * the correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public turbomeca.gamme.assembly.services.model.data.SubPhaseRef[] getSubPhaseRef(
    ) {
        turbomeca.gamme.assembly.services.model.data.SubPhaseRef[] array = new turbomeca.gamme.assembly.services.model.data.SubPhaseRef[0];
        return (turbomeca.gamme.assembly.services.model.data.SubPhaseRef[]) this._subPhaseRefList.toArray(array);
    }

    /**
     * Method getSubPhaseRefAsReference.Returns a reference to
     * '_subPhaseRefList'. No type checking is performed on any
     * modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<turbomeca.gamme.assembly.services.model.data.SubPhaseRef> getSubPhaseRefAsReference(
    ) {
        return this._subPhaseRefList;
    }

    /**
     * Method getSubPhaseRefCount.
     * 
     * @return the size of this collection
     */
    public int getSubPhaseRefCount(
    ) {
        return this._subPhaseRefList.size();
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllSubPhaseRef(
    ) {
        this._subPhaseRefList.clear();
    }

    /**
     * Method removeSubPhaseRef.
     * 
     * @param vSubPhaseRef
     * @return true if the object was removed from the collection.
     */
    public boolean removeSubPhaseRef(
            final turbomeca.gamme.assembly.services.model.data.SubPhaseRef vSubPhaseRef) {
        boolean removed = _subPhaseRefList.remove(vSubPhaseRef);
        return removed;
    }

    /**
     * Method removeSubPhaseRefAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public turbomeca.gamme.assembly.services.model.data.SubPhaseRef removeSubPhaseRefAt(
            final int index) {
        java.lang.Object obj = this._subPhaseRefList.remove(index);
        return (turbomeca.gamme.assembly.services.model.data.SubPhaseRef) obj;
    }

    /**
     * 
     * 
     * @param index
     * @param vSubPhaseRef
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setSubPhaseRef(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.SubPhaseRef vSubPhaseRef)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._subPhaseRefList.size()) {
            throw new IndexOutOfBoundsException("setSubPhaseRef: Index value '" + index + "' not in range [0.." + (this._subPhaseRefList.size() - 1) + "]");
        }

        this._subPhaseRefList.set(index, vSubPhaseRef);
    }

    /**
     * 
     * 
     * @param vSubPhaseRefArray
     */
    public void setSubPhaseRef(
            final turbomeca.gamme.assembly.services.model.data.SubPhaseRef[] vSubPhaseRefArray) {
        //-- copy array
        _subPhaseRefList.clear();

        for (int i = 0; i < vSubPhaseRefArray.length; i++) {
                this._subPhaseRefList.add(vSubPhaseRefArray[i]);
        }
    }

    /**
     * Sets the value of '_subPhaseRefList' by copying the given
     * Vector. All elements will be checked for type safety.
     * 
     * @param vSubPhaseRefList the Vector to copy.
     */
    public void setSubPhaseRef(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.SubPhaseRef> vSubPhaseRefList) {
        // copy vector
        this._subPhaseRefList.clear();

        this._subPhaseRefList.addAll(vSubPhaseRefList);
    }

    /**
     * Sets the value of '_subPhaseRefList' by setting it to the
     * given Vector. No type checking is performed.
     * @deprecated
     * 
     * @param subPhaseRefVector the Vector to set.
     */
    public void setSubPhaseRefAsReference(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.SubPhaseRef> subPhaseRefVector) {
        this._subPhaseRefList = subPhaseRefVector;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.ModifiedSubPhase
     */
    public static turbomeca.gamme.assembly.services.model.data.ModifiedSubPhase unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.ModifiedSubPhase) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.ModifiedSubPhase.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
