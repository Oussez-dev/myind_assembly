/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data.descriptors;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import turbomeca.gamme.assembly.services.model.data.TaskChoiceItem;

/**
 * Class TaskChoiceItemDescriptor.
 * 
 * @version $Revision$ $Date$
 */
public class TaskChoiceItemDescriptor extends org.exolab.castor.xml.util.XMLClassDescriptorImpl {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _elementDefinition.
     */
    private boolean _elementDefinition;

    /**
     * Field _nsPrefix.
     */
    private java.lang.String _nsPrefix;

    /**
     * Field _nsURI.
     */
    private java.lang.String _nsURI;

    /**
     * Field _xmlName.
     */
    private java.lang.String _xmlName;

    /**
     * Field _identity.
     */
    private org.exolab.castor.xml.XMLFieldDescriptor _identity;


      //----------------/
     //- Constructors -/
    //----------------/

    public TaskChoiceItemDescriptor() {
        super();
        _elementDefinition = false;

        //-- set grouping compositor
        setCompositorAsChoice();
        org.exolab.castor.xml.util.XMLFieldDescriptorImpl  desc           = null;
        org.exolab.castor.mapping.FieldHandler             handler        = null;
        org.exolab.castor.xml.FieldValidator               fieldValidator = null;
        //-- initialize attribute descriptors

        //-- initialize element descriptors

        //-- _taskMark
        desc = new org.exolab.castor.xml.util.XMLFieldDescriptorImpl(turbomeca.gamme.assembly.services.model.data.TaskMark.class, "_taskMark", "taskMark", org.exolab.castor.xml.NodeType.Element);
        handler = new org.exolab.castor.xml.XMLFieldHandler() {
            @Override
            public java.lang.Object getValue( java.lang.Object object ) 
                throws IllegalStateException
            {
                TaskChoiceItem target = (TaskChoiceItem) object;
                return target.getTaskMark();
            }
            @Override
            public void setValue( java.lang.Object object, java.lang.Object value) 
                throws IllegalStateException, IllegalArgumentException
            {
                try {
                    TaskChoiceItem target = (TaskChoiceItem) object;
                    target.setTaskMark( (turbomeca.gamme.assembly.services.model.data.TaskMark) value);
                } catch (java.lang.Exception ex) {
                    throw new IllegalStateException(ex.toString());
                }
            }
            @Override
            @SuppressWarnings("unused")
            public java.lang.Object newInstance(java.lang.Object parent) {
                return new turbomeca.gamme.assembly.services.model.data.TaskMark();
            }
        };
        desc.setSchemaType("turbomeca.gamme.assembly.services.model.data.TaskMark");
        desc.setHandler(handler);
        desc.setMultivalued(false);
        addFieldDescriptor(desc);
        addSequenceElement(desc);

        //-- validation code for: _taskMark
        fieldValidator = new org.exolab.castor.xml.FieldValidator();
        { //-- local scope
        }
        desc.setValidator(fieldValidator);
        //-- _taskPara
        desc = new org.exolab.castor.xml.util.XMLFieldDescriptorImpl(turbomeca.gamme.assembly.services.model.data.TaskPara.class, "_taskPara", "taskPara", org.exolab.castor.xml.NodeType.Element);
        handler = new org.exolab.castor.xml.XMLFieldHandler() {
            @Override
            public java.lang.Object getValue( java.lang.Object object ) 
                throws IllegalStateException
            {
                TaskChoiceItem target = (TaskChoiceItem) object;
                return target.getTaskPara();
            }
            @Override
            public void setValue( java.lang.Object object, java.lang.Object value) 
                throws IllegalStateException, IllegalArgumentException
            {
                try {
                    TaskChoiceItem target = (TaskChoiceItem) object;
                    target.setTaskPara( (turbomeca.gamme.assembly.services.model.data.TaskPara) value);
                } catch (java.lang.Exception ex) {
                    throw new IllegalStateException(ex.toString());
                }
            }
            @Override
            @SuppressWarnings("unused")
            public java.lang.Object newInstance(java.lang.Object parent) {
                return new turbomeca.gamme.assembly.services.model.data.TaskPara();
            }
        };
        desc.setSchemaType("turbomeca.gamme.assembly.services.model.data.TaskPara");
        desc.setHandler(handler);
        desc.setMultivalued(false);
        addFieldDescriptor(desc);
        addSequenceElement(desc);

        //-- validation code for: _taskPara
        fieldValidator = new org.exolab.castor.xml.FieldValidator();
        { //-- local scope
        }
        desc.setValidator(fieldValidator);
        //-- _taskAction
        desc = new org.exolab.castor.xml.util.XMLFieldDescriptorImpl(turbomeca.gamme.assembly.services.model.data.TaskAction.class, "_taskAction", "taskAction", org.exolab.castor.xml.NodeType.Element);
        handler = new org.exolab.castor.xml.XMLFieldHandler() {
            @Override
            public java.lang.Object getValue( java.lang.Object object ) 
                throws IllegalStateException
            {
                TaskChoiceItem target = (TaskChoiceItem) object;
                return target.getTaskAction();
            }
            @Override
            public void setValue( java.lang.Object object, java.lang.Object value) 
                throws IllegalStateException, IllegalArgumentException
            {
                try {
                    TaskChoiceItem target = (TaskChoiceItem) object;
                    target.setTaskAction( (turbomeca.gamme.assembly.services.model.data.TaskAction) value);
                } catch (java.lang.Exception ex) {
                    throw new IllegalStateException(ex.toString());
                }
            }
            @Override
            @SuppressWarnings("unused")
            public java.lang.Object newInstance(java.lang.Object parent) {
                return new turbomeca.gamme.assembly.services.model.data.TaskAction();
            }
        };
        desc.setSchemaType("turbomeca.gamme.assembly.services.model.data.TaskAction");
        desc.setHandler(handler);
        desc.setMultivalued(false);
        addFieldDescriptor(desc);
        addSequenceElement(desc);

        //-- validation code for: _taskAction
        fieldValidator = new org.exolab.castor.xml.FieldValidator();
        { //-- local scope
        }
        desc.setValidator(fieldValidator);
        //-- _taskActionMeasure
        desc = new org.exolab.castor.xml.util.XMLFieldDescriptorImpl(turbomeca.gamme.assembly.services.model.data.TaskActionMeasure.class, "_taskActionMeasure", "taskActionMeasure", org.exolab.castor.xml.NodeType.Element);
        handler = new org.exolab.castor.xml.XMLFieldHandler() {
            @Override
            public java.lang.Object getValue( java.lang.Object object ) 
                throws IllegalStateException
            {
                TaskChoiceItem target = (TaskChoiceItem) object;
                return target.getTaskActionMeasure();
            }
            @Override
            public void setValue( java.lang.Object object, java.lang.Object value) 
                throws IllegalStateException, IllegalArgumentException
            {
                try {
                    TaskChoiceItem target = (TaskChoiceItem) object;
                    target.setTaskActionMeasure( (turbomeca.gamme.assembly.services.model.data.TaskActionMeasure) value);
                } catch (java.lang.Exception ex) {
                    throw new IllegalStateException(ex.toString());
                }
            }
            @Override
            @SuppressWarnings("unused")
            public java.lang.Object newInstance(java.lang.Object parent) {
                return new turbomeca.gamme.assembly.services.model.data.TaskActionMeasure();
            }
        };
        desc.setSchemaType("turbomeca.gamme.assembly.services.model.data.TaskActionMeasure");
        desc.setHandler(handler);
        desc.setMultivalued(false);
        addFieldDescriptor(desc);
        addSequenceElement(desc);

        //-- validation code for: _taskActionMeasure
        fieldValidator = new org.exolab.castor.xml.FieldValidator();
        { //-- local scope
        }
        desc.setValidator(fieldValidator);
        //-- _taskActionTable
        desc = new org.exolab.castor.xml.util.XMLFieldDescriptorImpl(turbomeca.gamme.assembly.services.model.data.TaskActionTable.class, "_taskActionTable", "taskActionTable", org.exolab.castor.xml.NodeType.Element);
        handler = new org.exolab.castor.xml.XMLFieldHandler() {
            @Override
            public java.lang.Object getValue( java.lang.Object object ) 
                throws IllegalStateException
            {
                TaskChoiceItem target = (TaskChoiceItem) object;
                return target.getTaskActionTable();
            }
            @Override
            public void setValue( java.lang.Object object, java.lang.Object value) 
                throws IllegalStateException, IllegalArgumentException
            {
                try {
                    TaskChoiceItem target = (TaskChoiceItem) object;
                    target.setTaskActionTable( (turbomeca.gamme.assembly.services.model.data.TaskActionTable) value);
                } catch (java.lang.Exception ex) {
                    throw new IllegalStateException(ex.toString());
                }
            }
            @Override
            @SuppressWarnings("unused")
            public java.lang.Object newInstance(java.lang.Object parent) {
                return new turbomeca.gamme.assembly.services.model.data.TaskActionTable();
            }
        };
        desc.setSchemaType("turbomeca.gamme.assembly.services.model.data.TaskActionTable");
        desc.setHandler(handler);
        desc.setMultivalued(false);
        addFieldDescriptor(desc);
        addSequenceElement(desc);

        //-- validation code for: _taskActionTable
        fieldValidator = new org.exolab.castor.xml.FieldValidator();
        { //-- local scope
        }
        desc.setValidator(fieldValidator);
        //-- _taskPiloting
        desc = new org.exolab.castor.xml.util.XMLFieldDescriptorImpl(turbomeca.gamme.assembly.services.model.data.TaskPiloting.class, "_taskPiloting", "taskPiloting", org.exolab.castor.xml.NodeType.Element);
        handler = new org.exolab.castor.xml.XMLFieldHandler() {
            @Override
            public java.lang.Object getValue( java.lang.Object object ) 
                throws IllegalStateException
            {
                TaskChoiceItem target = (TaskChoiceItem) object;
                return target.getTaskPiloting();
            }
            @Override
            public void setValue( java.lang.Object object, java.lang.Object value) 
                throws IllegalStateException, IllegalArgumentException
            {
                try {
                    TaskChoiceItem target = (TaskChoiceItem) object;
                    target.setTaskPiloting( (turbomeca.gamme.assembly.services.model.data.TaskPiloting) value);
                } catch (java.lang.Exception ex) {
                    throw new IllegalStateException(ex.toString());
                }
            }
            @Override
            @SuppressWarnings("unused")
            public java.lang.Object newInstance(java.lang.Object parent) {
                return new turbomeca.gamme.assembly.services.model.data.TaskPiloting();
            }
        };
        desc.setSchemaType("turbomeca.gamme.assembly.services.model.data.TaskPiloting");
        desc.setHandler(handler);
        desc.setMultivalued(false);
        addFieldDescriptor(desc);
        addSequenceElement(desc);

        //-- validation code for: _taskPiloting
        fieldValidator = new org.exolab.castor.xml.FieldValidator();
        { //-- local scope
        }
        desc.setValidator(fieldValidator);
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method getAccessMode.
     * 
     * @return the access mode specified for this class.
     */
    @Override()
    public org.exolab.castor.mapping.AccessMode getAccessMode(
    ) {
        return null;
    }

    /**
     * Method getIdentity.
     * 
     * @return the identity field, null if this class has no
     * identity.
     */
    @Override()
    public org.exolab.castor.mapping.FieldDescriptor getIdentity(
    ) {
        return _identity;
    }

    /**
     * Method getJavaClass.
     * 
     * @return the Java class represented by this descriptor.
     */
    @Override()
    public java.lang.Class getJavaClass(
    ) {
        return turbomeca.gamme.assembly.services.model.data.TaskChoiceItem.class;
    }

    /**
     * Method getNameSpacePrefix.
     * 
     * @return the namespace prefix to use when marshaling as XML.
     */
    @Override()
    public java.lang.String getNameSpacePrefix(
    ) {
        return _nsPrefix;
    }

    /**
     * Method getNameSpaceURI.
     * 
     * @return the namespace URI used when marshaling and
     * unmarshaling as XML.
     */
    @Override()
    public java.lang.String getNameSpaceURI(
    ) {
        return _nsURI;
    }

    /**
     * Method getValidator.
     * 
     * @return a specific validator for the class described by this
     * ClassDescriptor.
     */
    @Override()
    public org.exolab.castor.xml.TypeValidator getValidator(
    ) {
        return this;
    }

    /**
     * Method getXMLName.
     * 
     * @return the XML Name for the Class being described.
     */
    @Override()
    public java.lang.String getXMLName(
    ) {
        return _xmlName;
    }

    /**
     * Method isElementDefinition.
     * 
     * @return true if XML schema definition of this Class is that
     * of a global
     * element or element with anonymous type definition.
     */
    public boolean isElementDefinition(
    ) {
        return _elementDefinition;
    }

}
