/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class Identification.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class Identification implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _geodeList.
     */
    private java.util.Vector<turbomeca.gamme.assembly.services.model.data.Geode> _geodeList;

    /**
     * Field _designation.
     */
    private turbomeca.gamme.assembly.services.model.data.Designation _designation;

    /**
     * Field _family.
     */
    private java.lang.String _family;

    /**
     * Field _familyDisplay.
     */
    private java.lang.String _familyDisplay;

    /**
     * Field _material.
     */
    private java.lang.String _material;

    /**
     * Field _instances.
     */
    private int _instances = 1;

    /**
     * keeps track of state for field: _instances
     */
    private boolean _has_instances;

    /**
     * Field _specificFlow.
     */
    private java.lang.String _specificFlow;

    /**
     * Field _standardTime.
     */
    private turbomeca.gamme.assembly.services.model.data.StandardTime _standardTime;


      //----------------/
     //- Constructors -/
    //----------------/

    public Identification() {
        super();
        this._geodeList = new java.util.Vector<turbomeca.gamme.assembly.services.model.data.Geode>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vGeode
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addGeode(
            final turbomeca.gamme.assembly.services.model.data.Geode vGeode)
    throws java.lang.IndexOutOfBoundsException {
        this._geodeList.addElement(vGeode);
    }

    /**
     * 
     * 
     * @param index
     * @param vGeode
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addGeode(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.Geode vGeode)
    throws java.lang.IndexOutOfBoundsException {
        this._geodeList.add(index, vGeode);
    }

    /**
     */
    public void deleteInstances(
    ) {
        this._has_instances= false;
    }

    /**
     * Method enumerateGeode.
     * 
     * @return an Enumeration over all
     * turbomeca.gamme.assembly.services.model.data.Geode elements
     */
    public java.util.Enumeration<? extends turbomeca.gamme.assembly.services.model.data.Geode> enumerateGeode(
    ) {
        return this._geodeList.elements();
    }

    /**
     * Returns the value of field 'designation'.
     * 
     * @return the value of field 'Designation'.
     */
    public turbomeca.gamme.assembly.services.model.data.Designation getDesignation(
    ) {
        return this._designation;
    }

    /**
     * Returns the value of field 'family'.
     * 
     * @return the value of field 'Family'.
     */
    public java.lang.String getFamily(
    ) {
        return this._family;
    }

    /**
     * Returns the value of field 'familyDisplay'.
     * 
     * @return the value of field 'FamilyDisplay'.
     */
    public java.lang.String getFamilyDisplay(
    ) {
        return this._familyDisplay;
    }

    /**
     * Method getGeode.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * turbomeca.gamme.assembly.services.model.data.Geode at the
     * given index
     */
    public turbomeca.gamme.assembly.services.model.data.Geode getGeode(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._geodeList.size()) {
            throw new IndexOutOfBoundsException("getGeode: Index value '" + index + "' not in range [0.." + (this._geodeList.size() - 1) + "]");
        }

        return (turbomeca.gamme.assembly.services.model.data.Geode) _geodeList.get(index);
    }

    /**
     * Method getGeode.Returns the contents of the collection in an
     * Array.  <p>Note:  Just in case the collection contents are
     * changing in another thread, we pass a 0-length Array of the
     * correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public turbomeca.gamme.assembly.services.model.data.Geode[] getGeode(
    ) {
        turbomeca.gamme.assembly.services.model.data.Geode[] array = new turbomeca.gamme.assembly.services.model.data.Geode[0];
        return (turbomeca.gamme.assembly.services.model.data.Geode[]) this._geodeList.toArray(array);
    }

    /**
     * Method getGeodeAsReference.Returns a reference to
     * '_geodeList'. No type checking is performed on any
     * modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<turbomeca.gamme.assembly.services.model.data.Geode> getGeodeAsReference(
    ) {
        return this._geodeList;
    }

    /**
     * Method getGeodeCount.
     * 
     * @return the size of this collection
     */
    public int getGeodeCount(
    ) {
        return this._geodeList.size();
    }

    /**
     * Returns the value of field 'instances'.
     * 
     * @return the value of field 'Instances'.
     */
    public int getInstances(
    ) {
        return this._instances;
    }

    /**
     * Returns the value of field 'material'.
     * 
     * @return the value of field 'Material'.
     */
    public java.lang.String getMaterial(
    ) {
        return this._material;
    }

    /**
     * Returns the value of field 'specificFlow'.
     * 
     * @return the value of field 'SpecificFlow'.
     */
    public java.lang.String getSpecificFlow(
    ) {
        return this._specificFlow;
    }

    /**
     * Returns the value of field 'standardTime'.
     * 
     * @return the value of field 'StandardTime'.
     */
    public turbomeca.gamme.assembly.services.model.data.StandardTime getStandardTime(
    ) {
        return this._standardTime;
    }

    /**
     * Method hasInstances.
     * 
     * @return true if at least one Instances has been added
     */
    public boolean hasInstances(
    ) {
        return this._has_instances;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllGeode(
    ) {
        this._geodeList.clear();
    }

    /**
     * Method removeGeode.
     * 
     * @param vGeode
     * @return true if the object was removed from the collection.
     */
    public boolean removeGeode(
            final turbomeca.gamme.assembly.services.model.data.Geode vGeode) {
        boolean removed = _geodeList.remove(vGeode);
        return removed;
    }

    /**
     * Method removeGeodeAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public turbomeca.gamme.assembly.services.model.data.Geode removeGeodeAt(
            final int index) {
        java.lang.Object obj = this._geodeList.remove(index);
        return (turbomeca.gamme.assembly.services.model.data.Geode) obj;
    }

    /**
     * Sets the value of field 'designation'.
     * 
     * @param designation the value of field 'designation'.
     */
    public void setDesignation(
            final turbomeca.gamme.assembly.services.model.data.Designation designation) {
        this._designation = designation;
    }

    /**
     * Sets the value of field 'family'.
     * 
     * @param family the value of field 'family'.
     */
    public void setFamily(
            final java.lang.String family) {
        this._family = family;
    }

    /**
     * Sets the value of field 'familyDisplay'.
     * 
     * @param familyDisplay the value of field 'familyDisplay'.
     */
    public void setFamilyDisplay(
            final java.lang.String familyDisplay) {
        this._familyDisplay = familyDisplay;
    }

    /**
     * 
     * 
     * @param index
     * @param vGeode
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setGeode(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.Geode vGeode)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._geodeList.size()) {
            throw new IndexOutOfBoundsException("setGeode: Index value '" + index + "' not in range [0.." + (this._geodeList.size() - 1) + "]");
        }

        this._geodeList.set(index, vGeode);
    }

    /**
     * 
     * 
     * @param vGeodeArray
     */
    public void setGeode(
            final turbomeca.gamme.assembly.services.model.data.Geode[] vGeodeArray) {
        //-- copy array
        _geodeList.clear();

        for (int i = 0; i < vGeodeArray.length; i++) {
                this._geodeList.add(vGeodeArray[i]);
        }
    }

    /**
     * Sets the value of '_geodeList' by copying the given Vector.
     * All elements will be checked for type safety.
     * 
     * @param vGeodeList the Vector to copy.
     */
    public void setGeode(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.Geode> vGeodeList) {
        // copy vector
        this._geodeList.clear();

        this._geodeList.addAll(vGeodeList);
    }

    /**
     * Sets the value of '_geodeList' by setting it to the given
     * Vector. No type checking is performed.
     * @deprecated
     * 
     * @param geodeVector the Vector to set.
     */
    public void setGeodeAsReference(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.Geode> geodeVector) {
        this._geodeList = geodeVector;
    }

    /**
     * Sets the value of field 'instances'.
     * 
     * @param instances the value of field 'instances'.
     */
    public void setInstances(
            final int instances) {
        this._instances = instances;
        this._has_instances = true;
    }

    /**
     * Sets the value of field 'material'.
     * 
     * @param material the value of field 'material'.
     */
    public void setMaterial(
            final java.lang.String material) {
        this._material = material;
    }

    /**
     * Sets the value of field 'specificFlow'.
     * 
     * @param specificFlow the value of field 'specificFlow'.
     */
    public void setSpecificFlow(
            final java.lang.String specificFlow) {
        this._specificFlow = specificFlow;
    }

    /**
     * Sets the value of field 'standardTime'.
     * 
     * @param standardTime the value of field 'standardTime'.
     */
    public void setStandardTime(
            final turbomeca.gamme.assembly.services.model.data.StandardTime standardTime) {
        this._standardTime = standardTime;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.Identification
     */
    public static turbomeca.gamme.assembly.services.model.data.Identification unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.Identification) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.Identification.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
