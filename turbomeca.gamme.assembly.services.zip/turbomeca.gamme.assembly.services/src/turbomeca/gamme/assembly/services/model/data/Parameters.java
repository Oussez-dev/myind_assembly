/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class Parameters.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class Parameters implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _variants.
     */
    private turbomeca.gamme.assembly.services.model.data.Variants _variants;

    /**
     * Field _interventionTypes.
     */
    private turbomeca.gamme.assembly.services.model.data.InterventionTypes _interventionTypes;

    /**
     * Field _sites.
     */
    private turbomeca.gamme.assembly.services.model.data.Sites _sites;

    /**
     * Field _languages.
     */
    private turbomeca.gamme.assembly.services.model.data.Languages _languages;

    /**
     * Field _effectivities.
     */
    private turbomeca.gamme.assembly.services.model.data.Effectivities _effectivities;

    /**
     * Field _levels.
     */
    private turbomeca.gamme.assembly.services.model.data.Levels _levels;

    /**
     * Field _methods.
     */
    private turbomeca.gamme.assembly.services.model.data.Methods _methods;

    /**
     * Field _isSapSchedule.
     */
    private turbomeca.gamme.assembly.services.model.data.IsSapSchedule _isSapSchedule;


      //----------------/
     //- Constructors -/
    //----------------/

    public Parameters() {
        super();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'effectivities'.
     * 
     * @return the value of field 'Effectivities'.
     */
    public turbomeca.gamme.assembly.services.model.data.Effectivities getEffectivities(
    ) {
        return this._effectivities;
    }

    /**
     * Returns the value of field 'interventionTypes'.
     * 
     * @return the value of field 'InterventionTypes'.
     */
    public turbomeca.gamme.assembly.services.model.data.InterventionTypes getInterventionTypes(
    ) {
        return this._interventionTypes;
    }

    /**
     * Returns the value of field 'isSapSchedule'.
     * 
     * @return the value of field 'IsSapSchedule'.
     */
    public turbomeca.gamme.assembly.services.model.data.IsSapSchedule getIsSapSchedule(
    ) {
        return this._isSapSchedule;
    }

    /**
     * Returns the value of field 'languages'.
     * 
     * @return the value of field 'Languages'.
     */
    public turbomeca.gamme.assembly.services.model.data.Languages getLanguages(
    ) {
        return this._languages;
    }

    /**
     * Returns the value of field 'levels'.
     * 
     * @return the value of field 'Levels'.
     */
    public turbomeca.gamme.assembly.services.model.data.Levels getLevels(
    ) {
        return this._levels;
    }

    /**
     * Returns the value of field 'methods'.
     * 
     * @return the value of field 'Methods'.
     */
    public turbomeca.gamme.assembly.services.model.data.Methods getMethods(
    ) {
        return this._methods;
    }

    /**
     * Returns the value of field 'sites'.
     * 
     * @return the value of field 'Sites'.
     */
    public turbomeca.gamme.assembly.services.model.data.Sites getSites(
    ) {
        return this._sites;
    }

    /**
     * Returns the value of field 'variants'.
     * 
     * @return the value of field 'Variants'.
     */
    public turbomeca.gamme.assembly.services.model.data.Variants getVariants(
    ) {
        return this._variants;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     * Sets the value of field 'effectivities'.
     * 
     * @param effectivities the value of field 'effectivities'.
     */
    public void setEffectivities(
            final turbomeca.gamme.assembly.services.model.data.Effectivities effectivities) {
        this._effectivities = effectivities;
    }

    /**
     * Sets the value of field 'interventionTypes'.
     * 
     * @param interventionTypes the value of field
     * 'interventionTypes'.
     */
    public void setInterventionTypes(
            final turbomeca.gamme.assembly.services.model.data.InterventionTypes interventionTypes) {
        this._interventionTypes = interventionTypes;
    }

    /**
     * Sets the value of field 'isSapSchedule'.
     * 
     * @param isSapSchedule the value of field 'isSapSchedule'.
     */
    public void setIsSapSchedule(
            final turbomeca.gamme.assembly.services.model.data.IsSapSchedule isSapSchedule) {
        this._isSapSchedule = isSapSchedule;
    }

    /**
     * Sets the value of field 'languages'.
     * 
     * @param languages the value of field 'languages'.
     */
    public void setLanguages(
            final turbomeca.gamme.assembly.services.model.data.Languages languages) {
        this._languages = languages;
    }

    /**
     * Sets the value of field 'levels'.
     * 
     * @param levels the value of field 'levels'.
     */
    public void setLevels(
            final turbomeca.gamme.assembly.services.model.data.Levels levels) {
        this._levels = levels;
    }

    /**
     * Sets the value of field 'methods'.
     * 
     * @param methods the value of field 'methods'.
     */
    public void setMethods(
            final turbomeca.gamme.assembly.services.model.data.Methods methods) {
        this._methods = methods;
    }

    /**
     * Sets the value of field 'sites'.
     * 
     * @param sites the value of field 'sites'.
     */
    public void setSites(
            final turbomeca.gamme.assembly.services.model.data.Sites sites) {
        this._sites = sites;
    }

    /**
     * Sets the value of field 'variants'.
     * 
     * @param variants the value of field 'variants'.
     */
    public void setVariants(
            final turbomeca.gamme.assembly.services.model.data.Variants variants) {
        this._variants = variants;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.Parameters
     */
    public static turbomeca.gamme.assembly.services.model.data.Parameters unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.Parameters) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.Parameters.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
