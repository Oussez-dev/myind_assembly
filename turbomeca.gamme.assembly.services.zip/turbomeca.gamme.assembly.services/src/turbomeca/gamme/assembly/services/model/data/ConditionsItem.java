/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class ConditionsItem.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class ConditionsItem implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Internal choice value storage
     */
    private java.lang.Object _choiceValue;

    /**
     * Field _conditionTask.
     */
    private turbomeca.gamme.assembly.services.model.data.ConditionTask _conditionTask;

    /**
     * Field _conditionInput.
     */
    private turbomeca.gamme.assembly.services.model.data.ConditionInput _conditionInput;


      //----------------/
     //- Constructors -/
    //----------------/

    public ConditionsItem() {
        super();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'choiceValue'. The field
     * 'choiceValue' has the following description: Internal choice
     * value storage
     * 
     * @return the value of field 'ChoiceValue'.
     */
    public java.lang.Object getChoiceValue(
    ) {
        return this._choiceValue;
    }

    /**
     * Returns the value of field 'conditionInput'.
     * 
     * @return the value of field 'ConditionInput'.
     */
    public turbomeca.gamme.assembly.services.model.data.ConditionInput getConditionInput(
    ) {
        return this._conditionInput;
    }

    /**
     * Returns the value of field 'conditionTask'.
     * 
     * @return the value of field 'ConditionTask'.
     */
    public turbomeca.gamme.assembly.services.model.data.ConditionTask getConditionTask(
    ) {
        return this._conditionTask;
    }

    /**
     * Sets the value of field 'conditionInput'.
     * 
     * @param conditionInput the value of field 'conditionInput'.
     */
    public void setConditionInput(
            final turbomeca.gamme.assembly.services.model.data.ConditionInput conditionInput) {
        this._conditionInput = conditionInput;
        this._choiceValue = conditionInput;
    }

    /**
     * Sets the value of field 'conditionTask'.
     * 
     * @param conditionTask the value of field 'conditionTask'.
     */
    public void setConditionTask(
            final turbomeca.gamme.assembly.services.model.data.ConditionTask conditionTask) {
        this._conditionTask = conditionTask;
        this._choiceValue = conditionTask;
    }

}
