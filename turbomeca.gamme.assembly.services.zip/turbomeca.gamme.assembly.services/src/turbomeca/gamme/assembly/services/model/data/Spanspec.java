/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class Spanspec.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class Spanspec implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _namest.
     */
    private java.lang.String _namest;

    /**
     * Field _nameend.
     */
    private java.lang.String _nameend;

    /**
     * Field _spanname.
     */
    private java.lang.String _spanname;

    /**
     * Field _colsep.
     */
    private turbomeca.gamme.assembly.services.model.data.types.BooleanType _colsep;

    /**
     * Field _rowsep.
     */
    private turbomeca.gamme.assembly.services.model.data.types.BooleanType _rowsep;

    /**
     * Field _align.
     */
    private turbomeca.gamme.assembly.services.model.data.types.Tbl_align_attribAlignType _align;

    /**
     * Field _char.
     */
    private java.lang.String _char;

    /**
     * Field _charoff.
     */
    private java.lang.String _charoff;


      //----------------/
     //- Constructors -/
    //----------------/

    public Spanspec() {
        super();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'align'.
     * 
     * @return the value of field 'Align'.
     */
    public turbomeca.gamme.assembly.services.model.data.types.Tbl_align_attribAlignType getAlign(
    ) {
        return this._align;
    }

    /**
     * Returns the value of field 'char'.
     * 
     * @return the value of field 'Char'.
     */
    public java.lang.String getChar(
    ) {
        return this._char;
    }

    /**
     * Returns the value of field 'charoff'.
     * 
     * @return the value of field 'Charoff'.
     */
    public java.lang.String getCharoff(
    ) {
        return this._charoff;
    }

    /**
     * Returns the value of field 'colsep'.
     * 
     * @return the value of field 'Colsep'.
     */
    public turbomeca.gamme.assembly.services.model.data.types.BooleanType getColsep(
    ) {
        return this._colsep;
    }

    /**
     * Returns the value of field 'nameend'.
     * 
     * @return the value of field 'Nameend'.
     */
    public java.lang.String getNameend(
    ) {
        return this._nameend;
    }

    /**
     * Returns the value of field 'namest'.
     * 
     * @return the value of field 'Namest'.
     */
    public java.lang.String getNamest(
    ) {
        return this._namest;
    }

    /**
     * Returns the value of field 'rowsep'.
     * 
     * @return the value of field 'Rowsep'.
     */
    public turbomeca.gamme.assembly.services.model.data.types.BooleanType getRowsep(
    ) {
        return this._rowsep;
    }

    /**
     * Returns the value of field 'spanname'.
     * 
     * @return the value of field 'Spanname'.
     */
    public java.lang.String getSpanname(
    ) {
        return this._spanname;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     * Sets the value of field 'align'.
     * 
     * @param align the value of field 'align'.
     */
    public void setAlign(
            final turbomeca.gamme.assembly.services.model.data.types.Tbl_align_attribAlignType align) {
        this._align = align;
    }

    /**
     * Sets the value of field 'char'.
     * 
     * @param _char
     * @param char the value of field 'char'.
     */
    public void setChar(
            final java.lang.String _char) {
        this._char = _char;
    }

    /**
     * Sets the value of field 'charoff'.
     * 
     * @param charoff the value of field 'charoff'.
     */
    public void setCharoff(
            final java.lang.String charoff) {
        this._charoff = charoff;
    }

    /**
     * Sets the value of field 'colsep'.
     * 
     * @param colsep the value of field 'colsep'.
     */
    public void setColsep(
            final turbomeca.gamme.assembly.services.model.data.types.BooleanType colsep) {
        this._colsep = colsep;
    }

    /**
     * Sets the value of field 'nameend'.
     * 
     * @param nameend the value of field 'nameend'.
     */
    public void setNameend(
            final java.lang.String nameend) {
        this._nameend = nameend;
    }

    /**
     * Sets the value of field 'namest'.
     * 
     * @param namest the value of field 'namest'.
     */
    public void setNamest(
            final java.lang.String namest) {
        this._namest = namest;
    }

    /**
     * Sets the value of field 'rowsep'.
     * 
     * @param rowsep the value of field 'rowsep'.
     */
    public void setRowsep(
            final turbomeca.gamme.assembly.services.model.data.types.BooleanType rowsep) {
        this._rowsep = rowsep;
    }

    /**
     * Sets the value of field 'spanname'.
     * 
     * @param spanname the value of field 'spanname'.
     */
    public void setSpanname(
            final java.lang.String spanname) {
        this._spanname = spanname;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.Spanspec
     */
    public static turbomeca.gamme.assembly.services.model.data.Spanspec unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.Spanspec) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.Spanspec.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
