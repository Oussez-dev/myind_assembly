/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class ActionChoice.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class ActionChoice implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _items.
     */
    private java.util.Vector<turbomeca.gamme.assembly.services.model.data.ActionChoiceItem> _items;


      //----------------/
     //- Constructors -/
    //----------------/

    public ActionChoice() {
        super();
        this._items = new java.util.Vector<turbomeca.gamme.assembly.services.model.data.ActionChoiceItem>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vActionChoiceItem
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addActionChoiceItem(
            final turbomeca.gamme.assembly.services.model.data.ActionChoiceItem vActionChoiceItem)
    throws java.lang.IndexOutOfBoundsException {
        this._items.addElement(vActionChoiceItem);
    }

    /**
     * 
     * 
     * @param index
     * @param vActionChoiceItem
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addActionChoiceItem(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.ActionChoiceItem vActionChoiceItem)
    throws java.lang.IndexOutOfBoundsException {
        this._items.add(index, vActionChoiceItem);
    }

    /**
     * Method enumerateActionChoiceItem.
     * 
     * @return an Enumeration over all
     * turbomeca.gamme.assembly.services.model.data.ActionChoiceItem
     * elements
     */
    public java.util.Enumeration<? extends turbomeca.gamme.assembly.services.model.data.ActionChoiceItem> enumerateActionChoiceItem(
    ) {
        return this._items.elements();
    }

    /**
     * Method getActionChoiceItem.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * turbomeca.gamme.assembly.services.model.data.ActionChoiceItem
     * at the given index
     */
    public turbomeca.gamme.assembly.services.model.data.ActionChoiceItem getActionChoiceItem(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._items.size()) {
            throw new IndexOutOfBoundsException("getActionChoiceItem: Index value '" + index + "' not in range [0.." + (this._items.size() - 1) + "]");
        }

        return (turbomeca.gamme.assembly.services.model.data.ActionChoiceItem) _items.get(index);
    }

    /**
     * Method getActionChoiceItem.Returns the contents of the
     * collection in an Array.  <p>Note:  Just in case the
     * collection contents are changing in another thread, we pass
     * a 0-length Array of the correct type into the API call. 
     * This way we <i>know</i> that the Array returned is of
     * exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public turbomeca.gamme.assembly.services.model.data.ActionChoiceItem[] getActionChoiceItem(
    ) {
        turbomeca.gamme.assembly.services.model.data.ActionChoiceItem[] array = new turbomeca.gamme.assembly.services.model.data.ActionChoiceItem[0];
        return (turbomeca.gamme.assembly.services.model.data.ActionChoiceItem[]) this._items.toArray(array);
    }

    /**
     * Method getActionChoiceItemAsReference.Returns a reference to
     * '_items'. No type checking is performed on any modifications
     * to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<turbomeca.gamme.assembly.services.model.data.ActionChoiceItem> getActionChoiceItemAsReference(
    ) {
        return this._items;
    }

    /**
     * Method getActionChoiceItemCount.
     * 
     * @return the size of this collection
     */
    public int getActionChoiceItemCount(
    ) {
        return this._items.size();
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     * Method removeActionChoiceItem.
     * 
     * @param vActionChoiceItem
     * @return true if the object was removed from the collection.
     */
    public boolean removeActionChoiceItem(
            final turbomeca.gamme.assembly.services.model.data.ActionChoiceItem vActionChoiceItem) {
        boolean removed = _items.remove(vActionChoiceItem);
        return removed;
    }

    /**
     * Method removeActionChoiceItemAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public turbomeca.gamme.assembly.services.model.data.ActionChoiceItem removeActionChoiceItemAt(
            final int index) {
        java.lang.Object obj = this._items.remove(index);
        return (turbomeca.gamme.assembly.services.model.data.ActionChoiceItem) obj;
    }

    /**
     */
    public void removeAllActionChoiceItem(
    ) {
        this._items.clear();
    }

    /**
     * 
     * 
     * @param index
     * @param vActionChoiceItem
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setActionChoiceItem(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.ActionChoiceItem vActionChoiceItem)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._items.size()) {
            throw new IndexOutOfBoundsException("setActionChoiceItem: Index value '" + index + "' not in range [0.." + (this._items.size() - 1) + "]");
        }

        this._items.set(index, vActionChoiceItem);
    }

    /**
     * 
     * 
     * @param vActionChoiceItemArray
     */
    public void setActionChoiceItem(
            final turbomeca.gamme.assembly.services.model.data.ActionChoiceItem[] vActionChoiceItemArray) {
        //-- copy array
        _items.clear();

        for (int i = 0; i < vActionChoiceItemArray.length; i++) {
                this._items.add(vActionChoiceItemArray[i]);
        }
    }

    /**
     * Sets the value of '_items' by copying the given Vector. All
     * elements will be checked for type safety.
     * 
     * @param vActionChoiceItemList the Vector to copy.
     */
    public void setActionChoiceItem(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.ActionChoiceItem> vActionChoiceItemList) {
        // copy vector
        this._items.clear();

        this._items.addAll(vActionChoiceItemList);
    }

    /**
     * Sets the value of '_items' by setting it to the given
     * Vector. No type checking is performed.
     * @deprecated
     * 
     * @param actionChoiceItemVector the Vector to set.
     */
    public void setActionChoiceItemAsReference(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.ActionChoiceItem> actionChoiceItemVector) {
        this._items = actionChoiceItemVector;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.ActionChoice
     */
    public static turbomeca.gamme.assembly.services.model.data.ActionChoice unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.ActionChoice) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.ActionChoice.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
