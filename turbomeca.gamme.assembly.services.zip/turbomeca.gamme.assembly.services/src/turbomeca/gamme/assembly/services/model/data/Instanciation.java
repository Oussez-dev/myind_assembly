/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class Instanciation.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class Instanciation implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _state.
     */
    private turbomeca.gamme.assembly.services.model.data.State _state;

    /**
     * Field _passing.
     */
    private int _passing;

    /**
     * keeps track of state for field: _passing
     */
    private boolean _has_passing;

    /**
     * Field _username.
     */
    private java.lang.String _username;

    /**
     * Field _userlogin.
     */
    private java.lang.String _userlogin;

    /**
     * Field _order.
     */
    private java.lang.String _order;

    /**
     * Field _affair.
     */
    private java.lang.String _affair;

    /**
     * Field _pn.
     */
    private java.lang.String _pn;

    /**
     * Field _SNList.
     */
    private java.util.Vector<turbomeca.gamme.assembly.services.model.data.SN> _SNList;

    /**
     * Field _site.
     */
    private java.lang.String _site;

    /**
     * Field _language.
     */
    private java.lang.String _language;

    /**
     * Field _variant.
     */
    private java.lang.String _variant;

    /**
     * Field _effectivity.
     */
    private java.lang.String _effectivity;

    /**
     * Field _modifications.
     */
    private turbomeca.gamme.assembly.services.model.data.Modifications _modifications;

    /**
     * Field _article.
     */
    private java.lang.String _article;

    /**
     * Field _context.
     */
    private java.lang.String _context;

    /**
     * Field _interventionType.
     */
    private java.lang.String _interventionType;

    /**
     * Field _instances.
     */
    private int _instances;

    /**
     * keeps track of state for field: _instances
     */
    private boolean _has_instances;

    /**
     * Field _method.
     */
    private java.lang.String _method;

    /**
     * Field _isolatedModule.
     */
    private boolean _isolatedModule;

    /**
     * keeps track of state for field: _isolatedModule
     */
    private boolean _has_isolatedModule;

    /**
     * Field _fictiveEngine.
     */
    private boolean _fictiveEngine;

    /**
     * keeps track of state for field: _fictiveEngine
     */
    private boolean _has_fictiveEngine;

    /**
     * Field _levelList.
     */
    private java.util.Vector<java.lang.String> _levelList;

    /**
     * Field _levelHistory.
     */
    private turbomeca.gamme.assembly.services.model.data.LevelHistory _levelHistory;

    /**
     * Field _synchronizedWithSap.
     */
    private boolean _synchronizedWithSap = false;

    /**
     * keeps track of state for field: _synchronizedWithSap
     */
    private boolean _has_synchronizedWithSap;


      //----------------/
     //- Constructors -/
    //----------------/

    public Instanciation() {
        super();
        this._SNList = new java.util.Vector<turbomeca.gamme.assembly.services.model.data.SN>();
        this._levelList = new java.util.Vector<java.lang.String>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vLevel
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addLevel(
            final java.lang.String vLevel)
    throws java.lang.IndexOutOfBoundsException {
        this._levelList.addElement(vLevel);
    }

    /**
     * 
     * 
     * @param index
     * @param vLevel
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addLevel(
            final int index,
            final java.lang.String vLevel)
    throws java.lang.IndexOutOfBoundsException {
        this._levelList.add(index, vLevel);
    }

    /**
     * 
     * 
     * @param vSN
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addSN(
            final turbomeca.gamme.assembly.services.model.data.SN vSN)
    throws java.lang.IndexOutOfBoundsException {
        this._SNList.addElement(vSN);
    }

    /**
     * 
     * 
     * @param index
     * @param vSN
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addSN(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.SN vSN)
    throws java.lang.IndexOutOfBoundsException {
        this._SNList.add(index, vSN);
    }

    /**
     */
    public void deleteFictiveEngine(
    ) {
        this._has_fictiveEngine= false;
    }

    /**
     */
    public void deleteInstances(
    ) {
        this._has_instances= false;
    }

    /**
     */
    public void deleteIsolatedModule(
    ) {
        this._has_isolatedModule= false;
    }

    /**
     */
    public void deletePassing(
    ) {
        this._has_passing= false;
    }

    /**
     */
    public void deleteSynchronizedWithSap(
    ) {
        this._has_synchronizedWithSap= false;
    }

    /**
     * Method enumerateLevel.
     * 
     * @return an Enumeration over all java.lang.String elements
     */
    public java.util.Enumeration<? extends java.lang.String> enumerateLevel(
    ) {
        return this._levelList.elements();
    }

    /**
     * Method enumerateSN.
     * 
     * @return an Enumeration over all
     * turbomeca.gamme.assembly.services.model.data.SN elements
     */
    public java.util.Enumeration<? extends turbomeca.gamme.assembly.services.model.data.SN> enumerateSN(
    ) {
        return this._SNList.elements();
    }

    /**
     * Returns the value of field 'affair'.
     * 
     * @return the value of field 'Affair'.
     */
    public java.lang.String getAffair(
    ) {
        return this._affair;
    }

    /**
     * Returns the value of field 'article'.
     * 
     * @return the value of field 'Article'.
     */
    public java.lang.String getArticle(
    ) {
        return this._article;
    }

    /**
     * Returns the value of field 'context'.
     * 
     * @return the value of field 'Context'.
     */
    public java.lang.String getContext(
    ) {
        return this._context;
    }

    /**
     * Returns the value of field 'effectivity'.
     * 
     * @return the value of field 'Effectivity'.
     */
    public java.lang.String getEffectivity(
    ) {
        return this._effectivity;
    }

    /**
     * Returns the value of field 'fictiveEngine'.
     * 
     * @return the value of field 'FictiveEngine'.
     */
    public boolean getFictiveEngine(
    ) {
        return this._fictiveEngine;
    }

    /**
     * Returns the value of field 'instances'.
     * 
     * @return the value of field 'Instances'.
     */
    public int getInstances(
    ) {
        return this._instances;
    }

    /**
     * Returns the value of field 'interventionType'.
     * 
     * @return the value of field 'InterventionType'.
     */
    public java.lang.String getInterventionType(
    ) {
        return this._interventionType;
    }

    /**
     * Returns the value of field 'isolatedModule'.
     * 
     * @return the value of field 'IsolatedModule'.
     */
    public boolean getIsolatedModule(
    ) {
        return this._isolatedModule;
    }

    /**
     * Returns the value of field 'language'.
     * 
     * @return the value of field 'Language'.
     */
    public java.lang.String getLanguage(
    ) {
        return this._language;
    }

    /**
     * Method getLevel.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the java.lang.String at the given index
     */
    public java.lang.String getLevel(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._levelList.size()) {
            throw new IndexOutOfBoundsException("getLevel: Index value '" + index + "' not in range [0.." + (this._levelList.size() - 1) + "]");
        }

        return (java.lang.String) _levelList.get(index);
    }

    /**
     * Method getLevel.Returns the contents of the collection in an
     * Array.  <p>Note:  Just in case the collection contents are
     * changing in another thread, we pass a 0-length Array of the
     * correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public java.lang.String[] getLevel(
    ) {
        java.lang.String[] array = new java.lang.String[0];
        return (java.lang.String[]) this._levelList.toArray(array);
    }

    /**
     * Method getLevelAsReference.Returns a reference to
     * '_levelList'. No type checking is performed on any
     * modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<java.lang.String> getLevelAsReference(
    ) {
        return this._levelList;
    }

    /**
     * Method getLevelCount.
     * 
     * @return the size of this collection
     */
    public int getLevelCount(
    ) {
        return this._levelList.size();
    }

    /**
     * Returns the value of field 'levelHistory'.
     * 
     * @return the value of field 'LevelHistory'.
     */
    public turbomeca.gamme.assembly.services.model.data.LevelHistory getLevelHistory(
    ) {
        return this._levelHistory;
    }

    /**
     * Returns the value of field 'method'.
     * 
     * @return the value of field 'Method'.
     */
    public java.lang.String getMethod(
    ) {
        return this._method;
    }

    /**
     * Returns the value of field 'modifications'.
     * 
     * @return the value of field 'Modifications'.
     */
    public turbomeca.gamme.assembly.services.model.data.Modifications getModifications(
    ) {
        return this._modifications;
    }

    /**
     * Returns the value of field 'order'.
     * 
     * @return the value of field 'Order'.
     */
    public java.lang.String getOrder(
    ) {
        return this._order;
    }

    /**
     * Returns the value of field 'passing'.
     * 
     * @return the value of field 'Passing'.
     */
    public int getPassing(
    ) {
        return this._passing;
    }

    /**
     * Returns the value of field 'pn'.
     * 
     * @return the value of field 'Pn'.
     */
    public java.lang.String getPn(
    ) {
        return this._pn;
    }

    /**
     * Method getSN.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * turbomeca.gamme.assembly.services.model.data.SN at the given
     * index
     */
    public turbomeca.gamme.assembly.services.model.data.SN getSN(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._SNList.size()) {
            throw new IndexOutOfBoundsException("getSN: Index value '" + index + "' not in range [0.." + (this._SNList.size() - 1) + "]");
        }

        return (turbomeca.gamme.assembly.services.model.data.SN) _SNList.get(index);
    }

    /**
     * Method getSN.Returns the contents of the collection in an
     * Array.  <p>Note:  Just in case the collection contents are
     * changing in another thread, we pass a 0-length Array of the
     * correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public turbomeca.gamme.assembly.services.model.data.SN[] getSN(
    ) {
        turbomeca.gamme.assembly.services.model.data.SN[] array = new turbomeca.gamme.assembly.services.model.data.SN[0];
        return (turbomeca.gamme.assembly.services.model.data.SN[]) this._SNList.toArray(array);
    }

    /**
     * Method getSNAsReference.Returns a reference to '_SNList'. No
     * type checking is performed on any modifications to the
     * Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<turbomeca.gamme.assembly.services.model.data.SN> getSNAsReference(
    ) {
        return this._SNList;
    }

    /**
     * Method getSNCount.
     * 
     * @return the size of this collection
     */
    public int getSNCount(
    ) {
        return this._SNList.size();
    }

    /**
     * Returns the value of field 'site'.
     * 
     * @return the value of field 'Site'.
     */
    public java.lang.String getSite(
    ) {
        return this._site;
    }

    /**
     * Returns the value of field 'state'.
     * 
     * @return the value of field 'State'.
     */
    public turbomeca.gamme.assembly.services.model.data.State getState(
    ) {
        return this._state;
    }

    /**
     * Returns the value of field 'synchronizedWithSap'.
     * 
     * @return the value of field 'SynchronizedWithSap'.
     */
    public boolean getSynchronizedWithSap(
    ) {
        return this._synchronizedWithSap;
    }

    /**
     * Returns the value of field 'userlogin'.
     * 
     * @return the value of field 'Userlogin'.
     */
    public java.lang.String getUserlogin(
    ) {
        return this._userlogin;
    }

    /**
     * Returns the value of field 'username'.
     * 
     * @return the value of field 'Username'.
     */
    public java.lang.String getUsername(
    ) {
        return this._username;
    }

    /**
     * Returns the value of field 'variant'.
     * 
     * @return the value of field 'Variant'.
     */
    public java.lang.String getVariant(
    ) {
        return this._variant;
    }

    /**
     * Method hasFictiveEngine.
     * 
     * @return true if at least one FictiveEngine has been added
     */
    public boolean hasFictiveEngine(
    ) {
        return this._has_fictiveEngine;
    }

    /**
     * Method hasInstances.
     * 
     * @return true if at least one Instances has been added
     */
    public boolean hasInstances(
    ) {
        return this._has_instances;
    }

    /**
     * Method hasIsolatedModule.
     * 
     * @return true if at least one IsolatedModule has been added
     */
    public boolean hasIsolatedModule(
    ) {
        return this._has_isolatedModule;
    }

    /**
     * Method hasPassing.
     * 
     * @return true if at least one Passing has been added
     */
    public boolean hasPassing(
    ) {
        return this._has_passing;
    }

    /**
     * Method hasSynchronizedWithSap.
     * 
     * @return true if at least one SynchronizedWithSap has been
     * added
     */
    public boolean hasSynchronizedWithSap(
    ) {
        return this._has_synchronizedWithSap;
    }

    /**
     * Returns the value of field 'fictiveEngine'.
     * 
     * @return the value of field 'FictiveEngine'.
     */
    public boolean isFictiveEngine(
    ) {
        return this._fictiveEngine;
    }

    /**
     * Returns the value of field 'isolatedModule'.
     * 
     * @return the value of field 'IsolatedModule'.
     */
    public boolean isIsolatedModule(
    ) {
        return this._isolatedModule;
    }

    /**
     * Returns the value of field 'synchronizedWithSap'.
     * 
     * @return the value of field 'SynchronizedWithSap'.
     */
    public boolean isSynchronizedWithSap(
    ) {
        return this._synchronizedWithSap;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllLevel(
    ) {
        this._levelList.clear();
    }

    /**
     */
    public void removeAllSN(
    ) {
        this._SNList.clear();
    }

    /**
     * Method removeLevel.
     * 
     * @param vLevel
     * @return true if the object was removed from the collection.
     */
    public boolean removeLevel(
            final java.lang.String vLevel) {
        boolean removed = _levelList.remove(vLevel);
        return removed;
    }

    /**
     * Method removeLevelAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public java.lang.String removeLevelAt(
            final int index) {
        java.lang.Object obj = this._levelList.remove(index);
        return (java.lang.String) obj;
    }

    /**
     * Method removeSN.
     * 
     * @param vSN
     * @return true if the object was removed from the collection.
     */
    public boolean removeSN(
            final turbomeca.gamme.assembly.services.model.data.SN vSN) {
        boolean removed = _SNList.remove(vSN);
        return removed;
    }

    /**
     * Method removeSNAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public turbomeca.gamme.assembly.services.model.data.SN removeSNAt(
            final int index) {
        java.lang.Object obj = this._SNList.remove(index);
        return (turbomeca.gamme.assembly.services.model.data.SN) obj;
    }

    /**
     * Sets the value of field 'affair'.
     * 
     * @param affair the value of field 'affair'.
     */
    public void setAffair(
            final java.lang.String affair) {
        this._affair = affair;
    }

    /**
     * Sets the value of field 'article'.
     * 
     * @param article the value of field 'article'.
     */
    public void setArticle(
            final java.lang.String article) {
        this._article = article;
    }

    /**
     * Sets the value of field 'context'.
     * 
     * @param context the value of field 'context'.
     */
    public void setContext(
            final java.lang.String context) {
        this._context = context;
    }

    /**
     * Sets the value of field 'effectivity'.
     * 
     * @param effectivity the value of field 'effectivity'.
     */
    public void setEffectivity(
            final java.lang.String effectivity) {
        this._effectivity = effectivity;
    }

    /**
     * Sets the value of field 'fictiveEngine'.
     * 
     * @param fictiveEngine the value of field 'fictiveEngine'.
     */
    public void setFictiveEngine(
            final boolean fictiveEngine) {
        this._fictiveEngine = fictiveEngine;
        this._has_fictiveEngine = true;
    }

    /**
     * Sets the value of field 'instances'.
     * 
     * @param instances the value of field 'instances'.
     */
    public void setInstances(
            final int instances) {
        this._instances = instances;
        this._has_instances = true;
    }

    /**
     * Sets the value of field 'interventionType'.
     * 
     * @param interventionType the value of field 'interventionType'
     */
    public void setInterventionType(
            final java.lang.String interventionType) {
        this._interventionType = interventionType;
    }

    /**
     * Sets the value of field 'isolatedModule'.
     * 
     * @param isolatedModule the value of field 'isolatedModule'.
     */
    public void setIsolatedModule(
            final boolean isolatedModule) {
        this._isolatedModule = isolatedModule;
        this._has_isolatedModule = true;
    }

    /**
     * Sets the value of field 'language'.
     * 
     * @param language the value of field 'language'.
     */
    public void setLanguage(
            final java.lang.String language) {
        this._language = language;
    }

    /**
     * 
     * 
     * @param index
     * @param vLevel
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setLevel(
            final int index,
            final java.lang.String vLevel)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._levelList.size()) {
            throw new IndexOutOfBoundsException("setLevel: Index value '" + index + "' not in range [0.." + (this._levelList.size() - 1) + "]");
        }

        this._levelList.set(index, vLevel);
    }

    /**
     * 
     * 
     * @param vLevelArray
     */
    public void setLevel(
            final java.lang.String[] vLevelArray) {
        //-- copy array
        _levelList.clear();

        for (int i = 0; i < vLevelArray.length; i++) {
                this._levelList.add(vLevelArray[i]);
        }
    }

    /**
     * Sets the value of '_levelList' by copying the given Vector.
     * All elements will be checked for type safety.
     * 
     * @param vLevelList the Vector to copy.
     */
    public void setLevel(
            final java.util.Vector<java.lang.String> vLevelList) {
        // copy vector
        this._levelList.clear();

        this._levelList.addAll(vLevelList);
    }

    /**
     * Sets the value of '_levelList' by setting it to the given
     * Vector. No type checking is performed.
     * @deprecated
     * 
     * @param levelVector the Vector to set.
     */
    public void setLevelAsReference(
            final java.util.Vector<java.lang.String> levelVector) {
        this._levelList = levelVector;
    }

    /**
     * Sets the value of field 'levelHistory'.
     * 
     * @param levelHistory the value of field 'levelHistory'.
     */
    public void setLevelHistory(
            final turbomeca.gamme.assembly.services.model.data.LevelHistory levelHistory) {
        this._levelHistory = levelHistory;
    }

    /**
     * Sets the value of field 'method'.
     * 
     * @param method the value of field 'method'.
     */
    public void setMethod(
            final java.lang.String method) {
        this._method = method;
    }

    /**
     * Sets the value of field 'modifications'.
     * 
     * @param modifications the value of field 'modifications'.
     */
    public void setModifications(
            final turbomeca.gamme.assembly.services.model.data.Modifications modifications) {
        this._modifications = modifications;
    }

    /**
     * Sets the value of field 'order'.
     * 
     * @param order the value of field 'order'.
     */
    public void setOrder(
            final java.lang.String order) {
        this._order = order;
    }

    /**
     * Sets the value of field 'passing'.
     * 
     * @param passing the value of field 'passing'.
     */
    public void setPassing(
            final int passing) {
        this._passing = passing;
        this._has_passing = true;
    }

    /**
     * Sets the value of field 'pn'.
     * 
     * @param pn the value of field 'pn'.
     */
    public void setPn(
            final java.lang.String pn) {
        this._pn = pn;
    }

    /**
     * 
     * 
     * @param index
     * @param vSN
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setSN(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.SN vSN)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._SNList.size()) {
            throw new IndexOutOfBoundsException("setSN: Index value '" + index + "' not in range [0.." + (this._SNList.size() - 1) + "]");
        }

        this._SNList.set(index, vSN);
    }

    /**
     * 
     * 
     * @param vSNArray
     */
    public void setSN(
            final turbomeca.gamme.assembly.services.model.data.SN[] vSNArray) {
        //-- copy array
        _SNList.clear();

        for (int i = 0; i < vSNArray.length; i++) {
                this._SNList.add(vSNArray[i]);
        }
    }

    /**
     * Sets the value of '_SNList' by copying the given Vector. All
     * elements will be checked for type safety.
     * 
     * @param vSNList the Vector to copy.
     */
    public void setSN(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.SN> vSNList) {
        // copy vector
        this._SNList.clear();

        this._SNList.addAll(vSNList);
    }

    /**
     * Sets the value of '_SNList' by setting it to the given
     * Vector. No type checking is performed.
     * @deprecated
     * 
     * @param SNVector the Vector to set.
     */
    public void setSNAsReference(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.SN> SNVector) {
        this._SNList = SNVector;
    }

    /**
     * Sets the value of field 'site'.
     * 
     * @param site the value of field 'site'.
     */
    public void setSite(
            final java.lang.String site) {
        this._site = site;
    }

    /**
     * Sets the value of field 'state'.
     * 
     * @param state the value of field 'state'.
     */
    public void setState(
            final turbomeca.gamme.assembly.services.model.data.State state) {
        this._state = state;
    }

    /**
     * Sets the value of field 'synchronizedWithSap'.
     * 
     * @param synchronizedWithSap the value of field
     * 'synchronizedWithSap'.
     */
    public void setSynchronizedWithSap(
            final boolean synchronizedWithSap) {
        this._synchronizedWithSap = synchronizedWithSap;
        this._has_synchronizedWithSap = true;
    }

    /**
     * Sets the value of field 'userlogin'.
     * 
     * @param userlogin the value of field 'userlogin'.
     */
    public void setUserlogin(
            final java.lang.String userlogin) {
        this._userlogin = userlogin;
    }

    /**
     * Sets the value of field 'username'.
     * 
     * @param username the value of field 'username'.
     */
    public void setUsername(
            final java.lang.String username) {
        this._username = username;
    }

    /**
     * Sets the value of field 'variant'.
     * 
     * @param variant the value of field 'variant'.
     */
    public void setVariant(
            final java.lang.String variant) {
        this._variant = variant;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.Instanciation
     */
    public static turbomeca.gamme.assembly.services.model.data.Instanciation unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.Instanciation) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.Instanciation.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
