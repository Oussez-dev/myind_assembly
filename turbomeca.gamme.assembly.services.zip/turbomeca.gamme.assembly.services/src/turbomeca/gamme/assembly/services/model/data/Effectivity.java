/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class Effectivity.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class Effectivity implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _effectivity.
     */
    private java.lang.String _effectivity;

    /**
     * Field _geodeImportFile.
     */
    private java.lang.String _geodeImportFile;

    /**
     * Field _effectivityVariantList.
     */
    private java.util.Vector<turbomeca.gamme.assembly.services.model.data.EffectivityVariant> _effectivityVariantList;


      //----------------/
     //- Constructors -/
    //----------------/

    public Effectivity() {
        super();
        this._effectivityVariantList = new java.util.Vector<turbomeca.gamme.assembly.services.model.data.EffectivityVariant>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vEffectivityVariant
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addEffectivityVariant(
            final turbomeca.gamme.assembly.services.model.data.EffectivityVariant vEffectivityVariant)
    throws java.lang.IndexOutOfBoundsException {
        this._effectivityVariantList.addElement(vEffectivityVariant);
    }

    /**
     * 
     * 
     * @param index
     * @param vEffectivityVariant
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addEffectivityVariant(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.EffectivityVariant vEffectivityVariant)
    throws java.lang.IndexOutOfBoundsException {
        this._effectivityVariantList.add(index, vEffectivityVariant);
    }

    /**
     * Method enumerateEffectivityVariant.
     * 
     * @return an Enumeration over all
     * turbomeca.gamme.assembly.services.model.data.EffectivityVariant
     * elements
     */
    public java.util.Enumeration<? extends turbomeca.gamme.assembly.services.model.data.EffectivityVariant> enumerateEffectivityVariant(
    ) {
        return this._effectivityVariantList.elements();
    }

    /**
     * Returns the value of field 'effectivity'.
     * 
     * @return the value of field 'Effectivity'.
     */
    public java.lang.String getEffectivity(
    ) {
        return this._effectivity;
    }

    /**
     * Method getEffectivityVariant.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * turbomeca.gamme.assembly.services.model.data.EffectivityVariant
     * at the given index
     */
    public turbomeca.gamme.assembly.services.model.data.EffectivityVariant getEffectivityVariant(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._effectivityVariantList.size()) {
            throw new IndexOutOfBoundsException("getEffectivityVariant: Index value '" + index + "' not in range [0.." + (this._effectivityVariantList.size() - 1) + "]");
        }

        return (turbomeca.gamme.assembly.services.model.data.EffectivityVariant) _effectivityVariantList.get(index);
    }

    /**
     * Method getEffectivityVariant.Returns the contents of the
     * collection in an Array.  <p>Note:  Just in case the
     * collection contents are changing in another thread, we pass
     * a 0-length Array of the correct type into the API call. 
     * This way we <i>know</i> that the Array returned is of
     * exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public turbomeca.gamme.assembly.services.model.data.EffectivityVariant[] getEffectivityVariant(
    ) {
        turbomeca.gamme.assembly.services.model.data.EffectivityVariant[] array = new turbomeca.gamme.assembly.services.model.data.EffectivityVariant[0];
        return (turbomeca.gamme.assembly.services.model.data.EffectivityVariant[]) this._effectivityVariantList.toArray(array);
    }

    /**
     * Method getEffectivityVariantAsReference.Returns a reference
     * to '_effectivityVariantList'. No type checking is performed
     * on any modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<turbomeca.gamme.assembly.services.model.data.EffectivityVariant> getEffectivityVariantAsReference(
    ) {
        return this._effectivityVariantList;
    }

    /**
     * Method getEffectivityVariantCount.
     * 
     * @return the size of this collection
     */
    public int getEffectivityVariantCount(
    ) {
        return this._effectivityVariantList.size();
    }

    /**
     * Returns the value of field 'geodeImportFile'.
     * 
     * @return the value of field 'GeodeImportFile'.
     */
    public java.lang.String getGeodeImportFile(
    ) {
        return this._geodeImportFile;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllEffectivityVariant(
    ) {
        this._effectivityVariantList.clear();
    }

    /**
     * Method removeEffectivityVariant.
     * 
     * @param vEffectivityVariant
     * @return true if the object was removed from the collection.
     */
    public boolean removeEffectivityVariant(
            final turbomeca.gamme.assembly.services.model.data.EffectivityVariant vEffectivityVariant) {
        boolean removed = _effectivityVariantList.remove(vEffectivityVariant);
        return removed;
    }

    /**
     * Method removeEffectivityVariantAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public turbomeca.gamme.assembly.services.model.data.EffectivityVariant removeEffectivityVariantAt(
            final int index) {
        java.lang.Object obj = this._effectivityVariantList.remove(index);
        return (turbomeca.gamme.assembly.services.model.data.EffectivityVariant) obj;
    }

    /**
     * Sets the value of field 'effectivity'.
     * 
     * @param effectivity the value of field 'effectivity'.
     */
    public void setEffectivity(
            final java.lang.String effectivity) {
        this._effectivity = effectivity;
    }

    /**
     * 
     * 
     * @param index
     * @param vEffectivityVariant
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setEffectivityVariant(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.EffectivityVariant vEffectivityVariant)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._effectivityVariantList.size()) {
            throw new IndexOutOfBoundsException("setEffectivityVariant: Index value '" + index + "' not in range [0.." + (this._effectivityVariantList.size() - 1) + "]");
        }

        this._effectivityVariantList.set(index, vEffectivityVariant);
    }

    /**
     * 
     * 
     * @param vEffectivityVariantArray
     */
    public void setEffectivityVariant(
            final turbomeca.gamme.assembly.services.model.data.EffectivityVariant[] vEffectivityVariantArray) {
        //-- copy array
        _effectivityVariantList.clear();

        for (int i = 0; i < vEffectivityVariantArray.length; i++) {
                this._effectivityVariantList.add(vEffectivityVariantArray[i]);
        }
    }

    /**
     * Sets the value of '_effectivityVariantList' by copying the
     * given Vector. All elements will be checked for type safety.
     * 
     * @param vEffectivityVariantList the Vector to copy.
     */
    public void setEffectivityVariant(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.EffectivityVariant> vEffectivityVariantList) {
        // copy vector
        this._effectivityVariantList.clear();

        this._effectivityVariantList.addAll(vEffectivityVariantList);
    }

    /**
     * Sets the value of '_effectivityVariantList' by setting it to
     * the given Vector. No type checking is performed.
     * @deprecated
     * 
     * @param effectivityVariantVector the Vector to set.
     */
    public void setEffectivityVariantAsReference(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.EffectivityVariant> effectivityVariantVector) {
        this._effectivityVariantList = effectivityVariantVector;
    }

    /**
     * Sets the value of field 'geodeImportFile'.
     * 
     * @param geodeImportFile the value of field 'geodeImportFile'.
     */
    public void setGeodeImportFile(
            final java.lang.String geodeImportFile) {
        this._geodeImportFile = geodeImportFile;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.Effectivity
     */
    public static turbomeca.gamme.assembly.services.model.data.Effectivity unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.Effectivity) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.Effectivity.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
