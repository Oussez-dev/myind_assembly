/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class EffectivityVariant.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class EffectivityVariant implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _variant.
     */
    private java.lang.String _variant;

    /**
     * Field _geodeImportFile.
     */
    private java.lang.String _geodeImportFile;

    /**
     * Field _modifications.
     */
    private turbomeca.gamme.assembly.services.model.data.Modifications _modifications;

    /**
     * Field _pns.
     */
    private turbomeca.gamme.assembly.services.model.data.Pns _pns;

    /**
     * Field _articles.
     */
    private turbomeca.gamme.assembly.services.model.data.Articles _articles;


      //----------------/
     //- Constructors -/
    //----------------/

    public EffectivityVariant() {
        super();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'articles'.
     * 
     * @return the value of field 'Articles'.
     */
    public turbomeca.gamme.assembly.services.model.data.Articles getArticles(
    ) {
        return this._articles;
    }

    /**
     * Returns the value of field 'geodeImportFile'.
     * 
     * @return the value of field 'GeodeImportFile'.
     */
    public java.lang.String getGeodeImportFile(
    ) {
        return this._geodeImportFile;
    }

    /**
     * Returns the value of field 'modifications'.
     * 
     * @return the value of field 'Modifications'.
     */
    public turbomeca.gamme.assembly.services.model.data.Modifications getModifications(
    ) {
        return this._modifications;
    }

    /**
     * Returns the value of field 'pns'.
     * 
     * @return the value of field 'Pns'.
     */
    public turbomeca.gamme.assembly.services.model.data.Pns getPns(
    ) {
        return this._pns;
    }

    /**
     * Returns the value of field 'variant'.
     * 
     * @return the value of field 'Variant'.
     */
    public java.lang.String getVariant(
    ) {
        return this._variant;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     * Sets the value of field 'articles'.
     * 
     * @param articles the value of field 'articles'.
     */
    public void setArticles(
            final turbomeca.gamme.assembly.services.model.data.Articles articles) {
        this._articles = articles;
    }

    /**
     * Sets the value of field 'geodeImportFile'.
     * 
     * @param geodeImportFile the value of field 'geodeImportFile'.
     */
    public void setGeodeImportFile(
            final java.lang.String geodeImportFile) {
        this._geodeImportFile = geodeImportFile;
    }

    /**
     * Sets the value of field 'modifications'.
     * 
     * @param modifications the value of field 'modifications'.
     */
    public void setModifications(
            final turbomeca.gamme.assembly.services.model.data.Modifications modifications) {
        this._modifications = modifications;
    }

    /**
     * Sets the value of field 'pns'.
     * 
     * @param pns the value of field 'pns'.
     */
    public void setPns(
            final turbomeca.gamme.assembly.services.model.data.Pns pns) {
        this._pns = pns;
    }

    /**
     * Sets the value of field 'variant'.
     * 
     * @param variant the value of field 'variant'.
     */
    public void setVariant(
            final java.lang.String variant) {
        this._variant = variant;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.EffectivityVariant
     */
    public static turbomeca.gamme.assembly.services.model.data.EffectivityVariant unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.EffectivityVariant) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.EffectivityVariant.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
