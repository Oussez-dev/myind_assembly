/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class Articles.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class Articles implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _category.
     */
    private java.lang.String _category;

    /**
     * Field _group.
     */
    private java.lang.String _group;

    /**
     * Field _vaList.
     */
    private java.util.Vector<java.lang.String> _vaList;


      //----------------/
     //- Constructors -/
    //----------------/

    public Articles() {
        super();
        this._vaList = new java.util.Vector<java.lang.String>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vVa
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addVa(
            final java.lang.String vVa)
    throws java.lang.IndexOutOfBoundsException {
        this._vaList.addElement(vVa);
    }

    /**
     * 
     * 
     * @param index
     * @param vVa
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addVa(
            final int index,
            final java.lang.String vVa)
    throws java.lang.IndexOutOfBoundsException {
        this._vaList.add(index, vVa);
    }

    /**
     * Method enumerateVa.
     * 
     * @return an Enumeration over all java.lang.String elements
     */
    public java.util.Enumeration<? extends java.lang.String> enumerateVa(
    ) {
        return this._vaList.elements();
    }

    /**
     * Returns the value of field 'category'.
     * 
     * @return the value of field 'Category'.
     */
    public java.lang.String getCategory(
    ) {
        return this._category;
    }

    /**
     * Returns the value of field 'group'.
     * 
     * @return the value of field 'Group'.
     */
    public java.lang.String getGroup(
    ) {
        return this._group;
    }

    /**
     * Method getVa.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the java.lang.String at the given index
     */
    public java.lang.String getVa(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._vaList.size()) {
            throw new IndexOutOfBoundsException("getVa: Index value '" + index + "' not in range [0.." + (this._vaList.size() - 1) + "]");
        }

        return (java.lang.String) _vaList.get(index);
    }

    /**
     * Method getVa.Returns the contents of the collection in an
     * Array.  <p>Note:  Just in case the collection contents are
     * changing in another thread, we pass a 0-length Array of the
     * correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public java.lang.String[] getVa(
    ) {
        java.lang.String[] array = new java.lang.String[0];
        return (java.lang.String[]) this._vaList.toArray(array);
    }

    /**
     * Method getVaAsReference.Returns a reference to '_vaList'. No
     * type checking is performed on any modifications to the
     * Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<java.lang.String> getVaAsReference(
    ) {
        return this._vaList;
    }

    /**
     * Method getVaCount.
     * 
     * @return the size of this collection
     */
    public int getVaCount(
    ) {
        return this._vaList.size();
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllVa(
    ) {
        this._vaList.clear();
    }

    /**
     * Method removeVa.
     * 
     * @param vVa
     * @return true if the object was removed from the collection.
     */
    public boolean removeVa(
            final java.lang.String vVa) {
        boolean removed = _vaList.remove(vVa);
        return removed;
    }

    /**
     * Method removeVaAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public java.lang.String removeVaAt(
            final int index) {
        java.lang.Object obj = this._vaList.remove(index);
        return (java.lang.String) obj;
    }

    /**
     * Sets the value of field 'category'.
     * 
     * @param category the value of field 'category'.
     */
    public void setCategory(
            final java.lang.String category) {
        this._category = category;
    }

    /**
     * Sets the value of field 'group'.
     * 
     * @param group the value of field 'group'.
     */
    public void setGroup(
            final java.lang.String group) {
        this._group = group;
    }

    /**
     * 
     * 
     * @param index
     * @param vVa
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setVa(
            final int index,
            final java.lang.String vVa)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._vaList.size()) {
            throw new IndexOutOfBoundsException("setVa: Index value '" + index + "' not in range [0.." + (this._vaList.size() - 1) + "]");
        }

        this._vaList.set(index, vVa);
    }

    /**
     * 
     * 
     * @param vVaArray
     */
    public void setVa(
            final java.lang.String[] vVaArray) {
        //-- copy array
        _vaList.clear();

        for (int i = 0; i < vVaArray.length; i++) {
                this._vaList.add(vVaArray[i]);
        }
    }

    /**
     * Sets the value of '_vaList' by copying the given Vector. All
     * elements will be checked for type safety.
     * 
     * @param vVaList the Vector to copy.
     */
    public void setVa(
            final java.util.Vector<java.lang.String> vVaList) {
        // copy vector
        this._vaList.clear();

        this._vaList.addAll(vVaList);
    }

    /**
     * Sets the value of '_vaList' by setting it to the given
     * Vector. No type checking is performed.
     * @deprecated
     * 
     * @param vaVector the Vector to set.
     */
    public void setVaAsReference(
            final java.util.Vector<java.lang.String> vaVector) {
        this._vaList = vaVector;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.Articles
     */
    public static turbomeca.gamme.assembly.services.model.data.Articles unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.Articles) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.Articles.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
