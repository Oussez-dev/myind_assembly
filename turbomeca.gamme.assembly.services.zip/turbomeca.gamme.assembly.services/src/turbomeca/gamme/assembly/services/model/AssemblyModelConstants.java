package turbomeca.gamme.assembly.services.model;

import turbomeca.gamme.ecran.services.model.constants.ModelGlobalConstants;

public class AssemblyModelConstants extends ModelGlobalConstants {

	public static final String ATTRIBUTE_ATTRIBUTE = "attribute";

	public static final String TAG_ATA = "ata";
	public static final String TAG_REP_NUMBER = "repNumber";
	public static final String TAG_DESIGNATION_LOCATION = "designationLocalisation";
	public static final String TAG_CONSTATATION = "constatation";
	public static final String TAG_PARA_ITEM = "paraItem";
	public static final String TAG_STANDARD_PARA_IMPORT = "standardParaImport";
	public static final String TAG_STANDARD_PARA = "standardPara";
	public static final String TAG_FAMILY = "family";
	public static final String TAG_UNIT = "unit";
	public static final String TAG_ENTRY = "entry";
	public static final String TAG_EVOLUTION_TYPE = "evolutionType";
	public static final String TAG_NOTICE_NUMBER = "noticeNumber";
	public static final String TAG_DRAWING_VERSION = "drawingVersion";
	public static final String TAG_SCHEDULE_TYPE = "scheduleType";
	public static final String TAG_AE_NUMBER = "aeNumber";
	public static final String TAG_ADDITIONNAL_RECORD = "additionalRecord";

	public static final String TAG_INTERVENTION_TYPES = "interventionTypes";
	public static final String TAG_INTERVENTION_TYPE = "interventionType";
	public static final String TAG_SCHEDULE_STATE = "scheduleState";
	
	public static final String TAG_METHOD = "method";
	public static final String TAG_NUMBER = "number";
	
	public static final String TAG_MODIF_DESCRIPT = "modifDescript";
	public static final String TAG_MATERIAL = "material";
	public static final String TAG_PNS = "pns";
	public static final String TAG_ANCESTORS = "ancestors";
	public static final String TAG_ARTICLES = "articles";
	public static final String TAG_TASK_MARK = "taskMark";
	public static final String TAG_COMPOUND = "compound";
	public static final String TAG_COMPOUNDS = "compounds";
	public static final String TAG_COMPOUNDREF = "compoundRef";
	
	public static final String TAG_TOOLREF = "toolRef";
	public static final String TAG_INGREDIENTREF = "ingredientRef";
	public static final String TAG_MARK = "mark";
	public static final String TAG_MARKS = "marks";
	public static final String TAG_TEXTREF = "textRef";
	public static final String TAG_XI_INCLUDE = "xi:include";

	public static final String TAG_CONDITION_TASK = "conditionTask";
	public static final String TAG_CONDITION_INPUT = "conditionInput";
	public static final String TAG_CONDITIONS = "conditions";
	public static final String TAG_INPUT_TEST_DEF = "inputTestDef";
	public static final String TAG_REWORK = "rework";
	public static final String TAG_SUBPHASE_DEF = "subPhaseDef";
	public static final String TAG_SUBPHASEREF = "subPhaseRef";
	public static final String TAG_TASK_LIST = "taskList";
	public static final String TAG_DEVIATIONS_FROM_REF = "deviationsFromRef";
	public static final String TAG_DIVISION = "division";
	public static final String TAG_CATEGORY = "category";
	public static final String TAG_TEST = "test";
	public static final String TAG_DOCUMENT = "document";
	public static final String TAG_DOCUMENT_SUBPHASE_REF = "documentSubPhaseRef";
	public static final String TAG_DOCUMENTS_JOINED = "documentsJoined";
	public static final String TAG_DOCUMENT_JOINED = "documentJoined";
	public static final String TAG_DRAWING_MARKER = "drawingMarker";
	public static final String TAG_TASK_ACTION_TABLE = "taskActionTable";
	public static final String TAG_TASK_ACTION_MEASURE = "taskActionMeasure";
	public static final String TAG_TASK_ACTION_TABLE_IMPORT = "taskActionTableImport";
	public static final String TAG_USER_LOGIN = "login";
	public static final String TAG_USER_NAME = "name";
	public static final String TAG_OPERATION_REF = "operationRef";
	public static final String TAG_TABLE_IMPORT = "tableImport";
	public static final String TAG_VAL = "val";
	public static final String TAG_VAL_REF = "valRef";
	public static final String TAG_INPUT_REF = "inputRef";
	public static final String TAG_TASK_ACTION_IMPORT = "taskActionImport";
	public static final String TAG_FORMULA = "formula";
	public static final String TAG_ROW = "row";
	public static final String TAG_CHOICE_ITEM = "choiceItem";
	public static final String TAG_DATA_VALUE = "dataValue";
	public static final String TAG_DEFAULT_VALUE = "defaultValue";
	public static final String TAG_INTERVAL = "interval";
	public static final String TAG_MIN = "min";
	public static final String TAG_MNEMONIC = "mnemonic";
	public static final String TAG_MAX = "max";
	public static final String TAG_UNCERTAINTY = "uncertainty";
	public static final String TAG_UNDERLINED = "underlined";
	public static final String TAG_STRING_VALUE = "stringValue";
	public static final String TAG_STYLE = "style";
	public static final String TAG_SPECIFIC_FLOW = "specificFlow";
	public static final String TAG_INPUT_CHOICE = "inputChoice";
	public static final String TAG_INPUT_COMPUTED = "inputComputed";
	public static final String TAG_INPUT_CONSTANT = "inputConstant";
	public static final String TAG_INPUT_CONTROL_SAP = "inputControlSap";
	public static final String TAG_INPUT_DOCUMENT = "inputDocument";
	public static final String TAG_REFERENTIAL_TASK = "referentialTask";
	public static final String TAG_INFO_OPERATION = "infoOperation";
	public static final String TAG_INPUT_FIELD = "inputField";
	public static final String TAG_INPUT_MEASURE = "inputMeasure";
	public static final String TAG_INPUT_SAP = "inputSap";
	public static final String TAG_INPUT_VALUE = "inputValue";
	public static final String TAG_INPUT_MEASURE_RDD = "measureRdd";
	public static final String TAG_INPUT_MEASURE_SAP = "measureSap";
	public static final String TAG_INPUT_MEASURE_TOOL = "measureTool";
	public static final String TAG_OBSERVATION = "observation";
	public static final String TAG_INGREDIENT_SUBPHASE_REF = "ingredientSubPhaseRef";
	public static final String TAG_TOOL_SUBPHASE_REF = "toolSubPhaseRef";
	public static final String TAG_GENERALITY = "generality";
	public static final String TAG_DATA_FROM_TABLE = "dataFromTable";
	public static final String TAG_TASK_BENCH_SETTING = "taskBenchSetting";
	
	public static final String TAG_VA = "va";
	public static final String TAG_VAS = "vas";

	public static final String ATTR_IMPORT_GEODE_FILE = "geodeImportFile";
	public static final String ATTR_MATERIAL = "material";
	public static final String ATTR_SITE = "site";

	public static final String ATTR_LABEL = "label";
	public static final String ATTR_OPTIONAL = "optional";

	public static final String ATTR_SAP_COMMAND = "sapCommand";
	public static final String ATTR_ISOLATED_MODULE = "isolatedModule";
	public static final String ATTR_FICTIVE_ENGINE = "fictiveEngine";

	public static final String ATTR_SUMMARY = "summary";


	public static final String ATTR_CHECK = "check";
	public static final String ATTR_COMMENT = "comment";
	public static final String ATTR_NOTIFICATION = "notification";
	public static final String ATTR_DOUBLE_VALIDATION = "doubleValidation";
	public static final String ATTR_DUPLICATE_INSTANCE = "duplicableInstance";
	public static final String ATTR_COMPARATOR = "comparator";
	public static final String ATTR_VALUE = "value";
	public static final String ATTR_STATUS = "status";
	public static final String ATTR_MODE = "andMode";
	public static final String ATTR_REWORK_ACTIVATION = "reworkActivation";
	public static final String ATTR_ROWSEP = "rowsep";
	public static final String ATTR_VALIGN = "valign";
	public static final String ATTR_POSITION = "position";
	public static final String ATTR_OPERATOR = "operator";
	public static final String TAG_PREVIOUS_PICTURE = "previousPicture";
	public static final String ATTR_WIDTH = "width";
	public static final String ATTR_HEIGHT = "height";
	public static final String ATTR_KEEP_RATIO = "keepRatio";
	public static final String ATTR_SHOW_GALLERY = "showGallery";
	public static final String ATTR_RECORD_PN = "recordPN";
	public static final String ATTR_RECORD_SN = "recordSN";
	public static final String ATTR_SN = "SN";
	public static final String ATTR_SUB_COMPONENT = "subComponent";
	public static final String ATTR_SUBSTITUTE = "substitute";
	public static final String ATTR_GEODE = "geode";
	public static final String ATTR_GEODE_URL = "geodeUrl";
	public static final String ATTR_GEODE_IMPORT_FILE = "geodeImportFile";
	public static final String ATTR_SPARE = "spare";
	public static final String ATTR_SCHEDULE_LEVEL_TOP_START = "scheduleLevelTopStart";
	public static final String ATTR_SYSTEMATIC = "systematic";
	public static final String ATTR_TECHNICAL_ALTERNATIVE = "technicalAlternative";
	public static final String ATTR_COMPOUND = "compound";
	public static final String ATTR_CATEGORY = "category";
	public static final String ATTR_GROUP = "group";
	public static final String ATTR_TESTS_ROW_INDEX = "testsRowIndex";
	public static final String ATTR_VALUES_ROW_INDEX = "valuesRowIndex";
	public static final String ATTR_TABLE_REF_ID = "tableRefId";
	public static final String ATTR_DRAWING_MARKER = "drawingMarker";
		
	public static final String ATTR_AUTOMATIC_ACQUISITION = "automaticAcquisition";
	
	public static final String ATTR_REF_NAME_ID = "refNameId";
	public static final String ATTR_MODIF = "modif";

	public static final String TAG_TASK_PARA = "taskPara";

	public static final String ATTR_CATALOG_OPERATION_TYPE = "operationType";
	public static final String TAG_INSPECTION_SUB_PHASE_REF = "subPhaseRef";


}
