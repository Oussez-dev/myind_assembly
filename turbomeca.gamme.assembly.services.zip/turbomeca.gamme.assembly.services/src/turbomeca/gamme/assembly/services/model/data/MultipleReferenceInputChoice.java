/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class MultipleReferenceInputChoice.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class MultipleReferenceInputChoice implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _instance.
     */
    private int _instance;

    /**
     * keeps track of state for field: _instance
     */
    private boolean _has_instance;

    /**
     * Field _languageList.
     */
    private java.util.Vector<turbomeca.gamme.assembly.services.model.data.types.LanguageAppType> _languageList;

    /**
     * Field _interventionTypeList.
     */
    private java.util.Vector<java.lang.String> _interventionTypeList;

    /**
     * Field _siteList.
     */
    private java.util.Vector<java.lang.String> _siteList;

    /**
     * Field _effectivityList.
     */
    private java.util.Vector<java.lang.String> _effectivityList;

    /**
     * Field _methodList.
     */
    private java.util.Vector<java.lang.String> _methodList;

    /**
     * Field _sap.
     */
    private turbomeca.gamme.assembly.services.model.data.types.BooleanType _sap;

    /**
     * Field _isolatedModule.
     */
    private turbomeca.gamme.assembly.services.model.data.types.BooleanType _isolatedModule;

    /**
     * Field _fictiveEngine.
     */
    private turbomeca.gamme.assembly.services.model.data.types.BooleanType _fictiveEngine;

    /**
     * Internal choice value storage
     */
    private java.lang.Object _choiceValue;

    /**
     * Field _value.
     */
    private java.lang.String _value;

    /**
     * Field _taskActionList.
     */
    private java.util.Vector<turbomeca.gamme.assembly.services.model.data.TaskAction> _taskActionList;


      //----------------/
     //- Constructors -/
    //----------------/

    public MultipleReferenceInputChoice() {
        super();
        this._languageList = new java.util.Vector<turbomeca.gamme.assembly.services.model.data.types.LanguageAppType>();
        this._interventionTypeList = new java.util.Vector<java.lang.String>();
        this._siteList = new java.util.Vector<java.lang.String>();
        this._effectivityList = new java.util.Vector<java.lang.String>();
        this._methodList = new java.util.Vector<java.lang.String>();
        this._taskActionList = new java.util.Vector<turbomeca.gamme.assembly.services.model.data.TaskAction>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vEffectivity
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addEffectivity(
            final java.lang.String vEffectivity)
    throws java.lang.IndexOutOfBoundsException {
        this._effectivityList.addElement(vEffectivity);
    }

    /**
     * 
     * 
     * @param index
     * @param vEffectivity
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addEffectivity(
            final int index,
            final java.lang.String vEffectivity)
    throws java.lang.IndexOutOfBoundsException {
        this._effectivityList.add(index, vEffectivity);
    }

    /**
     * 
     * 
     * @param vInterventionType
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addInterventionType(
            final java.lang.String vInterventionType)
    throws java.lang.IndexOutOfBoundsException {
        this._interventionTypeList.addElement(vInterventionType);
    }

    /**
     * 
     * 
     * @param index
     * @param vInterventionType
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addInterventionType(
            final int index,
            final java.lang.String vInterventionType)
    throws java.lang.IndexOutOfBoundsException {
        this._interventionTypeList.add(index, vInterventionType);
    }

    /**
     * 
     * 
     * @param vLanguage
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addLanguage(
            final turbomeca.gamme.assembly.services.model.data.types.LanguageAppType vLanguage)
    throws java.lang.IndexOutOfBoundsException {
        this._languageList.addElement(vLanguage);
    }

    /**
     * 
     * 
     * @param index
     * @param vLanguage
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addLanguage(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.types.LanguageAppType vLanguage)
    throws java.lang.IndexOutOfBoundsException {
        this._languageList.add(index, vLanguage);
    }

    /**
     * 
     * 
     * @param vMethod
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addMethod(
            final java.lang.String vMethod)
    throws java.lang.IndexOutOfBoundsException {
        this._methodList.addElement(vMethod);
    }

    /**
     * 
     * 
     * @param index
     * @param vMethod
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addMethod(
            final int index,
            final java.lang.String vMethod)
    throws java.lang.IndexOutOfBoundsException {
        this._methodList.add(index, vMethod);
    }

    /**
     * 
     * 
     * @param vSite
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addSite(
            final java.lang.String vSite)
    throws java.lang.IndexOutOfBoundsException {
        this._siteList.addElement(vSite);
    }

    /**
     * 
     * 
     * @param index
     * @param vSite
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addSite(
            final int index,
            final java.lang.String vSite)
    throws java.lang.IndexOutOfBoundsException {
        this._siteList.add(index, vSite);
    }

    /**
     * 
     * 
     * @param vTaskAction
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addTaskAction(
            final turbomeca.gamme.assembly.services.model.data.TaskAction vTaskAction)
    throws java.lang.IndexOutOfBoundsException {
        this._taskActionList.addElement(vTaskAction);
    }

    /**
     * 
     * 
     * @param index
     * @param vTaskAction
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addTaskAction(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.TaskAction vTaskAction)
    throws java.lang.IndexOutOfBoundsException {
        this._taskActionList.add(index, vTaskAction);
    }

    /**
     */
    public void deleteInstance(
    ) {
        this._has_instance= false;
    }

    /**
     * Method enumerateEffectivity.
     * 
     * @return an Enumeration over all java.lang.String elements
     */
    public java.util.Enumeration<? extends java.lang.String> enumerateEffectivity(
    ) {
        return this._effectivityList.elements();
    }

    /**
     * Method enumerateInterventionType.
     * 
     * @return an Enumeration over all java.lang.String elements
     */
    public java.util.Enumeration<? extends java.lang.String> enumerateInterventionType(
    ) {
        return this._interventionTypeList.elements();
    }

    /**
     * Method enumerateLanguage.
     * 
     * @return an Enumeration over all
     * turbomeca.gamme.assembly.client.model.data.types.LanguageAppType
     * elements
     */
    public java.util.Enumeration<? extends turbomeca.gamme.assembly.services.model.data.types.LanguageAppType> enumerateLanguage(
    ) {
        return this._languageList.elements();
    }

    /**
     * Method enumerateMethod.
     * 
     * @return an Enumeration over all java.lang.String elements
     */
    public java.util.Enumeration<? extends java.lang.String> enumerateMethod(
    ) {
        return this._methodList.elements();
    }

    /**
     * Method enumerateSite.
     * 
     * @return an Enumeration over all java.lang.String elements
     */
    public java.util.Enumeration<? extends java.lang.String> enumerateSite(
    ) {
        return this._siteList.elements();
    }

    /**
     * Method enumerateTaskAction.
     * 
     * @return an Enumeration over all
     * turbomeca.gamme.assembly.client.model.data.TaskAction element
     */
    public java.util.Enumeration<? extends turbomeca.gamme.assembly.services.model.data.TaskAction> enumerateTaskAction(
    ) {
        return this._taskActionList.elements();
    }

    /**
     * Returns the value of field 'choiceValue'. The field
     * 'choiceValue' has the following description: Internal choice
     * value storage
     * 
     * @return the value of field 'ChoiceValue'.
     */
    public java.lang.Object getChoiceValue(
    ) {
        return this._choiceValue;
    }

    /**
     * Method getEffectivity.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the java.lang.String at the given index
     */
    public java.lang.String getEffectivity(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._effectivityList.size()) {
            throw new IndexOutOfBoundsException("getEffectivity: Index value '" + index + "' not in range [0.." + (this._effectivityList.size() - 1) + "]");
        }

        return (java.lang.String) _effectivityList.get(index);
    }

    /**
     * Method getEffectivity.Returns the contents of the collection
     * in an Array.  <p>Note:  Just in case the collection contents
     * are changing in another thread, we pass a 0-length Array of
     * the correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public java.lang.String[] getEffectivity(
    ) {
        java.lang.String[] array = new java.lang.String[0];
        return (java.lang.String[]) this._effectivityList.toArray(array);
    }

    /**
     * Method getEffectivityAsReference.Returns a reference to
     * '_effectivityList'. No type checking is performed on any
     * modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<java.lang.String> getEffectivityAsReference(
    ) {
        return this._effectivityList;
    }

    /**
     * Method getEffectivityCount.
     * 
     * @return the size of this collection
     */
    public int getEffectivityCount(
    ) {
        return this._effectivityList.size();
    }

    /**
     * Returns the value of field 'fictiveEngine'.
     * 
     * @return the value of field 'FictiveEngine'.
     */
    public turbomeca.gamme.assembly.services.model.data.types.BooleanType getFictiveEngine(
    ) {
        return this._fictiveEngine;
    }

    /**
     * Returns the value of field 'instance'.
     * 
     * @return the value of field 'Instance'.
     */
    public int getInstance(
    ) {
        return this._instance;
    }

    /**
     * Method getInterventionType.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the java.lang.String at the given index
     */
    public java.lang.String getInterventionType(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._interventionTypeList.size()) {
            throw new IndexOutOfBoundsException("getInterventionType: Index value '" + index + "' not in range [0.." + (this._interventionTypeList.size() - 1) + "]");
        }

        return (java.lang.String) _interventionTypeList.get(index);
    }

    /**
     * Method getInterventionType.Returns the contents of the
     * collection in an Array.  <p>Note:  Just in case the
     * collection contents are changing in another thread, we pass
     * a 0-length Array of the correct type into the API call. 
     * This way we <i>know</i> that the Array returned is of
     * exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public java.lang.String[] getInterventionType(
    ) {
        java.lang.String[] array = new java.lang.String[0];
        return (java.lang.String[]) this._interventionTypeList.toArray(array);
    }

    /**
     * Method getInterventionTypeAsReference.Returns a reference to
     * '_interventionTypeList'. No type checking is performed on
     * any modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<java.lang.String> getInterventionTypeAsReference(
    ) {
        return this._interventionTypeList;
    }

    /**
     * Method getInterventionTypeCount.
     * 
     * @return the size of this collection
     */
    public int getInterventionTypeCount(
    ) {
        return this._interventionTypeList.size();
    }

    /**
     * Returns the value of field 'isolatedModule'.
     * 
     * @return the value of field 'IsolatedModule'.
     */
    public turbomeca.gamme.assembly.services.model.data.types.BooleanType getIsolatedModule(
    ) {
        return this._isolatedModule;
    }

    /**
     * Method getLanguage.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * turbomeca.gamme.assembly.client.model.data.types.LanguageAppType
     * at the given index
     */
    public turbomeca.gamme.assembly.services.model.data.types.LanguageAppType getLanguage(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._languageList.size()) {
            throw new IndexOutOfBoundsException("getLanguage: Index value '" + index + "' not in range [0.." + (this._languageList.size() - 1) + "]");
        }

        return (turbomeca.gamme.assembly.services.model.data.types.LanguageAppType) _languageList.get(index);
    }

    /**
     * Method getLanguage.Returns the contents of the collection in
     * an Array.  <p>Note:  Just in case the collection contents
     * are changing in another thread, we pass a 0-length Array of
     * the correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public turbomeca.gamme.assembly.services.model.data.types.LanguageAppType[] getLanguage(
    ) {
        turbomeca.gamme.assembly.services.model.data.types.LanguageAppType[] array = new turbomeca.gamme.assembly.services.model.data.types.LanguageAppType[0];
        return (turbomeca.gamme.assembly.services.model.data.types.LanguageAppType[]) this._languageList.toArray(array);
    }

    /**
     * Method getLanguageAsReference.Returns a reference to
     * '_languageList'. No type checking is performed on any
     * modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<turbomeca.gamme.assembly.services.model.data.types.LanguageAppType> getLanguageAsReference(
    ) {
        return this._languageList;
    }

    /**
     * Method getLanguageCount.
     * 
     * @return the size of this collection
     */
    public int getLanguageCount(
    ) {
        return this._languageList.size();
    }

    /**
     * Method getMethod.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the java.lang.String at the given index
     */
    public java.lang.String getMethod(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._methodList.size()) {
            throw new IndexOutOfBoundsException("getMethod: Index value '" + index + "' not in range [0.." + (this._methodList.size() - 1) + "]");
        }

        return (java.lang.String) _methodList.get(index);
    }

    /**
     * Method getMethod.Returns the contents of the collection in
     * an Array.  <p>Note:  Just in case the collection contents
     * are changing in another thread, we pass a 0-length Array of
     * the correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public java.lang.String[] getMethod(
    ) {
        java.lang.String[] array = new java.lang.String[0];
        return (java.lang.String[]) this._methodList.toArray(array);
    }

    /**
     * Method getMethodAsReference.Returns a reference to
     * '_methodList'. No type checking is performed on any
     * modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<java.lang.String> getMethodAsReference(
    ) {
        return this._methodList;
    }

    /**
     * Method getMethodCount.
     * 
     * @return the size of this collection
     */
    public int getMethodCount(
    ) {
        return this._methodList.size();
    }

    /**
     * Returns the value of field 'sap'.
     * 
     * @return the value of field 'Sap'.
     */
    public turbomeca.gamme.assembly.services.model.data.types.BooleanType getSap(
    ) {
        return this._sap;
    }

    /**
     * Method getSite.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the java.lang.String at the given index
     */
    public java.lang.String getSite(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._siteList.size()) {
            throw new IndexOutOfBoundsException("getSite: Index value '" + index + "' not in range [0.." + (this._siteList.size() - 1) + "]");
        }

        return (java.lang.String) _siteList.get(index);
    }

    /**
     * Method getSite.Returns the contents of the collection in an
     * Array.  <p>Note:  Just in case the collection contents are
     * changing in another thread, we pass a 0-length Array of the
     * correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public java.lang.String[] getSite(
    ) {
        java.lang.String[] array = new java.lang.String[0];
        return (java.lang.String[]) this._siteList.toArray(array);
    }

    /**
     * Method getSiteAsReference.Returns a reference to
     * '_siteList'. No type checking is performed on any
     * modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<java.lang.String> getSiteAsReference(
    ) {
        return this._siteList;
    }

    /**
     * Method getSiteCount.
     * 
     * @return the size of this collection
     */
    public int getSiteCount(
    ) {
        return this._siteList.size();
    }

    /**
     * Method getTaskAction.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * turbomeca.gamme.assembly.client.model.data.TaskAction at the
     * given index
     */
    public turbomeca.gamme.assembly.services.model.data.TaskAction getTaskAction(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._taskActionList.size()) {
            throw new IndexOutOfBoundsException("getTaskAction: Index value '" + index + "' not in range [0.." + (this._taskActionList.size() - 1) + "]");
        }

        return (turbomeca.gamme.assembly.services.model.data.TaskAction) _taskActionList.get(index);
    }

    /**
     * Method getTaskAction.Returns the contents of the collection
     * in an Array.  <p>Note:  Just in case the collection contents
     * are changing in another thread, we pass a 0-length Array of
     * the correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public turbomeca.gamme.assembly.services.model.data.TaskAction[] getTaskAction(
    ) {
        turbomeca.gamme.assembly.services.model.data.TaskAction[] array = new turbomeca.gamme.assembly.services.model.data.TaskAction[0];
        return (turbomeca.gamme.assembly.services.model.data.TaskAction[]) this._taskActionList.toArray(array);
    }

    /**
     * Method getTaskActionAsReference.Returns a reference to
     * '_taskActionList'. No type checking is performed on any
     * modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<turbomeca.gamme.assembly.services.model.data.TaskAction> getTaskActionAsReference(
    ) {
        return this._taskActionList;
    }

    /**
     * Method getTaskActionCount.
     * 
     * @return the size of this collection
     */
    public int getTaskActionCount(
    ) {
        return this._taskActionList.size();
    }

    /**
     * Returns the value of field 'value'.
     * 
     * @return the value of field 'Value'.
     */
    public java.lang.String getValue(
    ) {
        return this._value;
    }

    /**
     * Method hasInstance.
     * 
     * @return true if at least one Instance has been added
     */
    public boolean hasInstance(
    ) {
        return this._has_instance;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllEffectivity(
    ) {
        this._effectivityList.clear();
    }

    /**
     */
    public void removeAllInterventionType(
    ) {
        this._interventionTypeList.clear();
    }

    /**
     */
    public void removeAllLanguage(
    ) {
        this._languageList.clear();
    }

    /**
     */
    public void removeAllMethod(
    ) {
        this._methodList.clear();
    }

    /**
     */
    public void removeAllSite(
    ) {
        this._siteList.clear();
    }

    /**
     */
    public void removeAllTaskAction(
    ) {
        this._taskActionList.clear();
    }

    /**
     * Method removeEffectivity.
     * 
     * @param vEffectivity
     * @return true if the object was removed from the collection.
     */
    public boolean removeEffectivity(
            final java.lang.String vEffectivity) {
        boolean removed = _effectivityList.remove(vEffectivity);
        return removed;
    }

    /**
     * Method removeEffectivityAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public java.lang.String removeEffectivityAt(
            final int index) {
        java.lang.Object obj = this._effectivityList.remove(index);
        return (java.lang.String) obj;
    }

    /**
     * Method removeInterventionType.
     * 
     * @param vInterventionType
     * @return true if the object was removed from the collection.
     */
    public boolean removeInterventionType(
            final java.lang.String vInterventionType) {
        boolean removed = _interventionTypeList.remove(vInterventionType);
        return removed;
    }

    /**
     * Method removeInterventionTypeAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public java.lang.String removeInterventionTypeAt(
            final int index) {
        java.lang.Object obj = this._interventionTypeList.remove(index);
        return (java.lang.String) obj;
    }

    /**
     * Method removeLanguage.
     * 
     * @param vLanguage
     * @return true if the object was removed from the collection.
     */
    public boolean removeLanguage(
            final turbomeca.gamme.assembly.services.model.data.types.LanguageAppType vLanguage) {
        boolean removed = _languageList.remove(vLanguage);
        return removed;
    }

    /**
     * Method removeLanguageAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public turbomeca.gamme.assembly.services.model.data.types.LanguageAppType removeLanguageAt(
            final int index) {
        java.lang.Object obj = this._languageList.remove(index);
        return (turbomeca.gamme.assembly.services.model.data.types.LanguageAppType) obj;
    }

    /**
     * Method removeMethod.
     * 
     * @param vMethod
     * @return true if the object was removed from the collection.
     */
    public boolean removeMethod(
            final java.lang.String vMethod) {
        boolean removed = _methodList.remove(vMethod);
        return removed;
    }

    /**
     * Method removeMethodAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public java.lang.String removeMethodAt(
            final int index) {
        java.lang.Object obj = this._methodList.remove(index);
        return (java.lang.String) obj;
    }

    /**
     * Method removeSite.
     * 
     * @param vSite
     * @return true if the object was removed from the collection.
     */
    public boolean removeSite(
            final java.lang.String vSite) {
        boolean removed = _siteList.remove(vSite);
        return removed;
    }

    /**
     * Method removeSiteAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public java.lang.String removeSiteAt(
            final int index) {
        java.lang.Object obj = this._siteList.remove(index);
        return (java.lang.String) obj;
    }

    /**
     * Method removeTaskAction.
     * 
     * @param vTaskAction
     * @return true if the object was removed from the collection.
     */
    public boolean removeTaskAction(
            final turbomeca.gamme.assembly.services.model.data.TaskAction vTaskAction) {
        boolean removed = _taskActionList.remove(vTaskAction);
        return removed;
    }

    /**
     * Method removeTaskActionAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public turbomeca.gamme.assembly.services.model.data.TaskAction removeTaskActionAt(
            final int index) {
        java.lang.Object obj = this._taskActionList.remove(index);
        return (turbomeca.gamme.assembly.services.model.data.TaskAction) obj;
    }

    /**
     * 
     * 
     * @param index
     * @param vEffectivity
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setEffectivity(
            final int index,
            final java.lang.String vEffectivity)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._effectivityList.size()) {
            throw new IndexOutOfBoundsException("setEffectivity: Index value '" + index + "' not in range [0.." + (this._effectivityList.size() - 1) + "]");
        }

        this._effectivityList.set(index, vEffectivity);
    }

    /**
     * 
     * 
     * @param vEffectivityArray
     */
    public void setEffectivity(
            final java.lang.String[] vEffectivityArray) {
        //-- copy array
        _effectivityList.clear();

        for (int i = 0; i < vEffectivityArray.length; i++) {
                this._effectivityList.add(vEffectivityArray[i]);
        }
    }

    /**
     * Sets the value of '_effectivityList' by copying the given
     * Vector. All elements will be checked for type safety.
     * 
     * @param vEffectivityList the Vector to copy.
     */
    public void setEffectivity(
            final java.util.Vector<java.lang.String> vEffectivityList) {
        // copy vector
        this._effectivityList.clear();

        this._effectivityList.addAll(vEffectivityList);
    }

    /**
     * Sets the value of '_effectivityList' by setting it to the
     * given Vector. No type checking is performed.
     * @deprecated
     * 
     * @param effectivityVector the Vector to set.
     */
    public void setEffectivityAsReference(
            final java.util.Vector<java.lang.String> effectivityVector) {
        this._effectivityList = effectivityVector;
    }

    /**
     * Sets the value of field 'fictiveEngine'.
     * 
     * @param fictiveEngine the value of field 'fictiveEngine'.
     */
    public void setFictiveEngine(
            final turbomeca.gamme.assembly.services.model.data.types.BooleanType fictiveEngine) {
        this._fictiveEngine = fictiveEngine;
    }

    /**
     * Sets the value of field 'instance'.
     * 
     * @param instance the value of field 'instance'.
     */
    public void setInstance(
            final int instance) {
        this._instance = instance;
        this._has_instance = true;
    }

    /**
     * 
     * 
     * @param index
     * @param vInterventionType
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setInterventionType(
            final int index,
            final java.lang.String vInterventionType)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._interventionTypeList.size()) {
            throw new IndexOutOfBoundsException("setInterventionType: Index value '" + index + "' not in range [0.." + (this._interventionTypeList.size() - 1) + "]");
        }

        this._interventionTypeList.set(index, vInterventionType);
    }

    /**
     * 
     * 
     * @param vInterventionTypeArray
     */
    public void setInterventionType(
            final java.lang.String[] vInterventionTypeArray) {
        //-- copy array
        _interventionTypeList.clear();

        for (int i = 0; i < vInterventionTypeArray.length; i++) {
                this._interventionTypeList.add(vInterventionTypeArray[i]);
        }
    }

    /**
     * Sets the value of '_interventionTypeList' by copying the
     * given Vector. All elements will be checked for type safety.
     * 
     * @param vInterventionTypeList the Vector to copy.
     */
    public void setInterventionType(
            final java.util.Vector<java.lang.String> vInterventionTypeList) {
        // copy vector
        this._interventionTypeList.clear();

        this._interventionTypeList.addAll(vInterventionTypeList);
    }

    /**
     * Sets the value of '_interventionTypeList' by setting it to
     * the given Vector. No type checking is performed.
     * @deprecated
     * 
     * @param interventionTypeVector the Vector to set.
     */
    public void setInterventionTypeAsReference(
            final java.util.Vector<java.lang.String> interventionTypeVector) {
        this._interventionTypeList = interventionTypeVector;
    }

    /**
     * Sets the value of field 'isolatedModule'.
     * 
     * @param isolatedModule the value of field 'isolatedModule'.
     */
    public void setIsolatedModule(
            final turbomeca.gamme.assembly.services.model.data.types.BooleanType isolatedModule) {
        this._isolatedModule = isolatedModule;
    }

    /**
     * 
     * 
     * @param index
     * @param vLanguage
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setLanguage(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.types.LanguageAppType vLanguage)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._languageList.size()) {
            throw new IndexOutOfBoundsException("setLanguage: Index value '" + index + "' not in range [0.." + (this._languageList.size() - 1) + "]");
        }

        this._languageList.set(index, vLanguage);
    }

    /**
     * 
     * 
     * @param vLanguageArray
     */
    public void setLanguage(
            final turbomeca.gamme.assembly.services.model.data.types.LanguageAppType[] vLanguageArray) {
        //-- copy array
        _languageList.clear();

        for (int i = 0; i < vLanguageArray.length; i++) {
                this._languageList.add(vLanguageArray[i]);
        }
    }

    /**
     * Sets the value of '_languageList' by copying the given
     * Vector. All elements will be checked for type safety.
     * 
     * @param vLanguageList the Vector to copy.
     */
    public void setLanguage(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.types.LanguageAppType> vLanguageList) {
        // copy vector
        this._languageList.clear();

        this._languageList.addAll(vLanguageList);
    }

    /**
     * Sets the value of '_languageList' by setting it to the given
     * Vector. No type checking is performed.
     * @deprecated
     * 
     * @param languageVector the Vector to set.
     */
    public void setLanguageAsReference(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.types.LanguageAppType> languageVector) {
        this._languageList = languageVector;
    }

    /**
     * 
     * 
     * @param index
     * @param vMethod
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setMethod(
            final int index,
            final java.lang.String vMethod)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._methodList.size()) {
            throw new IndexOutOfBoundsException("setMethod: Index value '" + index + "' not in range [0.." + (this._methodList.size() - 1) + "]");
        }

        this._methodList.set(index, vMethod);
    }

    /**
     * 
     * 
     * @param vMethodArray
     */
    public void setMethod(
            final java.lang.String[] vMethodArray) {
        //-- copy array
        _methodList.clear();

        for (int i = 0; i < vMethodArray.length; i++) {
                this._methodList.add(vMethodArray[i]);
        }
    }

    /**
     * Sets the value of '_methodList' by copying the given Vector.
     * All elements will be checked for type safety.
     * 
     * @param vMethodList the Vector to copy.
     */
    public void setMethod(
            final java.util.Vector<java.lang.String> vMethodList) {
        // copy vector
        this._methodList.clear();

        this._methodList.addAll(vMethodList);
    }

    /**
     * Sets the value of '_methodList' by setting it to the given
     * Vector. No type checking is performed.
     * @deprecated
     * 
     * @param methodVector the Vector to set.
     */
    public void setMethodAsReference(
            final java.util.Vector<java.lang.String> methodVector) {
        this._methodList = methodVector;
    }

    /**
     * Sets the value of field 'sap'.
     * 
     * @param sap the value of field 'sap'.
     */
    public void setSap(
            final turbomeca.gamme.assembly.services.model.data.types.BooleanType sap) {
        this._sap = sap;
    }

    /**
     * 
     * 
     * @param index
     * @param vSite
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setSite(
            final int index,
            final java.lang.String vSite)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._siteList.size()) {
            throw new IndexOutOfBoundsException("setSite: Index value '" + index + "' not in range [0.." + (this._siteList.size() - 1) + "]");
        }

        this._siteList.set(index, vSite);
    }

    /**
     * 
     * 
     * @param vSiteArray
     */
    public void setSite(
            final java.lang.String[] vSiteArray) {
        //-- copy array
        _siteList.clear();

        for (int i = 0; i < vSiteArray.length; i++) {
                this._siteList.add(vSiteArray[i]);
        }
    }

    /**
     * Sets the value of '_siteList' by copying the given Vector.
     * All elements will be checked for type safety.
     * 
     * @param vSiteList the Vector to copy.
     */
    public void setSite(
            final java.util.Vector<java.lang.String> vSiteList) {
        // copy vector
        this._siteList.clear();

        this._siteList.addAll(vSiteList);
    }

    /**
     * Sets the value of '_siteList' by setting it to the given
     * Vector. No type checking is performed.
     * @deprecated
     * 
     * @param siteVector the Vector to set.
     */
    public void setSiteAsReference(
            final java.util.Vector<java.lang.String> siteVector) {
        this._siteList = siteVector;
    }

    /**
     * 
     * 
     * @param index
     * @param vTaskAction
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setTaskAction(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.TaskAction vTaskAction)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._taskActionList.size()) {
            throw new IndexOutOfBoundsException("setTaskAction: Index value '" + index + "' not in range [0.." + (this._taskActionList.size() - 1) + "]");
        }

        this._taskActionList.set(index, vTaskAction);
    }

    /**
     * 
     * 
     * @param vTaskActionArray
     */
    public void setTaskAction(
            final turbomeca.gamme.assembly.services.model.data.TaskAction[] vTaskActionArray) {
        //-- copy array
        _taskActionList.clear();

        for (int i = 0; i < vTaskActionArray.length; i++) {
                this._taskActionList.add(vTaskActionArray[i]);
        }
    }

    /**
     * Sets the value of '_taskActionList' by copying the given
     * Vector. All elements will be checked for type safety.
     * 
     * @param vTaskActionList the Vector to copy.
     */
    public void setTaskAction(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.TaskAction> vTaskActionList) {
        // copy vector
        this._taskActionList.clear();

        this._taskActionList.addAll(vTaskActionList);
    }

    /**
     * Sets the value of '_taskActionList' by setting it to the
     * given Vector. No type checking is performed.
     * @deprecated
     * 
     * @param taskActionVector the Vector to set.
     */
    public void setTaskActionAsReference(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.TaskAction> taskActionVector) {
        this._taskActionList = taskActionVector;
    }

    /**
     * Sets the value of field 'value'.
     * 
     * @param value the value of field 'value'.
     */
    public void setValue(
            final java.lang.String value) {
        this._value = value;
        this._choiceValue = value;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.client.model.data.MultipleReferenceInputChoice
     */
    public static turbomeca.gamme.assembly.services.model.data.MultipleReferenceInputChoice unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.MultipleReferenceInputChoice) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.MultipleReferenceInputChoice.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
