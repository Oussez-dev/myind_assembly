/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class InterventionTypes.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class InterventionTypes implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _interventionTypeList.
     */
    private java.util.Vector<turbomeca.gamme.assembly.services.model.data.InterventionType> _interventionTypeList;


      //----------------/
     //- Constructors -/
    //----------------/

    public InterventionTypes() {
        super();
        this._interventionTypeList = new java.util.Vector<turbomeca.gamme.assembly.services.model.data.InterventionType>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vInterventionType
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addInterventionType(
            final turbomeca.gamme.assembly.services.model.data.InterventionType vInterventionType)
    throws java.lang.IndexOutOfBoundsException {
        this._interventionTypeList.addElement(vInterventionType);
    }

    /**
     * 
     * 
     * @param index
     * @param vInterventionType
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addInterventionType(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.InterventionType vInterventionType)
    throws java.lang.IndexOutOfBoundsException {
        this._interventionTypeList.add(index, vInterventionType);
    }

    /**
     * Method enumerateInterventionType.
     * 
     * @return an Enumeration over all
     * turbomeca.gamme.assembly.services.model.data.InterventionType
     * elements
     */
    public java.util.Enumeration<? extends turbomeca.gamme.assembly.services.model.data.InterventionType> enumerateInterventionType(
    ) {
        return this._interventionTypeList.elements();
    }

    /**
     * Method getInterventionType.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * turbomeca.gamme.assembly.services.model.data.InterventionType
     * at the given index
     */
    public turbomeca.gamme.assembly.services.model.data.InterventionType getInterventionType(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._interventionTypeList.size()) {
            throw new IndexOutOfBoundsException("getInterventionType: Index value '" + index + "' not in range [0.." + (this._interventionTypeList.size() - 1) + "]");
        }

        return (turbomeca.gamme.assembly.services.model.data.InterventionType) _interventionTypeList.get(index);
    }

    /**
     * Method getInterventionType.Returns the contents of the
     * collection in an Array.  <p>Note:  Just in case the
     * collection contents are changing in another thread, we pass
     * a 0-length Array of the correct type into the API call. 
     * This way we <i>know</i> that the Array returned is of
     * exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public turbomeca.gamme.assembly.services.model.data.InterventionType[] getInterventionType(
    ) {
        turbomeca.gamme.assembly.services.model.data.InterventionType[] array = new turbomeca.gamme.assembly.services.model.data.InterventionType[0];
        return (turbomeca.gamme.assembly.services.model.data.InterventionType[]) this._interventionTypeList.toArray(array);
    }

    /**
     * Method getInterventionTypeAsReference.Returns a reference to
     * '_interventionTypeList'. No type checking is performed on
     * any modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<turbomeca.gamme.assembly.services.model.data.InterventionType> getInterventionTypeAsReference(
    ) {
        return this._interventionTypeList;
    }

    /**
     * Method getInterventionTypeCount.
     * 
     * @return the size of this collection
     */
    public int getInterventionTypeCount(
    ) {
        return this._interventionTypeList.size();
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllInterventionType(
    ) {
        this._interventionTypeList.clear();
    }

    /**
     * Method removeInterventionType.
     * 
     * @param vInterventionType
     * @return true if the object was removed from the collection.
     */
    public boolean removeInterventionType(
            final turbomeca.gamme.assembly.services.model.data.InterventionType vInterventionType) {
        boolean removed = _interventionTypeList.remove(vInterventionType);
        return removed;
    }

    /**
     * Method removeInterventionTypeAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public turbomeca.gamme.assembly.services.model.data.InterventionType removeInterventionTypeAt(
            final int index) {
        java.lang.Object obj = this._interventionTypeList.remove(index);
        return (turbomeca.gamme.assembly.services.model.data.InterventionType) obj;
    }

    /**
     * 
     * 
     * @param index
     * @param vInterventionType
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setInterventionType(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.InterventionType vInterventionType)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._interventionTypeList.size()) {
            throw new IndexOutOfBoundsException("setInterventionType: Index value '" + index + "' not in range [0.." + (this._interventionTypeList.size() - 1) + "]");
        }

        this._interventionTypeList.set(index, vInterventionType);
    }

    /**
     * 
     * 
     * @param vInterventionTypeArray
     */
    public void setInterventionType(
            final turbomeca.gamme.assembly.services.model.data.InterventionType[] vInterventionTypeArray) {
        //-- copy array
        _interventionTypeList.clear();

        for (int i = 0; i < vInterventionTypeArray.length; i++) {
                this._interventionTypeList.add(vInterventionTypeArray[i]);
        }
    }

    /**
     * Sets the value of '_interventionTypeList' by copying the
     * given Vector. All elements will be checked for type safety.
     * 
     * @param vInterventionTypeList the Vector to copy.
     */
    public void setInterventionType(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.InterventionType> vInterventionTypeList) {
        // copy vector
        this._interventionTypeList.clear();

        this._interventionTypeList.addAll(vInterventionTypeList);
    }

    /**
     * Sets the value of '_interventionTypeList' by setting it to
     * the given Vector. No type checking is performed.
     * @deprecated
     * 
     * @param interventionTypeVector the Vector to set.
     */
    public void setInterventionTypeAsReference(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.InterventionType> interventionTypeVector) {
        this._interventionTypeList = interventionTypeVector;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.InterventionType
     */
    public static turbomeca.gamme.assembly.services.model.data.InterventionTypes unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.InterventionTypes) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.InterventionTypes.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
