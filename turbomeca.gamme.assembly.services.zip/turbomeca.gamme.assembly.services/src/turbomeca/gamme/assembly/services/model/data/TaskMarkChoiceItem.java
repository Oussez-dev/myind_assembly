/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class TaskMarkChoiceItem.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class TaskMarkChoiceItem implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _para.
     */
    private turbomeca.gamme.assembly.services.model.data.Para _para;

    /**
     * Field _tolerance.
     */
    private turbomeca.gamme.assembly.services.model.data.Tolerance _tolerance;

    /**
     * Field _pictogram.
     */
    private turbomeca.gamme.assembly.services.model.data.Pictogram _pictogram;


      //----------------/
     //- Constructors -/
    //----------------/

    public TaskMarkChoiceItem() {
        super();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'para'.
     * 
     * @return the value of field 'Para'.
     */
    public turbomeca.gamme.assembly.services.model.data.Para getPara(
    ) {
        return this._para;
    }

    /**
     * Returns the value of field 'pictogram'.
     * 
     * @return the value of field 'Pictogram'.
     */
    public turbomeca.gamme.assembly.services.model.data.Pictogram getPictogram(
    ) {
        return this._pictogram;
    }

    /**
     * Returns the value of field 'tolerance'.
     * 
     * @return the value of field 'Tolerance'.
     */
    public turbomeca.gamme.assembly.services.model.data.Tolerance getTolerance(
    ) {
        return this._tolerance;
    }

    /**
     * Sets the value of field 'para'.
     * 
     * @param para the value of field 'para'.
     */
    public void setPara(
            final turbomeca.gamme.assembly.services.model.data.Para para) {
        this._para = para;
    }

    /**
     * Sets the value of field 'pictogram'.
     * 
     * @param pictogram the value of field 'pictogram'.
     */
    public void setPictogram(
            final turbomeca.gamme.assembly.services.model.data.Pictogram pictogram) {
        this._pictogram = pictogram;
    }

    /**
     * Sets the value of field 'tolerance'.
     * 
     * @param tolerance the value of field 'tolerance'.
     */
    public void setTolerance(
            final turbomeca.gamme.assembly.services.model.data.Tolerance tolerance) {
        this._tolerance = tolerance;
    }

}
