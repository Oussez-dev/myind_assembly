/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class SubIssue.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class SubIssue implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _version.
     */
    private java.lang.String _version;

    /**
     * Field _issueModificationList.
     */
    private java.util.Vector<turbomeca.gamme.assembly.services.model.data.IssueModification> _issueModificationList;

    /**
     * Field _issuePublicationList.
     */
    private java.util.Vector<turbomeca.gamme.assembly.services.model.data.IssuePublication> _issuePublicationList;


      //----------------/
     //- Constructors -/
    //----------------/

    public SubIssue() {
        super();
        this._issueModificationList = new java.util.Vector<turbomeca.gamme.assembly.services.model.data.IssueModification>();
        this._issuePublicationList = new java.util.Vector<turbomeca.gamme.assembly.services.model.data.IssuePublication>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vIssueModification
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addIssueModification(
            final turbomeca.gamme.assembly.services.model.data.IssueModification vIssueModification)
    throws java.lang.IndexOutOfBoundsException {
        this._issueModificationList.addElement(vIssueModification);
    }

    /**
     * 
     * 
     * @param index
     * @param vIssueModification
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addIssueModification(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.IssueModification vIssueModification)
    throws java.lang.IndexOutOfBoundsException {
        this._issueModificationList.add(index, vIssueModification);
    }

    /**
     * 
     * 
     * @param vIssuePublication
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addIssuePublication(
            final turbomeca.gamme.assembly.services.model.data.IssuePublication vIssuePublication)
    throws java.lang.IndexOutOfBoundsException {
        this._issuePublicationList.addElement(vIssuePublication);
    }

    /**
     * 
     * 
     * @param index
     * @param vIssuePublication
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addIssuePublication(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.IssuePublication vIssuePublication)
    throws java.lang.IndexOutOfBoundsException {
        this._issuePublicationList.add(index, vIssuePublication);
    }

    /**
     * Method enumerateIssueModification.
     * 
     * @return an Enumeration over all
     * turbomeca.gamme.assembly.services.model.data.IssueModification
     * elements
     */
    public java.util.Enumeration<? extends turbomeca.gamme.assembly.services.model.data.IssueModification> enumerateIssueModification(
    ) {
        return this._issueModificationList.elements();
    }

    /**
     * Method enumerateIssuePublication.
     * 
     * @return an Enumeration over all
     * turbomeca.gamme.assembly.services.model.data.IssuePublication
     * elements
     */
    public java.util.Enumeration<? extends turbomeca.gamme.assembly.services.model.data.IssuePublication> enumerateIssuePublication(
    ) {
        return this._issuePublicationList.elements();
    }

    /**
     * Method getIssueModification.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * turbomeca.gamme.assembly.services.model.data.IssueModification
     * at the given index
     */
    public turbomeca.gamme.assembly.services.model.data.IssueModification getIssueModification(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._issueModificationList.size()) {
            throw new IndexOutOfBoundsException("getIssueModification: Index value '" + index + "' not in range [0.." + (this._issueModificationList.size() - 1) + "]");
        }

        return (turbomeca.gamme.assembly.services.model.data.IssueModification) _issueModificationList.get(index);
    }

    /**
     * Method getIssueModification.Returns the contents of the
     * collection in an Array.  <p>Note:  Just in case the
     * collection contents are changing in another thread, we pass
     * a 0-length Array of the correct type into the API call. 
     * This way we <i>know</i> that the Array returned is of
     * exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public turbomeca.gamme.assembly.services.model.data.IssueModification[] getIssueModification(
    ) {
        turbomeca.gamme.assembly.services.model.data.IssueModification[] array = new turbomeca.gamme.assembly.services.model.data.IssueModification[0];
        return (turbomeca.gamme.assembly.services.model.data.IssueModification[]) this._issueModificationList.toArray(array);
    }

    /**
     * Method getIssueModificationAsReference.Returns a reference
     * to '_issueModificationList'. No type checking is performed
     * on any modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<turbomeca.gamme.assembly.services.model.data.IssueModification> getIssueModificationAsReference(
    ) {
        return this._issueModificationList;
    }

    /**
     * Method getIssueModificationCount.
     * 
     * @return the size of this collection
     */
    public int getIssueModificationCount(
    ) {
        return this._issueModificationList.size();
    }

    /**
     * Method getIssuePublication.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * turbomeca.gamme.assembly.services.model.data.IssuePublication
     * at the given index
     */
    public turbomeca.gamme.assembly.services.model.data.IssuePublication getIssuePublication(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._issuePublicationList.size()) {
            throw new IndexOutOfBoundsException("getIssuePublication: Index value '" + index + "' not in range [0.." + (this._issuePublicationList.size() - 1) + "]");
        }

        return (turbomeca.gamme.assembly.services.model.data.IssuePublication) _issuePublicationList.get(index);
    }

    /**
     * Method getIssuePublication.Returns the contents of the
     * collection in an Array.  <p>Note:  Just in case the
     * collection contents are changing in another thread, we pass
     * a 0-length Array of the correct type into the API call. 
     * This way we <i>know</i> that the Array returned is of
     * exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public turbomeca.gamme.assembly.services.model.data.IssuePublication[] getIssuePublication(
    ) {
        turbomeca.gamme.assembly.services.model.data.IssuePublication[] array = new turbomeca.gamme.assembly.services.model.data.IssuePublication[0];
        return (turbomeca.gamme.assembly.services.model.data.IssuePublication[]) this._issuePublicationList.toArray(array);
    }

    /**
     * Method getIssuePublicationAsReference.Returns a reference to
     * '_issuePublicationList'. No type checking is performed on
     * any modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<turbomeca.gamme.assembly.services.model.data.IssuePublication> getIssuePublicationAsReference(
    ) {
        return this._issuePublicationList;
    }

    /**
     * Method getIssuePublicationCount.
     * 
     * @return the size of this collection
     */
    public int getIssuePublicationCount(
    ) {
        return this._issuePublicationList.size();
    }

    /**
     * Returns the value of field 'version'.
     * 
     * @return the value of field 'Version'.
     */
    public java.lang.String getVersion(
    ) {
        return this._version;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllIssueModification(
    ) {
        this._issueModificationList.clear();
    }

    /**
     */
    public void removeAllIssuePublication(
    ) {
        this._issuePublicationList.clear();
    }

    /**
     * Method removeIssueModification.
     * 
     * @param vIssueModification
     * @return true if the object was removed from the collection.
     */
    public boolean removeIssueModification(
            final turbomeca.gamme.assembly.services.model.data.IssueModification vIssueModification) {
        boolean removed = _issueModificationList.remove(vIssueModification);
        return removed;
    }

    /**
     * Method removeIssueModificationAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public turbomeca.gamme.assembly.services.model.data.IssueModification removeIssueModificationAt(
            final int index) {
        java.lang.Object obj = this._issueModificationList.remove(index);
        return (turbomeca.gamme.assembly.services.model.data.IssueModification) obj;
    }

    /**
     * Method removeIssuePublication.
     * 
     * @param vIssuePublication
     * @return true if the object was removed from the collection.
     */
    public boolean removeIssuePublication(
            final turbomeca.gamme.assembly.services.model.data.IssuePublication vIssuePublication) {
        boolean removed = _issuePublicationList.remove(vIssuePublication);
        return removed;
    }

    /**
     * Method removeIssuePublicationAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public turbomeca.gamme.assembly.services.model.data.IssuePublication removeIssuePublicationAt(
            final int index) {
        java.lang.Object obj = this._issuePublicationList.remove(index);
        return (turbomeca.gamme.assembly.services.model.data.IssuePublication) obj;
    }

    /**
     * 
     * 
     * @param index
     * @param vIssueModification
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setIssueModification(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.IssueModification vIssueModification)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._issueModificationList.size()) {
            throw new IndexOutOfBoundsException("setIssueModification: Index value '" + index + "' not in range [0.." + (this._issueModificationList.size() - 1) + "]");
        }

        this._issueModificationList.set(index, vIssueModification);
    }

    /**
     * 
     * 
     * @param vIssueModificationArray
     */
    public void setIssueModification(
            final turbomeca.gamme.assembly.services.model.data.IssueModification[] vIssueModificationArray) {
        //-- copy array
        _issueModificationList.clear();

        for (int i = 0; i < vIssueModificationArray.length; i++) {
                this._issueModificationList.add(vIssueModificationArray[i]);
        }
    }

    /**
     * Sets the value of '_issueModificationList' by copying the
     * given Vector. All elements will be checked for type safety.
     * 
     * @param vIssueModificationList the Vector to copy.
     */
    public void setIssueModification(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.IssueModification> vIssueModificationList) {
        // copy vector
        this._issueModificationList.clear();

        this._issueModificationList.addAll(vIssueModificationList);
    }

    /**
     * Sets the value of '_issueModificationList' by setting it to
     * the given Vector. No type checking is performed.
     * @deprecated
     * 
     * @param issueModificationVector the Vector to set.
     */
    public void setIssueModificationAsReference(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.IssueModification> issueModificationVector) {
        this._issueModificationList = issueModificationVector;
    }

    /**
     * 
     * 
     * @param index
     * @param vIssuePublication
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setIssuePublication(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.IssuePublication vIssuePublication)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._issuePublicationList.size()) {
            throw new IndexOutOfBoundsException("setIssuePublication: Index value '" + index + "' not in range [0.." + (this._issuePublicationList.size() - 1) + "]");
        }

        this._issuePublicationList.set(index, vIssuePublication);
    }

    /**
     * 
     * 
     * @param vIssuePublicationArray
     */
    public void setIssuePublication(
            final turbomeca.gamme.assembly.services.model.data.IssuePublication[] vIssuePublicationArray) {
        //-- copy array
        _issuePublicationList.clear();

        for (int i = 0; i < vIssuePublicationArray.length; i++) {
                this._issuePublicationList.add(vIssuePublicationArray[i]);
        }
    }

    /**
     * Sets the value of '_issuePublicationList' by copying the
     * given Vector. All elements will be checked for type safety.
     * 
     * @param vIssuePublicationList the Vector to copy.
     */
    public void setIssuePublication(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.IssuePublication> vIssuePublicationList) {
        // copy vector
        this._issuePublicationList.clear();

        this._issuePublicationList.addAll(vIssuePublicationList);
    }

    /**
     * Sets the value of '_issuePublicationList' by setting it to
     * the given Vector. No type checking is performed.
     * @deprecated
     * 
     * @param issuePublicationVector the Vector to set.
     */
    public void setIssuePublicationAsReference(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.IssuePublication> issuePublicationVector) {
        this._issuePublicationList = issuePublicationVector;
    }

    /**
     * Sets the value of field 'version'.
     * 
     * @param version the value of field 'version'.
     */
    public void setVersion(
            final java.lang.String version) {
        this._version = version;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.SubIssue
     */
    public static turbomeca.gamme.assembly.services.model.data.SubIssue unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.SubIssue) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.SubIssue.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
