/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class Generality.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class Generality implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _languageList.
     */
    private java.util.Vector<java.lang.String> _languageList;

    /**
     * Field _interventionTypeList.
     */
    private java.util.Vector<java.lang.String> _interventionTypeList;

    /**
     * Field _siteList.
     */
    private java.util.Vector<java.lang.String> _siteList;

    /**
     * Field _effectivityList.
     */
    private java.util.Vector<java.lang.String> _effectivityList;

    /**
     * Field _variantList.
     */
    private java.util.Vector<java.lang.String> _variantList;

    /**
     * Field _methodList.
     */
    private java.util.Vector<java.lang.String> _methodList;

    /**
     * Field _sap.
     */
    private turbomeca.gamme.assembly.services.model.data.types.BooleanType _sap;

    /**
     * Field _isolatedModule.
     */
    private turbomeca.gamme.assembly.services.model.data.types.BooleanType _isolatedModule;

    /**
     * Field _fictiveEngine.
     */
    private turbomeca.gamme.assembly.services.model.data.types.BooleanType _fictiveEngine;

    /**
     * Field _titleList.
     */
    private java.util.Vector<turbomeca.gamme.assembly.services.model.data.Title> _titleList;

    /**
     * Field _taskDetailList.
     */
    private java.util.Vector<turbomeca.gamme.assembly.services.model.data.TaskDetail> _taskDetailList;


      //----------------/
     //- Constructors -/
    //----------------/

    public Generality() {
        super();
        this._languageList = new java.util.Vector<java.lang.String>();
        this._interventionTypeList = new java.util.Vector<java.lang.String>();
        this._siteList = new java.util.Vector<java.lang.String>();
        this._effectivityList = new java.util.Vector<java.lang.String>();
        this._variantList = new java.util.Vector<java.lang.String>();
        this._methodList = new java.util.Vector<java.lang.String>();
        this._titleList = new java.util.Vector<turbomeca.gamme.assembly.services.model.data.Title>();
        this._taskDetailList = new java.util.Vector<turbomeca.gamme.assembly.services.model.data.TaskDetail>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vEffectivity
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addEffectivity(
            final java.lang.String vEffectivity)
    throws java.lang.IndexOutOfBoundsException {
        this._effectivityList.addElement(vEffectivity);
    }

    /**
     * 
     * 
     * @param index
     * @param vEffectivity
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addEffectivity(
            final int index,
            final java.lang.String vEffectivity)
    throws java.lang.IndexOutOfBoundsException {
        this._effectivityList.add(index, vEffectivity);
    }

    /**
     * 
     * 
     * @param vInterventionType
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addInterventionType(
            final java.lang.String vInterventionType)
    throws java.lang.IndexOutOfBoundsException {
        this._interventionTypeList.addElement(vInterventionType);
    }

    /**
     * 
     * 
     * @param index
     * @param vInterventionType
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addInterventionType(
            final int index,
            final java.lang.String vInterventionType)
    throws java.lang.IndexOutOfBoundsException {
        this._interventionTypeList.add(index, vInterventionType);
    }

    /**
     * 
     * 
     * @param vLanguage
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addLanguage(
            final java.lang.String vLanguage)
    throws java.lang.IndexOutOfBoundsException {
        this._languageList.addElement(vLanguage);
    }

    /**
     * 
     * 
     * @param index
     * @param vLanguage
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addLanguage(
            final int index,
            final java.lang.String vLanguage)
    throws java.lang.IndexOutOfBoundsException {
        this._languageList.add(index, vLanguage);
    }

    /**
     * 
     * 
     * @param vMethod
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addMethod(
            final java.lang.String vMethod)
    throws java.lang.IndexOutOfBoundsException {
        this._methodList.addElement(vMethod);
    }

    /**
     * 
     * 
     * @param index
     * @param vMethod
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addMethod(
            final int index,
            final java.lang.String vMethod)
    throws java.lang.IndexOutOfBoundsException {
        this._methodList.add(index, vMethod);
    }

    /**
     * 
     * 
     * @param vSite
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addSite(
            final java.lang.String vSite)
    throws java.lang.IndexOutOfBoundsException {
        this._siteList.addElement(vSite);
    }

    /**
     * 
     * 
     * @param index
     * @param vSite
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addSite(
            final int index,
            final java.lang.String vSite)
    throws java.lang.IndexOutOfBoundsException {
        this._siteList.add(index, vSite);
    }

    /**
     * 
     * 
     * @param vTaskDetail
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addTaskDetail(
            final turbomeca.gamme.assembly.services.model.data.TaskDetail vTaskDetail)
    throws java.lang.IndexOutOfBoundsException {
        this._taskDetailList.addElement(vTaskDetail);
    }

    /**
     * 
     * 
     * @param index
     * @param vTaskDetail
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addTaskDetail(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.TaskDetail vTaskDetail)
    throws java.lang.IndexOutOfBoundsException {
        this._taskDetailList.add(index, vTaskDetail);
    }

    /**
     * 
     * 
     * @param vTitle
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addTitle(
            final turbomeca.gamme.assembly.services.model.data.Title vTitle)
    throws java.lang.IndexOutOfBoundsException {
        this._titleList.addElement(vTitle);
    }

    /**
     * 
     * 
     * @param index
     * @param vTitle
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addTitle(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.Title vTitle)
    throws java.lang.IndexOutOfBoundsException {
        this._titleList.add(index, vTitle);
    }

    /**
     * 
     * 
     * @param vVariant
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addVariant(
            final java.lang.String vVariant)
    throws java.lang.IndexOutOfBoundsException {
        this._variantList.addElement(vVariant);
    }

    /**
     * 
     * 
     * @param index
     * @param vVariant
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addVariant(
            final int index,
            final java.lang.String vVariant)
    throws java.lang.IndexOutOfBoundsException {
        this._variantList.add(index, vVariant);
    }

    /**
     * Method enumerateEffectivity.
     * 
     * @return an Enumeration over all java.lang.String elements
     */
    public java.util.Enumeration<? extends java.lang.String> enumerateEffectivity(
    ) {
        return this._effectivityList.elements();
    }

    /**
     * Method enumerateInterventionType.
     * 
     * @return an Enumeration over all java.lang.String elements
     */
    public java.util.Enumeration<? extends java.lang.String> enumerateInterventionType(
    ) {
        return this._interventionTypeList.elements();
    }

    /**
     * Method enumerateLanguage.
     * 
     * @return an Enumeration over all java.lang.String elements
     */
    public java.util.Enumeration<? extends java.lang.String> enumerateLanguage(
    ) {
        return this._languageList.elements();
    }

    /**
     * Method enumerateMethod.
     * 
     * @return an Enumeration over all java.lang.String elements
     */
    public java.util.Enumeration<? extends java.lang.String> enumerateMethod(
    ) {
        return this._methodList.elements();
    }

    /**
     * Method enumerateSite.
     * 
     * @return an Enumeration over all java.lang.String elements
     */
    public java.util.Enumeration<? extends java.lang.String> enumerateSite(
    ) {
        return this._siteList.elements();
    }

    /**
     * Method enumerateTaskDetail.
     * 
     * @return an Enumeration over all
     * turbomeca.gamme.assembly.services.model.data.TaskDetail
     * elements
     */
    public java.util.Enumeration<? extends turbomeca.gamme.assembly.services.model.data.TaskDetail> enumerateTaskDetail(
    ) {
        return this._taskDetailList.elements();
    }

    /**
     * Method enumerateTitle.
     * 
     * @return an Enumeration over all
     * turbomeca.gamme.assembly.services.model.data.Title elements
     */
    public java.util.Enumeration<? extends turbomeca.gamme.assembly.services.model.data.Title> enumerateTitle(
    ) {
        return this._titleList.elements();
    }

    /**
     * Method enumerateVariant.
     * 
     * @return an Enumeration over all java.lang.String elements
     */
    public java.util.Enumeration<? extends java.lang.String> enumerateVariant(
    ) {
        return this._variantList.elements();
    }

    /**
     * Method getEffectivity.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the java.lang.String at the given index
     */
    public java.lang.String getEffectivity(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._effectivityList.size()) {
            throw new IndexOutOfBoundsException("getEffectivity: Index value '" + index + "' not in range [0.." + (this._effectivityList.size() - 1) + "]");
        }

        return (java.lang.String) _effectivityList.get(index);
    }

    /**
     * Method getEffectivity.Returns the contents of the collection
     * in an Array.  <p>Note:  Just in case the collection contents
     * are changing in another thread, we pass a 0-length Array of
     * the correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public java.lang.String[] getEffectivity(
    ) {
        java.lang.String[] array = new java.lang.String[0];
        return (java.lang.String[]) this._effectivityList.toArray(array);
    }

    /**
     * Method getEffectivityAsReference.Returns a reference to
     * '_effectivityList'. No type checking is performed on any
     * modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<java.lang.String> getEffectivityAsReference(
    ) {
        return this._effectivityList;
    }

    /**
     * Method getEffectivityCount.
     * 
     * @return the size of this collection
     */
    public int getEffectivityCount(
    ) {
        return this._effectivityList.size();
    }

    /**
     * Returns the value of field 'fictiveEngine'.
     * 
     * @return the value of field 'FictiveEngine'.
     */
    public turbomeca.gamme.assembly.services.model.data.types.BooleanType getFictiveEngine(
    ) {
        return this._fictiveEngine;
    }

    /**
     * Method getInterventionType.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the java.lang.String at the given index
     */
    public java.lang.String getInterventionType(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._interventionTypeList.size()) {
            throw new IndexOutOfBoundsException("getInterventionType: Index value '" + index + "' not in range [0.." + (this._interventionTypeList.size() - 1) + "]");
        }

        return (java.lang.String) _interventionTypeList.get(index);
    }

    /**
     * Method getInterventionType.Returns the contents of the
     * collection in an Array.  <p>Note:  Just in case the
     * collection contents are changing in another thread, we pass
     * a 0-length Array of the correct type into the API call. 
     * This way we <i>know</i> that the Array returned is of
     * exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public java.lang.String[] getInterventionType(
    ) {
        java.lang.String[] array = new java.lang.String[0];
        return (java.lang.String[]) this._interventionTypeList.toArray(array);
    }

    /**
     * Method getInterventionTypeAsReference.Returns a reference to
     * '_interventionTypeList'. No type checking is performed on
     * any modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<java.lang.String> getInterventionTypeAsReference(
    ) {
        return this._interventionTypeList;
    }

    /**
     * Method getInterventionTypeCount.
     * 
     * @return the size of this collection
     */
    public int getInterventionTypeCount(
    ) {
        return this._interventionTypeList.size();
    }

    /**
     * Returns the value of field 'isolatedModule'.
     * 
     * @return the value of field 'IsolatedModule'.
     */
    public turbomeca.gamme.assembly.services.model.data.types.BooleanType getIsolatedModule(
    ) {
        return this._isolatedModule;
    }

    /**
     * Method getLanguage.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the java.lang.String at the given index
     */
    public java.lang.String getLanguage(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._languageList.size()) {
            throw new IndexOutOfBoundsException("getLanguage: Index value '" + index + "' not in range [0.." + (this._languageList.size() - 1) + "]");
        }

        return (java.lang.String) _languageList.get(index);
    }

    /**
     * Method getLanguage.Returns the contents of the collection in
     * an Array.  <p>Note:  Just in case the collection contents
     * are changing in another thread, we pass a 0-length Array of
     * the correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public java.lang.String[] getLanguage(
    ) {
        java.lang.String[] array = new java.lang.String[0];
        return (java.lang.String[]) this._languageList.toArray(array);
    }

    /**
     * Method getLanguageAsReference.Returns a reference to
     * '_languageList'. No type checking is performed on any
     * modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<java.lang.String> getLanguageAsReference(
    ) {
        return this._languageList;
    }

    /**
     * Method getLanguageCount.
     * 
     * @return the size of this collection
     */
    public int getLanguageCount(
    ) {
        return this._languageList.size();
    }

    /**
     * Method getMethod.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the java.lang.String at the given index
     */
    public java.lang.String getMethod(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._methodList.size()) {
            throw new IndexOutOfBoundsException("getMethod: Index value '" + index + "' not in range [0.." + (this._methodList.size() - 1) + "]");
        }

        return (java.lang.String) _methodList.get(index);
    }

    /**
     * Method getMethod.Returns the contents of the collection in
     * an Array.  <p>Note:  Just in case the collection contents
     * are changing in another thread, we pass a 0-length Array of
     * the correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public java.lang.String[] getMethod(
    ) {
        java.lang.String[] array = new java.lang.String[0];
        return (java.lang.String[]) this._methodList.toArray(array);
    }

    /**
     * Method getMethodAsReference.Returns a reference to
     * '_methodList'. No type checking is performed on any
     * modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<java.lang.String> getMethodAsReference(
    ) {
        return this._methodList;
    }

    /**
     * Method getMethodCount.
     * 
     * @return the size of this collection
     */
    public int getMethodCount(
    ) {
        return this._methodList.size();
    }

    /**
     * Returns the value of field 'sap'.
     * 
     * @return the value of field 'Sap'.
     */
    public turbomeca.gamme.assembly.services.model.data.types.BooleanType getSap(
    ) {
        return this._sap;
    }

    /**
     * Method getSite.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the java.lang.String at the given index
     */
    public java.lang.String getSite(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._siteList.size()) {
            throw new IndexOutOfBoundsException("getSite: Index value '" + index + "' not in range [0.." + (this._siteList.size() - 1) + "]");
        }

        return (java.lang.String) _siteList.get(index);
    }

    /**
     * Method getSite.Returns the contents of the collection in an
     * Array.  <p>Note:  Just in case the collection contents are
     * changing in another thread, we pass a 0-length Array of the
     * correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public java.lang.String[] getSite(
    ) {
        java.lang.String[] array = new java.lang.String[0];
        return (java.lang.String[]) this._siteList.toArray(array);
    }

    /**
     * Method getSiteAsReference.Returns a reference to
     * '_siteList'. No type checking is performed on any
     * modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<java.lang.String> getSiteAsReference(
    ) {
        return this._siteList;
    }

    /**
     * Method getSiteCount.
     * 
     * @return the size of this collection
     */
    public int getSiteCount(
    ) {
        return this._siteList.size();
    }

    /**
     * Method getTaskDetail.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * turbomeca.gamme.assembly.services.model.data.TaskDetail at
     * the given index
     */
    public turbomeca.gamme.assembly.services.model.data.TaskDetail getTaskDetail(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._taskDetailList.size()) {
            throw new IndexOutOfBoundsException("getTaskDetail: Index value '" + index + "' not in range [0.." + (this._taskDetailList.size() - 1) + "]");
        }

        return (turbomeca.gamme.assembly.services.model.data.TaskDetail) _taskDetailList.get(index);
    }

    /**
     * Method getTaskDetail.Returns the contents of the collection
     * in an Array.  <p>Note:  Just in case the collection contents
     * are changing in another thread, we pass a 0-length Array of
     * the correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public turbomeca.gamme.assembly.services.model.data.TaskDetail[] getTaskDetail(
    ) {
        turbomeca.gamme.assembly.services.model.data.TaskDetail[] array = new turbomeca.gamme.assembly.services.model.data.TaskDetail[0];
        return (turbomeca.gamme.assembly.services.model.data.TaskDetail[]) this._taskDetailList.toArray(array);
    }

    /**
     * Method getTaskDetailAsReference.Returns a reference to
     * '_taskDetailList'. No type checking is performed on any
     * modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<turbomeca.gamme.assembly.services.model.data.TaskDetail> getTaskDetailAsReference(
    ) {
        return this._taskDetailList;
    }

    /**
     * Method getTaskDetailCount.
     * 
     * @return the size of this collection
     */
    public int getTaskDetailCount(
    ) {
        return this._taskDetailList.size();
    }

    /**
     * Method getTitle.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * turbomeca.gamme.assembly.services.model.data.Title at the
     * given index
     */
    public turbomeca.gamme.assembly.services.model.data.Title getTitle(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._titleList.size()) {
            throw new IndexOutOfBoundsException("getTitle: Index value '" + index + "' not in range [0.." + (this._titleList.size() - 1) + "]");
        }

        return (turbomeca.gamme.assembly.services.model.data.Title) _titleList.get(index);
    }

    /**
     * Method getTitle.Returns the contents of the collection in an
     * Array.  <p>Note:  Just in case the collection contents are
     * changing in another thread, we pass a 0-length Array of the
     * correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public turbomeca.gamme.assembly.services.model.data.Title[] getTitle(
    ) {
        turbomeca.gamme.assembly.services.model.data.Title[] array = new turbomeca.gamme.assembly.services.model.data.Title[0];
        return (turbomeca.gamme.assembly.services.model.data.Title[]) this._titleList.toArray(array);
    }

    /**
     * Method getTitleAsReference.Returns a reference to
     * '_titleList'. No type checking is performed on any
     * modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<turbomeca.gamme.assembly.services.model.data.Title> getTitleAsReference(
    ) {
        return this._titleList;
    }

    /**
     * Method getTitleCount.
     * 
     * @return the size of this collection
     */
    public int getTitleCount(
    ) {
        return this._titleList.size();
    }

    /**
     * Method getVariant.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the java.lang.String at the given index
     */
    public java.lang.String getVariant(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._variantList.size()) {
            throw new IndexOutOfBoundsException("getVariant: Index value '" + index + "' not in range [0.." + (this._variantList.size() - 1) + "]");
        }

        return (java.lang.String) _variantList.get(index);
    }

    /**
     * Method getVariant.Returns the contents of the collection in
     * an Array.  <p>Note:  Just in case the collection contents
     * are changing in another thread, we pass a 0-length Array of
     * the correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public java.lang.String[] getVariant(
    ) {
        java.lang.String[] array = new java.lang.String[0];
        return (java.lang.String[]) this._variantList.toArray(array);
    }

    /**
     * Method getVariantAsReference.Returns a reference to
     * '_variantList'. No type checking is performed on any
     * modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<java.lang.String> getVariantAsReference(
    ) {
        return this._variantList;
    }

    /**
     * Method getVariantCount.
     * 
     * @return the size of this collection
     */
    public int getVariantCount(
    ) {
        return this._variantList.size();
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllEffectivity(
    ) {
        this._effectivityList.clear();
    }

    /**
     */
    public void removeAllInterventionType(
    ) {
        this._interventionTypeList.clear();
    }

    /**
     */
    public void removeAllLanguage(
    ) {
        this._languageList.clear();
    }

    /**
     */
    public void removeAllMethod(
    ) {
        this._methodList.clear();
    }

    /**
     */
    public void removeAllSite(
    ) {
        this._siteList.clear();
    }

    /**
     */
    public void removeAllTaskDetail(
    ) {
        this._taskDetailList.clear();
    }

    /**
     */
    public void removeAllTitle(
    ) {
        this._titleList.clear();
    }

    /**
     */
    public void removeAllVariant(
    ) {
        this._variantList.clear();
    }

    /**
     * Method removeEffectivity.
     * 
     * @param vEffectivity
     * @return true if the object was removed from the collection.
     */
    public boolean removeEffectivity(
            final java.lang.String vEffectivity) {
        boolean removed = _effectivityList.remove(vEffectivity);
        return removed;
    }

    /**
     * Method removeEffectivityAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public java.lang.String removeEffectivityAt(
            final int index) {
        java.lang.Object obj = this._effectivityList.remove(index);
        return (java.lang.String) obj;
    }

    /**
     * Method removeInterventionType.
     * 
     * @param vInterventionType
     * @return true if the object was removed from the collection.
     */
    public boolean removeInterventionType(
            final java.lang.String vInterventionType) {
        boolean removed = _interventionTypeList.remove(vInterventionType);
        return removed;
    }

    /**
     * Method removeInterventionTypeAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public java.lang.String removeInterventionTypeAt(
            final int index) {
        java.lang.Object obj = this._interventionTypeList.remove(index);
        return (java.lang.String) obj;
    }

    /**
     * Method removeLanguage.
     * 
     * @param vLanguage
     * @return true if the object was removed from the collection.
     */
    public boolean removeLanguage(
            final java.lang.String vLanguage) {
        boolean removed = _languageList.remove(vLanguage);
        return removed;
    }

    /**
     * Method removeLanguageAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public java.lang.String removeLanguageAt(
            final int index) {
        java.lang.Object obj = this._languageList.remove(index);
        return (java.lang.String) obj;
    }

    /**
     * Method removeMethod.
     * 
     * @param vMethod
     * @return true if the object was removed from the collection.
     */
    public boolean removeMethod(
            final java.lang.String vMethod) {
        boolean removed = _methodList.remove(vMethod);
        return removed;
    }

    /**
     * Method removeMethodAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public java.lang.String removeMethodAt(
            final int index) {
        java.lang.Object obj = this._methodList.remove(index);
        return (java.lang.String) obj;
    }

    /**
     * Method removeSite.
     * 
     * @param vSite
     * @return true if the object was removed from the collection.
     */
    public boolean removeSite(
            final java.lang.String vSite) {
        boolean removed = _siteList.remove(vSite);
        return removed;
    }

    /**
     * Method removeSiteAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public java.lang.String removeSiteAt(
            final int index) {
        java.lang.Object obj = this._siteList.remove(index);
        return (java.lang.String) obj;
    }

    /**
     * Method removeTaskDetail.
     * 
     * @param vTaskDetail
     * @return true if the object was removed from the collection.
     */
    public boolean removeTaskDetail(
            final turbomeca.gamme.assembly.services.model.data.TaskDetail vTaskDetail) {
        boolean removed = _taskDetailList.remove(vTaskDetail);
        return removed;
    }

    /**
     * Method removeTaskDetailAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public turbomeca.gamme.assembly.services.model.data.TaskDetail removeTaskDetailAt(
            final int index) {
        java.lang.Object obj = this._taskDetailList.remove(index);
        return (turbomeca.gamme.assembly.services.model.data.TaskDetail) obj;
    }

    /**
     * Method removeTitle.
     * 
     * @param vTitle
     * @return true if the object was removed from the collection.
     */
    public boolean removeTitle(
            final turbomeca.gamme.assembly.services.model.data.Title vTitle) {
        boolean removed = _titleList.remove(vTitle);
        return removed;
    }

    /**
     * Method removeTitleAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public turbomeca.gamme.assembly.services.model.data.Title removeTitleAt(
            final int index) {
        java.lang.Object obj = this._titleList.remove(index);
        return (turbomeca.gamme.assembly.services.model.data.Title) obj;
    }

    /**
     * Method removeVariant.
     * 
     * @param vVariant
     * @return true if the object was removed from the collection.
     */
    public boolean removeVariant(
            final java.lang.String vVariant) {
        boolean removed = _variantList.remove(vVariant);
        return removed;
    }

    /**
     * Method removeVariantAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public java.lang.String removeVariantAt(
            final int index) {
        java.lang.Object obj = this._variantList.remove(index);
        return (java.lang.String) obj;
    }

    /**
     * 
     * 
     * @param index
     * @param vEffectivity
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setEffectivity(
            final int index,
            final java.lang.String vEffectivity)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._effectivityList.size()) {
            throw new IndexOutOfBoundsException("setEffectivity: Index value '" + index + "' not in range [0.." + (this._effectivityList.size() - 1) + "]");
        }

        this._effectivityList.set(index, vEffectivity);
    }

    /**
     * 
     * 
     * @param vEffectivityArray
     */
    public void setEffectivity(
            final java.lang.String[] vEffectivityArray) {
        //-- copy array
        _effectivityList.clear();

        for (int i = 0; i < vEffectivityArray.length; i++) {
                this._effectivityList.add(vEffectivityArray[i]);
        }
    }

    /**
     * Sets the value of '_effectivityList' by copying the given
     * Vector. All elements will be checked for type safety.
     * 
     * @param vEffectivityList the Vector to copy.
     */
    public void setEffectivity(
            final java.util.Vector<java.lang.String> vEffectivityList) {
        // copy vector
        this._effectivityList.clear();

        this._effectivityList.addAll(vEffectivityList);
    }

    /**
     * Sets the value of '_effectivityList' by setting it to the
     * given Vector. No type checking is performed.
     * @deprecated
     * 
     * @param effectivityVector the Vector to set.
     */
    public void setEffectivityAsReference(
            final java.util.Vector<java.lang.String> effectivityVector) {
        this._effectivityList = effectivityVector;
    }

    /**
     * Sets the value of field 'fictiveEngine'.
     * 
     * @param fictiveEngine the value of field 'fictiveEngine'.
     */
    public void setFictiveEngine(
            final turbomeca.gamme.assembly.services.model.data.types.BooleanType fictiveEngine) {
        this._fictiveEngine = fictiveEngine;
    }

    /**
     * 
     * 
     * @param index
     * @param vInterventionType
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setInterventionType(
            final int index,
            final java.lang.String vInterventionType)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._interventionTypeList.size()) {
            throw new IndexOutOfBoundsException("setInterventionType: Index value '" + index + "' not in range [0.." + (this._interventionTypeList.size() - 1) + "]");
        }

        this._interventionTypeList.set(index, vInterventionType);
    }

    /**
     * 
     * 
     * @param vInterventionTypeArray
     */
    public void setInterventionType(
            final java.lang.String[] vInterventionTypeArray) {
        //-- copy array
        _interventionTypeList.clear();

        for (int i = 0; i < vInterventionTypeArray.length; i++) {
                this._interventionTypeList.add(vInterventionTypeArray[i]);
        }
    }

    /**
     * Sets the value of '_interventionTypeList' by copying the
     * given Vector. All elements will be checked for type safety.
     * 
     * @param vInterventionTypeList the Vector to copy.
     */
    public void setInterventionType(
            final java.util.Vector<java.lang.String> vInterventionTypeList) {
        // copy vector
        this._interventionTypeList.clear();

        this._interventionTypeList.addAll(vInterventionTypeList);
    }

    /**
     * Sets the value of '_interventionTypeList' by setting it to
     * the given Vector. No type checking is performed.
     * @deprecated
     * 
     * @param interventionTypeVector the Vector to set.
     */
    public void setInterventionTypeAsReference(
            final java.util.Vector<java.lang.String> interventionTypeVector) {
        this._interventionTypeList = interventionTypeVector;
    }

    /**
     * Sets the value of field 'isolatedModule'.
     * 
     * @param isolatedModule the value of field 'isolatedModule'.
     */
    public void setIsolatedModule(
            final turbomeca.gamme.assembly.services.model.data.types.BooleanType isolatedModule) {
        this._isolatedModule = isolatedModule;
    }

    /**
     * 
     * 
     * @param index
     * @param vLanguage
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setLanguage(
            final int index,
            final java.lang.String vLanguage)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._languageList.size()) {
            throw new IndexOutOfBoundsException("setLanguage: Index value '" + index + "' not in range [0.." + (this._languageList.size() - 1) + "]");
        }

        this._languageList.set(index, vLanguage);
    }

    /**
     * 
     * 
     * @param vLanguageArray
     */
    public void setLanguage(
            final java.lang.String[] vLanguageArray) {
        //-- copy array
        _languageList.clear();

        for (int i = 0; i < vLanguageArray.length; i++) {
                this._languageList.add(vLanguageArray[i]);
        }
    }

    /**
     * Sets the value of '_languageList' by copying the given
     * Vector. All elements will be checked for type safety.
     * 
     * @param vLanguageList the Vector to copy.
     */
    public void setLanguage(
            final java.util.Vector<java.lang.String> vLanguageList) {
        // copy vector
        this._languageList.clear();

        this._languageList.addAll(vLanguageList);
    }

    /**
     * Sets the value of '_languageList' by setting it to the given
     * Vector. No type checking is performed.
     * @deprecated
     * 
     * @param languageVector the Vector to set.
     */
    public void setLanguageAsReference(
            final java.util.Vector<java.lang.String> languageVector) {
        this._languageList = languageVector;
    }

    /**
     * 
     * 
     * @param index
     * @param vMethod
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setMethod(
            final int index,
            final java.lang.String vMethod)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._methodList.size()) {
            throw new IndexOutOfBoundsException("setMethod: Index value '" + index + "' not in range [0.." + (this._methodList.size() - 1) + "]");
        }

        this._methodList.set(index, vMethod);
    }

    /**
     * 
     * 
     * @param vMethodArray
     */
    public void setMethod(
            final java.lang.String[] vMethodArray) {
        //-- copy array
        _methodList.clear();

        for (int i = 0; i < vMethodArray.length; i++) {
                this._methodList.add(vMethodArray[i]);
        }
    }

    /**
     * Sets the value of '_methodList' by copying the given Vector.
     * All elements will be checked for type safety.
     * 
     * @param vMethodList the Vector to copy.
     */
    public void setMethod(
            final java.util.Vector<java.lang.String> vMethodList) {
        // copy vector
        this._methodList.clear();

        this._methodList.addAll(vMethodList);
    }

    /**
     * Sets the value of '_methodList' by setting it to the given
     * Vector. No type checking is performed.
     * @deprecated
     * 
     * @param methodVector the Vector to set.
     */
    public void setMethodAsReference(
            final java.util.Vector<java.lang.String> methodVector) {
        this._methodList = methodVector;
    }

    /**
     * Sets the value of field 'sap'.
     * 
     * @param sap the value of field 'sap'.
     */
    public void setSap(
            final turbomeca.gamme.assembly.services.model.data.types.BooleanType sap) {
        this._sap = sap;
    }

    /**
     * 
     * 
     * @param index
     * @param vSite
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setSite(
            final int index,
            final java.lang.String vSite)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._siteList.size()) {
            throw new IndexOutOfBoundsException("setSite: Index value '" + index + "' not in range [0.." + (this._siteList.size() - 1) + "]");
        }

        this._siteList.set(index, vSite);
    }

    /**
     * 
     * 
     * @param vSiteArray
     */
    public void setSite(
            final java.lang.String[] vSiteArray) {
        //-- copy array
        _siteList.clear();

        for (int i = 0; i < vSiteArray.length; i++) {
                this._siteList.add(vSiteArray[i]);
        }
    }

    /**
     * Sets the value of '_siteList' by copying the given Vector.
     * All elements will be checked for type safety.
     * 
     * @param vSiteList the Vector to copy.
     */
    public void setSite(
            final java.util.Vector<java.lang.String> vSiteList) {
        // copy vector
        this._siteList.clear();

        this._siteList.addAll(vSiteList);
    }

    /**
     * Sets the value of '_siteList' by setting it to the given
     * Vector. No type checking is performed.
     * @deprecated
     * 
     * @param siteVector the Vector to set.
     */
    public void setSiteAsReference(
            final java.util.Vector<java.lang.String> siteVector) {
        this._siteList = siteVector;
    }

    /**
     * 
     * 
     * @param index
     * @param vTaskDetail
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setTaskDetail(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.TaskDetail vTaskDetail)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._taskDetailList.size()) {
            throw new IndexOutOfBoundsException("setTaskDetail: Index value '" + index + "' not in range [0.." + (this._taskDetailList.size() - 1) + "]");
        }

        this._taskDetailList.set(index, vTaskDetail);
    }

    /**
     * 
     * 
     * @param vTaskDetailArray
     */
    public void setTaskDetail(
            final turbomeca.gamme.assembly.services.model.data.TaskDetail[] vTaskDetailArray) {
        //-- copy array
        _taskDetailList.clear();

        for (int i = 0; i < vTaskDetailArray.length; i++) {
                this._taskDetailList.add(vTaskDetailArray[i]);
        }
    }

    /**
     * Sets the value of '_taskDetailList' by copying the given
     * Vector. All elements will be checked for type safety.
     * 
     * @param vTaskDetailList the Vector to copy.
     */
    public void setTaskDetail(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.TaskDetail> vTaskDetailList) {
        // copy vector
        this._taskDetailList.clear();

        this._taskDetailList.addAll(vTaskDetailList);
    }

    /**
     * Sets the value of '_taskDetailList' by setting it to the
     * given Vector. No type checking is performed.
     * @deprecated
     * 
     * @param taskDetailVector the Vector to set.
     */
    public void setTaskDetailAsReference(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.TaskDetail> taskDetailVector) {
        this._taskDetailList = taskDetailVector;
    }

    /**
     * 
     * 
     * @param index
     * @param vTitle
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setTitle(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.Title vTitle)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._titleList.size()) {
            throw new IndexOutOfBoundsException("setTitle: Index value '" + index + "' not in range [0.." + (this._titleList.size() - 1) + "]");
        }

        this._titleList.set(index, vTitle);
    }

    /**
     * 
     * 
     * @param vTitleArray
     */
    public void setTitle(
            final turbomeca.gamme.assembly.services.model.data.Title[] vTitleArray) {
        //-- copy array
        _titleList.clear();

        for (int i = 0; i < vTitleArray.length; i++) {
                this._titleList.add(vTitleArray[i]);
        }
    }

    /**
     * Sets the value of '_titleList' by copying the given Vector.
     * All elements will be checked for type safety.
     * 
     * @param vTitleList the Vector to copy.
     */
    public void setTitle(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.Title> vTitleList) {
        // copy vector
        this._titleList.clear();

        this._titleList.addAll(vTitleList);
    }

    /**
     * Sets the value of '_titleList' by setting it to the given
     * Vector. No type checking is performed.
     * @deprecated
     * 
     * @param titleVector the Vector to set.
     */
    public void setTitleAsReference(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.Title> titleVector) {
        this._titleList = titleVector;
    }

    /**
     * 
     * 
     * @param index
     * @param vVariant
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setVariant(
            final int index,
            final java.lang.String vVariant)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._variantList.size()) {
            throw new IndexOutOfBoundsException("setVariant: Index value '" + index + "' not in range [0.." + (this._variantList.size() - 1) + "]");
        }

        this._variantList.set(index, vVariant);
    }

    /**
     * 
     * 
     * @param vVariantArray
     */
    public void setVariant(
            final java.lang.String[] vVariantArray) {
        //-- copy array
        _variantList.clear();

        for (int i = 0; i < vVariantArray.length; i++) {
                this._variantList.add(vVariantArray[i]);
        }
    }

    /**
     * Sets the value of '_variantList' by copying the given
     * Vector. All elements will be checked for type safety.
     * 
     * @param vVariantList the Vector to copy.
     */
    public void setVariant(
            final java.util.Vector<java.lang.String> vVariantList) {
        // copy vector
        this._variantList.clear();

        this._variantList.addAll(vVariantList);
    }

    /**
     * Sets the value of '_variantList' by setting it to the given
     * Vector. No type checking is performed.
     * @deprecated
     * 
     * @param variantVector the Vector to set.
     */
    public void setVariantAsReference(
            final java.util.Vector<java.lang.String> variantVector) {
        this._variantList = variantVector;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.Generality
     */
    public static turbomeca.gamme.assembly.services.model.data.Generality unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.Generality) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.Generality.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
