/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class ScheduleType.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class ScheduleType implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _key.
     */
    private java.lang.String _key;

    /**
     * Field _version.
     */
    private int _version;

    /**
     * keeps track of state for field: _version
     */
    private boolean _has_version;

    /**
     * Field _type.
     */
    private turbomeca.gamme.assembly.services.model.data.types.ContextType _type;

    /**
     * Field _suffix.
     */
    private java.lang.String _suffix;

    /**
     * Field _identification.
     */
    private turbomeca.gamme.assembly.services.model.data.Identification _identification;

    /**
     * Field _authors.
     */
    private turbomeca.gamme.assembly.services.model.data.Authors _authors;

    /**
     * Field _qualifications.
     */
    private turbomeca.gamme.assembly.services.model.data.Qualifications _qualifications;

    /**
     * Field _observations.
     */
    private turbomeca.gamme.assembly.services.model.data.Observations _observations;

    /**
     * Field _historical.
     */
    private turbomeca.gamme.assembly.services.model.data.Historical _historical;

    /**
     * Field _parameters.
     */
    private turbomeca.gamme.assembly.services.model.data.Parameters _parameters;

    /**
     * Field _documents.
     */
    private turbomeca.gamme.assembly.services.model.data.Documents _documents;

    /**
     * Field _preGeneralities.
     */
    private turbomeca.gamme.assembly.services.model.data.PreGeneralities _preGeneralities;

    /**
     * Field _deviationsFromRefList.
     */
    private java.util.Vector<turbomeca.gamme.assembly.services.model.data.DeviationsFromRef> _deviationsFromRefList;

    /**
     * Field _compounds.
     */
    private turbomeca.gamme.assembly.services.model.data.Compounds _compounds;

    /**
     * Field _objectsToSynchronize.
     */
    private turbomeca.gamme.assembly.services.model.data.ObjectsToSynchronize _objectsToSynchronize;

    /**
     * Field _instanciation.
     */
    private turbomeca.gamme.assembly.services.model.data.Instanciation _instanciation;

    /**
     * Container to store user mark and user comments associated
     * with each new passing action
     *  
     */
    private turbomeca.gamme.assembly.services.model.data.HistoricalPassing _historicalPassing;

    /**
     * Field _electronicPostIt.
     */
    private turbomeca.gamme.assembly.services.model.data.ElectronicPostIt _electronicPostIt;

    /**
     * Field _derogationMarks.
     */
    private turbomeca.gamme.assembly.services.model.data.DerogationMarks _derogationMarks;

    /**
     * Field _operations.
     */
    private turbomeca.gamme.assembly.services.model.data.Operations _operations;

    /**
     * Field _postGeneralities.
     */
    private turbomeca.gamme.assembly.services.model.data.PostGeneralities _postGeneralities;

    /**
     * Field _rework.
     */
    private turbomeca.gamme.assembly.services.model.data.Rework _rework;


      //----------------/
     //- Constructors -/
    //----------------/

    public ScheduleType() {
        super();
        this._deviationsFromRefList = new java.util.Vector<turbomeca.gamme.assembly.services.model.data.DeviationsFromRef>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vDeviationsFromRef
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addDeviationsFromRef(
            final turbomeca.gamme.assembly.services.model.data.DeviationsFromRef vDeviationsFromRef)
    throws java.lang.IndexOutOfBoundsException {
        this._deviationsFromRefList.addElement(vDeviationsFromRef);
    }

    /**
     * 
     * 
     * @param index
     * @param vDeviationsFromRef
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addDeviationsFromRef(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.DeviationsFromRef vDeviationsFromRef)
    throws java.lang.IndexOutOfBoundsException {
        this._deviationsFromRefList.add(index, vDeviationsFromRef);
    }

    /**
     */
    public void deleteVersion(
    ) {
        this._has_version= false;
    }

    /**
     * Method enumerateDeviationsFromRef.
     * 
     * @return an Enumeration over all
     * turbomeca.gamme.assembly.services.model.data.DeviationsFromRef
     * elements
     */
    public java.util.Enumeration<? extends turbomeca.gamme.assembly.services.model.data.DeviationsFromRef> enumerateDeviationsFromRef(
    ) {
        return this._deviationsFromRefList.elements();
    }

    /**
     * Returns the value of field 'authors'.
     * 
     * @return the value of field 'Authors'.
     */
    public turbomeca.gamme.assembly.services.model.data.Authors getAuthors(
    ) {
        return this._authors;
    }

    /**
     * Returns the value of field 'compounds'.
     * 
     * @return the value of field 'Compounds'.
     */
    public turbomeca.gamme.assembly.services.model.data.Compounds getCompounds(
    ) {
        return this._compounds;
    }

    /**
     * Returns the value of field 'derogationMarks'.
     * 
     * @return the value of field 'DerogationMarks'.
     */
    public turbomeca.gamme.assembly.services.model.data.DerogationMarks getDerogationMarks(
    ) {
        return this._derogationMarks;
    }

    /**
     * Method getDeviationsFromRef.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * turbomeca.gamme.assembly.services.model.data.DeviationsFromRef
     * at the given index
     */
    public turbomeca.gamme.assembly.services.model.data.DeviationsFromRef getDeviationsFromRef(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._deviationsFromRefList.size()) {
            throw new IndexOutOfBoundsException("getDeviationsFromRef: Index value '" + index + "' not in range [0.." + (this._deviationsFromRefList.size() - 1) + "]");
        }

        return (turbomeca.gamme.assembly.services.model.data.DeviationsFromRef) _deviationsFromRefList.get(index);
    }

    /**
     * Method getDeviationsFromRef.Returns the contents of the
     * collection in an Array.  <p>Note:  Just in case the
     * collection contents are changing in another thread, we pass
     * a 0-length Array of the correct type into the API call. 
     * This way we <i>know</i> that the Array returned is of
     * exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public turbomeca.gamme.assembly.services.model.data.DeviationsFromRef[] getDeviationsFromRef(
    ) {
        turbomeca.gamme.assembly.services.model.data.DeviationsFromRef[] array = new turbomeca.gamme.assembly.services.model.data.DeviationsFromRef[0];
        return (turbomeca.gamme.assembly.services.model.data.DeviationsFromRef[]) this._deviationsFromRefList.toArray(array);
    }

    /**
     * Method getDeviationsFromRefAsReference.Returns a reference
     * to '_deviationsFromRefList'. No type checking is performed
     * on any modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<turbomeca.gamme.assembly.services.model.data.DeviationsFromRef> getDeviationsFromRefAsReference(
    ) {
        return this._deviationsFromRefList;
    }

    /**
     * Method getDeviationsFromRefCount.
     * 
     * @return the size of this collection
     */
    public int getDeviationsFromRefCount(
    ) {
        return this._deviationsFromRefList.size();
    }

    /**
     * Returns the value of field 'documents'.
     * 
     * @return the value of field 'Documents'.
     */
    public turbomeca.gamme.assembly.services.model.data.Documents getDocuments(
    ) {
        return this._documents;
    }

    /**
     * Returns the value of field 'electronicPostIt'.
     * 
     * @return the value of field 'ElectronicPostIt'.
     */
    public turbomeca.gamme.assembly.services.model.data.ElectronicPostIt getElectronicPostIt(
    ) {
        return this._electronicPostIt;
    }

    /**
     * Returns the value of field 'historical'.
     * 
     * @return the value of field 'Historical'.
     */
    public turbomeca.gamme.assembly.services.model.data.Historical getHistorical(
    ) {
        return this._historical;
    }

    /**
     * Returns the value of field 'historicalPassing'. The field
     * 'historicalPassing' has the following description: Container
     * to store user mark and user comments associated with each
     * new passing action
     *  
     * 
     * @return the value of field 'HistoricalPassing'.
     */
    public turbomeca.gamme.assembly.services.model.data.HistoricalPassing getHistoricalPassing(
    ) {
        return this._historicalPassing;
    }

    /**
     * Returns the value of field 'identification'.
     * 
     * @return the value of field 'Identification'.
     */
    public turbomeca.gamme.assembly.services.model.data.Identification getIdentification(
    ) {
        return this._identification;
    }

    /**
     * Returns the value of field 'instanciation'.
     * 
     * @return the value of field 'Instanciation'.
     */
    public turbomeca.gamme.assembly.services.model.data.Instanciation getInstanciation(
    ) {
        return this._instanciation;
    }

    /**
     * Returns the value of field 'key'.
     * 
     * @return the value of field 'Key'.
     */
    public java.lang.String getKey(
    ) {
        return this._key;
    }

    /**
     * Returns the value of field 'objectsToSynchronize'.
     * 
     * @return the value of field 'ObjectsToSynchronize'.
     */
    public turbomeca.gamme.assembly.services.model.data.ObjectsToSynchronize getObjectsToSynchronize(
    ) {
        return this._objectsToSynchronize;
    }

    /**
     * Returns the value of field 'observations'.
     * 
     * @return the value of field 'Observations'.
     */
    public turbomeca.gamme.assembly.services.model.data.Observations getObservations(
    ) {
        return this._observations;
    }

    /**
     * Returns the value of field 'operations'.
     * 
     * @return the value of field 'Operations'.
     */
    public turbomeca.gamme.assembly.services.model.data.Operations getOperations(
    ) {
        return this._operations;
    }

    /**
     * Returns the value of field 'parameters'.
     * 
     * @return the value of field 'Parameters'.
     */
    public turbomeca.gamme.assembly.services.model.data.Parameters getParameters(
    ) {
        return this._parameters;
    }

    /**
     * Returns the value of field 'postGeneralities'.
     * 
     * @return the value of field 'PostGeneralities'.
     */
    public turbomeca.gamme.assembly.services.model.data.PostGeneralities getPostGeneralities(
    ) {
        return this._postGeneralities;
    }

    /**
     * Returns the value of field 'preGeneralities'.
     * 
     * @return the value of field 'PreGeneralities'.
     */
    public turbomeca.gamme.assembly.services.model.data.PreGeneralities getPreGeneralities(
    ) {
        return this._preGeneralities;
    }

    /**
     * Returns the value of field 'qualifications'.
     * 
     * @return the value of field 'Qualifications'.
     */
    public turbomeca.gamme.assembly.services.model.data.Qualifications getQualifications(
    ) {
        return this._qualifications;
    }

    /**
     * Returns the value of field 'rework'.
     * 
     * @return the value of field 'Rework'.
     */
    public turbomeca.gamme.assembly.services.model.data.Rework getRework(
    ) {
        return this._rework;
    }

    /**
     * Returns the value of field 'suffix'.
     * 
     * @return the value of field 'Suffix'.
     */
    public java.lang.String getSuffix(
    ) {
        return this._suffix;
    }

    /**
     * Returns the value of field 'type'.
     * 
     * @return the value of field 'Type'.
     */
    public turbomeca.gamme.assembly.services.model.data.types.ContextType getType(
    ) {
        return this._type;
    }

    /**
     * Returns the value of field 'version'.
     * 
     * @return the value of field 'Version'.
     */
    public int getVersion(
    ) {
        return this._version;
    }

    /**
     * Method hasVersion.
     * 
     * @return true if at least one Version has been added
     */
    public boolean hasVersion(
    ) {
        return this._has_version;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllDeviationsFromRef(
    ) {
        this._deviationsFromRefList.clear();
    }

    /**
     * Method removeDeviationsFromRef.
     * 
     * @param vDeviationsFromRef
     * @return true if the object was removed from the collection.
     */
    public boolean removeDeviationsFromRef(
            final turbomeca.gamme.assembly.services.model.data.DeviationsFromRef vDeviationsFromRef) {
        boolean removed = _deviationsFromRefList.remove(vDeviationsFromRef);
        return removed;
    }

    /**
     * Method removeDeviationsFromRefAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public turbomeca.gamme.assembly.services.model.data.DeviationsFromRef removeDeviationsFromRefAt(
            final int index) {
        java.lang.Object obj = this._deviationsFromRefList.remove(index);
        return (turbomeca.gamme.assembly.services.model.data.DeviationsFromRef) obj;
    }

    /**
     * Sets the value of field 'authors'.
     * 
     * @param authors the value of field 'authors'.
     */
    public void setAuthors(
            final turbomeca.gamme.assembly.services.model.data.Authors authors) {
        this._authors = authors;
    }

    /**
     * Sets the value of field 'compounds'.
     * 
     * @param compounds the value of field 'compounds'.
     */
    public void setCompounds(
            final turbomeca.gamme.assembly.services.model.data.Compounds compounds) {
        this._compounds = compounds;
    }

    /**
     * Sets the value of field 'derogationMarks'.
     * 
     * @param derogationMarks the value of field 'derogationMarks'.
     */
    public void setDerogationMarks(
            final turbomeca.gamme.assembly.services.model.data.DerogationMarks derogationMarks) {
        this._derogationMarks = derogationMarks;
    }

    /**
     * 
     * 
     * @param index
     * @param vDeviationsFromRef
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setDeviationsFromRef(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.DeviationsFromRef vDeviationsFromRef)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._deviationsFromRefList.size()) {
            throw new IndexOutOfBoundsException("setDeviationsFromRef: Index value '" + index + "' not in range [0.." + (this._deviationsFromRefList.size() - 1) + "]");
        }

        this._deviationsFromRefList.set(index, vDeviationsFromRef);
    }

    /**
     * 
     * 
     * @param vDeviationsFromRefArray
     */
    public void setDeviationsFromRef(
            final turbomeca.gamme.assembly.services.model.data.DeviationsFromRef[] vDeviationsFromRefArray) {
        //-- copy array
        _deviationsFromRefList.clear();

        for (int i = 0; i < vDeviationsFromRefArray.length; i++) {
                this._deviationsFromRefList.add(vDeviationsFromRefArray[i]);
        }
    }

    /**
     * Sets the value of '_deviationsFromRefList' by copying the
     * given Vector. All elements will be checked for type safety.
     * 
     * @param vDeviationsFromRefList the Vector to copy.
     */
    public void setDeviationsFromRef(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.DeviationsFromRef> vDeviationsFromRefList) {
        // copy vector
        this._deviationsFromRefList.clear();

        this._deviationsFromRefList.addAll(vDeviationsFromRefList);
    }

    /**
     * Sets the value of '_deviationsFromRefList' by setting it to
     * the given Vector. No type checking is performed.
     * @deprecated
     * 
     * @param deviationsFromRefVector the Vector to set.
     */
    public void setDeviationsFromRefAsReference(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.DeviationsFromRef> deviationsFromRefVector) {
        this._deviationsFromRefList = deviationsFromRefVector;
    }

    /**
     * Sets the value of field 'documents'.
     * 
     * @param documents the value of field 'documents'.
     */
    public void setDocuments(
            final turbomeca.gamme.assembly.services.model.data.Documents documents) {
        this._documents = documents;
    }

    /**
     * Sets the value of field 'electronicPostIt'.
     * 
     * @param electronicPostIt the value of field 'electronicPostIt'
     */
    public void setElectronicPostIt(
            final turbomeca.gamme.assembly.services.model.data.ElectronicPostIt electronicPostIt) {
        this._electronicPostIt = electronicPostIt;
    }

    /**
     * Sets the value of field 'historical'.
     * 
     * @param historical the value of field 'historical'.
     */
    public void setHistorical(
            final turbomeca.gamme.assembly.services.model.data.Historical historical) {
        this._historical = historical;
    }

    /**
     * Sets the value of field 'historicalPassing'. The field
     * 'historicalPassing' has the following description: Container
     * to store user mark and user comments associated with each
     * new passing action
     *  
     * 
     * @param historicalPassing the value of field
     * 'historicalPassing'.
     */
    public void setHistoricalPassing(
            final turbomeca.gamme.assembly.services.model.data.HistoricalPassing historicalPassing) {
        this._historicalPassing = historicalPassing;
    }

    /**
     * Sets the value of field 'identification'.
     * 
     * @param identification the value of field 'identification'.
     */
    public void setIdentification(
            final turbomeca.gamme.assembly.services.model.data.Identification identification) {
        this._identification = identification;
    }

    /**
     * Sets the value of field 'instanciation'.
     * 
     * @param instanciation the value of field 'instanciation'.
     */
    public void setInstanciation(
            final turbomeca.gamme.assembly.services.model.data.Instanciation instanciation) {
        this._instanciation = instanciation;
    }

    /**
     * Sets the value of field 'key'.
     * 
     * @param key the value of field 'key'.
     */
    public void setKey(
            final java.lang.String key) {
        this._key = key;
    }

    /**
     * Sets the value of field 'objectsToSynchronize'.
     * 
     * @param objectsToSynchronize the value of field
     * 'objectsToSynchronize'.
     */
    public void setObjectsToSynchronize(
            final turbomeca.gamme.assembly.services.model.data.ObjectsToSynchronize objectsToSynchronize) {
        this._objectsToSynchronize = objectsToSynchronize;
    }

    /**
     * Sets the value of field 'observations'.
     * 
     * @param observations the value of field 'observations'.
     */
    public void setObservations(
            final turbomeca.gamme.assembly.services.model.data.Observations observations) {
        this._observations = observations;
    }

    /**
     * Sets the value of field 'operations'.
     * 
     * @param operations the value of field 'operations'.
     */
    public void setOperations(
            final turbomeca.gamme.assembly.services.model.data.Operations operations) {
        this._operations = operations;
    }

    /**
     * Sets the value of field 'parameters'.
     * 
     * @param parameters the value of field 'parameters'.
     */
    public void setParameters(
            final turbomeca.gamme.assembly.services.model.data.Parameters parameters) {
        this._parameters = parameters;
    }

    /**
     * Sets the value of field 'postGeneralities'.
     * 
     * @param postGeneralities the value of field 'postGeneralities'
     */
    public void setPostGeneralities(
            final turbomeca.gamme.assembly.services.model.data.PostGeneralities postGeneralities) {
        this._postGeneralities = postGeneralities;
    }

    /**
     * Sets the value of field 'preGeneralities'.
     * 
     * @param preGeneralities the value of field 'preGeneralities'.
     */
    public void setPreGeneralities(
            final turbomeca.gamme.assembly.services.model.data.PreGeneralities preGeneralities) {
        this._preGeneralities = preGeneralities;
    }

    /**
     * Sets the value of field 'qualifications'.
     * 
     * @param qualifications the value of field 'qualifications'.
     */
    public void setQualifications(
            final turbomeca.gamme.assembly.services.model.data.Qualifications qualifications) {
        this._qualifications = qualifications;
    }

    /**
     * Sets the value of field 'rework'.
     * 
     * @param rework the value of field 'rework'.
     */
    public void setRework(
            final turbomeca.gamme.assembly.services.model.data.Rework rework) {
        this._rework = rework;
    }

    /**
     * Sets the value of field 'suffix'.
     * 
     * @param suffix the value of field 'suffix'.
     */
    public void setSuffix(
            final java.lang.String suffix) {
        this._suffix = suffix;
    }

    /**
     * Sets the value of field 'type'.
     * 
     * @param type the value of field 'type'.
     */
    public void setType(
            final turbomeca.gamme.assembly.services.model.data.types.ContextType type) {
        this._type = type;
    }

    /**
     * Sets the value of field 'version'.
     * 
     * @param version the value of field 'version'.
     */
    public void setVersion(
            final int version) {
        this._version = version;
        this._has_version = true;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.ScheduleType
     */
    public static turbomeca.gamme.assembly.services.model.data.ScheduleType unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.ScheduleType) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.ScheduleType.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
