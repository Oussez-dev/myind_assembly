/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class InputControlSap.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class InputControlSap implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _id.
     */
    private java.lang.String _id;

    /**
     * Field _module.
     */
    private turbomeca.gamme.assembly.services.model.data.types.ModuleSapType _module;

    /**
     * Field _codeReference.
     */
    private java.lang.String _codeReference;

    /**
     * Field _type.
     */
    private java.lang.String _type;

    /**
     * Field _completion.
     */
    private boolean _completion;

    /**
     * keeps track of state for field: _completion
     */
    private boolean _has_completion;


      //----------------/
     //- Constructors -/
    //----------------/

    public InputControlSap() {
        super();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     */
    public void deleteCompletion(
    ) {
        this._has_completion= false;
    }

    /**
     * Returns the value of field 'codeReference'.
     * 
     * @return the value of field 'CodeReference'.
     */
    public java.lang.String getCodeReference(
    ) {
        return this._codeReference;
    }

    /**
     * Returns the value of field 'completion'.
     * 
     * @return the value of field 'Completion'.
     */
    public boolean getCompletion(
    ) {
        return this._completion;
    }

    /**
     * Returns the value of field 'id'.
     * 
     * @return the value of field 'Id'.
     */
    public java.lang.String getId(
    ) {
        return this._id;
    }

    /**
     * Returns the value of field 'module'.
     * 
     * @return the value of field 'Module'.
     */
    public turbomeca.gamme.assembly.services.model.data.types.ModuleSapType getModule(
    ) {
        return this._module;
    }

    /**
     * Returns the value of field 'type'.
     * 
     * @return the value of field 'Type'.
     */
    public java.lang.String getType(
    ) {
        return this._type;
    }

    /**
     * Method hasCompletion.
     * 
     * @return true if at least one Completion has been added
     */
    public boolean hasCompletion(
    ) {
        return this._has_completion;
    }

    /**
     * Returns the value of field 'completion'.
     * 
     * @return the value of field 'Completion'.
     */
    public boolean isCompletion(
    ) {
        return this._completion;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     * Sets the value of field 'codeReference'.
     * 
     * @param codeReference the value of field 'codeReference'.
     */
    public void setCodeReference(
            final java.lang.String codeReference) {
        this._codeReference = codeReference;
    }

    /**
     * Sets the value of field 'completion'.
     * 
     * @param completion the value of field 'completion'.
     */
    public void setCompletion(
            final boolean completion) {
        this._completion = completion;
        this._has_completion = true;
    }

    /**
     * Sets the value of field 'id'.
     * 
     * @param id the value of field 'id'.
     */
    public void setId(
            final java.lang.String id) {
        this._id = id;
    }

    /**
     * Sets the value of field 'module'.
     * 
     * @param module the value of field 'module'.
     */
    public void setModule(
            final turbomeca.gamme.assembly.services.model.data.types.ModuleSapType module) {
        this._module = module;
    }

    /**
     * Sets the value of field 'type'.
     * 
     * @param type the value of field 'type'.
     */
    public void setType(
            final java.lang.String type) {
        this._type = type;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.InputControlSap
     */
    public static turbomeca.gamme.assembly.services.model.data.InputControlSap unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.InputControlSap) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.InputControlSap.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
