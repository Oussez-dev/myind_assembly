/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class Tools.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class Tools implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _toolList.
     */
    private java.util.Vector<turbomeca.gamme.assembly.services.model.data.Tool> _toolList;


      //----------------/
     //- Constructors -/
    //----------------/

    public Tools() {
        super();
        this._toolList = new java.util.Vector<turbomeca.gamme.assembly.services.model.data.Tool>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vTool
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addTool(
            final turbomeca.gamme.assembly.services.model.data.Tool vTool)
    throws java.lang.IndexOutOfBoundsException {
        this._toolList.addElement(vTool);
    }

    /**
     * 
     * 
     * @param index
     * @param vTool
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addTool(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.Tool vTool)
    throws java.lang.IndexOutOfBoundsException {
        this._toolList.add(index, vTool);
    }

    /**
     * Method enumerateTool.
     * 
     * @return an Enumeration over all
     * turbomeca.gamme.assembly.services.model.data.Tool elements
     */
    public java.util.Enumeration<? extends turbomeca.gamme.assembly.services.model.data.Tool> enumerateTool(
    ) {
        return this._toolList.elements();
    }

    /**
     * Method getTool.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * turbomeca.gamme.assembly.services.model.data.Tool at the
     * given index
     */
    public turbomeca.gamme.assembly.services.model.data.Tool getTool(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._toolList.size()) {
            throw new IndexOutOfBoundsException("getTool: Index value '" + index + "' not in range [0.." + (this._toolList.size() - 1) + "]");
        }

        return (turbomeca.gamme.assembly.services.model.data.Tool) _toolList.get(index);
    }

    /**
     * Method getTool.Returns the contents of the collection in an
     * Array.  <p>Note:  Just in case the collection contents are
     * changing in another thread, we pass a 0-length Array of the
     * correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public turbomeca.gamme.assembly.services.model.data.Tool[] getTool(
    ) {
        turbomeca.gamme.assembly.services.model.data.Tool[] array = new turbomeca.gamme.assembly.services.model.data.Tool[0];
        return (turbomeca.gamme.assembly.services.model.data.Tool[]) this._toolList.toArray(array);
    }

    /**
     * Method getToolAsReference.Returns a reference to
     * '_toolList'. No type checking is performed on any
     * modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<turbomeca.gamme.assembly.services.model.data.Tool> getToolAsReference(
    ) {
        return this._toolList;
    }

    /**
     * Method getToolCount.
     * 
     * @return the size of this collection
     */
    public int getToolCount(
    ) {
        return this._toolList.size();
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllTool(
    ) {
        this._toolList.clear();
    }

    /**
     * Method removeTool.
     * 
     * @param vTool
     * @return true if the object was removed from the collection.
     */
    public boolean removeTool(
            final turbomeca.gamme.assembly.services.model.data.Tool vTool) {
        boolean removed = _toolList.remove(vTool);
        return removed;
    }

    /**
     * Method removeToolAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public turbomeca.gamme.assembly.services.model.data.Tool removeToolAt(
            final int index) {
        java.lang.Object obj = this._toolList.remove(index);
        return (turbomeca.gamme.assembly.services.model.data.Tool) obj;
    }

    /**
     * 
     * 
     * @param index
     * @param vTool
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setTool(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.Tool vTool)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._toolList.size()) {
            throw new IndexOutOfBoundsException("setTool: Index value '" + index + "' not in range [0.." + (this._toolList.size() - 1) + "]");
        }

        this._toolList.set(index, vTool);
    }

    /**
     * 
     * 
     * @param vToolArray
     */
    public void setTool(
            final turbomeca.gamme.assembly.services.model.data.Tool[] vToolArray) {
        //-- copy array
        _toolList.clear();

        for (int i = 0; i < vToolArray.length; i++) {
                this._toolList.add(vToolArray[i]);
        }
    }

    /**
     * Sets the value of '_toolList' by copying the given Vector.
     * All elements will be checked for type safety.
     * 
     * @param vToolList the Vector to copy.
     */
    public void setTool(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.Tool> vToolList) {
        // copy vector
        this._toolList.clear();

        this._toolList.addAll(vToolList);
    }

    /**
     * Sets the value of '_toolList' by setting it to the given
     * Vector. No type checking is performed.
     * @deprecated
     * 
     * @param toolVector the Vector to set.
     */
    public void setToolAsReference(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.Tool> toolVector) {
        this._toolList = toolVector;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.Tools
     */
    public static turbomeca.gamme.assembly.services.model.data.Tools unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.Tools) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.Tools.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
