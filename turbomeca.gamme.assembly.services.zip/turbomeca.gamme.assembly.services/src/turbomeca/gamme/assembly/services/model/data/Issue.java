/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class Issue.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class Issue implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _version.
     */
    private java.lang.String _version;

    /**
     * Field _issueModificationList.
     */
    private java.util.Vector<turbomeca.gamme.assembly.services.model.data.IssueModification> _issueModificationList;

    /**
     * Field _subIssueList.
     */
    private java.util.Vector<turbomeca.gamme.assembly.services.model.data.SubIssue> _subIssueList;


      //----------------/
     //- Constructors -/
    //----------------/

    public Issue() {
        super();
        this._issueModificationList = new java.util.Vector<turbomeca.gamme.assembly.services.model.data.IssueModification>();
        this._subIssueList = new java.util.Vector<turbomeca.gamme.assembly.services.model.data.SubIssue>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vIssueModification
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addIssueModification(
            final turbomeca.gamme.assembly.services.model.data.IssueModification vIssueModification)
    throws java.lang.IndexOutOfBoundsException {
        this._issueModificationList.addElement(vIssueModification);
    }

    /**
     * 
     * 
     * @param index
     * @param vIssueModification
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addIssueModification(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.IssueModification vIssueModification)
    throws java.lang.IndexOutOfBoundsException {
        this._issueModificationList.add(index, vIssueModification);
    }

    /**
     * 
     * 
     * @param vSubIssue
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addSubIssue(
            final turbomeca.gamme.assembly.services.model.data.SubIssue vSubIssue)
    throws java.lang.IndexOutOfBoundsException {
        this._subIssueList.addElement(vSubIssue);
    }

    /**
     * 
     * 
     * @param index
     * @param vSubIssue
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addSubIssue(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.SubIssue vSubIssue)
    throws java.lang.IndexOutOfBoundsException {
        this._subIssueList.add(index, vSubIssue);
    }

    /**
     * Method enumerateIssueModification.
     * 
     * @return an Enumeration over all
     * turbomeca.gamme.assembly.services.model.data.IssueModification
     * elements
     */
    public java.util.Enumeration<? extends turbomeca.gamme.assembly.services.model.data.IssueModification> enumerateIssueModification(
    ) {
        return this._issueModificationList.elements();
    }

    /**
     * Method enumerateSubIssue.
     * 
     * @return an Enumeration over all
     * turbomeca.gamme.assembly.services.model.data.SubIssue element
     */
    public java.util.Enumeration<? extends turbomeca.gamme.assembly.services.model.data.SubIssue> enumerateSubIssue(
    ) {
        return this._subIssueList.elements();
    }

    /**
     * Method getIssueModification.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * turbomeca.gamme.assembly.services.model.data.IssueModification
     * at the given index
     */
    public turbomeca.gamme.assembly.services.model.data.IssueModification getIssueModification(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._issueModificationList.size()) {
            throw new IndexOutOfBoundsException("getIssueModification: Index value '" + index + "' not in range [0.." + (this._issueModificationList.size() - 1) + "]");
        }

        return (turbomeca.gamme.assembly.services.model.data.IssueModification) _issueModificationList.get(index);
    }

    /**
     * Method getIssueModification.Returns the contents of the
     * collection in an Array.  <p>Note:  Just in case the
     * collection contents are changing in another thread, we pass
     * a 0-length Array of the correct type into the API call. 
     * This way we <i>know</i> that the Array returned is of
     * exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public turbomeca.gamme.assembly.services.model.data.IssueModification[] getIssueModification(
    ) {
        turbomeca.gamme.assembly.services.model.data.IssueModification[] array = new turbomeca.gamme.assembly.services.model.data.IssueModification[0];
        return (turbomeca.gamme.assembly.services.model.data.IssueModification[]) this._issueModificationList.toArray(array);
    }

    /**
     * Method getIssueModificationAsReference.Returns a reference
     * to '_issueModificationList'. No type checking is performed
     * on any modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<turbomeca.gamme.assembly.services.model.data.IssueModification> getIssueModificationAsReference(
    ) {
        return this._issueModificationList;
    }

    /**
     * Method getIssueModificationCount.
     * 
     * @return the size of this collection
     */
    public int getIssueModificationCount(
    ) {
        return this._issueModificationList.size();
    }

    /**
     * Method getSubIssue.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * turbomeca.gamme.assembly.services.model.data.SubIssue at the
     * given index
     */
    public turbomeca.gamme.assembly.services.model.data.SubIssue getSubIssue(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._subIssueList.size()) {
            throw new IndexOutOfBoundsException("getSubIssue: Index value '" + index + "' not in range [0.." + (this._subIssueList.size() - 1) + "]");
        }

        return (turbomeca.gamme.assembly.services.model.data.SubIssue) _subIssueList.get(index);
    }

    /**
     * Method getSubIssue.Returns the contents of the collection in
     * an Array.  <p>Note:  Just in case the collection contents
     * are changing in another thread, we pass a 0-length Array of
     * the correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public turbomeca.gamme.assembly.services.model.data.SubIssue[] getSubIssue(
    ) {
        turbomeca.gamme.assembly.services.model.data.SubIssue[] array = new turbomeca.gamme.assembly.services.model.data.SubIssue[0];
        return (turbomeca.gamme.assembly.services.model.data.SubIssue[]) this._subIssueList.toArray(array);
    }

    /**
     * Method getSubIssueAsReference.Returns a reference to
     * '_subIssueList'. No type checking is performed on any
     * modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<turbomeca.gamme.assembly.services.model.data.SubIssue> getSubIssueAsReference(
    ) {
        return this._subIssueList;
    }

    /**
     * Method getSubIssueCount.
     * 
     * @return the size of this collection
     */
    public int getSubIssueCount(
    ) {
        return this._subIssueList.size();
    }

    /**
     * Returns the value of field 'version'.
     * 
     * @return the value of field 'Version'.
     */
    public java.lang.String getVersion(
    ) {
        return this._version;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllIssueModification(
    ) {
        this._issueModificationList.clear();
    }

    /**
     */
    public void removeAllSubIssue(
    ) {
        this._subIssueList.clear();
    }

    /**
     * Method removeIssueModification.
     * 
     * @param vIssueModification
     * @return true if the object was removed from the collection.
     */
    public boolean removeIssueModification(
            final turbomeca.gamme.assembly.services.model.data.IssueModification vIssueModification) {
        boolean removed = _issueModificationList.remove(vIssueModification);
        return removed;
    }

    /**
     * Method removeIssueModificationAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public turbomeca.gamme.assembly.services.model.data.IssueModification removeIssueModificationAt(
            final int index) {
        java.lang.Object obj = this._issueModificationList.remove(index);
        return (turbomeca.gamme.assembly.services.model.data.IssueModification) obj;
    }

    /**
     * Method removeSubIssue.
     * 
     * @param vSubIssue
     * @return true if the object was removed from the collection.
     */
    public boolean removeSubIssue(
            final turbomeca.gamme.assembly.services.model.data.SubIssue vSubIssue) {
        boolean removed = _subIssueList.remove(vSubIssue);
        return removed;
    }

    /**
     * Method removeSubIssueAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public turbomeca.gamme.assembly.services.model.data.SubIssue removeSubIssueAt(
            final int index) {
        java.lang.Object obj = this._subIssueList.remove(index);
        return (turbomeca.gamme.assembly.services.model.data.SubIssue) obj;
    }

    /**
     * 
     * 
     * @param index
     * @param vIssueModification
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setIssueModification(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.IssueModification vIssueModification)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._issueModificationList.size()) {
            throw new IndexOutOfBoundsException("setIssueModification: Index value '" + index + "' not in range [0.." + (this._issueModificationList.size() - 1) + "]");
        }

        this._issueModificationList.set(index, vIssueModification);
    }

    /**
     * 
     * 
     * @param vIssueModificationArray
     */
    public void setIssueModification(
            final turbomeca.gamme.assembly.services.model.data.IssueModification[] vIssueModificationArray) {
        //-- copy array
        _issueModificationList.clear();

        for (int i = 0; i < vIssueModificationArray.length; i++) {
                this._issueModificationList.add(vIssueModificationArray[i]);
        }
    }

    /**
     * Sets the value of '_issueModificationList' by copying the
     * given Vector. All elements will be checked for type safety.
     * 
     * @param vIssueModificationList the Vector to copy.
     */
    public void setIssueModification(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.IssueModification> vIssueModificationList) {
        // copy vector
        this._issueModificationList.clear();

        this._issueModificationList.addAll(vIssueModificationList);
    }

    /**
     * Sets the value of '_issueModificationList' by setting it to
     * the given Vector. No type checking is performed.
     * @deprecated
     * 
     * @param issueModificationVector the Vector to set.
     */
    public void setIssueModificationAsReference(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.IssueModification> issueModificationVector) {
        this._issueModificationList = issueModificationVector;
    }

    /**
     * 
     * 
     * @param index
     * @param vSubIssue
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setSubIssue(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.SubIssue vSubIssue)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._subIssueList.size()) {
            throw new IndexOutOfBoundsException("setSubIssue: Index value '" + index + "' not in range [0.." + (this._subIssueList.size() - 1) + "]");
        }

        this._subIssueList.set(index, vSubIssue);
    }

    /**
     * 
     * 
     * @param vSubIssueArray
     */
    public void setSubIssue(
            final turbomeca.gamme.assembly.services.model.data.SubIssue[] vSubIssueArray) {
        //-- copy array
        _subIssueList.clear();

        for (int i = 0; i < vSubIssueArray.length; i++) {
                this._subIssueList.add(vSubIssueArray[i]);
        }
    }

    /**
     * Sets the value of '_subIssueList' by copying the given
     * Vector. All elements will be checked for type safety.
     * 
     * @param vSubIssueList the Vector to copy.
     */
    public void setSubIssue(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.SubIssue> vSubIssueList) {
        // copy vector
        this._subIssueList.clear();

        this._subIssueList.addAll(vSubIssueList);
    }

    /**
     * Sets the value of '_subIssueList' by setting it to the given
     * Vector. No type checking is performed.
     * @deprecated
     * 
     * @param subIssueVector the Vector to set.
     */
    public void setSubIssueAsReference(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.SubIssue> subIssueVector) {
        this._subIssueList = subIssueVector;
    }

    /**
     * Sets the value of field 'version'.
     * 
     * @param version the value of field 'version'.
     */
    public void setVersion(
            final java.lang.String version) {
        this._version = version;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.Issue
     */
    public static turbomeca.gamme.assembly.services.model.data.Issue unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.Issue) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.Issue.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
