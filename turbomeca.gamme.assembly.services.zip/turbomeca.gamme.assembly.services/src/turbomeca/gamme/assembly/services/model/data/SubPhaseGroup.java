/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class SubPhaseGroup.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class SubPhaseGroup implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _id.
     */
    private java.lang.String _id;

    /**
     * Field _isAlternative.
     */
    private boolean _isAlternative = false;

    /**
     * keeps track of state for field: _isAlternative
     */
    private boolean _has_isAlternative;

    /**
     * Field _rework.
     */
    private turbomeca.gamme.assembly.services.model.data.types.BooleanType _rework;

    /**
     * Field _displayId.
     */
    private java.lang.String _displayId;

    /**
     * Field _applicable.
     */
    private boolean _applicable = true;

    /**
     * keeps track of state for field: _applicable
     */
    private boolean _has_applicable;

    /**
     * Field _archive.
     */
    private boolean _archive = false;

    /**
     * keeps track of state for field: _archive
     */
    private boolean _has_archive;

    /**
     * Field _state.
     */
    private turbomeca.gamme.assembly.services.model.data.State _state;

    /**
     * Field _title.
     */
    private turbomeca.gamme.assembly.services.model.data.Title _title;

    /**
     * Field _resources.
     */
    private turbomeca.gamme.assembly.services.model.data.Resources _resources;

    /**
     * Field _subPhaseList.
     */
    private java.util.Vector<turbomeca.gamme.assembly.services.model.data.SubPhase> _subPhaseList;


      //----------------/
     //- Constructors -/
    //----------------/

    public SubPhaseGroup() {
        super();
        this._subPhaseList = new java.util.Vector<turbomeca.gamme.assembly.services.model.data.SubPhase>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vSubPhase
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addSubPhase(
            final turbomeca.gamme.assembly.services.model.data.SubPhase vSubPhase)
    throws java.lang.IndexOutOfBoundsException {
        this._subPhaseList.addElement(vSubPhase);
    }

    /**
     * 
     * 
     * @param index
     * @param vSubPhase
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addSubPhase(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.SubPhase vSubPhase)
    throws java.lang.IndexOutOfBoundsException {
        this._subPhaseList.add(index, vSubPhase);
    }

    /**
     */
    public void deleteApplicable(
    ) {
        this._has_applicable= false;
    }

    /**
     */
    public void deleteArchive(
    ) {
        this._has_archive= false;
    }

    /**
     */
    public void deleteIsAlternative(
    ) {
        this._has_isAlternative= false;
    }

    /**
     * Method enumerateSubPhase.
     * 
     * @return an Enumeration over all
     * turbomeca.gamme.assembly.services.model.data.SubPhase element
     */
    public java.util.Enumeration<? extends turbomeca.gamme.assembly.services.model.data.SubPhase> enumerateSubPhase(
    ) {
        return this._subPhaseList.elements();
    }

    /**
     * Returns the value of field 'applicable'.
     * 
     * @return the value of field 'Applicable'.
     */
    public boolean getApplicable(
    ) {
        return this._applicable;
    }

    /**
     * Returns the value of field 'archive'.
     * 
     * @return the value of field 'Archive'.
     */
    public boolean getArchive(
    ) {
        return this._archive;
    }

    /**
     * Returns the value of field 'displayId'.
     * 
     * @return the value of field 'DisplayId'.
     */
    public java.lang.String getDisplayId(
    ) {
        return this._displayId;
    }

    /**
     * Returns the value of field 'id'.
     * 
     * @return the value of field 'Id'.
     */
    public java.lang.String getId(
    ) {
        return this._id;
    }

    /**
     * Returns the value of field 'isAlternative'.
     * 
     * @return the value of field 'IsAlternative'.
     */
    public boolean getIsAlternative(
    ) {
        return this._isAlternative;
    }

    /**
     * Returns the value of field 'resources'.
     * 
     * @return the value of field 'Resources'.
     */
    public turbomeca.gamme.assembly.services.model.data.Resources getResources(
    ) {
        return this._resources;
    }

    /**
     * Returns the value of field 'rework'.
     * 
     * @return the value of field 'Rework'.
     */
    public turbomeca.gamme.assembly.services.model.data.types.BooleanType getRework(
    ) {
        return this._rework;
    }

    /**
     * Returns the value of field 'state'.
     * 
     * @return the value of field 'State'.
     */
    public turbomeca.gamme.assembly.services.model.data.State getState(
    ) {
        return this._state;
    }

    /**
     * Method getSubPhase.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * turbomeca.gamme.assembly.services.model.data.SubPhase at the
     * given index
     */
    public turbomeca.gamme.assembly.services.model.data.SubPhase getSubPhase(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._subPhaseList.size()) {
            throw new IndexOutOfBoundsException("getSubPhase: Index value '" + index + "' not in range [0.." + (this._subPhaseList.size() - 1) + "]");
        }

        return (turbomeca.gamme.assembly.services.model.data.SubPhase) _subPhaseList.get(index);
    }

    /**
     * Method getSubPhase.Returns the contents of the collection in
     * an Array.  <p>Note:  Just in case the collection contents
     * are changing in another thread, we pass a 0-length Array of
     * the correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public turbomeca.gamme.assembly.services.model.data.SubPhase[] getSubPhase(
    ) {
        turbomeca.gamme.assembly.services.model.data.SubPhase[] array = new turbomeca.gamme.assembly.services.model.data.SubPhase[0];
        return (turbomeca.gamme.assembly.services.model.data.SubPhase[]) this._subPhaseList.toArray(array);
    }

    /**
     * Method getSubPhaseAsReference.Returns a reference to
     * '_subPhaseList'. No type checking is performed on any
     * modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<turbomeca.gamme.assembly.services.model.data.SubPhase> getSubPhaseAsReference(
    ) {
        return this._subPhaseList;
    }

    /**
     * Method getSubPhaseCount.
     * 
     * @return the size of this collection
     */
    public int getSubPhaseCount(
    ) {
        return this._subPhaseList.size();
    }

    /**
     * Returns the value of field 'title'.
     * 
     * @return the value of field 'Title'.
     */
    public turbomeca.gamme.assembly.services.model.data.Title getTitle(
    ) {
        return this._title;
    }

    /**
     * Method hasApplicable.
     * 
     * @return true if at least one Applicable has been added
     */
    public boolean hasApplicable(
    ) {
        return this._has_applicable;
    }

    /**
     * Method hasArchive.
     * 
     * @return true if at least one Archive has been added
     */
    public boolean hasArchive(
    ) {
        return this._has_archive;
    }

    /**
     * Method hasIsAlternative.
     * 
     * @return true if at least one IsAlternative has been added
     */
    public boolean hasIsAlternative(
    ) {
        return this._has_isAlternative;
    }

    /**
     * Returns the value of field 'applicable'.
     * 
     * @return the value of field 'Applicable'.
     */
    public boolean isApplicable(
    ) {
        return this._applicable;
    }

    /**
     * Returns the value of field 'archive'.
     * 
     * @return the value of field 'Archive'.
     */
    public boolean isArchive(
    ) {
        return this._archive;
    }

    /**
     * Returns the value of field 'isAlternative'.
     * 
     * @return the value of field 'IsAlternative'.
     */
    public boolean isIsAlternative(
    ) {
        return this._isAlternative;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllSubPhase(
    ) {
        this._subPhaseList.clear();
    }

    /**
     * Method removeSubPhase.
     * 
     * @param vSubPhase
     * @return true if the object was removed from the collection.
     */
    public boolean removeSubPhase(
            final turbomeca.gamme.assembly.services.model.data.SubPhase vSubPhase) {
        boolean removed = _subPhaseList.remove(vSubPhase);
        return removed;
    }

    /**
     * Method removeSubPhaseAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public turbomeca.gamme.assembly.services.model.data.SubPhase removeSubPhaseAt(
            final int index) {
        java.lang.Object obj = this._subPhaseList.remove(index);
        return (turbomeca.gamme.assembly.services.model.data.SubPhase) obj;
    }

    /**
     * Sets the value of field 'applicable'.
     * 
     * @param applicable the value of field 'applicable'.
     */
    public void setApplicable(
            final boolean applicable) {
        this._applicable = applicable;
        this._has_applicable = true;
    }

    /**
     * Sets the value of field 'archive'.
     * 
     * @param archive the value of field 'archive'.
     */
    public void setArchive(
            final boolean archive) {
        this._archive = archive;
        this._has_archive = true;
    }

    /**
     * Sets the value of field 'displayId'.
     * 
     * @param displayId the value of field 'displayId'.
     */
    public void setDisplayId(
            final java.lang.String displayId) {
        this._displayId = displayId;
    }

    /**
     * Sets the value of field 'id'.
     * 
     * @param id the value of field 'id'.
     */
    public void setId(
            final java.lang.String id) {
        this._id = id;
    }

    /**
     * Sets the value of field 'isAlternative'.
     * 
     * @param isAlternative the value of field 'isAlternative'.
     */
    public void setIsAlternative(
            final boolean isAlternative) {
        this._isAlternative = isAlternative;
        this._has_isAlternative = true;
    }

    /**
     * Sets the value of field 'resources'.
     * 
     * @param resources the value of field 'resources'.
     */
    public void setResources(
            final turbomeca.gamme.assembly.services.model.data.Resources resources) {
        this._resources = resources;
    }

    /**
     * Sets the value of field 'rework'.
     * 
     * @param rework the value of field 'rework'.
     */
    public void setRework(
            final turbomeca.gamme.assembly.services.model.data.types.BooleanType rework) {
        this._rework = rework;
    }

    /**
     * Sets the value of field 'state'.
     * 
     * @param state the value of field 'state'.
     */
    public void setState(
            final turbomeca.gamme.assembly.services.model.data.State state) {
        this._state = state;
    }

    /**
     * 
     * 
     * @param index
     * @param vSubPhase
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setSubPhase(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.SubPhase vSubPhase)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._subPhaseList.size()) {
            throw new IndexOutOfBoundsException("setSubPhase: Index value '" + index + "' not in range [0.." + (this._subPhaseList.size() - 1) + "]");
        }

        this._subPhaseList.set(index, vSubPhase);
    }

    /**
     * 
     * 
     * @param vSubPhaseArray
     */
    public void setSubPhase(
            final turbomeca.gamme.assembly.services.model.data.SubPhase[] vSubPhaseArray) {
        //-- copy array
        _subPhaseList.clear();

        for (int i = 0; i < vSubPhaseArray.length; i++) {
                this._subPhaseList.add(vSubPhaseArray[i]);
        }
    }

    /**
     * Sets the value of '_subPhaseList' by copying the given
     * Vector. All elements will be checked for type safety.
     * 
     * @param vSubPhaseList the Vector to copy.
     */
    public void setSubPhase(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.SubPhase> vSubPhaseList) {
        // copy vector
        this._subPhaseList.clear();

        this._subPhaseList.addAll(vSubPhaseList);
    }

    /**
     * Sets the value of '_subPhaseList' by setting it to the given
     * Vector. No type checking is performed.
     * @deprecated
     * 
     * @param subPhaseVector the Vector to set.
     */
    public void setSubPhaseAsReference(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.SubPhase> subPhaseVector) {
        this._subPhaseList = subPhaseVector;
    }

    /**
     * Sets the value of field 'title'.
     * 
     * @param title the value of field 'title'.
     */
    public void setTitle(
            final turbomeca.gamme.assembly.services.model.data.Title title) {
        this._title = title;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.SubPhaseGroup
     */
    public static turbomeca.gamme.assembly.services.model.data.SubPhaseGroup unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.SubPhaseGroup) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.SubPhaseGroup.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
