/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class Tolerance.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class Tolerance implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _minValue.
     */
    private float _minValue;

    /**
     * keeps track of state for field: _minValue
     */
    private boolean _has_minValue;

    /**
     * Field _maxValue.
     */
    private float _maxValue;

    /**
     * keeps track of state for field: _maxValue
     */
    private boolean _has_maxValue;


      //----------------/
     //- Constructors -/
    //----------------/

    public Tolerance() {
        super();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     */
    public void deleteMaxValue(
    ) {
        this._has_maxValue= false;
    }

    /**
     */
    public void deleteMinValue(
    ) {
        this._has_minValue= false;
    }

    /**
     * Returns the value of field 'maxValue'.
     * 
     * @return the value of field 'MaxValue'.
     */
    public float getMaxValue(
    ) {
        return this._maxValue;
    }

    /**
     * Returns the value of field 'minValue'.
     * 
     * @return the value of field 'MinValue'.
     */
    public float getMinValue(
    ) {
        return this._minValue;
    }

    /**
     * Method hasMaxValue.
     * 
     * @return true if at least one MaxValue has been added
     */
    public boolean hasMaxValue(
    ) {
        return this._has_maxValue;
    }

    /**
     * Method hasMinValue.
     * 
     * @return true if at least one MinValue has been added
     */
    public boolean hasMinValue(
    ) {
        return this._has_minValue;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     * Sets the value of field 'maxValue'.
     * 
     * @param maxValue the value of field 'maxValue'.
     */
    public void setMaxValue(
            final float maxValue) {
        this._maxValue = maxValue;
        this._has_maxValue = true;
    }

    /**
     * Sets the value of field 'minValue'.
     * 
     * @param minValue the value of field 'minValue'.
     */
    public void setMinValue(
            final float minValue) {
        this._minValue = minValue;
        this._has_minValue = true;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.Tolerance
     */
    public static turbomeca.gamme.assembly.services.model.data.Tolerance unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.Tolerance) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.Tolerance.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
