/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class ActionChoiceItem.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class ActionChoiceItem implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _carriage_return.
     */
    private turbomeca.gamme.assembly.services.model.data.Carriage_return _carriage_return;

    /**
     * Field _para.
     */
    private turbomeca.gamme.assembly.services.model.data.Para _para;

    /**
     * Field _warning.
     */
    private turbomeca.gamme.assembly.services.model.data.Warning _warning;

    /**
     * Field _externalLink.
     */
    private turbomeca.gamme.assembly.services.model.data.ExternalLink _externalLink;

    /**
     * Field _table.
     */
    private turbomeca.gamme.assembly.services.model.data.Table _table;

    /**
     * Field _barCode.
     */
    private java.lang.String _barCode;

    /**
     * Field _paraList.
     */
    private turbomeca.gamme.assembly.services.model.data.ParaList _paraList;

    /**
     * Field _letterDigitBoxed.
     */
    private java.lang.String _letterDigitBoxed;

    /**
     * Field _tolerance.
     */
    private turbomeca.gamme.assembly.services.model.data.Tolerance _tolerance;

    /**
     * Field _exponent.
     */
    private turbomeca.gamme.assembly.services.model.data.Exponent _exponent;

    /**
     * Field _index.
     */
    private turbomeca.gamme.assembly.services.model.data.Index _index;

    /**
     * Field _pictogram.
     */
    private turbomeca.gamme.assembly.services.model.data.Pictogram _pictogram;


      //----------------/
     //- Constructors -/
    //----------------/

    public ActionChoiceItem() {
        super();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'barCode'.
     * 
     * @return the value of field 'BarCode'.
     */
    public java.lang.String getBarCode(
    ) {
        return this._barCode;
    }

    /**
     * Returns the value of field 'carriage_return'.
     * 
     * @return the value of field 'Carriage_return'.
     */
    public turbomeca.gamme.assembly.services.model.data.Carriage_return getCarriage_return(
    ) {
        return this._carriage_return;
    }

    /**
     * Returns the value of field 'exponent'.
     * 
     * @return the value of field 'Exponent'.
     */
    public turbomeca.gamme.assembly.services.model.data.Exponent getExponent(
    ) {
        return this._exponent;
    }

    /**
     * Returns the value of field 'externalLink'.
     * 
     * @return the value of field 'ExternalLink'.
     */
    public turbomeca.gamme.assembly.services.model.data.ExternalLink getExternalLink(
    ) {
        return this._externalLink;
    }

    /**
     * Returns the value of field 'index'.
     * 
     * @return the value of field 'Index'.
     */
    public turbomeca.gamme.assembly.services.model.data.Index getIndex(
    ) {
        return this._index;
    }

    /**
     * Returns the value of field 'letterDigitBoxed'.
     * 
     * @return the value of field 'LetterDigitBoxed'.
     */
    public java.lang.String getLetterDigitBoxed(
    ) {
        return this._letterDigitBoxed;
    }

    /**
     * Returns the value of field 'para'.
     * 
     * @return the value of field 'Para'.
     */
    public turbomeca.gamme.assembly.services.model.data.Para getPara(
    ) {
        return this._para;
    }

    /**
     * Returns the value of field 'paraList'.
     * 
     * @return the value of field 'ParaList'.
     */
    public turbomeca.gamme.assembly.services.model.data.ParaList getParaList(
    ) {
        return this._paraList;
    }

    /**
     * Returns the value of field 'pictogram'.
     * 
     * @return the value of field 'Pictogram'.
     */
    public turbomeca.gamme.assembly.services.model.data.Pictogram getPictogram(
    ) {
        return this._pictogram;
    }

    /**
     * Returns the value of field 'table'.
     * 
     * @return the value of field 'Table'.
     */
    public turbomeca.gamme.assembly.services.model.data.Table getTable(
    ) {
        return this._table;
    }

    /**
     * Returns the value of field 'tolerance'.
     * 
     * @return the value of field 'Tolerance'.
     */
    public turbomeca.gamme.assembly.services.model.data.Tolerance getTolerance(
    ) {
        return this._tolerance;
    }

    /**
     * Returns the value of field 'warning'.
     * 
     * @return the value of field 'Warning'.
     */
    public turbomeca.gamme.assembly.services.model.data.Warning getWarning(
    ) {
        return this._warning;
    }

    /**
     * Sets the value of field 'barCode'.
     * 
     * @param barCode the value of field 'barCode'.
     */
    public void setBarCode(
            final java.lang.String barCode) {
        this._barCode = barCode;
    }

    /**
     * Sets the value of field 'carriage_return'.
     * 
     * @param carriage_return the value of field 'carriage_return'.
     */
    public void setCarriage_return(
            final turbomeca.gamme.assembly.services.model.data.Carriage_return carriage_return) {
        this._carriage_return = carriage_return;
    }

    /**
     * Sets the value of field 'exponent'.
     * 
     * @param exponent the value of field 'exponent'.
     */
    public void setExponent(
            final turbomeca.gamme.assembly.services.model.data.Exponent exponent) {
        this._exponent = exponent;
    }

    /**
     * Sets the value of field 'externalLink'.
     * 
     * @param externalLink the value of field 'externalLink'.
     */
    public void setExternalLink(
            final turbomeca.gamme.assembly.services.model.data.ExternalLink externalLink) {
        this._externalLink = externalLink;
    }

    /**
     * Sets the value of field 'index'.
     * 
     * @param index the value of field 'index'.
     */
    public void setIndex(
            final turbomeca.gamme.assembly.services.model.data.Index index) {
        this._index = index;
    }

    /**
     * Sets the value of field 'letterDigitBoxed'.
     * 
     * @param letterDigitBoxed the value of field 'letterDigitBoxed'
     */
    public void setLetterDigitBoxed(
            final java.lang.String letterDigitBoxed) {
        this._letterDigitBoxed = letterDigitBoxed;
    }

    /**
     * Sets the value of field 'para'.
     * 
     * @param para the value of field 'para'.
     */
    public void setPara(
            final turbomeca.gamme.assembly.services.model.data.Para para) {
        this._para = para;
    }

    /**
     * Sets the value of field 'paraList'.
     * 
     * @param paraList the value of field 'paraList'.
     */
    public void setParaList(
            final turbomeca.gamme.assembly.services.model.data.ParaList paraList) {
        this._paraList = paraList;
    }

    /**
     * Sets the value of field 'pictogram'.
     * 
     * @param pictogram the value of field 'pictogram'.
     */
    public void setPictogram(
            final turbomeca.gamme.assembly.services.model.data.Pictogram pictogram) {
        this._pictogram = pictogram;
    }

    /**
     * Sets the value of field 'table'.
     * 
     * @param table the value of field 'table'.
     */
    public void setTable(
            final turbomeca.gamme.assembly.services.model.data.Table table) {
        this._table = table;
    }

    /**
     * Sets the value of field 'tolerance'.
     * 
     * @param tolerance the value of field 'tolerance'.
     */
    public void setTolerance(
            final turbomeca.gamme.assembly.services.model.data.Tolerance tolerance) {
        this._tolerance = tolerance;
    }

    /**
     * Sets the value of field 'warning'.
     * 
     * @param warning the value of field 'warning'.
     */
    public void setWarning(
            final turbomeca.gamme.assembly.services.model.data.Warning warning) {
        this._warning = warning;
    }

}
