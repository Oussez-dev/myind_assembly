/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class SubPhase.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class SubPhase implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _id.
     */
    private java.lang.String _id;

    /**
     * Field _optional.
     */
    private boolean _optional = false;

    /**
     * keeps track of state for field: _optional
     */
    private boolean _has_optional;

    /**
     * Field _signature.
     */
    private turbomeca.gamme.assembly.services.model.data.types.BooleanTypeWithNull _signature = turbomeca.gamme.assembly.services.model.data.types.BooleanTypeWithNull.fromValue("true");

    /**
     * Field _validable.
     */
    private boolean _validable = true;

    /**
     * keeps track of state for field: _validable
     */
    private boolean _has_validable;

    /**
     * Field _duplicableInstance.
     */
    private turbomeca.gamme.assembly.services.model.data.types.BooleanType _duplicableInstance;

    /**
     * Field _rework.
     */
    private turbomeca.gamme.assembly.services.model.data.types.BooleanType _rework;

    /**
     * Field _instance.
     */
    private int _instance;

    /**
     * keeps track of state for field: _instance
     */
    private boolean _has_instance;

    /**
     * Field _passing.
     */
    private int _passing;

    /**
     * keeps track of state for field: _passing
     */
    private boolean _has_passing;

    /**
     * Field _displayId.
     */
    private java.lang.String _displayId;

    /**
     * Field _applicable.
     */
    private boolean _applicable = true;

    /**
     * keeps track of state for field: _applicable
     */
    private boolean _has_applicable;

    /**
     * Field _archive.
     */
    private boolean _archive = false;

    /**
     * keeps track of state for field: _archive
     */
    private boolean _has_archive;

    /**
     * Field _alternatives.
     */
    private java.util.Vector<java.lang.Object> _alternatives;

    /**
     * Field _isAlternative.
     */
    private boolean _isAlternative = false;

    /**
     * keeps track of state for field: _isAlternative
     */
    private boolean _has_isAlternative;

    /**
     * Field _isDelegate.
     */
    private boolean _isDelegate = false;

    /**
     * keeps track of state for field: _isDelegate
     */
    private boolean _has_isDelegate;

    /**
     * Field _predecessors.
     */
    private java.util.Vector<java.lang.Object> _predecessors;

    /**
     * Field _followers.
     */
    private java.util.Vector<java.lang.Object> _followers;

    /**
     * Field _forcePredecessorsValid.
     */
    private boolean _forcePredecessorsValid = false;

    /**
     * keeps track of state for field: _forcePredecessorsValid
     */
    private boolean _has_forcePredecessorsValid;

    /**
     * Field _type.
     */
    private java.lang.String _type;

    /**
     * Field _sapCommand.
     */
    private java.lang.String _sapCommand;

    /**
     * Field _synchronizedWithSap.
     */
    private boolean _synchronizedWithSap = false;

    /**
     * keeps track of state for field: _synchronizedWithSap
     */
    private boolean _has_synchronizedWithSap;

    /**
     * SubPhase Effectivity, used for merge from SAP, see
     * CreateAndSynchronizeScheduleService.java
     */
    private java.util.Vector<java.lang.String> _effectivityList;

    /**
     * Field _partialTuning.
     */
    private boolean _partialTuning;

    /**
     * keeps track of state for field: _partialTuning
     */
    private boolean _has_partialTuning;

    /**
     * Field _state.
     */
    private turbomeca.gamme.assembly.services.model.data.State _state;

    /**
     * Field _unlockComment.
     */
    private java.lang.String _unlockComment;

    /**
     * Field _comment.
     */
    private java.lang.String _comment;

    /**
     * Field _matrix.
     */
    private turbomeca.gamme.assembly.services.model.data.Matrix _matrix;

    /**
     * Field _infoSubPhase.
     */
    private turbomeca.gamme.assembly.services.model.data.InfoSubPhase _infoSubPhase;

    /**
     * Field _optionalChoice.
     */
    private turbomeca.gamme.assembly.services.model.data.OptionalChoice _optionalChoice;

    /**
     * SubPhase Number to be displayed in GUI when defined
     */
    private int _number;

    /**
     * keeps track of state for field: _number
     */
    private boolean _has_number;

    /**
     * Field _title.
     */
    private turbomeca.gamme.assembly.services.model.data.Title _title;

    /**
     * Field _historical.
     */
    private turbomeca.gamme.assembly.services.model.data.Historical _historical;

    /**
     * Field _electronicNotifications.
     */
    private turbomeca.gamme.assembly.services.model.data.ElectronicNotifications _electronicNotifications;

    /**
     * Field _documentsJoined.
     */
    private turbomeca.gamme.assembly.services.model.data.DocumentsJoined _documentsJoined;

    /**
     * Field _resources.
     */
    private turbomeca.gamme.assembly.services.model.data.Resources _resources;

    /**
     * Field _qualifications.
     */
    private turbomeca.gamme.assembly.services.model.data.Qualifications _qualifications;

    /**
     * Field _tasks.
     */
    private turbomeca.gamme.assembly.services.model.data.Tasks _tasks;


      //----------------/
     //- Constructors -/
    //----------------/

    public SubPhase() {
        super();
        setSignature(turbomeca.gamme.assembly.services.model.data.types.BooleanTypeWithNull.fromValue("true"));
        this._alternatives = new java.util.Vector<java.lang.Object>();
        this._predecessors = new java.util.Vector<java.lang.Object>();
        this._followers = new java.util.Vector<java.lang.Object>();
        this._effectivityList = new java.util.Vector<java.lang.String>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vAlternatives
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addAlternatives(
            final java.lang.Object vAlternatives)
    throws java.lang.IndexOutOfBoundsException {
        this._alternatives.addElement(vAlternatives);
    }

    /**
     * 
     * 
     * @param index
     * @param vAlternatives
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addAlternatives(
            final int index,
            final java.lang.Object vAlternatives)
    throws java.lang.IndexOutOfBoundsException {
        this._alternatives.add(index, vAlternatives);
    }

    /**
     * 
     * 
     * @param vEffectivity
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addEffectivity(
            final java.lang.String vEffectivity)
    throws java.lang.IndexOutOfBoundsException {
        this._effectivityList.addElement(vEffectivity);
    }

    /**
     * 
     * 
     * @param index
     * @param vEffectivity
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addEffectivity(
            final int index,
            final java.lang.String vEffectivity)
    throws java.lang.IndexOutOfBoundsException {
        this._effectivityList.add(index, vEffectivity);
    }

    /**
     * 
     * 
     * @param vFollowers
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addFollowers(
            final java.lang.Object vFollowers)
    throws java.lang.IndexOutOfBoundsException {
        this._followers.addElement(vFollowers);
    }

    /**
     * 
     * 
     * @param index
     * @param vFollowers
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addFollowers(
            final int index,
            final java.lang.Object vFollowers)
    throws java.lang.IndexOutOfBoundsException {
        this._followers.add(index, vFollowers);
    }

    /**
     * 
     * 
     * @param vPredecessors
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addPredecessors(
            final java.lang.Object vPredecessors)
    throws java.lang.IndexOutOfBoundsException {
        this._predecessors.addElement(vPredecessors);
    }

    /**
     * 
     * 
     * @param index
     * @param vPredecessors
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addPredecessors(
            final int index,
            final java.lang.Object vPredecessors)
    throws java.lang.IndexOutOfBoundsException {
        this._predecessors.add(index, vPredecessors);
    }

    /**
     */
    public void deleteApplicable(
    ) {
        this._has_applicable= false;
    }

    /**
     */
    public void deleteArchive(
    ) {
        this._has_archive= false;
    }

    /**
     */
    public void deleteForcePredecessorsValid(
    ) {
        this._has_forcePredecessorsValid= false;
    }

    /**
     */
    public void deleteInstance(
    ) {
        this._has_instance= false;
    }

    /**
     */
    public void deleteIsAlternative(
    ) {
        this._has_isAlternative= false;
    }

    /**
     */
    public void deleteIsDelegate(
    ) {
        this._has_isDelegate= false;
    }

    /**
     */
    public void deleteNumber(
    ) {
        this._has_number= false;
    }

    /**
     */
    public void deleteOptional(
    ) {
        this._has_optional= false;
    }

    /**
     */
    public void deletePartialTuning(
    ) {
        this._has_partialTuning= false;
    }

    /**
     */
    public void deletePassing(
    ) {
        this._has_passing= false;
    }

    /**
     */
    public void deleteSynchronizedWithSap(
    ) {
        this._has_synchronizedWithSap= false;
    }

    /**
     */
    public void deleteValidable(
    ) {
        this._has_validable= false;
    }

    /**
     * Method enumerateAlternatives.
     * 
     * @return an Enumeration over all java.lang.Object elements
     */
    public java.util.Enumeration<? extends java.lang.Object> enumerateAlternatives(
    ) {
        return this._alternatives.elements();
    }

    /**
     * Method enumerateEffectivity.
     * 
     * @return an Enumeration over all java.lang.String elements
     */
    public java.util.Enumeration<? extends java.lang.String> enumerateEffectivity(
    ) {
        return this._effectivityList.elements();
    }

    /**
     * Method enumerateFollowers.
     * 
     * @return an Enumeration over all java.lang.Object elements
     */
    public java.util.Enumeration<? extends java.lang.Object> enumerateFollowers(
    ) {
        return this._followers.elements();
    }

    /**
     * Method enumeratePredecessors.
     * 
     * @return an Enumeration over all java.lang.Object elements
     */
    public java.util.Enumeration<? extends java.lang.Object> enumeratePredecessors(
    ) {
        return this._predecessors.elements();
    }

    /**
     * Method getAlternatives.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the java.lang.Object at the given index
     */
    public java.lang.Object getAlternatives(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._alternatives.size()) {
            throw new IndexOutOfBoundsException("getAlternatives: Index value '" + index + "' not in range [0.." + (this._alternatives.size() - 1) + "]");
        }

        return _alternatives.get(index);
    }

    /**
     * Method getAlternatives.Returns the contents of the
     * collection in an Array.  <p>Note:  Just in case the
     * collection contents are changing in another thread, we pass
     * a 0-length Array of the correct type into the API call. 
     * This way we <i>know</i> that the Array returned is of
     * exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public java.lang.Object[] getAlternatives(
    ) {
        java.lang.Object[] array = new java.lang.Object[0];
        return (java.lang.Object[]) this._alternatives.toArray(array);
    }

    /**
     * Method getAlternativesAsReference.Returns a reference to
     * '_alternatives'. No type checking is performed on any
     * modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<java.lang.Object> getAlternativesAsReference(
    ) {
        return this._alternatives;
    }

    /**
     * Method getAlternativesCount.
     * 
     * @return the size of this collection
     */
    public int getAlternativesCount(
    ) {
        return this._alternatives.size();
    }

    /**
     * Returns the value of field 'applicable'.
     * 
     * @return the value of field 'Applicable'.
     */
    public boolean getApplicable(
    ) {
        return this._applicable;
    }

    /**
     * Returns the value of field 'archive'.
     * 
     * @return the value of field 'Archive'.
     */
    public boolean getArchive(
    ) {
        return this._archive;
    }

    /**
     * Returns the value of field 'comment'.
     * 
     * @return the value of field 'Comment'.
     */
    public java.lang.String getComment(
    ) {
        return this._comment;
    }

    /**
     * Returns the value of field 'displayId'.
     * 
     * @return the value of field 'DisplayId'.
     */
    public java.lang.String getDisplayId(
    ) {
        return this._displayId;
    }

    /**
     * Returns the value of field 'documentsJoined'.
     * 
     * @return the value of field 'DocumentsJoined'.
     */
    public turbomeca.gamme.assembly.services.model.data.DocumentsJoined getDocumentsJoined(
    ) {
        return this._documentsJoined;
    }

    /**
     * Returns the value of field 'duplicableInstance'.
     * 
     * @return the value of field 'DuplicableInstance'.
     */
    public turbomeca.gamme.assembly.services.model.data.types.BooleanType getDuplicableInstance(
    ) {
        return this._duplicableInstance;
    }

    /**
     * Method getEffectivity.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the java.lang.String at the given index
     */
    public java.lang.String getEffectivity(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._effectivityList.size()) {
            throw new IndexOutOfBoundsException("getEffectivity: Index value '" + index + "' not in range [0.." + (this._effectivityList.size() - 1) + "]");
        }

        return (java.lang.String) _effectivityList.get(index);
    }

    /**
     * Method getEffectivity.Returns the contents of the collection
     * in an Array.  <p>Note:  Just in case the collection contents
     * are changing in another thread, we pass a 0-length Array of
     * the correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public java.lang.String[] getEffectivity(
    ) {
        java.lang.String[] array = new java.lang.String[0];
        return (java.lang.String[]) this._effectivityList.toArray(array);
    }

    /**
     * Method getEffectivityAsReference.Returns a reference to
     * '_effectivityList'. No type checking is performed on any
     * modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<java.lang.String> getEffectivityAsReference(
    ) {
        return this._effectivityList;
    }

    /**
     * Method getEffectivityCount.
     * 
     * @return the size of this collection
     */
    public int getEffectivityCount(
    ) {
        return this._effectivityList.size();
    }

    /**
     * Returns the value of field 'electronicNotifications'.
     * 
     * @return the value of field 'ElectronicNotifications'.
     */
    public turbomeca.gamme.assembly.services.model.data.ElectronicNotifications getElectronicNotifications(
    ) {
        return this._electronicNotifications;
    }

    /**
     * Method getFollowers.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the java.lang.Object at the given index
     */
    public java.lang.Object getFollowers(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._followers.size()) {
            throw new IndexOutOfBoundsException("getFollowers: Index value '" + index + "' not in range [0.." + (this._followers.size() - 1) + "]");
        }

        return _followers.get(index);
    }

    /**
     * Method getFollowers.Returns the contents of the collection
     * in an Array.  <p>Note:  Just in case the collection contents
     * are changing in another thread, we pass a 0-length Array of
     * the correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public java.lang.Object[] getFollowers(
    ) {
        java.lang.Object[] array = new java.lang.Object[0];
        return (java.lang.Object[]) this._followers.toArray(array);
    }

    /**
     * Method getFollowersAsReference.Returns a reference to
     * '_followers'. No type checking is performed on any
     * modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<java.lang.Object> getFollowersAsReference(
    ) {
        return this._followers;
    }

    /**
     * Method getFollowersCount.
     * 
     * @return the size of this collection
     */
    public int getFollowersCount(
    ) {
        return this._followers.size();
    }

    /**
     * Returns the value of field 'forcePredecessorsValid'.
     * 
     * @return the value of field 'ForcePredecessorsValid'.
     */
    public boolean getForcePredecessorsValid(
    ) {
        return this._forcePredecessorsValid;
    }

    /**
     * Returns the value of field 'historical'.
     * 
     * @return the value of field 'Historical'.
     */
    public turbomeca.gamme.assembly.services.model.data.Historical getHistorical(
    ) {
        return this._historical;
    }

    /**
     * Returns the value of field 'id'.
     * 
     * @return the value of field 'Id'.
     */
    public java.lang.String getId(
    ) {
        return this._id;
    }

    /**
     * Returns the value of field 'infoSubPhase'.
     * 
     * @return the value of field 'InfoSubPhase'.
     */
    public turbomeca.gamme.assembly.services.model.data.InfoSubPhase getInfoSubPhase(
    ) {
        return this._infoSubPhase;
    }

    /**
     * Returns the value of field 'instance'.
     * 
     * @return the value of field 'Instance'.
     */
    public int getInstance(
    ) {
        return this._instance;
    }

    /**
     * Returns the value of field 'isAlternative'.
     * 
     * @return the value of field 'IsAlternative'.
     */
    public boolean getIsAlternative(
    ) {
        return this._isAlternative;
    }

    /**
     * Returns the value of field 'isDelegate'.
     * 
     * @return the value of field 'IsDelegate'.
     */
    public boolean getIsDelegate(
    ) {
        return this._isDelegate;
    }

    /**
     * Returns the value of field 'matrix'.
     * 
     * @return the value of field 'Matrix'.
     */
    public turbomeca.gamme.assembly.services.model.data.Matrix getMatrix(
    ) {
        return this._matrix;
    }

    /**
     * Returns the value of field 'number'. The field 'number' has
     * the following description: SubPhase Number to be displayed
     * in GUI when defined
     * 
     * @return the value of field 'Number'.
     */
    public int getNumber(
    ) {
        return this._number;
    }

    /**
     * Returns the value of field 'optional'.
     * 
     * @return the value of field 'Optional'.
     */
    public boolean getOptional(
    ) {
        return this._optional;
    }

    /**
     * Returns the value of field 'optionalChoice'.
     * 
     * @return the value of field 'OptionalChoice'.
     */
    public turbomeca.gamme.assembly.services.model.data.OptionalChoice getOptionalChoice(
    ) {
        return this._optionalChoice;
    }

    /**
     * Returns the value of field 'partialTuning'.
     * 
     * @return the value of field 'PartialTuning'.
     */
    public boolean getPartialTuning(
    ) {
        return this._partialTuning;
    }

    /**
     * Returns the value of field 'passing'.
     * 
     * @return the value of field 'Passing'.
     */
    public int getPassing(
    ) {
        return this._passing;
    }

    /**
     * Method getPredecessors.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the java.lang.Object at the given index
     */
    public java.lang.Object getPredecessors(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._predecessors.size()) {
            throw new IndexOutOfBoundsException("getPredecessors: Index value '" + index + "' not in range [0.." + (this._predecessors.size() - 1) + "]");
        }

        return _predecessors.get(index);
    }

    /**
     * Method getPredecessors.Returns the contents of the
     * collection in an Array.  <p>Note:  Just in case the
     * collection contents are changing in another thread, we pass
     * a 0-length Array of the correct type into the API call. 
     * This way we <i>know</i> that the Array returned is of
     * exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public java.lang.Object[] getPredecessors(
    ) {
        java.lang.Object[] array = new java.lang.Object[0];
        return (java.lang.Object[]) this._predecessors.toArray(array);
    }

    /**
     * Method getPredecessorsAsReference.Returns a reference to
     * '_predecessors'. No type checking is performed on any
     * modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<java.lang.Object> getPredecessorsAsReference(
    ) {
        return this._predecessors;
    }

    /**
     * Method getPredecessorsCount.
     * 
     * @return the size of this collection
     */
    public int getPredecessorsCount(
    ) {
        return this._predecessors.size();
    }

    /**
     * Returns the value of field 'qualifications'.
     * 
     * @return the value of field 'Qualifications'.
     */
    public turbomeca.gamme.assembly.services.model.data.Qualifications getQualifications(
    ) {
        return this._qualifications;
    }

    /**
     * Returns the value of field 'resources'.
     * 
     * @return the value of field 'Resources'.
     */
    public turbomeca.gamme.assembly.services.model.data.Resources getResources(
    ) {
        return this._resources;
    }

    /**
     * Returns the value of field 'rework'.
     * 
     * @return the value of field 'Rework'.
     */
    public turbomeca.gamme.assembly.services.model.data.types.BooleanType getRework(
    ) {
        return this._rework;
    }

    /**
     * Returns the value of field 'sapCommand'.
     * 
     * @return the value of field 'SapCommand'.
     */
    public java.lang.String getSapCommand(
    ) {
        return this._sapCommand;
    }

    /**
     * Returns the value of field 'signature'.
     * 
     * @return the value of field 'Signature'.
     */
    public turbomeca.gamme.assembly.services.model.data.types.BooleanTypeWithNull getSignature(
    ) {
        return this._signature;
    }

    /**
     * Returns the value of field 'state'.
     * 
     * @return the value of field 'State'.
     */
    public turbomeca.gamme.assembly.services.model.data.State getState(
    ) {
        return this._state;
    }

    /**
     * Returns the value of field 'synchronizedWithSap'.
     * 
     * @return the value of field 'SynchronizedWithSap'.
     */
    public boolean getSynchronizedWithSap(
    ) {
        return this._synchronizedWithSap;
    }

    /**
     * Returns the value of field 'tasks'.
     * 
     * @return the value of field 'Tasks'.
     */
    public turbomeca.gamme.assembly.services.model.data.Tasks getTasks(
    ) {
        return this._tasks;
    }

    /**
     * Returns the value of field 'title'.
     * 
     * @return the value of field 'Title'.
     */
    public turbomeca.gamme.assembly.services.model.data.Title getTitle(
    ) {
        return this._title;
    }

    /**
     * Returns the value of field 'type'.
     * 
     * @return the value of field 'Type'.
     */
    public java.lang.String getType(
    ) {
        return this._type;
    }

    /**
     * Returns the value of field 'unlockComment'.
     * 
     * @return the value of field 'UnlockComment'.
     */
    public java.lang.String getUnlockComment(
    ) {
        return this._unlockComment;
    }

    /**
     * Returns the value of field 'validable'.
     * 
     * @return the value of field 'Validable'.
     */
    public boolean getValidable(
    ) {
        return this._validable;
    }

    /**
     * Method hasApplicable.
     * 
     * @return true if at least one Applicable has been added
     */
    public boolean hasApplicable(
    ) {
        return this._has_applicable;
    }

    /**
     * Method hasArchive.
     * 
     * @return true if at least one Archive has been added
     */
    public boolean hasArchive(
    ) {
        return this._has_archive;
    }

    /**
     * Method hasForcePredecessorsValid.
     * 
     * @return true if at least one ForcePredecessorsValid has been
     * added
     */
    public boolean hasForcePredecessorsValid(
    ) {
        return this._has_forcePredecessorsValid;
    }

    /**
     * Method hasInstance.
     * 
     * @return true if at least one Instance has been added
     */
    public boolean hasInstance(
    ) {
        return this._has_instance;
    }

    /**
     * Method hasIsAlternative.
     * 
     * @return true if at least one IsAlternative has been added
     */
    public boolean hasIsAlternative(
    ) {
        return this._has_isAlternative;
    }

    /**
     * Method hasIsDelegate.
     * 
     * @return true if at least one IsDelegate has been added
     */
    public boolean hasIsDelegate(
    ) {
        return this._has_isDelegate;
    }

    /**
     * Method hasNumber.
     * 
     * @return true if at least one Number has been added
     */
    public boolean hasNumber(
    ) {
        return this._has_number;
    }

    /**
     * Method hasOptional.
     * 
     * @return true if at least one Optional has been added
     */
    public boolean hasOptional(
    ) {
        return this._has_optional;
    }

    /**
     * Method hasPartialTuning.
     * 
     * @return true if at least one PartialTuning has been added
     */
    public boolean hasPartialTuning(
    ) {
        return this._has_partialTuning;
    }

    /**
     * Method hasPassing.
     * 
     * @return true if at least one Passing has been added
     */
    public boolean hasPassing(
    ) {
        return this._has_passing;
    }

    /**
     * Method hasSynchronizedWithSap.
     * 
     * @return true if at least one SynchronizedWithSap has been
     * added
     */
    public boolean hasSynchronizedWithSap(
    ) {
        return this._has_synchronizedWithSap;
    }

    /**
     * Method hasValidable.
     * 
     * @return true if at least one Validable has been added
     */
    public boolean hasValidable(
    ) {
        return this._has_validable;
    }

    /**
     * Returns the value of field 'applicable'.
     * 
     * @return the value of field 'Applicable'.
     */
    public boolean isApplicable(
    ) {
        return this._applicable;
    }

    /**
     * Returns the value of field 'archive'.
     * 
     * @return the value of field 'Archive'.
     */
    public boolean isArchive(
    ) {
        return this._archive;
    }

    /**
     * Returns the value of field 'forcePredecessorsValid'.
     * 
     * @return the value of field 'ForcePredecessorsValid'.
     */
    public boolean isForcePredecessorsValid(
    ) {
        return this._forcePredecessorsValid;
    }

    /**
     * Returns the value of field 'isAlternative'.
     * 
     * @return the value of field 'IsAlternative'.
     */
    public boolean isIsAlternative(
    ) {
        return this._isAlternative;
    }

    /**
     * Returns the value of field 'isDelegate'.
     * 
     * @return the value of field 'IsDelegate'.
     */
    public boolean isIsDelegate(
    ) {
        return this._isDelegate;
    }

    /**
     * Returns the value of field 'optional'.
     * 
     * @return the value of field 'Optional'.
     */
    public boolean isOptional(
    ) {
        return this._optional;
    }

    /**
     * Returns the value of field 'partialTuning'.
     * 
     * @return the value of field 'PartialTuning'.
     */
    public boolean isPartialTuning(
    ) {
        return this._partialTuning;
    }

    /**
     * Returns the value of field 'synchronizedWithSap'.
     * 
     * @return the value of field 'SynchronizedWithSap'.
     */
    public boolean isSynchronizedWithSap(
    ) {
        return this._synchronizedWithSap;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * Returns the value of field 'validable'.
     * 
     * @return the value of field 'Validable'.
     */
    public boolean isValidable(
    ) {
        return this._validable;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllAlternatives(
    ) {
        this._alternatives.clear();
    }

    /**
     */
    public void removeAllEffectivity(
    ) {
        this._effectivityList.clear();
    }

    /**
     */
    public void removeAllFollowers(
    ) {
        this._followers.clear();
    }

    /**
     */
    public void removeAllPredecessors(
    ) {
        this._predecessors.clear();
    }

    /**
     * Method removeAlternatives.
     * 
     * @param vAlternatives
     * @return true if the object was removed from the collection.
     */
    public boolean removeAlternatives(
            final java.lang.Object vAlternatives) {
        boolean removed = _alternatives.remove(vAlternatives);
        return removed;
    }

    /**
     * Method removeAlternativesAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public java.lang.Object removeAlternativesAt(
            final int index) {
        java.lang.Object obj = this._alternatives.remove(index);
        return obj;
    }

    /**
     * Method removeEffectivity.
     * 
     * @param vEffectivity
     * @return true if the object was removed from the collection.
     */
    public boolean removeEffectivity(
            final java.lang.String vEffectivity) {
        boolean removed = _effectivityList.remove(vEffectivity);
        return removed;
    }

    /**
     * Method removeEffectivityAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public java.lang.String removeEffectivityAt(
            final int index) {
        java.lang.Object obj = this._effectivityList.remove(index);
        return (java.lang.String) obj;
    }

    /**
     * Method removeFollowers.
     * 
     * @param vFollowers
     * @return true if the object was removed from the collection.
     */
    public boolean removeFollowers(
            final java.lang.Object vFollowers) {
        boolean removed = _followers.remove(vFollowers);
        return removed;
    }

    /**
     * Method removeFollowersAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public java.lang.Object removeFollowersAt(
            final int index) {
        java.lang.Object obj = this._followers.remove(index);
        return obj;
    }

    /**
     * Method removePredecessors.
     * 
     * @param vPredecessors
     * @return true if the object was removed from the collection.
     */
    public boolean removePredecessors(
            final java.lang.Object vPredecessors) {
        boolean removed = _predecessors.remove(vPredecessors);
        return removed;
    }

    /**
     * Method removePredecessorsAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public java.lang.Object removePredecessorsAt(
            final int index) {
        java.lang.Object obj = this._predecessors.remove(index);
        return obj;
    }

    /**
     * 
     * 
     * @param index
     * @param vAlternatives
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setAlternatives(
            final int index,
            final java.lang.Object vAlternatives)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._alternatives.size()) {
            throw new IndexOutOfBoundsException("setAlternatives: Index value '" + index + "' not in range [0.." + (this._alternatives.size() - 1) + "]");
        }

        this._alternatives.set(index, vAlternatives);
    }

    /**
     * 
     * 
     * @param vAlternativesArray
     */
    public void setAlternatives(
            final java.lang.Object[] vAlternativesArray) {
        //-- copy array
        _alternatives.clear();

        for (int i = 0; i < vAlternativesArray.length; i++) {
                this._alternatives.add(vAlternativesArray[i]);
        }
    }

    /**
     * Sets the value of '_alternatives' by copying the given
     * Vector. All elements will be checked for type safety.
     * 
     * @param vAlternativesList the Vector to copy.
     */
    public void setAlternatives(
            final java.util.Vector<java.lang.Object> vAlternativesList) {
        // copy vector
        this._alternatives.clear();

        this._alternatives.addAll(vAlternativesList);
    }

    /**
     * Sets the value of '_alternatives' by setting it to the given
     * Vector. No type checking is performed.
     * @deprecated
     * 
     * @param alternativesVector the Vector to set.
     */
    public void setAlternativesAsReference(
            final java.util.Vector<java.lang.Object> alternativesVector) {
        this._alternatives = alternativesVector;
    }

    /**
     * Sets the value of field 'applicable'.
     * 
     * @param applicable the value of field 'applicable'.
     */
    public void setApplicable(
            final boolean applicable) {
        this._applicable = applicable;
        this._has_applicable = true;
    }

    /**
     * Sets the value of field 'archive'.
     * 
     * @param archive the value of field 'archive'.
     */
    public void setArchive(
            final boolean archive) {
        this._archive = archive;
        this._has_archive = true;
    }

    /**
     * Sets the value of field 'comment'.
     * 
     * @param comment the value of field 'comment'.
     */
    public void setComment(
            final java.lang.String comment) {
        this._comment = comment;
    }

    /**
     * Sets the value of field 'displayId'.
     * 
     * @param displayId the value of field 'displayId'.
     */
    public void setDisplayId(
            final java.lang.String displayId) {
        this._displayId = displayId;
    }

    /**
     * Sets the value of field 'documentsJoined'.
     * 
     * @param documentsJoined the value of field 'documentsJoined'.
     */
    public void setDocumentsJoined(
            final turbomeca.gamme.assembly.services.model.data.DocumentsJoined documentsJoined) {
        this._documentsJoined = documentsJoined;
    }

    /**
     * Sets the value of field 'duplicableInstance'.
     * 
     * @param duplicableInstance the value of field
     * 'duplicableInstance'.
     */
    public void setDuplicableInstance(
            final turbomeca.gamme.assembly.services.model.data.types.BooleanType duplicableInstance) {
        this._duplicableInstance = duplicableInstance;
    }

    /**
     * 
     * 
     * @param index
     * @param vEffectivity
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setEffectivity(
            final int index,
            final java.lang.String vEffectivity)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._effectivityList.size()) {
            throw new IndexOutOfBoundsException("setEffectivity: Index value '" + index + "' not in range [0.." + (this._effectivityList.size() - 1) + "]");
        }

        this._effectivityList.set(index, vEffectivity);
    }

    /**
     * 
     * 
     * @param vEffectivityArray
     */
    public void setEffectivity(
            final java.lang.String[] vEffectivityArray) {
        //-- copy array
        _effectivityList.clear();

        for (int i = 0; i < vEffectivityArray.length; i++) {
                this._effectivityList.add(vEffectivityArray[i]);
        }
    }

    /**
     * Sets the value of '_effectivityList' by copying the given
     * Vector. All elements will be checked for type safety.
     * 
     * @param vEffectivityList the Vector to copy.
     */
    public void setEffectivity(
            final java.util.Vector<java.lang.String> vEffectivityList) {
        // copy vector
        this._effectivityList.clear();

        this._effectivityList.addAll(vEffectivityList);
    }

    /**
     * Sets the value of '_effectivityList' by setting it to the
     * given Vector. No type checking is performed.
     * @deprecated
     * 
     * @param effectivityVector the Vector to set.
     */
    public void setEffectivityAsReference(
            final java.util.Vector<java.lang.String> effectivityVector) {
        this._effectivityList = effectivityVector;
    }

    /**
     * Sets the value of field 'electronicNotifications'.
     * 
     * @param electronicNotifications the value of field
     * 'electronicNotifications'.
     */
    public void setElectronicNotifications(
            final turbomeca.gamme.assembly.services.model.data.ElectronicNotifications electronicNotifications) {
        this._electronicNotifications = electronicNotifications;
    }

    /**
     * 
     * 
     * @param index
     * @param vFollowers
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setFollowers(
            final int index,
            final java.lang.Object vFollowers)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._followers.size()) {
            throw new IndexOutOfBoundsException("setFollowers: Index value '" + index + "' not in range [0.." + (this._followers.size() - 1) + "]");
        }

        this._followers.set(index, vFollowers);
    }

    /**
     * 
     * 
     * @param vFollowersArray
     */
    public void setFollowers(
            final java.lang.Object[] vFollowersArray) {
        //-- copy array
        _followers.clear();

        for (int i = 0; i < vFollowersArray.length; i++) {
                this._followers.add(vFollowersArray[i]);
        }
    }

    /**
     * Sets the value of '_followers' by copying the given Vector.
     * All elements will be checked for type safety.
     * 
     * @param vFollowersList the Vector to copy.
     */
    public void setFollowers(
            final java.util.Vector<java.lang.Object> vFollowersList) {
        // copy vector
        this._followers.clear();

        this._followers.addAll(vFollowersList);
    }

    /**
     * Sets the value of '_followers' by setting it to the given
     * Vector. No type checking is performed.
     * @deprecated
     * 
     * @param followersVector the Vector to set.
     */
    public void setFollowersAsReference(
            final java.util.Vector<java.lang.Object> followersVector) {
        this._followers = followersVector;
    }

    /**
     * Sets the value of field 'forcePredecessorsValid'.
     * 
     * @param forcePredecessorsValid the value of field
     * 'forcePredecessorsValid'.
     */
    public void setForcePredecessorsValid(
            final boolean forcePredecessorsValid) {
        this._forcePredecessorsValid = forcePredecessorsValid;
        this._has_forcePredecessorsValid = true;
    }

    /**
     * Sets the value of field 'historical'.
     * 
     * @param historical the value of field 'historical'.
     */
    public void setHistorical(
            final turbomeca.gamme.assembly.services.model.data.Historical historical) {
        this._historical = historical;
    }

    /**
     * Sets the value of field 'id'.
     * 
     * @param id the value of field 'id'.
     */
    public void setId(
            final java.lang.String id) {
        this._id = id;
    }

    /**
     * Sets the value of field 'infoSubPhase'.
     * 
     * @param infoSubPhase the value of field 'infoSubPhase'.
     */
    public void setInfoSubPhase(
            final turbomeca.gamme.assembly.services.model.data.InfoSubPhase infoSubPhase) {
        this._infoSubPhase = infoSubPhase;
    }

    /**
     * Sets the value of field 'instance'.
     * 
     * @param instance the value of field 'instance'.
     */
    public void setInstance(
            final int instance) {
        this._instance = instance;
        this._has_instance = true;
    }

    /**
     * Sets the value of field 'isAlternative'.
     * 
     * @param isAlternative the value of field 'isAlternative'.
     */
    public void setIsAlternative(
            final boolean isAlternative) {
        this._isAlternative = isAlternative;
        this._has_isAlternative = true;
    }

    /**
     * Sets the value of field 'isDelegate'.
     * 
     * @param isDelegate the value of field 'isDelegate'.
     */
    public void setIsDelegate(
            final boolean isDelegate) {
        this._isDelegate = isDelegate;
        this._has_isDelegate = true;
    }

    /**
     * Sets the value of field 'matrix'.
     * 
     * @param matrix the value of field 'matrix'.
     */
    public void setMatrix(
            final turbomeca.gamme.assembly.services.model.data.Matrix matrix) {
        this._matrix = matrix;
    }

    /**
     * Sets the value of field 'number'. The field 'number' has the
     * following description: SubPhase Number to be displayed in
     * GUI when defined
     * 
     * @param number the value of field 'number'.
     */
    public void setNumber(
            final int number) {
        this._number = number;
        this._has_number = true;
    }

    /**
     * Sets the value of field 'optional'.
     * 
     * @param optional the value of field 'optional'.
     */
    public void setOptional(
            final boolean optional) {
        this._optional = optional;
        this._has_optional = true;
    }

    /**
     * Sets the value of field 'optionalChoice'.
     * 
     * @param optionalChoice the value of field 'optionalChoice'.
     */
    public void setOptionalChoice(
            final turbomeca.gamme.assembly.services.model.data.OptionalChoice optionalChoice) {
        this._optionalChoice = optionalChoice;
    }

    /**
     * Sets the value of field 'partialTuning'.
     * 
     * @param partialTuning the value of field 'partialTuning'.
     */
    public void setPartialTuning(
            final boolean partialTuning) {
        this._partialTuning = partialTuning;
        this._has_partialTuning = true;
    }

    /**
     * Sets the value of field 'passing'.
     * 
     * @param passing the value of field 'passing'.
     */
    public void setPassing(
            final int passing) {
        this._passing = passing;
        this._has_passing = true;
    }

    /**
     * 
     * 
     * @param index
     * @param vPredecessors
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setPredecessors(
            final int index,
            final java.lang.Object vPredecessors)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._predecessors.size()) {
            throw new IndexOutOfBoundsException("setPredecessors: Index value '" + index + "' not in range [0.." + (this._predecessors.size() - 1) + "]");
        }

        this._predecessors.set(index, vPredecessors);
    }

    /**
     * 
     * 
     * @param vPredecessorsArray
     */
    public void setPredecessors(
            final java.lang.Object[] vPredecessorsArray) {
        //-- copy array
        _predecessors.clear();

        for (int i = 0; i < vPredecessorsArray.length; i++) {
                this._predecessors.add(vPredecessorsArray[i]);
        }
    }

    /**
     * Sets the value of '_predecessors' by copying the given
     * Vector. All elements will be checked for type safety.
     * 
     * @param vPredecessorsList the Vector to copy.
     */
    public void setPredecessors(
            final java.util.Vector<java.lang.Object> vPredecessorsList) {
        // copy vector
        this._predecessors.clear();

        this._predecessors.addAll(vPredecessorsList);
    }

    /**
     * Sets the value of '_predecessors' by setting it to the given
     * Vector. No type checking is performed.
     * @deprecated
     * 
     * @param predecessorsVector the Vector to set.
     */
    public void setPredecessorsAsReference(
            final java.util.Vector<java.lang.Object> predecessorsVector) {
        this._predecessors = predecessorsVector;
    }

    /**
     * Sets the value of field 'qualifications'.
     * 
     * @param qualifications the value of field 'qualifications'.
     */
    public void setQualifications(
            final turbomeca.gamme.assembly.services.model.data.Qualifications qualifications) {
        this._qualifications = qualifications;
    }

    /**
     * Sets the value of field 'resources'.
     * 
     * @param resources the value of field 'resources'.
     */
    public void setResources(
            final turbomeca.gamme.assembly.services.model.data.Resources resources) {
        this._resources = resources;
    }

    /**
     * Sets the value of field 'rework'.
     * 
     * @param rework the value of field 'rework'.
     */
    public void setRework(
            final turbomeca.gamme.assembly.services.model.data.types.BooleanType rework) {
        this._rework = rework;
    }

    /**
     * Sets the value of field 'sapCommand'.
     * 
     * @param sapCommand the value of field 'sapCommand'.
     */
    public void setSapCommand(
            final java.lang.String sapCommand) {
        this._sapCommand = sapCommand;
    }

    /**
     * Sets the value of field 'signature'.
     * 
     * @param signature the value of field 'signature'.
     */
    public void setSignature(
            final turbomeca.gamme.assembly.services.model.data.types.BooleanTypeWithNull signature) {
        this._signature = signature;
    }

    /**
     * Sets the value of field 'state'.
     * 
     * @param state the value of field 'state'.
     */
    public void setState(
            final turbomeca.gamme.assembly.services.model.data.State state) {
        this._state = state;
    }

    /**
     * Sets the value of field 'synchronizedWithSap'.
     * 
     * @param synchronizedWithSap the value of field
     * 'synchronizedWithSap'.
     */
    public void setSynchronizedWithSap(
            final boolean synchronizedWithSap) {
        this._synchronizedWithSap = synchronizedWithSap;
        this._has_synchronizedWithSap = true;
    }

    /**
     * Sets the value of field 'tasks'.
     * 
     * @param tasks the value of field 'tasks'.
     */
    public void setTasks(
            final turbomeca.gamme.assembly.services.model.data.Tasks tasks) {
        this._tasks = tasks;
    }

    /**
     * Sets the value of field 'title'.
     * 
     * @param title the value of field 'title'.
     */
    public void setTitle(
            final turbomeca.gamme.assembly.services.model.data.Title title) {
        this._title = title;
    }

    /**
     * Sets the value of field 'type'.
     * 
     * @param type the value of field 'type'.
     */
    public void setType(
            final java.lang.String type) {
        this._type = type;
    }

    /**
     * Sets the value of field 'unlockComment'.
     * 
     * @param unlockComment the value of field 'unlockComment'.
     */
    public void setUnlockComment(
            final java.lang.String unlockComment) {
        this._unlockComment = unlockComment;
    }

    /**
     * Sets the value of field 'validable'.
     * 
     * @param validable the value of field 'validable'.
     */
    public void setValidable(
            final boolean validable) {
        this._validable = validable;
        this._has_validable = true;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.SubPhase
     */
    public static turbomeca.gamme.assembly.services.model.data.SubPhase unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.SubPhase) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.SubPhase.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
