/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class TaskParaItem.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class TaskParaItem implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Internal choice value storage
     */
    private java.lang.Object _choiceValue;

    /**
     * Field _carriage_return.
     */
    private java.lang.Object _carriage_return;

    /**
     * Field _para.
     */
    private turbomeca.gamme.assembly.services.model.data.Para _para;

    /**
     * Field _ingredientSubPhaseRef.
     */
    private turbomeca.gamme.assembly.services.model.data.IngredientSubPhaseRef _ingredientSubPhaseRef;

    /**
     * Field _toolSubPhaseRef.
     */
    private turbomeca.gamme.assembly.services.model.data.ToolSubPhaseRef _toolSubPhaseRef;

    /**
     * Field _documentSubPhaseRef.
     */
    private turbomeca.gamme.assembly.services.model.data.DocumentSubPhaseRef _documentSubPhaseRef;

    /**
     * Field _warning.
     */
    private turbomeca.gamme.assembly.services.model.data.Warning _warning;

    /**
     * Field _externalLink.
     */
    private turbomeca.gamme.assembly.services.model.data.ExternalLink _externalLink;

    /**
     * Field _table.
     */
    private turbomeca.gamme.assembly.services.model.data.Table _table;

    /**
     * Field _barCode.
     */
    private java.lang.String _barCode;

    /**
     * Field _paraList.
     */
    private turbomeca.gamme.assembly.services.model.data.ParaList _paraList;

    /**
     * Field _letterDigitBoxed.
     */
    private java.lang.String _letterDigitBoxed;

    /**
     * Field _letterDigitCircled.
     */
    private java.lang.String _letterDigitCircled;

    /**
     * Field _tolerance.
     */
    private int _tolerance;

    /**
     * keeps track of state for field: _tolerance
     */
    private boolean _has_tolerance;

    /**
     * Field _exponent.
     */
    private int _exponent;

    /**
     * keeps track of state for field: _exponent
     */
    private boolean _has_exponent;

    /**
     * Field _index.
     */
    private int _index;

    /**
     * keeps track of state for field: _index
     */
    private boolean _has_index;

    /**
     * Field _pictogram.
     */
    private turbomeca.gamme.assembly.services.model.data.Pictogram _pictogram;


      //----------------/
     //- Constructors -/
    //----------------/

    public TaskParaItem() {
        super();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     */
    public void deleteExponent(
    ) {
        this._has_exponent= false;
    }

    /**
     */
    public void deleteIndex(
    ) {
        this._has_index= false;
    }

    /**
     */
    public void deleteTolerance(
    ) {
        this._has_tolerance= false;
    }

    /**
     * Returns the value of field 'barCode'.
     * 
     * @return the value of field 'BarCode'.
     */
    public java.lang.String getBarCode(
    ) {
        return this._barCode;
    }

    /**
     * Returns the value of field 'carriage_return'.
     * 
     * @return the value of field 'Carriage_return'.
     */
    public java.lang.Object getCarriage_return(
    ) {
        return this._carriage_return;
    }

    /**
     * Returns the value of field 'choiceValue'. The field
     * 'choiceValue' has the following description: Internal choice
     * value storage
     * 
     * @return the value of field 'ChoiceValue'.
     */
    public java.lang.Object getChoiceValue(
    ) {
        return this._choiceValue;
    }

    /**
     * Returns the value of field 'documentSubPhaseRef'.
     * 
     * @return the value of field 'DocumentSubPhaseRef'.
     */
    public turbomeca.gamme.assembly.services.model.data.DocumentSubPhaseRef getDocumentSubPhaseRef(
    ) {
        return this._documentSubPhaseRef;
    }

    /**
     * Returns the value of field 'exponent'.
     * 
     * @return the value of field 'Exponent'.
     */
    public int getExponent(
    ) {
        return this._exponent;
    }

    /**
     * Returns the value of field 'externalLink'.
     * 
     * @return the value of field 'ExternalLink'.
     */
    public turbomeca.gamme.assembly.services.model.data.ExternalLink getExternalLink(
    ) {
        return this._externalLink;
    }

    /**
     * Returns the value of field 'index'.
     * 
     * @return the value of field 'Index'.
     */
    public int getIndex(
    ) {
        return this._index;
    }

    /**
     * Returns the value of field 'ingredientSubPhaseRef'.
     * 
     * @return the value of field 'IngredientSubPhaseRef'.
     */
    public turbomeca.gamme.assembly.services.model.data.IngredientSubPhaseRef getIngredientSubPhaseRef(
    ) {
        return this._ingredientSubPhaseRef;
    }

    /**
     * Returns the value of field 'letterDigitBoxed'.
     * 
     * @return the value of field 'LetterDigitBoxed'.
     */
    public java.lang.String getLetterDigitBoxed(
    ) {
        return this._letterDigitBoxed;
    }

    /**
     * Returns the value of field 'letterDigitCircled'.
     * 
     * @return the value of field 'LetterDigitCircled'.
     */
    public java.lang.String getLetterDigitCircled(
    ) {
        return this._letterDigitCircled;
    }

    /**
     * Returns the value of field 'para'.
     * 
     * @return the value of field 'Para'.
     */
    public turbomeca.gamme.assembly.services.model.data.Para getPara(
    ) {
        return this._para;
    }

    /**
     * Returns the value of field 'paraList'.
     * 
     * @return the value of field 'ParaList'.
     */
    public turbomeca.gamme.assembly.services.model.data.ParaList getParaList(
    ) {
        return this._paraList;
    }

    /**
     * Returns the value of field 'pictogram'.
     * 
     * @return the value of field 'Pictogram'.
     */
    public turbomeca.gamme.assembly.services.model.data.Pictogram getPictogram(
    ) {
        return this._pictogram;
    }

    /**
     * Returns the value of field 'table'.
     * 
     * @return the value of field 'Table'.
     */
    public turbomeca.gamme.assembly.services.model.data.Table getTable(
    ) {
        return this._table;
    }

    /**
     * Returns the value of field 'tolerance'.
     * 
     * @return the value of field 'Tolerance'.
     */
    public int getTolerance(
    ) {
        return this._tolerance;
    }

    /**
     * Returns the value of field 'toolSubPhaseRef'.
     * 
     * @return the value of field 'ToolSubPhaseRef'.
     */
    public turbomeca.gamme.assembly.services.model.data.ToolSubPhaseRef getToolSubPhaseRef(
    ) {
        return this._toolSubPhaseRef;
    }

    /**
     * Returns the value of field 'warning'.
     * 
     * @return the value of field 'Warning'.
     */
    public turbomeca.gamme.assembly.services.model.data.Warning getWarning(
    ) {
        return this._warning;
    }

    /**
     * Method hasExponent.
     * 
     * @return true if at least one Exponent has been added
     */
    public boolean hasExponent(
    ) {
        return this._has_exponent;
    }

    /**
     * Method hasIndex.
     * 
     * @return true if at least one Index has been added
     */
    public boolean hasIndex(
    ) {
        return this._has_index;
    }

    /**
     * Method hasTolerance.
     * 
     * @return true if at least one Tolerance has been added
     */
    public boolean hasTolerance(
    ) {
        return this._has_tolerance;
    }

    /**
     * Sets the value of field 'barCode'.
     * 
     * @param barCode the value of field 'barCode'.
     */
    public void setBarCode(
            final java.lang.String barCode) {
        this._barCode = barCode;
        this._choiceValue = barCode;
    }

    /**
     * Sets the value of field 'carriage_return'.
     * 
     * @param carriage_return the value of field 'carriage_return'.
     */
    public void setCarriage_return(
            final java.lang.Object carriage_return) {
        this._carriage_return = carriage_return;
        this._choiceValue = carriage_return;
    }

    /**
     * Sets the value of field 'documentSubPhaseRef'.
     * 
     * @param documentSubPhaseRef the value of field
     * 'documentSubPhaseRef'.
     */
    public void setDocumentSubPhaseRef(
            final turbomeca.gamme.assembly.services.model.data.DocumentSubPhaseRef documentSubPhaseRef) {
        this._documentSubPhaseRef = documentSubPhaseRef;
        this._choiceValue = documentSubPhaseRef;
    }

    /**
     * Sets the value of field 'exponent'.
     * 
     * @param exponent the value of field 'exponent'.
     */
    public void setExponent(
            final int exponent) {
        this._exponent = exponent;
        this._choiceValue = new java.lang.Integer(exponent);
        this._has_exponent = true;
    }

    /**
     * Sets the value of field 'externalLink'.
     * 
     * @param externalLink the value of field 'externalLink'.
     */
    public void setExternalLink(
            final turbomeca.gamme.assembly.services.model.data.ExternalLink externalLink) {
        this._externalLink = externalLink;
        this._choiceValue = externalLink;
    }

    /**
     * Sets the value of field 'index'.
     * 
     * @param index the value of field 'index'.
     */
    public void setIndex(
            final int index) {
        this._index = index;
        this._choiceValue = new java.lang.Integer(index);
        this._has_index = true;
    }

    /**
     * Sets the value of field 'ingredientSubPhaseRef'.
     * 
     * @param ingredientSubPhaseRef the value of field
     * 'ingredientSubPhaseRef'.
     */
    public void setIngredientSubPhaseRef(
            final turbomeca.gamme.assembly.services.model.data.IngredientSubPhaseRef ingredientSubPhaseRef) {
        this._ingredientSubPhaseRef = ingredientSubPhaseRef;
        this._choiceValue = ingredientSubPhaseRef;
    }

    /**
     * Sets the value of field 'letterDigitBoxed'.
     * 
     * @param letterDigitBoxed the value of field 'letterDigitBoxed'
     */
    public void setLetterDigitBoxed(
            final java.lang.String letterDigitBoxed) {
        this._letterDigitBoxed = letterDigitBoxed;
        this._choiceValue = letterDigitBoxed;
    }

    /**
     * Sets the value of field 'letterDigitCircled'.
     * 
     * @param letterDigitCircled the value of field
     * 'letterDigitCircled'.
     */
    public void setLetterDigitCircled(
            final java.lang.String letterDigitCircled) {
        this._letterDigitCircled = letterDigitCircled;
        this._choiceValue = letterDigitCircled;
    }

    /**
     * Sets the value of field 'para'.
     * 
     * @param para the value of field 'para'.
     */
    public void setPara(
            final turbomeca.gamme.assembly.services.model.data.Para para) {
        this._para = para;
        this._choiceValue = para;
    }

    /**
     * Sets the value of field 'paraList'.
     * 
     * @param paraList the value of field 'paraList'.
     */
    public void setParaList(
            final turbomeca.gamme.assembly.services.model.data.ParaList paraList) {
        this._paraList = paraList;
        this._choiceValue = paraList;
    }

    /**
     * Sets the value of field 'pictogram'.
     * 
     * @param pictogram the value of field 'pictogram'.
     */
    public void setPictogram(
            final turbomeca.gamme.assembly.services.model.data.Pictogram pictogram) {
        this._pictogram = pictogram;
        this._choiceValue = pictogram;
    }

    /**
     * Sets the value of field 'table'.
     * 
     * @param table the value of field 'table'.
     */
    public void setTable(
            final turbomeca.gamme.assembly.services.model.data.Table table) {
        this._table = table;
        this._choiceValue = table;
    }

    /**
     * Sets the value of field 'tolerance'.
     * 
     * @param tolerance the value of field 'tolerance'.
     */
    public void setTolerance(
            final int tolerance) {
        this._tolerance = tolerance;
        this._choiceValue = new java.lang.Integer(tolerance);
        this._has_tolerance = true;
    }

    /**
     * Sets the value of field 'toolSubPhaseRef'.
     * 
     * @param toolSubPhaseRef the value of field 'toolSubPhaseRef'.
     */
    public void setToolSubPhaseRef(
            final turbomeca.gamme.assembly.services.model.data.ToolSubPhaseRef toolSubPhaseRef) {
        this._toolSubPhaseRef = toolSubPhaseRef;
        this._choiceValue = toolSubPhaseRef;
    }

    /**
     * Sets the value of field 'warning'.
     * 
     * @param warning the value of field 'warning'.
     */
    public void setWarning(
            final turbomeca.gamme.assembly.services.model.data.Warning warning) {
        this._warning = warning;
        this._choiceValue = warning;
    }

}
