/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class ModifDescriptItem.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class ModifDescriptItem implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Internal choice value storage
     */
    private java.lang.Object _choiceValue;

    /**
     * Field _paraList.
     */
    private java.util.Vector<turbomeca.gamme.assembly.services.model.data.Para> _paraList;

    /**
     * Field _carriage_returnList.
     */
    private java.util.Vector<turbomeca.gamme.assembly.services.model.data.Carriage_return> _carriage_returnList;


      //----------------/
     //- Constructors -/
    //----------------/

    public ModifDescriptItem() {
        super();
        this._paraList = new java.util.Vector<turbomeca.gamme.assembly.services.model.data.Para>();
        this._carriage_returnList = new java.util.Vector<turbomeca.gamme.assembly.services.model.data.Carriage_return>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vCarriage_return
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addCarriage_return(
            final turbomeca.gamme.assembly.services.model.data.Carriage_return vCarriage_return)
    throws java.lang.IndexOutOfBoundsException {
        this._carriage_returnList.addElement(vCarriage_return);
    }

    /**
     * 
     * 
     * @param index
     * @param vCarriage_return
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addCarriage_return(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.Carriage_return vCarriage_return)
    throws java.lang.IndexOutOfBoundsException {
        this._carriage_returnList.add(index, vCarriage_return);
    }

    /**
     * 
     * 
     * @param vPara
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addPara(
            final turbomeca.gamme.assembly.services.model.data.Para vPara)
    throws java.lang.IndexOutOfBoundsException {
        this._paraList.addElement(vPara);
    }

    /**
     * 
     * 
     * @param index
     * @param vPara
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addPara(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.Para vPara)
    throws java.lang.IndexOutOfBoundsException {
        this._paraList.add(index, vPara);
    }

    /**
     * Method enumerateCarriage_return.
     * 
     * @return an Enumeration over all
     * turbomeca.gamme.assembly.services.model.data.Carriage_return
     * elements
     */
    public java.util.Enumeration<? extends turbomeca.gamme.assembly.services.model.data.Carriage_return> enumerateCarriage_return(
    ) {
        return this._carriage_returnList.elements();
    }

    /**
     * Method enumeratePara.
     * 
     * @return an Enumeration over all
     * turbomeca.gamme.assembly.services.model.data.Para elements
     */
    public java.util.Enumeration<? extends turbomeca.gamme.assembly.services.model.data.Para> enumeratePara(
    ) {
        return this._paraList.elements();
    }

    /**
     * Method getCarriage_return.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * turbomeca.gamme.assembly.services.model.data.Carriage_return
     * at the given index
     */
    public turbomeca.gamme.assembly.services.model.data.Carriage_return getCarriage_return(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._carriage_returnList.size()) {
            throw new IndexOutOfBoundsException("getCarriage_return: Index value '" + index + "' not in range [0.." + (this._carriage_returnList.size() - 1) + "]");
        }

        return (turbomeca.gamme.assembly.services.model.data.Carriage_return) _carriage_returnList.get(index);
    }

    /**
     * Method getCarriage_return.Returns the contents of the
     * collection in an Array.  <p>Note:  Just in case the
     * collection contents are changing in another thread, we pass
     * a 0-length Array of the correct type into the API call. 
     * This way we <i>know</i> that the Array returned is of
     * exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public turbomeca.gamme.assembly.services.model.data.Carriage_return[] getCarriage_return(
    ) {
        turbomeca.gamme.assembly.services.model.data.Carriage_return[] array = new turbomeca.gamme.assembly.services.model.data.Carriage_return[0];
        return (turbomeca.gamme.assembly.services.model.data.Carriage_return[]) this._carriage_returnList.toArray(array);
    }

    /**
     * Method getCarriage_returnAsReference.Returns a reference to
     * '_carriage_returnList'. No type checking is performed on any
     * modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<turbomeca.gamme.assembly.services.model.data.Carriage_return> getCarriage_returnAsReference(
    ) {
        return this._carriage_returnList;
    }

    /**
     * Method getCarriage_returnCount.
     * 
     * @return the size of this collection
     */
    public int getCarriage_returnCount(
    ) {
        return this._carriage_returnList.size();
    }

    /**
     * Returns the value of field 'choiceValue'. The field
     * 'choiceValue' has the following description: Internal choice
     * value storage
     * 
     * @return the value of field 'ChoiceValue'.
     */
    public java.lang.Object getChoiceValue(
    ) {
        return this._choiceValue;
    }

    /**
     * Method getPara.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * turbomeca.gamme.assembly.services.model.data.Para at the
     * given index
     */
    public turbomeca.gamme.assembly.services.model.data.Para getPara(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._paraList.size()) {
            throw new IndexOutOfBoundsException("getPara: Index value '" + index + "' not in range [0.." + (this._paraList.size() - 1) + "]");
        }

        return (turbomeca.gamme.assembly.services.model.data.Para) _paraList.get(index);
    }

    /**
     * Method getPara.Returns the contents of the collection in an
     * Array.  <p>Note:  Just in case the collection contents are
     * changing in another thread, we pass a 0-length Array of the
     * correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public turbomeca.gamme.assembly.services.model.data.Para[] getPara(
    ) {
        turbomeca.gamme.assembly.services.model.data.Para[] array = new turbomeca.gamme.assembly.services.model.data.Para[0];
        return (turbomeca.gamme.assembly.services.model.data.Para[]) this._paraList.toArray(array);
    }

    /**
     * Method getParaAsReference.Returns a reference to
     * '_paraList'. No type checking is performed on any
     * modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<turbomeca.gamme.assembly.services.model.data.Para> getParaAsReference(
    ) {
        return this._paraList;
    }

    /**
     * Method getParaCount.
     * 
     * @return the size of this collection
     */
    public int getParaCount(
    ) {
        return this._paraList.size();
    }

    /**
     */
    public void removeAllCarriage_return(
    ) {
        this._carriage_returnList.clear();
    }

    /**
     */
    public void removeAllPara(
    ) {
        this._paraList.clear();
    }

    /**
     * Method removeCarriage_return.
     * 
     * @param vCarriage_return
     * @return true if the object was removed from the collection.
     */
    public boolean removeCarriage_return(
            final turbomeca.gamme.assembly.services.model.data.Carriage_return vCarriage_return) {
        boolean removed = _carriage_returnList.remove(vCarriage_return);
        return removed;
    }

    /**
     * Method removeCarriage_returnAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public turbomeca.gamme.assembly.services.model.data.Carriage_return removeCarriage_returnAt(
            final int index) {
        java.lang.Object obj = this._carriage_returnList.remove(index);
        return (turbomeca.gamme.assembly.services.model.data.Carriage_return) obj;
    }

    /**
     * Method removePara.
     * 
     * @param vPara
     * @return true if the object was removed from the collection.
     */
    public boolean removePara(
            final turbomeca.gamme.assembly.services.model.data.Para vPara) {
        boolean removed = _paraList.remove(vPara);
        return removed;
    }

    /**
     * Method removeParaAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public turbomeca.gamme.assembly.services.model.data.Para removeParaAt(
            final int index) {
        java.lang.Object obj = this._paraList.remove(index);
        return (turbomeca.gamme.assembly.services.model.data.Para) obj;
    }

    /**
     * 
     * 
     * @param index
     * @param vCarriage_return
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setCarriage_return(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.Carriage_return vCarriage_return)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._carriage_returnList.size()) {
            throw new IndexOutOfBoundsException("setCarriage_return: Index value '" + index + "' not in range [0.." + (this._carriage_returnList.size() - 1) + "]");
        }

        this._carriage_returnList.set(index, vCarriage_return);
    }

    /**
     * 
     * 
     * @param vCarriage_returnArray
     */
    public void setCarriage_return(
            final turbomeca.gamme.assembly.services.model.data.Carriage_return[] vCarriage_returnArray) {
        //-- copy array
        _carriage_returnList.clear();

        for (int i = 0; i < vCarriage_returnArray.length; i++) {
                this._carriage_returnList.add(vCarriage_returnArray[i]);
        }
    }

    /**
     * Sets the value of '_carriage_returnList' by copying the
     * given Vector. All elements will be checked for type safety.
     * 
     * @param vCarriage_returnList the Vector to copy.
     */
    public void setCarriage_return(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.Carriage_return> vCarriage_returnList) {
        // copy vector
        this._carriage_returnList.clear();

        this._carriage_returnList.addAll(vCarriage_returnList);
    }

    /**
     * Sets the value of '_carriage_returnList' by setting it to
     * the given Vector. No type checking is performed.
     * @deprecated
     * 
     * @param carriage_returnVector the Vector to set.
     */
    public void setCarriage_returnAsReference(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.Carriage_return> carriage_returnVector) {
        this._carriage_returnList = carriage_returnVector;
    }

    /**
     * 
     * 
     * @param index
     * @param vPara
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setPara(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.Para vPara)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._paraList.size()) {
            throw new IndexOutOfBoundsException("setPara: Index value '" + index + "' not in range [0.." + (this._paraList.size() - 1) + "]");
        }

        this._paraList.set(index, vPara);
    }

    /**
     * 
     * 
     * @param vParaArray
     */
    public void setPara(
            final turbomeca.gamme.assembly.services.model.data.Para[] vParaArray) {
        //-- copy array
        _paraList.clear();

        for (int i = 0; i < vParaArray.length; i++) {
                this._paraList.add(vParaArray[i]);
        }
    }

    /**
     * Sets the value of '_paraList' by copying the given Vector.
     * All elements will be checked for type safety.
     * 
     * @param vParaList the Vector to copy.
     */
    public void setPara(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.Para> vParaList) {
        // copy vector
        this._paraList.clear();

        this._paraList.addAll(vParaList);
    }

    /**
     * Sets the value of '_paraList' by setting it to the given
     * Vector. No type checking is performed.
     * @deprecated
     * 
     * @param paraVector the Vector to set.
     */
    public void setParaAsReference(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.Para> paraVector) {
        this._paraList = paraVector;
    }

}
