/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class ObservationItem.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class ObservationItem implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Internal choice value storage
     */
    private java.lang.Object _choiceValue;

    /**
     * Field _carriage_return.
     */
    private turbomeca.gamme.assembly.services.model.data.Carriage_return _carriage_return;

    /**
     * Field _para.
     */
    private turbomeca.gamme.assembly.services.model.data.Para _para;


      //----------------/
     //- Constructors -/
    //----------------/

    public ObservationItem() {
        super();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'carriage_return'.
     * 
     * @return the value of field 'Carriage_return'.
     */
    public turbomeca.gamme.assembly.services.model.data.Carriage_return getCarriage_return(
    ) {
        return this._carriage_return;
    }

    /**
     * Returns the value of field 'choiceValue'. The field
     * 'choiceValue' has the following description: Internal choice
     * value storage
     * 
     * @return the value of field 'ChoiceValue'.
     */
    public java.lang.Object getChoiceValue(
    ) {
        return this._choiceValue;
    }

    /**
     * Returns the value of field 'para'.
     * 
     * @return the value of field 'Para'.
     */
    public turbomeca.gamme.assembly.services.model.data.Para getPara(
    ) {
        return this._para;
    }

    /**
     * Sets the value of field 'carriage_return'.
     * 
     * @param carriage_return the value of field 'carriage_return'.
     */
    public void setCarriage_return(
            final turbomeca.gamme.assembly.services.model.data.Carriage_return carriage_return) {
        this._carriage_return = carriage_return;
        this._choiceValue = carriage_return;
    }

    /**
     * Sets the value of field 'para'.
     * 
     * @param para the value of field 'para'.
     */
    public void setPara(
            final turbomeca.gamme.assembly.services.model.data.Para para) {
        this._para = para;
        this._choiceValue = para;
    }

}
