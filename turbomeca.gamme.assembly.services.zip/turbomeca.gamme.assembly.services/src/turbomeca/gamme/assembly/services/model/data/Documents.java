/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class Documents.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class Documents implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _documentList.
     */
    private java.util.Vector<turbomeca.gamme.assembly.services.model.data.Document> _documentList;


      //----------------/
     //- Constructors -/
    //----------------/

    public Documents() {
        super();
        this._documentList = new java.util.Vector<turbomeca.gamme.assembly.services.model.data.Document>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vDocument
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addDocument(
            final turbomeca.gamme.assembly.services.model.data.Document vDocument)
    throws java.lang.IndexOutOfBoundsException {
        this._documentList.addElement(vDocument);
    }

    /**
     * 
     * 
     * @param index
     * @param vDocument
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addDocument(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.Document vDocument)
    throws java.lang.IndexOutOfBoundsException {
        this._documentList.add(index, vDocument);
    }

    /**
     * Method enumerateDocument.
     * 
     * @return an Enumeration over all
     * turbomeca.gamme.assembly.services.model.data.Document element
     */
    public java.util.Enumeration<? extends turbomeca.gamme.assembly.services.model.data.Document> enumerateDocument(
    ) {
        return this._documentList.elements();
    }

    /**
     * Method getDocument.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * turbomeca.gamme.assembly.services.model.data.Document at the
     * given index
     */
    public turbomeca.gamme.assembly.services.model.data.Document getDocument(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._documentList.size()) {
            throw new IndexOutOfBoundsException("getDocument: Index value '" + index + "' not in range [0.." + (this._documentList.size() - 1) + "]");
        }

        return (turbomeca.gamme.assembly.services.model.data.Document) _documentList.get(index);
    }

    /**
     * Method getDocument.Returns the contents of the collection in
     * an Array.  <p>Note:  Just in case the collection contents
     * are changing in another thread, we pass a 0-length Array of
     * the correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public turbomeca.gamme.assembly.services.model.data.Document[] getDocument(
    ) {
        turbomeca.gamme.assembly.services.model.data.Document[] array = new turbomeca.gamme.assembly.services.model.data.Document[0];
        return (turbomeca.gamme.assembly.services.model.data.Document[]) this._documentList.toArray(array);
    }

    /**
     * Method getDocumentAsReference.Returns a reference to
     * '_documentList'. No type checking is performed on any
     * modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<turbomeca.gamme.assembly.services.model.data.Document> getDocumentAsReference(
    ) {
        return this._documentList;
    }

    /**
     * Method getDocumentCount.
     * 
     * @return the size of this collection
     */
    public int getDocumentCount(
    ) {
        return this._documentList.size();
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllDocument(
    ) {
        this._documentList.clear();
    }

    /**
     * Method removeDocument.
     * 
     * @param vDocument
     * @return true if the object was removed from the collection.
     */
    public boolean removeDocument(
            final turbomeca.gamme.assembly.services.model.data.Document vDocument) {
        boolean removed = _documentList.remove(vDocument);
        return removed;
    }

    /**
     * Method removeDocumentAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public turbomeca.gamme.assembly.services.model.data.Document removeDocumentAt(
            final int index) {
        java.lang.Object obj = this._documentList.remove(index);
        return (turbomeca.gamme.assembly.services.model.data.Document) obj;
    }

    /**
     * 
     * 
     * @param index
     * @param vDocument
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setDocument(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.Document vDocument)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._documentList.size()) {
            throw new IndexOutOfBoundsException("setDocument: Index value '" + index + "' not in range [0.." + (this._documentList.size() - 1) + "]");
        }

        this._documentList.set(index, vDocument);
    }

    /**
     * 
     * 
     * @param vDocumentArray
     */
    public void setDocument(
            final turbomeca.gamme.assembly.services.model.data.Document[] vDocumentArray) {
        //-- copy array
        _documentList.clear();

        for (int i = 0; i < vDocumentArray.length; i++) {
                this._documentList.add(vDocumentArray[i]);
        }
    }

    /**
     * Sets the value of '_documentList' by copying the given
     * Vector. All elements will be checked for type safety.
     * 
     * @param vDocumentList the Vector to copy.
     */
    public void setDocument(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.Document> vDocumentList) {
        // copy vector
        this._documentList.clear();

        this._documentList.addAll(vDocumentList);
    }

    /**
     * Sets the value of '_documentList' by setting it to the given
     * Vector. No type checking is performed.
     * @deprecated
     * 
     * @param documentVector the Vector to set.
     */
    public void setDocumentAsReference(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.Document> documentVector) {
        this._documentList = documentVector;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.Documents
     */
    public static turbomeca.gamme.assembly.services.model.data.Documents unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.Documents) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.Documents.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
