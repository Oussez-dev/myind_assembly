/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class LevelHistory.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class LevelHistory implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _levelChangeList.
     */
    private java.util.Vector<turbomeca.gamme.assembly.services.model.data.LevelChange> _levelChangeList;


      //----------------/
     //- Constructors -/
    //----------------/

    public LevelHistory() {
        super();
        this._levelChangeList = new java.util.Vector<turbomeca.gamme.assembly.services.model.data.LevelChange>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vLevelChange
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addLevelChange(
            final turbomeca.gamme.assembly.services.model.data.LevelChange vLevelChange)
    throws java.lang.IndexOutOfBoundsException {
        this._levelChangeList.addElement(vLevelChange);
    }

    /**
     * 
     * 
     * @param index
     * @param vLevelChange
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addLevelChange(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.LevelChange vLevelChange)
    throws java.lang.IndexOutOfBoundsException {
        this._levelChangeList.add(index, vLevelChange);
    }

    /**
     * Method enumerateLevelChange.
     * 
     * @return an Enumeration over all
     * turbomeca.gamme.assembly.services.model.data.LevelChange
     * elements
     */
    public java.util.Enumeration<? extends turbomeca.gamme.assembly.services.model.data.LevelChange> enumerateLevelChange(
    ) {
        return this._levelChangeList.elements();
    }

    /**
     * Method getLevelChange.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * turbomeca.gamme.assembly.services.model.data.LevelChange at
     * the given index
     */
    public turbomeca.gamme.assembly.services.model.data.LevelChange getLevelChange(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._levelChangeList.size()) {
            throw new IndexOutOfBoundsException("getLevelChange: Index value '" + index + "' not in range [0.." + (this._levelChangeList.size() - 1) + "]");
        }

        return (turbomeca.gamme.assembly.services.model.data.LevelChange) _levelChangeList.get(index);
    }

    /**
     * Method getLevelChange.Returns the contents of the collection
     * in an Array.  <p>Note:  Just in case the collection contents
     * are changing in another thread, we pass a 0-length Array of
     * the correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public turbomeca.gamme.assembly.services.model.data.LevelChange[] getLevelChange(
    ) {
        turbomeca.gamme.assembly.services.model.data.LevelChange[] array = new turbomeca.gamme.assembly.services.model.data.LevelChange[0];
        return (turbomeca.gamme.assembly.services.model.data.LevelChange[]) this._levelChangeList.toArray(array);
    }

    /**
     * Method getLevelChangeAsReference.Returns a reference to
     * '_levelChangeList'. No type checking is performed on any
     * modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<turbomeca.gamme.assembly.services.model.data.LevelChange> getLevelChangeAsReference(
    ) {
        return this._levelChangeList;
    }

    /**
     * Method getLevelChangeCount.
     * 
     * @return the size of this collection
     */
    public int getLevelChangeCount(
    ) {
        return this._levelChangeList.size();
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllLevelChange(
    ) {
        this._levelChangeList.clear();
    }

    /**
     * Method removeLevelChange.
     * 
     * @param vLevelChange
     * @return true if the object was removed from the collection.
     */
    public boolean removeLevelChange(
            final turbomeca.gamme.assembly.services.model.data.LevelChange vLevelChange) {
        boolean removed = _levelChangeList.remove(vLevelChange);
        return removed;
    }

    /**
     * Method removeLevelChangeAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public turbomeca.gamme.assembly.services.model.data.LevelChange removeLevelChangeAt(
            final int index) {
        java.lang.Object obj = this._levelChangeList.remove(index);
        return (turbomeca.gamme.assembly.services.model.data.LevelChange) obj;
    }

    /**
     * 
     * 
     * @param index
     * @param vLevelChange
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setLevelChange(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.LevelChange vLevelChange)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._levelChangeList.size()) {
            throw new IndexOutOfBoundsException("setLevelChange: Index value '" + index + "' not in range [0.." + (this._levelChangeList.size() - 1) + "]");
        }

        this._levelChangeList.set(index, vLevelChange);
    }

    /**
     * 
     * 
     * @param vLevelChangeArray
     */
    public void setLevelChange(
            final turbomeca.gamme.assembly.services.model.data.LevelChange[] vLevelChangeArray) {
        //-- copy array
        _levelChangeList.clear();

        for (int i = 0; i < vLevelChangeArray.length; i++) {
                this._levelChangeList.add(vLevelChangeArray[i]);
        }
    }

    /**
     * Sets the value of '_levelChangeList' by copying the given
     * Vector. All elements will be checked for type safety.
     * 
     * @param vLevelChangeList the Vector to copy.
     */
    public void setLevelChange(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.LevelChange> vLevelChangeList) {
        // copy vector
        this._levelChangeList.clear();

        this._levelChangeList.addAll(vLevelChangeList);
    }

    /**
     * Sets the value of '_levelChangeList' by setting it to the
     * given Vector. No type checking is performed.
     * @deprecated
     * 
     * @param levelChangeVector the Vector to set.
     */
    public void setLevelChangeAsReference(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.LevelChange> levelChangeVector) {
        this._levelChangeList = levelChangeVector;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.LevelHistory
     */
    public static turbomeca.gamme.assembly.services.model.data.LevelHistory unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.LevelHistory) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.LevelHistory.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
