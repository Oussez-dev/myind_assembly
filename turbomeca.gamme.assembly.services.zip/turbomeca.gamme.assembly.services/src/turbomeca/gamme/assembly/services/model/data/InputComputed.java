/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class InputComputed.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class InputComputed implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _digitPrecision.
     */
    private int _digitPrecision;

    /**
     * keeps track of state for field: _digitPrecision
     */
    private boolean _has_digitPrecision;

    /**
     * Internal choice value storage
     */
    private java.lang.Object _choiceValue;

    /**
     * Field _inputRef.
     */
    private turbomeca.gamme.assembly.services.model.data.InputRef _inputRef;

    /**
     * Field _formula.
     */
    private turbomeca.gamme.assembly.services.model.data.Formula _formula;


      //----------------/
     //- Constructors -/
    //----------------/

    public InputComputed() {
        super();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     */
    public void deleteDigitPrecision(
    ) {
        this._has_digitPrecision= false;
    }

    /**
     * Returns the value of field 'choiceValue'. The field
     * 'choiceValue' has the following description: Internal choice
     * value storage
     * 
     * @return the value of field 'ChoiceValue'.
     */
    public java.lang.Object getChoiceValue(
    ) {
        return this._choiceValue;
    }

    /**
     * Returns the value of field 'digitPrecision'.
     * 
     * @return the value of field 'DigitPrecision'.
     */
    public int getDigitPrecision(
    ) {
        return this._digitPrecision;
    }

    /**
     * Returns the value of field 'formula'.
     * 
     * @return the value of field 'Formula'.
     */
    public turbomeca.gamme.assembly.services.model.data.Formula getFormula(
    ) {
        return this._formula;
    }

    /**
     * Returns the value of field 'inputRef'.
     * 
     * @return the value of field 'InputRef'.
     */
    public turbomeca.gamme.assembly.services.model.data.InputRef getInputRef(
    ) {
        return this._inputRef;
    }

    /**
     * Method hasDigitPrecision.
     * 
     * @return true if at least one DigitPrecision has been added
     */
    public boolean hasDigitPrecision(
    ) {
        return this._has_digitPrecision;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     * Sets the value of field 'digitPrecision'.
     * 
     * @param digitPrecision the value of field 'digitPrecision'.
     */
    public void setDigitPrecision(
            final int digitPrecision) {
        this._digitPrecision = digitPrecision;
        this._has_digitPrecision = true;
    }

    /**
     * Sets the value of field 'formula'.
     * 
     * @param formula the value of field 'formula'.
     */
    public void setFormula(
            final turbomeca.gamme.assembly.services.model.data.Formula formula) {
        this._formula = formula;
        this._choiceValue = formula;
    }

    /**
     * Sets the value of field 'inputRef'.
     * 
     * @param inputRef the value of field 'inputRef'.
     */
    public void setInputRef(
            final turbomeca.gamme.assembly.services.model.data.InputRef inputRef) {
        this._inputRef = inputRef;
        this._choiceValue = inputRef;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.InputComputed
     */
    public static turbomeca.gamme.assembly.services.model.data.InputComputed unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.InputComputed) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.InputComputed.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
