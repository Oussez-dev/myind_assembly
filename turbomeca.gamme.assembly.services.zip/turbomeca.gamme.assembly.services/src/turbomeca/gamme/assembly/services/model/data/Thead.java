/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class Thead.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class Thead implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _valign.
     */
    private turbomeca.gamme.assembly.services.model.data.types.Tbl_valign_attribValignType _valign;

    /**
     * Field _colspecList.
     */
    private java.util.Vector<turbomeca.gamme.assembly.services.model.data.Colspec> _colspecList;

    /**
     * Field _rowList.
     */
    private java.util.Vector<turbomeca.gamme.assembly.services.model.data.Row> _rowList;


      //----------------/
     //- Constructors -/
    //----------------/

    public Thead() {
        super();
        this._colspecList = new java.util.Vector<turbomeca.gamme.assembly.services.model.data.Colspec>();
        this._rowList = new java.util.Vector<turbomeca.gamme.assembly.services.model.data.Row>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vColspec
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addColspec(
            final turbomeca.gamme.assembly.services.model.data.Colspec vColspec)
    throws java.lang.IndexOutOfBoundsException {
        this._colspecList.addElement(vColspec);
    }

    /**
     * 
     * 
     * @param index
     * @param vColspec
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addColspec(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.Colspec vColspec)
    throws java.lang.IndexOutOfBoundsException {
        this._colspecList.add(index, vColspec);
    }

    /**
     * 
     * 
     * @param vRow
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addRow(
            final turbomeca.gamme.assembly.services.model.data.Row vRow)
    throws java.lang.IndexOutOfBoundsException {
        this._rowList.addElement(vRow);
    }

    /**
     * 
     * 
     * @param index
     * @param vRow
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addRow(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.Row vRow)
    throws java.lang.IndexOutOfBoundsException {
        this._rowList.add(index, vRow);
    }

    /**
     * Method enumerateColspec.
     * 
     * @return an Enumeration over all
     * turbomeca.gamme.assembly.services.model.data.Colspec elements
     */
    public java.util.Enumeration<? extends turbomeca.gamme.assembly.services.model.data.Colspec> enumerateColspec(
    ) {
        return this._colspecList.elements();
    }

    /**
     * Method enumerateRow.
     * 
     * @return an Enumeration over all
     * turbomeca.gamme.assembly.services.model.data.Row elements
     */
    public java.util.Enumeration<? extends turbomeca.gamme.assembly.services.model.data.Row> enumerateRow(
    ) {
        return this._rowList.elements();
    }

    /**
     * Method getColspec.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * turbomeca.gamme.assembly.services.model.data.Colspec at the
     * given index
     */
    public turbomeca.gamme.assembly.services.model.data.Colspec getColspec(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._colspecList.size()) {
            throw new IndexOutOfBoundsException("getColspec: Index value '" + index + "' not in range [0.." + (this._colspecList.size() - 1) + "]");
        }

        return (turbomeca.gamme.assembly.services.model.data.Colspec) _colspecList.get(index);
    }

    /**
     * Method getColspec.Returns the contents of the collection in
     * an Array.  <p>Note:  Just in case the collection contents
     * are changing in another thread, we pass a 0-length Array of
     * the correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public turbomeca.gamme.assembly.services.model.data.Colspec[] getColspec(
    ) {
        turbomeca.gamme.assembly.services.model.data.Colspec[] array = new turbomeca.gamme.assembly.services.model.data.Colspec[0];
        return (turbomeca.gamme.assembly.services.model.data.Colspec[]) this._colspecList.toArray(array);
    }

    /**
     * Method getColspecAsReference.Returns a reference to
     * '_colspecList'. No type checking is performed on any
     * modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<turbomeca.gamme.assembly.services.model.data.Colspec> getColspecAsReference(
    ) {
        return this._colspecList;
    }

    /**
     * Method getColspecCount.
     * 
     * @return the size of this collection
     */
    public int getColspecCount(
    ) {
        return this._colspecList.size();
    }

    /**
     * Method getRow.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * turbomeca.gamme.assembly.services.model.data.Row at the
     * given index
     */
    public turbomeca.gamme.assembly.services.model.data.Row getRow(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._rowList.size()) {
            throw new IndexOutOfBoundsException("getRow: Index value '" + index + "' not in range [0.." + (this._rowList.size() - 1) + "]");
        }

        return (turbomeca.gamme.assembly.services.model.data.Row) _rowList.get(index);
    }

    /**
     * Method getRow.Returns the contents of the collection in an
     * Array.  <p>Note:  Just in case the collection contents are
     * changing in another thread, we pass a 0-length Array of the
     * correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public turbomeca.gamme.assembly.services.model.data.Row[] getRow(
    ) {
        turbomeca.gamme.assembly.services.model.data.Row[] array = new turbomeca.gamme.assembly.services.model.data.Row[0];
        return (turbomeca.gamme.assembly.services.model.data.Row[]) this._rowList.toArray(array);
    }

    /**
     * Method getRowAsReference.Returns a reference to '_rowList'.
     * No type checking is performed on any modifications to the
     * Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<turbomeca.gamme.assembly.services.model.data.Row> getRowAsReference(
    ) {
        return this._rowList;
    }

    /**
     * Method getRowCount.
     * 
     * @return the size of this collection
     */
    public int getRowCount(
    ) {
        return this._rowList.size();
    }

    /**
     * Returns the value of field 'valign'.
     * 
     * @return the value of field 'Valign'.
     */
    public turbomeca.gamme.assembly.services.model.data.types.Tbl_valign_attribValignType getValign(
    ) {
        return this._valign;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllColspec(
    ) {
        this._colspecList.clear();
    }

    /**
     */
    public void removeAllRow(
    ) {
        this._rowList.clear();
    }

    /**
     * Method removeColspec.
     * 
     * @param vColspec
     * @return true if the object was removed from the collection.
     */
    public boolean removeColspec(
            final turbomeca.gamme.assembly.services.model.data.Colspec vColspec) {
        boolean removed = _colspecList.remove(vColspec);
        return removed;
    }

    /**
     * Method removeColspecAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public turbomeca.gamme.assembly.services.model.data.Colspec removeColspecAt(
            final int index) {
        java.lang.Object obj = this._colspecList.remove(index);
        return (turbomeca.gamme.assembly.services.model.data.Colspec) obj;
    }

    /**
     * Method removeRow.
     * 
     * @param vRow
     * @return true if the object was removed from the collection.
     */
    public boolean removeRow(
            final turbomeca.gamme.assembly.services.model.data.Row vRow) {
        boolean removed = _rowList.remove(vRow);
        return removed;
    }

    /**
     * Method removeRowAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public turbomeca.gamme.assembly.services.model.data.Row removeRowAt(
            final int index) {
        java.lang.Object obj = this._rowList.remove(index);
        return (turbomeca.gamme.assembly.services.model.data.Row) obj;
    }

    /**
     * 
     * 
     * @param index
     * @param vColspec
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setColspec(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.Colspec vColspec)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._colspecList.size()) {
            throw new IndexOutOfBoundsException("setColspec: Index value '" + index + "' not in range [0.." + (this._colspecList.size() - 1) + "]");
        }

        this._colspecList.set(index, vColspec);
    }

    /**
     * 
     * 
     * @param vColspecArray
     */
    public void setColspec(
            final turbomeca.gamme.assembly.services.model.data.Colspec[] vColspecArray) {
        //-- copy array
        _colspecList.clear();

        for (int i = 0; i < vColspecArray.length; i++) {
                this._colspecList.add(vColspecArray[i]);
        }
    }

    /**
     * Sets the value of '_colspecList' by copying the given
     * Vector. All elements will be checked for type safety.
     * 
     * @param vColspecList the Vector to copy.
     */
    public void setColspec(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.Colspec> vColspecList) {
        // copy vector
        this._colspecList.clear();

        this._colspecList.addAll(vColspecList);
    }

    /**
     * Sets the value of '_colspecList' by setting it to the given
     * Vector. No type checking is performed.
     * @deprecated
     * 
     * @param colspecVector the Vector to set.
     */
    public void setColspecAsReference(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.Colspec> colspecVector) {
        this._colspecList = colspecVector;
    }

    /**
     * 
     * 
     * @param index
     * @param vRow
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setRow(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.Row vRow)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._rowList.size()) {
            throw new IndexOutOfBoundsException("setRow: Index value '" + index + "' not in range [0.." + (this._rowList.size() - 1) + "]");
        }

        this._rowList.set(index, vRow);
    }

    /**
     * 
     * 
     * @param vRowArray
     */
    public void setRow(
            final turbomeca.gamme.assembly.services.model.data.Row[] vRowArray) {
        //-- copy array
        _rowList.clear();

        for (int i = 0; i < vRowArray.length; i++) {
                this._rowList.add(vRowArray[i]);
        }
    }

    /**
     * Sets the value of '_rowList' by copying the given Vector.
     * All elements will be checked for type safety.
     * 
     * @param vRowList the Vector to copy.
     */
    public void setRow(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.Row> vRowList) {
        // copy vector
        this._rowList.clear();

        this._rowList.addAll(vRowList);
    }

    /**
     * Sets the value of '_rowList' by setting it to the given
     * Vector. No type checking is performed.
     * @deprecated
     * 
     * @param rowVector the Vector to set.
     */
    public void setRowAsReference(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.Row> rowVector) {
        this._rowList = rowVector;
    }

    /**
     * Sets the value of field 'valign'.
     * 
     * @param valign the value of field 'valign'.
     */
    public void setValign(
            final turbomeca.gamme.assembly.services.model.data.types.Tbl_valign_attribValignType valign) {
        this._valign = valign;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.Thead
     */
    public static turbomeca.gamme.assembly.services.model.data.Thead unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.Thead) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.Thead.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
