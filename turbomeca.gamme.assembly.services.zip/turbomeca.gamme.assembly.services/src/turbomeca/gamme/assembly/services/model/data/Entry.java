/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class Entry.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class Entry implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _colname.
     */
    private java.lang.String _colname;

    /**
     * Field _namest.
     */
    private java.lang.String _namest;

    /**
     * Field _nameend.
     */
    private java.lang.String _nameend;

    /**
     * Field _spanname.
     */
    private java.lang.String _spanname;

    /**
     * Field _morerows.
     */
    private long _morerows;

    /**
     * keeps track of state for field: _morerows
     */
    private boolean _has_morerows;

    /**
     * Field _colsep.
     */
    private turbomeca.gamme.assembly.services.model.data.types.BooleanType _colsep;

    /**
     * Field _rowsep.
     */
    private turbomeca.gamme.assembly.services.model.data.types.BooleanType _rowsep;

    /**
     * Field _rotate.
     */
    private turbomeca.gamme.assembly.services.model.data.types.BooleanType _rotate;

    /**
     * Field _align.
     */
    private turbomeca.gamme.assembly.services.model.data.types.Tbl_align_attribAlignType _align;

    /**
     * Field _char.
     */
    private java.lang.String _char;

    /**
     * Field _charoff.
     */
    private java.lang.String _charoff;

    /**
     * Field _valign.
     */
    private turbomeca.gamme.assembly.services.model.data.types.Tbl_valign_attribValignType _valign;

    /**
     * Internal choice value storage
     */
    private java.lang.Object _choiceValue;

    /**
     * Field _valList.
     */
    private java.util.Vector<java.math.BigDecimal> _valList;

    /**
     * Field _stringValueList.
     */
    private java.util.Vector<turbomeca.gamme.assembly.services.model.data.StringValue> _stringValueList;

    /**
     * Field _taskActionList.
     */
    private java.util.Vector<turbomeca.gamme.assembly.services.model.data.TaskAction> _taskActionList;

    /**
     * Field _paraList.
     */
    private java.util.Vector<turbomeca.gamme.assembly.services.model.data.Para> _paraList;

    /**
     * Field _test.
     */
    private turbomeca.gamme.assembly.services.model.data.Test _test;


      //----------------/
     //- Constructors -/
    //----------------/

    public Entry() {
        super();
        this._valList = new java.util.Vector<java.math.BigDecimal>();
        this._stringValueList = new java.util.Vector<turbomeca.gamme.assembly.services.model.data.StringValue>();
        this._taskActionList = new java.util.Vector<turbomeca.gamme.assembly.services.model.data.TaskAction>();
        this._paraList = new java.util.Vector<turbomeca.gamme.assembly.services.model.data.Para>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vPara
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addPara(
            final turbomeca.gamme.assembly.services.model.data.Para vPara)
    throws java.lang.IndexOutOfBoundsException {
        this._paraList.addElement(vPara);
    }

    /**
     * 
     * 
     * @param index
     * @param vPara
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addPara(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.Para vPara)
    throws java.lang.IndexOutOfBoundsException {
        this._paraList.add(index, vPara);
    }

    /**
     * 
     * 
     * @param vStringValue
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addStringValue(
            final turbomeca.gamme.assembly.services.model.data.StringValue vStringValue)
    throws java.lang.IndexOutOfBoundsException {
        this._stringValueList.addElement(vStringValue);
    }

    /**
     * 
     * 
     * @param index
     * @param vStringValue
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addStringValue(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.StringValue vStringValue)
    throws java.lang.IndexOutOfBoundsException {
        this._stringValueList.add(index, vStringValue);
    }

    /**
     * 
     * 
     * @param vTaskAction
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addTaskAction(
            final turbomeca.gamme.assembly.services.model.data.TaskAction vTaskAction)
    throws java.lang.IndexOutOfBoundsException {
        this._taskActionList.addElement(vTaskAction);
    }

    /**
     * 
     * 
     * @param index
     * @param vTaskAction
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addTaskAction(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.TaskAction vTaskAction)
    throws java.lang.IndexOutOfBoundsException {
        this._taskActionList.add(index, vTaskAction);
    }

    /**
     * 
     * 
     * @param vVal
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addVal(
            final java.math.BigDecimal vVal)
    throws java.lang.IndexOutOfBoundsException {
        this._valList.addElement(vVal);
    }

    /**
     * 
     * 
     * @param index
     * @param vVal
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addVal(
            final int index,
            final java.math.BigDecimal vVal)
    throws java.lang.IndexOutOfBoundsException {
        this._valList.add(index, vVal);
    }

    /**
     */
    public void deleteMorerows(
    ) {
        this._has_morerows= false;
    }

    /**
     * Method enumeratePara.
     * 
     * @return an Enumeration over all
     * turbomeca.gamme.assembly.services.model.data.Para elements
     */
    public java.util.Enumeration<? extends turbomeca.gamme.assembly.services.model.data.Para> enumeratePara(
    ) {
        return this._paraList.elements();
    }

    /**
     * Method enumerateStringValue.
     * 
     * @return an Enumeration over all
     * turbomeca.gamme.assembly.services.model.data.StringValue
     * elements
     */
    public java.util.Enumeration<? extends turbomeca.gamme.assembly.services.model.data.StringValue> enumerateStringValue(
    ) {
        return this._stringValueList.elements();
    }

    /**
     * Method enumerateTaskAction.
     * 
     * @return an Enumeration over all
     * turbomeca.gamme.assembly.services.model.data.TaskAction
     * elements
     */
    public java.util.Enumeration<? extends turbomeca.gamme.assembly.services.model.data.TaskAction> enumerateTaskAction(
    ) {
        return this._taskActionList.elements();
    }

    /**
     * Method enumerateVal.
     * 
     * @return an Enumeration over all java.math.BigDecimal elements
     */
    public java.util.Enumeration<? extends java.math.BigDecimal> enumerateVal(
    ) {
        return this._valList.elements();
    }

    /**
     * Returns the value of field 'align'.
     * 
     * @return the value of field 'Align'.
     */
    public turbomeca.gamme.assembly.services.model.data.types.Tbl_align_attribAlignType getAlign(
    ) {
        return this._align;
    }

    /**
     * Returns the value of field 'char'.
     * 
     * @return the value of field 'Char'.
     */
    public java.lang.String getChar(
    ) {
        return this._char;
    }

    /**
     * Returns the value of field 'charoff'.
     * 
     * @return the value of field 'Charoff'.
     */
    public java.lang.String getCharoff(
    ) {
        return this._charoff;
    }

    /**
     * Returns the value of field 'choiceValue'. The field
     * 'choiceValue' has the following description: Internal choice
     * value storage
     * 
     * @return the value of field 'ChoiceValue'.
     */
    public java.lang.Object getChoiceValue(
    ) {
        return this._choiceValue;
    }

    /**
     * Returns the value of field 'colname'.
     * 
     * @return the value of field 'Colname'.
     */
    public java.lang.String getColname(
    ) {
        return this._colname;
    }

    /**
     * Returns the value of field 'colsep'.
     * 
     * @return the value of field 'Colsep'.
     */
    public turbomeca.gamme.assembly.services.model.data.types.BooleanType getColsep(
    ) {
        return this._colsep;
    }

    /**
     * Returns the value of field 'morerows'.
     * 
     * @return the value of field 'Morerows'.
     */
    public long getMorerows(
    ) {
        return this._morerows;
    }

    /**
     * Returns the value of field 'nameend'.
     * 
     * @return the value of field 'Nameend'.
     */
    public java.lang.String getNameend(
    ) {
        return this._nameend;
    }

    /**
     * Returns the value of field 'namest'.
     * 
     * @return the value of field 'Namest'.
     */
    public java.lang.String getNamest(
    ) {
        return this._namest;
    }

    /**
     * Method getPara.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * turbomeca.gamme.assembly.services.model.data.Para at the
     * given index
     */
    public turbomeca.gamme.assembly.services.model.data.Para getPara(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._paraList.size()) {
            throw new IndexOutOfBoundsException("getPara: Index value '" + index + "' not in range [0.." + (this._paraList.size() - 1) + "]");
        }

        return (turbomeca.gamme.assembly.services.model.data.Para) _paraList.get(index);
    }

    /**
     * Method getPara.Returns the contents of the collection in an
     * Array.  <p>Note:  Just in case the collection contents are
     * changing in another thread, we pass a 0-length Array of the
     * correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public turbomeca.gamme.assembly.services.model.data.Para[] getPara(
    ) {
        turbomeca.gamme.assembly.services.model.data.Para[] array = new turbomeca.gamme.assembly.services.model.data.Para[0];
        return (turbomeca.gamme.assembly.services.model.data.Para[]) this._paraList.toArray(array);
    }

    /**
     * Method getParaAsReference.Returns a reference to
     * '_paraList'. No type checking is performed on any
     * modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<turbomeca.gamme.assembly.services.model.data.Para> getParaAsReference(
    ) {
        return this._paraList;
    }

    /**
     * Method getParaCount.
     * 
     * @return the size of this collection
     */
    public int getParaCount(
    ) {
        return this._paraList.size();
    }

    /**
     * Returns the value of field 'rotate'.
     * 
     * @return the value of field 'Rotate'.
     */
    public turbomeca.gamme.assembly.services.model.data.types.BooleanType getRotate(
    ) {
        return this._rotate;
    }

    /**
     * Returns the value of field 'rowsep'.
     * 
     * @return the value of field 'Rowsep'.
     */
    public turbomeca.gamme.assembly.services.model.data.types.BooleanType getRowsep(
    ) {
        return this._rowsep;
    }

    /**
     * Returns the value of field 'spanname'.
     * 
     * @return the value of field 'Spanname'.
     */
    public java.lang.String getSpanname(
    ) {
        return this._spanname;
    }

    /**
     * Method getStringValue.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * turbomeca.gamme.assembly.services.model.data.StringValue at
     * the given index
     */
    public turbomeca.gamme.assembly.services.model.data.StringValue getStringValue(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._stringValueList.size()) {
            throw new IndexOutOfBoundsException("getStringValue: Index value '" + index + "' not in range [0.." + (this._stringValueList.size() - 1) + "]");
        }

        return (turbomeca.gamme.assembly.services.model.data.StringValue) _stringValueList.get(index);
    }

    /**
     * Method getStringValue.Returns the contents of the collection
     * in an Array.  <p>Note:  Just in case the collection contents
     * are changing in another thread, we pass a 0-length Array of
     * the correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public turbomeca.gamme.assembly.services.model.data.StringValue[] getStringValue(
    ) {
        turbomeca.gamme.assembly.services.model.data.StringValue[] array = new turbomeca.gamme.assembly.services.model.data.StringValue[0];
        return (turbomeca.gamme.assembly.services.model.data.StringValue[]) this._stringValueList.toArray(array);
    }

    /**
     * Method getStringValueAsReference.Returns a reference to
     * '_stringValueList'. No type checking is performed on any
     * modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<turbomeca.gamme.assembly.services.model.data.StringValue> getStringValueAsReference(
    ) {
        return this._stringValueList;
    }

    /**
     * Method getStringValueCount.
     * 
     * @return the size of this collection
     */
    public int getStringValueCount(
    ) {
        return this._stringValueList.size();
    }

    /**
     * Method getTaskAction.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * turbomeca.gamme.assembly.services.model.data.TaskAction at
     * the given index
     */
    public turbomeca.gamme.assembly.services.model.data.TaskAction getTaskAction(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._taskActionList.size()) {
            throw new IndexOutOfBoundsException("getTaskAction: Index value '" + index + "' not in range [0.." + (this._taskActionList.size() - 1) + "]");
        }

        return (turbomeca.gamme.assembly.services.model.data.TaskAction) _taskActionList.get(index);
    }

    /**
     * Method getTaskAction.Returns the contents of the collection
     * in an Array.  <p>Note:  Just in case the collection contents
     * are changing in another thread, we pass a 0-length Array of
     * the correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public turbomeca.gamme.assembly.services.model.data.TaskAction[] getTaskAction(
    ) {
        turbomeca.gamme.assembly.services.model.data.TaskAction[] array = new turbomeca.gamme.assembly.services.model.data.TaskAction[0];
        return (turbomeca.gamme.assembly.services.model.data.TaskAction[]) this._taskActionList.toArray(array);
    }

    /**
     * Method getTaskActionAsReference.Returns a reference to
     * '_taskActionList'. No type checking is performed on any
     * modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<turbomeca.gamme.assembly.services.model.data.TaskAction> getTaskActionAsReference(
    ) {
        return this._taskActionList;
    }

    /**
     * Method getTaskActionCount.
     * 
     * @return the size of this collection
     */
    public int getTaskActionCount(
    ) {
        return this._taskActionList.size();
    }

    /**
     * Returns the value of field 'test'.
     * 
     * @return the value of field 'Test'.
     */
    public turbomeca.gamme.assembly.services.model.data.Test getTest(
    ) {
        return this._test;
    }

    /**
     * Method getVal.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the java.math.BigDecimal at the given
     * index
     */
    public java.math.BigDecimal getVal(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._valList.size()) {
            throw new IndexOutOfBoundsException("getVal: Index value '" + index + "' not in range [0.." + (this._valList.size() - 1) + "]");
        }

        return (java.math.BigDecimal) _valList.get(index);
    }

    /**
     * Method getVal.Returns the contents of the collection in an
     * Array.  <p>Note:  Just in case the collection contents are
     * changing in another thread, we pass a 0-length Array of the
     * correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public java.math.BigDecimal[] getVal(
    ) {
        java.math.BigDecimal[] array = new java.math.BigDecimal[0];
        return (java.math.BigDecimal[]) this._valList.toArray(array);
    }

    /**
     * Method getValAsReference.Returns a reference to '_valList'.
     * No type checking is performed on any modifications to the
     * Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<java.math.BigDecimal> getValAsReference(
    ) {
        return this._valList;
    }

    /**
     * Method getValCount.
     * 
     * @return the size of this collection
     */
    public int getValCount(
    ) {
        return this._valList.size();
    }

    /**
     * Returns the value of field 'valign'.
     * 
     * @return the value of field 'Valign'.
     */
    public turbomeca.gamme.assembly.services.model.data.types.Tbl_valign_attribValignType getValign(
    ) {
        return this._valign;
    }

    /**
     * Method hasMorerows.
     * 
     * @return true if at least one Morerows has been added
     */
    public boolean hasMorerows(
    ) {
        return this._has_morerows;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllPara(
    ) {
        this._paraList.clear();
    }

    /**
     */
    public void removeAllStringValue(
    ) {
        this._stringValueList.clear();
    }

    /**
     */
    public void removeAllTaskAction(
    ) {
        this._taskActionList.clear();
    }

    /**
     */
    public void removeAllVal(
    ) {
        this._valList.clear();
    }

    /**
     * Method removePara.
     * 
     * @param vPara
     * @return true if the object was removed from the collection.
     */
    public boolean removePara(
            final turbomeca.gamme.assembly.services.model.data.Para vPara) {
        boolean removed = _paraList.remove(vPara);
        return removed;
    }

    /**
     * Method removeParaAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public turbomeca.gamme.assembly.services.model.data.Para removeParaAt(
            final int index) {
        java.lang.Object obj = this._paraList.remove(index);
        return (turbomeca.gamme.assembly.services.model.data.Para) obj;
    }

    /**
     * Method removeStringValue.
     * 
     * @param vStringValue
     * @return true if the object was removed from the collection.
     */
    public boolean removeStringValue(
            final turbomeca.gamme.assembly.services.model.data.StringValue vStringValue) {
        boolean removed = _stringValueList.remove(vStringValue);
        return removed;
    }

    /**
     * Method removeStringValueAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public turbomeca.gamme.assembly.services.model.data.StringValue removeStringValueAt(
            final int index) {
        java.lang.Object obj = this._stringValueList.remove(index);
        return (turbomeca.gamme.assembly.services.model.data.StringValue) obj;
    }

    /**
     * Method removeTaskAction.
     * 
     * @param vTaskAction
     * @return true if the object was removed from the collection.
     */
    public boolean removeTaskAction(
            final turbomeca.gamme.assembly.services.model.data.TaskAction vTaskAction) {
        boolean removed = _taskActionList.remove(vTaskAction);
        return removed;
    }

    /**
     * Method removeTaskActionAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public turbomeca.gamme.assembly.services.model.data.TaskAction removeTaskActionAt(
            final int index) {
        java.lang.Object obj = this._taskActionList.remove(index);
        return (turbomeca.gamme.assembly.services.model.data.TaskAction) obj;
    }

    /**
     * Method removeVal.
     * 
     * @param vVal
     * @return true if the object was removed from the collection.
     */
    public boolean removeVal(
            final java.math.BigDecimal vVal) {
        boolean removed = _valList.remove(vVal);
        return removed;
    }

    /**
     * Method removeValAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public java.math.BigDecimal removeValAt(
            final int index) {
        java.lang.Object obj = this._valList.remove(index);
        return (java.math.BigDecimal) obj;
    }

    /**
     * Sets the value of field 'align'.
     * 
     * @param align the value of field 'align'.
     */
    public void setAlign(
            final turbomeca.gamme.assembly.services.model.data.types.Tbl_align_attribAlignType align) {
        this._align = align;
    }

    /**
     * Sets the value of field 'char'.
     * 
     * @param _char
     * @param char the value of field 'char'.
     */
    public void setChar(
            final java.lang.String _char) {
        this._char = _char;
    }

    /**
     * Sets the value of field 'charoff'.
     * 
     * @param charoff the value of field 'charoff'.
     */
    public void setCharoff(
            final java.lang.String charoff) {
        this._charoff = charoff;
    }

    /**
     * Sets the value of field 'colname'.
     * 
     * @param colname the value of field 'colname'.
     */
    public void setColname(
            final java.lang.String colname) {
        this._colname = colname;
    }

    /**
     * Sets the value of field 'colsep'.
     * 
     * @param colsep the value of field 'colsep'.
     */
    public void setColsep(
            final turbomeca.gamme.assembly.services.model.data.types.BooleanType colsep) {
        this._colsep = colsep;
    }

    /**
     * Sets the value of field 'morerows'.
     * 
     * @param morerows the value of field 'morerows'.
     */
    public void setMorerows(
            final long morerows) {
        this._morerows = morerows;
        this._has_morerows = true;
    }

    /**
     * Sets the value of field 'nameend'.
     * 
     * @param nameend the value of field 'nameend'.
     */
    public void setNameend(
            final java.lang.String nameend) {
        this._nameend = nameend;
    }

    /**
     * Sets the value of field 'namest'.
     * 
     * @param namest the value of field 'namest'.
     */
    public void setNamest(
            final java.lang.String namest) {
        this._namest = namest;
    }

    /**
     * 
     * 
     * @param index
     * @param vPara
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setPara(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.Para vPara)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._paraList.size()) {
            throw new IndexOutOfBoundsException("setPara: Index value '" + index + "' not in range [0.." + (this._paraList.size() - 1) + "]");
        }

        this._paraList.set(index, vPara);
    }

    /**
     * 
     * 
     * @param vParaArray
     */
    public void setPara(
            final turbomeca.gamme.assembly.services.model.data.Para[] vParaArray) {
        //-- copy array
        _paraList.clear();

        for (int i = 0; i < vParaArray.length; i++) {
                this._paraList.add(vParaArray[i]);
        }
    }

    /**
     * Sets the value of '_paraList' by copying the given Vector.
     * All elements will be checked for type safety.
     * 
     * @param vParaList the Vector to copy.
     */
    public void setPara(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.Para> vParaList) {
        // copy vector
        this._paraList.clear();

        this._paraList.addAll(vParaList);
    }

    /**
     * Sets the value of '_paraList' by setting it to the given
     * Vector. No type checking is performed.
     * @deprecated
     * 
     * @param paraVector the Vector to set.
     */
    public void setParaAsReference(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.Para> paraVector) {
        this._paraList = paraVector;
    }

    /**
     * Sets the value of field 'rotate'.
     * 
     * @param rotate the value of field 'rotate'.
     */
    public void setRotate(
            final turbomeca.gamme.assembly.services.model.data.types.BooleanType rotate) {
        this._rotate = rotate;
    }

    /**
     * Sets the value of field 'rowsep'.
     * 
     * @param rowsep the value of field 'rowsep'.
     */
    public void setRowsep(
            final turbomeca.gamme.assembly.services.model.data.types.BooleanType rowsep) {
        this._rowsep = rowsep;
    }

    /**
     * Sets the value of field 'spanname'.
     * 
     * @param spanname the value of field 'spanname'.
     */
    public void setSpanname(
            final java.lang.String spanname) {
        this._spanname = spanname;
    }

    /**
     * 
     * 
     * @param index
     * @param vStringValue
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setStringValue(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.StringValue vStringValue)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._stringValueList.size()) {
            throw new IndexOutOfBoundsException("setStringValue: Index value '" + index + "' not in range [0.." + (this._stringValueList.size() - 1) + "]");
        }

        this._stringValueList.set(index, vStringValue);
    }

    /**
     * 
     * 
     * @param vStringValueArray
     */
    public void setStringValue(
            final turbomeca.gamme.assembly.services.model.data.StringValue[] vStringValueArray) {
        //-- copy array
        _stringValueList.clear();

        for (int i = 0; i < vStringValueArray.length; i++) {
                this._stringValueList.add(vStringValueArray[i]);
        }
    }

    /**
     * Sets the value of '_stringValueList' by copying the given
     * Vector. All elements will be checked for type safety.
     * 
     * @param vStringValueList the Vector to copy.
     */
    public void setStringValue(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.StringValue> vStringValueList) {
        // copy vector
        this._stringValueList.clear();

        this._stringValueList.addAll(vStringValueList);
    }

    /**
     * Sets the value of '_stringValueList' by setting it to the
     * given Vector. No type checking is performed.
     * @deprecated
     * 
     * @param stringValueVector the Vector to set.
     */
    public void setStringValueAsReference(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.StringValue> stringValueVector) {
        this._stringValueList = stringValueVector;
    }

    /**
     * 
     * 
     * @param index
     * @param vTaskAction
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setTaskAction(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.TaskAction vTaskAction)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._taskActionList.size()) {
            throw new IndexOutOfBoundsException("setTaskAction: Index value '" + index + "' not in range [0.." + (this._taskActionList.size() - 1) + "]");
        }

        this._taskActionList.set(index, vTaskAction);
    }

    /**
     * 
     * 
     * @param vTaskActionArray
     */
    public void setTaskAction(
            final turbomeca.gamme.assembly.services.model.data.TaskAction[] vTaskActionArray) {
        //-- copy array
        _taskActionList.clear();

        for (int i = 0; i < vTaskActionArray.length; i++) {
                this._taskActionList.add(vTaskActionArray[i]);
        }
    }

    /**
     * Sets the value of '_taskActionList' by copying the given
     * Vector. All elements will be checked for type safety.
     * 
     * @param vTaskActionList the Vector to copy.
     */
    public void setTaskAction(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.TaskAction> vTaskActionList) {
        // copy vector
        this._taskActionList.clear();

        this._taskActionList.addAll(vTaskActionList);
    }

    /**
     * Sets the value of '_taskActionList' by setting it to the
     * given Vector. No type checking is performed.
     * @deprecated
     * 
     * @param taskActionVector the Vector to set.
     */
    public void setTaskActionAsReference(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.TaskAction> taskActionVector) {
        this._taskActionList = taskActionVector;
    }

    /**
     * Sets the value of field 'test'.
     * 
     * @param test the value of field 'test'.
     */
    public void setTest(
            final turbomeca.gamme.assembly.services.model.data.Test test) {
        this._test = test;
        this._choiceValue = test;
    }

    /**
     * 
     * 
     * @param index
     * @param vVal
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setVal(
            final int index,
            final java.math.BigDecimal vVal)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._valList.size()) {
            throw new IndexOutOfBoundsException("setVal: Index value '" + index + "' not in range [0.." + (this._valList.size() - 1) + "]");
        }

        this._valList.set(index, vVal);
    }

    /**
     * 
     * 
     * @param vValArray
     */
    public void setVal(
            final java.math.BigDecimal[] vValArray) {
        //-- copy array
        _valList.clear();

        for (int i = 0; i < vValArray.length; i++) {
                this._valList.add(vValArray[i]);
        }
    }

    /**
     * Sets the value of '_valList' by copying the given Vector.
     * All elements will be checked for type safety.
     * 
     * @param vValList the Vector to copy.
     */
    public void setVal(
            final java.util.Vector<java.math.BigDecimal> vValList) {
        // copy vector
        this._valList.clear();

        this._valList.addAll(vValList);
    }

    /**
     * Sets the value of '_valList' by setting it to the given
     * Vector. No type checking is performed.
     * @deprecated
     * 
     * @param valVector the Vector to set.
     */
    public void setValAsReference(
            final java.util.Vector<java.math.BigDecimal> valVector) {
        this._valList = valVector;
    }

    /**
     * Sets the value of field 'valign'.
     * 
     * @param valign the value of field 'valign'.
     */
    public void setValign(
            final turbomeca.gamme.assembly.services.model.data.types.Tbl_valign_attribValignType valign) {
        this._valign = valign;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.Entry
     */
    public static turbomeca.gamme.assembly.services.model.data.Entry unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.Entry) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.Entry.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
