/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Container to store user mark and user comments associated with
 * each new passing action
 *  
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class HistoricalPassing implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _passingList.
     */
    private java.util.Vector<turbomeca.gamme.assembly.services.model.data.Passing> _passingList;


      //----------------/
     //- Constructors -/
    //----------------/

    public HistoricalPassing() {
        super();
        this._passingList = new java.util.Vector<turbomeca.gamme.assembly.services.model.data.Passing>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vPassing
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addPassing(
            final turbomeca.gamme.assembly.services.model.data.Passing vPassing)
    throws java.lang.IndexOutOfBoundsException {
        this._passingList.addElement(vPassing);
    }

    /**
     * 
     * 
     * @param index
     * @param vPassing
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addPassing(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.Passing vPassing)
    throws java.lang.IndexOutOfBoundsException {
        this._passingList.add(index, vPassing);
    }

    /**
     * Method enumeratePassing.
     * 
     * @return an Enumeration over all
     * turbomeca.gamme.assembly.services.model.data.Passing elements
     */
    public java.util.Enumeration<? extends turbomeca.gamme.assembly.services.model.data.Passing> enumeratePassing(
    ) {
        return this._passingList.elements();
    }

    /**
     * Method getPassing.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * turbomeca.gamme.assembly.services.model.data.Passing at the
     * given index
     */
    public turbomeca.gamme.assembly.services.model.data.Passing getPassing(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._passingList.size()) {
            throw new IndexOutOfBoundsException("getPassing: Index value '" + index + "' not in range [0.." + (this._passingList.size() - 1) + "]");
        }

        return (turbomeca.gamme.assembly.services.model.data.Passing) _passingList.get(index);
    }

    /**
     * Method getPassing.Returns the contents of the collection in
     * an Array.  <p>Note:  Just in case the collection contents
     * are changing in another thread, we pass a 0-length Array of
     * the correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public turbomeca.gamme.assembly.services.model.data.Passing[] getPassing(
    ) {
        turbomeca.gamme.assembly.services.model.data.Passing[] array = new turbomeca.gamme.assembly.services.model.data.Passing[0];
        return (turbomeca.gamme.assembly.services.model.data.Passing[]) this._passingList.toArray(array);
    }

    /**
     * Method getPassingAsReference.Returns a reference to
     * '_passingList'. No type checking is performed on any
     * modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<turbomeca.gamme.assembly.services.model.data.Passing> getPassingAsReference(
    ) {
        return this._passingList;
    }

    /**
     * Method getPassingCount.
     * 
     * @return the size of this collection
     */
    public int getPassingCount(
    ) {
        return this._passingList.size();
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllPassing(
    ) {
        this._passingList.clear();
    }

    /**
     * Method removePassing.
     * 
     * @param vPassing
     * @return true if the object was removed from the collection.
     */
    public boolean removePassing(
            final turbomeca.gamme.assembly.services.model.data.Passing vPassing) {
        boolean removed = _passingList.remove(vPassing);
        return removed;
    }

    /**
     * Method removePassingAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public turbomeca.gamme.assembly.services.model.data.Passing removePassingAt(
            final int index) {
        java.lang.Object obj = this._passingList.remove(index);
        return (turbomeca.gamme.assembly.services.model.data.Passing) obj;
    }

    /**
     * 
     * 
     * @param index
     * @param vPassing
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setPassing(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.Passing vPassing)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._passingList.size()) {
            throw new IndexOutOfBoundsException("setPassing: Index value '" + index + "' not in range [0.." + (this._passingList.size() - 1) + "]");
        }

        this._passingList.set(index, vPassing);
    }

    /**
     * 
     * 
     * @param vPassingArray
     */
    public void setPassing(
            final turbomeca.gamme.assembly.services.model.data.Passing[] vPassingArray) {
        //-- copy array
        _passingList.clear();

        for (int i = 0; i < vPassingArray.length; i++) {
                this._passingList.add(vPassingArray[i]);
        }
    }

    /**
     * Sets the value of '_passingList' by copying the given
     * Vector. All elements will be checked for type safety.
     * 
     * @param vPassingList the Vector to copy.
     */
    public void setPassing(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.Passing> vPassingList) {
        // copy vector
        this._passingList.clear();

        this._passingList.addAll(vPassingList);
    }

    /**
     * Sets the value of '_passingList' by setting it to the given
     * Vector. No type checking is performed.
     * @deprecated
     * 
     * @param passingVector the Vector to set.
     */
    public void setPassingAsReference(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.Passing> passingVector) {
        this._passingList = passingVector;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.HistoricalPassin
     */
    public static turbomeca.gamme.assembly.services.model.data.HistoricalPassing unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.HistoricalPassing) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.HistoricalPassing.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
