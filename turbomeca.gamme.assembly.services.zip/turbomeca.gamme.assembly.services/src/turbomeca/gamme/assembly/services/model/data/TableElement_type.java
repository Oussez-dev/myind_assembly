/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class TableElement_type.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class TableElement_type implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _frame.
     */
    private turbomeca.gamme.assembly.services.model.data.types.TableElement_typeFrameType _frame;

    /**
     * Field _id.
     */
    private java.lang.String _id;

    /**
     * Field _colsep.
     */
    private turbomeca.gamme.assembly.services.model.data.types.BooleanType _colsep;

    /**
     * Field _rowsep.
     */
    private turbomeca.gamme.assembly.services.model.data.types.BooleanType _rowsep;

    /**
     * Field _pdf.
     */
    private turbomeca.gamme.assembly.services.model.data.types.BooleanType _pdf;

    /**
     * Field _pdfOnly.
     */
    private java.lang.Object _pdfOnly;

    /**
     * Field _pgwide.
     */
    private turbomeca.gamme.assembly.services.model.data.types.BooleanType _pgwide;

    /**
     * Field _tabstyle.
     */
    private java.lang.String _tabstyle;

    /**
     * Field _tocentry.
     */
    private turbomeca.gamme.assembly.services.model.data.types.BooleanType _tocentry;

    /**
     * Field _shortentry.
     */
    private turbomeca.gamme.assembly.services.model.data.types.BooleanType _shortentry;

    /**
     * Field _orient.
     */
    private turbomeca.gamme.assembly.services.model.data.types.Tbl_table_attOrientType _orient;

    /**
     * Field _tgroupList.
     */
    private java.util.Vector<turbomeca.gamme.assembly.services.model.data.Tgroup> _tgroupList;


      //----------------/
     //- Constructors -/
    //----------------/

    public TableElement_type() {
        super();
        this._tgroupList = new java.util.Vector<turbomeca.gamme.assembly.services.model.data.Tgroup>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vTgroup
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addTgroup(
            final turbomeca.gamme.assembly.services.model.data.Tgroup vTgroup)
    throws java.lang.IndexOutOfBoundsException {
        this._tgroupList.addElement(vTgroup);
    }

    /**
     * 
     * 
     * @param index
     * @param vTgroup
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addTgroup(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.Tgroup vTgroup)
    throws java.lang.IndexOutOfBoundsException {
        this._tgroupList.add(index, vTgroup);
    }

    /**
     * Method enumerateTgroup.
     * 
     * @return an Enumeration over all
     * turbomeca.gamme.assembly.services.model.data.Tgroup elements
     */
    public java.util.Enumeration<? extends turbomeca.gamme.assembly.services.model.data.Tgroup> enumerateTgroup(
    ) {
        return this._tgroupList.elements();
    }

    /**
     * Returns the value of field 'colsep'.
     * 
     * @return the value of field 'Colsep'.
     */
    public turbomeca.gamme.assembly.services.model.data.types.BooleanType getColsep(
    ) {
        return this._colsep;
    }

    /**
     * Returns the value of field 'frame'.
     * 
     * @return the value of field 'Frame'.
     */
    public turbomeca.gamme.assembly.services.model.data.types.TableElement_typeFrameType getFrame(
    ) {
        return this._frame;
    }

    /**
     * Returns the value of field 'id'.
     * 
     * @return the value of field 'Id'.
     */
    public java.lang.String getId(
    ) {
        return this._id;
    }

    /**
     * Returns the value of field 'orient'.
     * 
     * @return the value of field 'Orient'.
     */
    public turbomeca.gamme.assembly.services.model.data.types.Tbl_table_attOrientType getOrient(
    ) {
        return this._orient;
    }

    /**
     * Returns the value of field 'pdf'.
     * 
     * @return the value of field 'Pdf'.
     */
    public turbomeca.gamme.assembly.services.model.data.types.BooleanType getPdf(
    ) {
        return this._pdf;
    }

    /**
     * Returns the value of field 'pdfOnly'.
     * 
     * @return the value of field 'PdfOnly'.
     */
    public java.lang.Object getPdfOnly(
    ) {
        return this._pdfOnly;
    }

    /**
     * Returns the value of field 'pgwide'.
     * 
     * @return the value of field 'Pgwide'.
     */
    public turbomeca.gamme.assembly.services.model.data.types.BooleanType getPgwide(
    ) {
        return this._pgwide;
    }

    /**
     * Returns the value of field 'rowsep'.
     * 
     * @return the value of field 'Rowsep'.
     */
    public turbomeca.gamme.assembly.services.model.data.types.BooleanType getRowsep(
    ) {
        return this._rowsep;
    }

    /**
     * Returns the value of field 'shortentry'.
     * 
     * @return the value of field 'Shortentry'.
     */
    public turbomeca.gamme.assembly.services.model.data.types.BooleanType getShortentry(
    ) {
        return this._shortentry;
    }

    /**
     * Returns the value of field 'tabstyle'.
     * 
     * @return the value of field 'Tabstyle'.
     */
    public java.lang.String getTabstyle(
    ) {
        return this._tabstyle;
    }

    /**
     * Method getTgroup.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * turbomeca.gamme.assembly.services.model.data.Tgroup at the
     * given index
     */
    public turbomeca.gamme.assembly.services.model.data.Tgroup getTgroup(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._tgroupList.size()) {
            throw new IndexOutOfBoundsException("getTgroup: Index value '" + index + "' not in range [0.." + (this._tgroupList.size() - 1) + "]");
        }

        return (turbomeca.gamme.assembly.services.model.data.Tgroup) _tgroupList.get(index);
    }

    /**
     * Method getTgroup.Returns the contents of the collection in
     * an Array.  <p>Note:  Just in case the collection contents
     * are changing in another thread, we pass a 0-length Array of
     * the correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public turbomeca.gamme.assembly.services.model.data.Tgroup[] getTgroup(
    ) {
        turbomeca.gamme.assembly.services.model.data.Tgroup[] array = new turbomeca.gamme.assembly.services.model.data.Tgroup[0];
        return (turbomeca.gamme.assembly.services.model.data.Tgroup[]) this._tgroupList.toArray(array);
    }

    /**
     * Method getTgroupAsReference.Returns a reference to
     * '_tgroupList'. No type checking is performed on any
     * modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<turbomeca.gamme.assembly.services.model.data.Tgroup> getTgroupAsReference(
    ) {
        return this._tgroupList;
    }

    /**
     * Method getTgroupCount.
     * 
     * @return the size of this collection
     */
    public int getTgroupCount(
    ) {
        return this._tgroupList.size();
    }

    /**
     * Returns the value of field 'tocentry'.
     * 
     * @return the value of field 'Tocentry'.
     */
    public turbomeca.gamme.assembly.services.model.data.types.BooleanType getTocentry(
    ) {
        return this._tocentry;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllTgroup(
    ) {
        this._tgroupList.clear();
    }

    /**
     * Method removeTgroup.
     * 
     * @param vTgroup
     * @return true if the object was removed from the collection.
     */
    public boolean removeTgroup(
            final turbomeca.gamme.assembly.services.model.data.Tgroup vTgroup) {
        boolean removed = _tgroupList.remove(vTgroup);
        return removed;
    }

    /**
     * Method removeTgroupAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public turbomeca.gamme.assembly.services.model.data.Tgroup removeTgroupAt(
            final int index) {
        java.lang.Object obj = this._tgroupList.remove(index);
        return (turbomeca.gamme.assembly.services.model.data.Tgroup) obj;
    }

    /**
     * Sets the value of field 'colsep'.
     * 
     * @param colsep the value of field 'colsep'.
     */
    public void setColsep(
            final turbomeca.gamme.assembly.services.model.data.types.BooleanType colsep) {
        this._colsep = colsep;
    }

    /**
     * Sets the value of field 'frame'.
     * 
     * @param frame the value of field 'frame'.
     */
    public void setFrame(
            final turbomeca.gamme.assembly.services.model.data.types.TableElement_typeFrameType frame) {
        this._frame = frame;
    }

    /**
     * Sets the value of field 'id'.
     * 
     * @param id the value of field 'id'.
     */
    public void setId(
            final java.lang.String id) {
        this._id = id;
    }

    /**
     * Sets the value of field 'orient'.
     * 
     * @param orient the value of field 'orient'.
     */
    public void setOrient(
            final turbomeca.gamme.assembly.services.model.data.types.Tbl_table_attOrientType orient) {
        this._orient = orient;
    }

    /**
     * Sets the value of field 'pdf'.
     * 
     * @param pdf the value of field 'pdf'.
     */
    public void setPdf(
            final turbomeca.gamme.assembly.services.model.data.types.BooleanType pdf) {
        this._pdf = pdf;
    }

    /**
     * Sets the value of field 'pdfOnly'.
     * 
     * @param pdfOnly the value of field 'pdfOnly'.
     */
    public void setPdfOnly(
            final java.lang.Object pdfOnly) {
        this._pdfOnly = pdfOnly;
    }

    /**
     * Sets the value of field 'pgwide'.
     * 
     * @param pgwide the value of field 'pgwide'.
     */
    public void setPgwide(
            final turbomeca.gamme.assembly.services.model.data.types.BooleanType pgwide) {
        this._pgwide = pgwide;
    }

    /**
     * Sets the value of field 'rowsep'.
     * 
     * @param rowsep the value of field 'rowsep'.
     */
    public void setRowsep(
            final turbomeca.gamme.assembly.services.model.data.types.BooleanType rowsep) {
        this._rowsep = rowsep;
    }

    /**
     * Sets the value of field 'shortentry'.
     * 
     * @param shortentry the value of field 'shortentry'.
     */
    public void setShortentry(
            final turbomeca.gamme.assembly.services.model.data.types.BooleanType shortentry) {
        this._shortentry = shortentry;
    }

    /**
     * Sets the value of field 'tabstyle'.
     * 
     * @param tabstyle the value of field 'tabstyle'.
     */
    public void setTabstyle(
            final java.lang.String tabstyle) {
        this._tabstyle = tabstyle;
    }

    /**
     * 
     * 
     * @param index
     * @param vTgroup
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setTgroup(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.Tgroup vTgroup)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._tgroupList.size()) {
            throw new IndexOutOfBoundsException("setTgroup: Index value '" + index + "' not in range [0.." + (this._tgroupList.size() - 1) + "]");
        }

        this._tgroupList.set(index, vTgroup);
    }

    /**
     * 
     * 
     * @param vTgroupArray
     */
    public void setTgroup(
            final turbomeca.gamme.assembly.services.model.data.Tgroup[] vTgroupArray) {
        //-- copy array
        _tgroupList.clear();

        for (int i = 0; i < vTgroupArray.length; i++) {
                this._tgroupList.add(vTgroupArray[i]);
        }
    }

    /**
     * Sets the value of '_tgroupList' by copying the given Vector.
     * All elements will be checked for type safety.
     * 
     * @param vTgroupList the Vector to copy.
     */
    public void setTgroup(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.Tgroup> vTgroupList) {
        // copy vector
        this._tgroupList.clear();

        this._tgroupList.addAll(vTgroupList);
    }

    /**
     * Sets the value of '_tgroupList' by setting it to the given
     * Vector. No type checking is performed.
     * @deprecated
     * 
     * @param tgroupVector the Vector to set.
     */
    public void setTgroupAsReference(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.Tgroup> tgroupVector) {
        this._tgroupList = tgroupVector;
    }

    /**
     * Sets the value of field 'tocentry'.
     * 
     * @param tocentry the value of field 'tocentry'.
     */
    public void setTocentry(
            final turbomeca.gamme.assembly.services.model.data.types.BooleanType tocentry) {
        this._tocentry = tocentry;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.TableElement_typ
     */
    public static turbomeca.gamme.assembly.services.model.data.TableElement_type unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.TableElement_type) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.TableElement_type.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
