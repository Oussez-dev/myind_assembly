/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class Pns.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class Pns implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _pnList.
     */
    private java.util.Vector<java.lang.String> _pnList;


      //----------------/
     //- Constructors -/
    //----------------/

    public Pns() {
        super();
        this._pnList = new java.util.Vector<java.lang.String>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vPn
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addPn(
            final java.lang.String vPn)
    throws java.lang.IndexOutOfBoundsException {
        this._pnList.addElement(vPn);
    }

    /**
     * 
     * 
     * @param index
     * @param vPn
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addPn(
            final int index,
            final java.lang.String vPn)
    throws java.lang.IndexOutOfBoundsException {
        this._pnList.add(index, vPn);
    }

    /**
     * Method enumeratePn.
     * 
     * @return an Enumeration over all java.lang.String elements
     */
    public java.util.Enumeration<? extends java.lang.String> enumeratePn(
    ) {
        return this._pnList.elements();
    }

    /**
     * Method getPn.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the java.lang.String at the given index
     */
    public java.lang.String getPn(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._pnList.size()) {
            throw new IndexOutOfBoundsException("getPn: Index value '" + index + "' not in range [0.." + (this._pnList.size() - 1) + "]");
        }

        return (java.lang.String) _pnList.get(index);
    }

    /**
     * Method getPn.Returns the contents of the collection in an
     * Array.  <p>Note:  Just in case the collection contents are
     * changing in another thread, we pass a 0-length Array of the
     * correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public java.lang.String[] getPn(
    ) {
        java.lang.String[] array = new java.lang.String[0];
        return (java.lang.String[]) this._pnList.toArray(array);
    }

    /**
     * Method getPnAsReference.Returns a reference to '_pnList'. No
     * type checking is performed on any modifications to the
     * Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<java.lang.String> getPnAsReference(
    ) {
        return this._pnList;
    }

    /**
     * Method getPnCount.
     * 
     * @return the size of this collection
     */
    public int getPnCount(
    ) {
        return this._pnList.size();
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllPn(
    ) {
        this._pnList.clear();
    }

    /**
     * Method removePn.
     * 
     * @param vPn
     * @return true if the object was removed from the collection.
     */
    public boolean removePn(
            final java.lang.String vPn) {
        boolean removed = _pnList.remove(vPn);
        return removed;
    }

    /**
     * Method removePnAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public java.lang.String removePnAt(
            final int index) {
        java.lang.Object obj = this._pnList.remove(index);
        return (java.lang.String) obj;
    }

    /**
     * 
     * 
     * @param index
     * @param vPn
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setPn(
            final int index,
            final java.lang.String vPn)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._pnList.size()) {
            throw new IndexOutOfBoundsException("setPn: Index value '" + index + "' not in range [0.." + (this._pnList.size() - 1) + "]");
        }

        this._pnList.set(index, vPn);
    }

    /**
     * 
     * 
     * @param vPnArray
     */
    public void setPn(
            final java.lang.String[] vPnArray) {
        //-- copy array
        _pnList.clear();

        for (int i = 0; i < vPnArray.length; i++) {
                this._pnList.add(vPnArray[i]);
        }
    }

    /**
     * Sets the value of '_pnList' by copying the given Vector. All
     * elements will be checked for type safety.
     * 
     * @param vPnList the Vector to copy.
     */
    public void setPn(
            final java.util.Vector<java.lang.String> vPnList) {
        // copy vector
        this._pnList.clear();

        this._pnList.addAll(vPnList);
    }

    /**
     * Sets the value of '_pnList' by setting it to the given
     * Vector. No type checking is performed.
     * @deprecated
     * 
     * @param pnVector the Vector to set.
     */
    public void setPnAsReference(
            final java.util.Vector<java.lang.String> pnVector) {
        this._pnList = pnVector;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.Pns
     */
    public static turbomeca.gamme.assembly.services.model.data.Pns unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.Pns) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.Pns.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
