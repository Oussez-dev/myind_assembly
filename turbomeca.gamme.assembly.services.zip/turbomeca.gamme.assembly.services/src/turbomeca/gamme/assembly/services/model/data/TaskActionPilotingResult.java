/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class TaskActionPilotingResult.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class TaskActionPilotingResult implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _taskActionList.
     */
    private java.util.Vector<turbomeca.gamme.assembly.services.model.data.TaskAction> _taskActionList;


      //----------------/
     //- Constructors -/
    //----------------/

    public TaskActionPilotingResult() {
        super();
        this._taskActionList = new java.util.Vector<turbomeca.gamme.assembly.services.model.data.TaskAction>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vTaskAction
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addTaskAction(
            final turbomeca.gamme.assembly.services.model.data.TaskAction vTaskAction)
    throws java.lang.IndexOutOfBoundsException {
        this._taskActionList.addElement(vTaskAction);
    }

    /**
     * 
     * 
     * @param index
     * @param vTaskAction
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addTaskAction(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.TaskAction vTaskAction)
    throws java.lang.IndexOutOfBoundsException {
        this._taskActionList.add(index, vTaskAction);
    }

    /**
     * Method enumerateTaskAction.
     * 
     * @return an Enumeration over all
     * turbomeca.gamme.assembly.services.model.data.TaskAction
     * elements
     */
    public java.util.Enumeration<? extends turbomeca.gamme.assembly.services.model.data.TaskAction> enumerateTaskAction(
    ) {
        return this._taskActionList.elements();
    }

    /**
     * Method getTaskAction.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * turbomeca.gamme.assembly.services.model.data.TaskAction at
     * the given index
     */
    public turbomeca.gamme.assembly.services.model.data.TaskAction getTaskAction(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._taskActionList.size()) {
            throw new IndexOutOfBoundsException("getTaskAction: Index value '" + index + "' not in range [0.." + (this._taskActionList.size() - 1) + "]");
        }

        return (turbomeca.gamme.assembly.services.model.data.TaskAction) _taskActionList.get(index);
    }

    /**
     * Method getTaskAction.Returns the contents of the collection
     * in an Array.  <p>Note:  Just in case the collection contents
     * are changing in another thread, we pass a 0-length Array of
     * the correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public turbomeca.gamme.assembly.services.model.data.TaskAction[] getTaskAction(
    ) {
        turbomeca.gamme.assembly.services.model.data.TaskAction[] array = new turbomeca.gamme.assembly.services.model.data.TaskAction[0];
        return (turbomeca.gamme.assembly.services.model.data.TaskAction[]) this._taskActionList.toArray(array);
    }

    /**
     * Method getTaskActionAsReference.Returns a reference to
     * '_taskActionList'. No type checking is performed on any
     * modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<turbomeca.gamme.assembly.services.model.data.TaskAction> getTaskActionAsReference(
    ) {
        return this._taskActionList;
    }

    /**
     * Method getTaskActionCount.
     * 
     * @return the size of this collection
     */
    public int getTaskActionCount(
    ) {
        return this._taskActionList.size();
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllTaskAction(
    ) {
        this._taskActionList.clear();
    }

    /**
     * Method removeTaskAction.
     * 
     * @param vTaskAction
     * @return true if the object was removed from the collection.
     */
    public boolean removeTaskAction(
            final turbomeca.gamme.assembly.services.model.data.TaskAction vTaskAction) {
        boolean removed = _taskActionList.remove(vTaskAction);
        return removed;
    }

    /**
     * Method removeTaskActionAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public turbomeca.gamme.assembly.services.model.data.TaskAction removeTaskActionAt(
            final int index) {
        java.lang.Object obj = this._taskActionList.remove(index);
        return (turbomeca.gamme.assembly.services.model.data.TaskAction) obj;
    }

    /**
     * 
     * 
     * @param index
     * @param vTaskAction
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setTaskAction(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.TaskAction vTaskAction)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._taskActionList.size()) {
            throw new IndexOutOfBoundsException("setTaskAction: Index value '" + index + "' not in range [0.." + (this._taskActionList.size() - 1) + "]");
        }

        this._taskActionList.set(index, vTaskAction);
    }

    /**
     * 
     * 
     * @param vTaskActionArray
     */
    public void setTaskAction(
            final turbomeca.gamme.assembly.services.model.data.TaskAction[] vTaskActionArray) {
        //-- copy array
        _taskActionList.clear();

        for (int i = 0; i < vTaskActionArray.length; i++) {
                this._taskActionList.add(vTaskActionArray[i]);
        }
    }

    /**
     * Sets the value of '_taskActionList' by copying the given
     * Vector. All elements will be checked for type safety.
     * 
     * @param vTaskActionList the Vector to copy.
     */
    public void setTaskAction(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.TaskAction> vTaskActionList) {
        // copy vector
        this._taskActionList.clear();

        this._taskActionList.addAll(vTaskActionList);
    }

    /**
     * Sets the value of '_taskActionList' by setting it to the
     * given Vector. No type checking is performed.
     * @deprecated
     * 
     * @param taskActionVector the Vector to set.
     */
    public void setTaskActionAsReference(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.TaskAction> taskActionVector) {
        this._taskActionList = taskActionVector;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.TaskActionPilotingResult
     */
    public static turbomeca.gamme.assembly.services.model.data.TaskActionPilotingResult unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.TaskActionPilotingResult) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.TaskActionPilotingResult.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
