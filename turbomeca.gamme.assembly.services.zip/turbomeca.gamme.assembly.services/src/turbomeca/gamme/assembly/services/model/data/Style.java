/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class Style.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class Style implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _italic.
     */
    private boolean _italic;

    /**
     * keeps track of state for field: _italic
     */
    private boolean _has_italic;

    /**
     * Field _bold.
     */
    private boolean _bold;

    /**
     * keeps track of state for field: _bold
     */
    private boolean _has_bold;

    /**
     * Field _underline.
     */
    private boolean _underline;

    /**
     * keeps track of state for field: _underline
     */
    private boolean _has_underline;

    /**
     * internal content storage
     */
    private java.lang.String _content = "";

    /**
     * Field _items.
     */
    private java.util.Vector<turbomeca.gamme.assembly.services.model.data.StyleItem> _items;


      //----------------/
     //- Constructors -/
    //----------------/

    public Style() {
        super();
        setContent("");
        this._items = new java.util.Vector<turbomeca.gamme.assembly.services.model.data.StyleItem>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vStyleItem
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addStyleItem(
            final turbomeca.gamme.assembly.services.model.data.StyleItem vStyleItem)
    throws java.lang.IndexOutOfBoundsException {
        this._items.addElement(vStyleItem);
    }

    /**
     * 
     * 
     * @param index
     * @param vStyleItem
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addStyleItem(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.StyleItem vStyleItem)
    throws java.lang.IndexOutOfBoundsException {
        this._items.add(index, vStyleItem);
    }

    /**
     */
    public void deleteBold(
    ) {
        this._has_bold= false;
    }

    /**
     */
    public void deleteItalic(
    ) {
        this._has_italic= false;
    }

    /**
     */
    public void deleteUnderline(
    ) {
        this._has_underline= false;
    }

    /**
     * Method enumerateStyleItem.
     * 
     * @return an Enumeration over all
     * turbomeca.gamme.assembly.services.model.data.StyleItem
     * elements
     */
    public java.util.Enumeration<? extends turbomeca.gamme.assembly.services.model.data.StyleItem> enumerateStyleItem(
    ) {
        return this._items.elements();
    }

    /**
     * Returns the value of field 'bold'.
     * 
     * @return the value of field 'Bold'.
     */
    public boolean getBold(
    ) {
        return this._bold;
    }

    /**
     * Returns the value of field 'content'. The field 'content'
     * has the following description: internal content storage
     * 
     * @return the value of field 'Content'.
     */
    public java.lang.String getContent(
    ) {
        return this._content;
    }

    /**
     * Returns the value of field 'italic'.
     * 
     * @return the value of field 'Italic'.
     */
    public boolean getItalic(
    ) {
        return this._italic;
    }

    /**
     * Method getStyleItem.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * turbomeca.gamme.assembly.services.model.data.StyleItem at
     * the given index
     */
    public turbomeca.gamme.assembly.services.model.data.StyleItem getStyleItem(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._items.size()) {
            throw new IndexOutOfBoundsException("getStyleItem: Index value '" + index + "' not in range [0.." + (this._items.size() - 1) + "]");
        }

        return (turbomeca.gamme.assembly.services.model.data.StyleItem) _items.get(index);
    }

    /**
     * Method getStyleItem.Returns the contents of the collection
     * in an Array.  <p>Note:  Just in case the collection contents
     * are changing in another thread, we pass a 0-length Array of
     * the correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public turbomeca.gamme.assembly.services.model.data.StyleItem[] getStyleItem(
    ) {
        turbomeca.gamme.assembly.services.model.data.StyleItem[] array = new turbomeca.gamme.assembly.services.model.data.StyleItem[0];
        return (turbomeca.gamme.assembly.services.model.data.StyleItem[]) this._items.toArray(array);
    }

    /**
     * Method getStyleItemAsReference.Returns a reference to
     * '_items'. No type checking is performed on any modifications
     * to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<turbomeca.gamme.assembly.services.model.data.StyleItem> getStyleItemAsReference(
    ) {
        return this._items;
    }

    /**
     * Method getStyleItemCount.
     * 
     * @return the size of this collection
     */
    public int getStyleItemCount(
    ) {
        return this._items.size();
    }

    /**
     * Returns the value of field 'underline'.
     * 
     * @return the value of field 'Underline'.
     */
    public boolean getUnderline(
    ) {
        return this._underline;
    }

    /**
     * Method hasBold.
     * 
     * @return true if at least one Bold has been added
     */
    public boolean hasBold(
    ) {
        return this._has_bold;
    }

    /**
     * Method hasItalic.
     * 
     * @return true if at least one Italic has been added
     */
    public boolean hasItalic(
    ) {
        return this._has_italic;
    }

    /**
     * Method hasUnderline.
     * 
     * @return true if at least one Underline has been added
     */
    public boolean hasUnderline(
    ) {
        return this._has_underline;
    }

    /**
     * Returns the value of field 'bold'.
     * 
     * @return the value of field 'Bold'.
     */
    public boolean isBold(
    ) {
        return this._bold;
    }

    /**
     * Returns the value of field 'italic'.
     * 
     * @return the value of field 'Italic'.
     */
    public boolean isItalic(
    ) {
        return this._italic;
    }

    /**
     * Returns the value of field 'underline'.
     * 
     * @return the value of field 'Underline'.
     */
    public boolean isUnderline(
    ) {
        return this._underline;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllStyleItem(
    ) {
        this._items.clear();
    }

    /**
     * Method removeStyleItem.
     * 
     * @param vStyleItem
     * @return true if the object was removed from the collection.
     */
    public boolean removeStyleItem(
            final turbomeca.gamme.assembly.services.model.data.StyleItem vStyleItem) {
        boolean removed = _items.remove(vStyleItem);
        return removed;
    }

    /**
     * Method removeStyleItemAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public turbomeca.gamme.assembly.services.model.data.StyleItem removeStyleItemAt(
            final int index) {
        java.lang.Object obj = this._items.remove(index);
        return (turbomeca.gamme.assembly.services.model.data.StyleItem) obj;
    }

    /**
     * Sets the value of field 'bold'.
     * 
     * @param bold the value of field 'bold'.
     */
    public void setBold(
            final boolean bold) {
        this._bold = bold;
        this._has_bold = true;
    }

    /**
     * Sets the value of field 'content'. The field 'content' has
     * the following description: internal content storage
     * 
     * @param content the value of field 'content'.
     */
    public void setContent(
            final java.lang.String content) {
        this._content = content;
    }

    /**
     * Sets the value of field 'italic'.
     * 
     * @param italic the value of field 'italic'.
     */
    public void setItalic(
            final boolean italic) {
        this._italic = italic;
        this._has_italic = true;
    }

    /**
     * 
     * 
     * @param index
     * @param vStyleItem
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setStyleItem(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.StyleItem vStyleItem)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._items.size()) {
            throw new IndexOutOfBoundsException("setStyleItem: Index value '" + index + "' not in range [0.." + (this._items.size() - 1) + "]");
        }

        this._items.set(index, vStyleItem);
    }

    /**
     * 
     * 
     * @param vStyleItemArray
     */
    public void setStyleItem(
            final turbomeca.gamme.assembly.services.model.data.StyleItem[] vStyleItemArray) {
        //-- copy array
        _items.clear();

        for (int i = 0; i < vStyleItemArray.length; i++) {
                this._items.add(vStyleItemArray[i]);
        }
    }

    /**
     * Sets the value of '_items' by copying the given Vector. All
     * elements will be checked for type safety.
     * 
     * @param vStyleItemList the Vector to copy.
     */
    public void setStyleItem(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.StyleItem> vStyleItemList) {
        // copy vector
        this._items.clear();

        this._items.addAll(vStyleItemList);
    }

    /**
     * Sets the value of '_items' by setting it to the given
     * Vector. No type checking is performed.
     * @deprecated
     * 
     * @param styleItemVector the Vector to set.
     */
    public void setStyleItemAsReference(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.StyleItem> styleItemVector) {
        this._items = styleItemVector;
    }

    /**
     * Sets the value of field 'underline'.
     * 
     * @param underline the value of field 'underline'.
     */
    public void setUnderline(
            final boolean underline) {
        this._underline = underline;
        this._has_underline = true;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.Style
     */
    public static turbomeca.gamme.assembly.services.model.data.Style unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.Style) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.Style.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
