/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class MeasureRdd.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class MeasureRdd implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _caracteristic.
     */
    private java.lang.String _caracteristic;

    /**
     * Field _programNum.
     */
    private java.lang.String _programNum;

    /**
     * Field _state.
     */
    private turbomeca.gamme.assembly.services.model.data.State _state;


      //----------------/
     //- Constructors -/
    //----------------/

    public MeasureRdd() {
        super();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'caracteristic'.
     * 
     * @return the value of field 'Caracteristic'.
     */
    public java.lang.String getCaracteristic(
    ) {
        return this._caracteristic;
    }

    /**
     * Returns the value of field 'programNum'.
     * 
     * @return the value of field 'ProgramNum'.
     */
    public java.lang.String getProgramNum(
    ) {
        return this._programNum;
    }

    /**
     * Returns the value of field 'state'.
     * 
     * @return the value of field 'State'.
     */
    public turbomeca.gamme.assembly.services.model.data.State getState(
    ) {
        return this._state;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     * Sets the value of field 'caracteristic'.
     * 
     * @param caracteristic the value of field 'caracteristic'.
     */
    public void setCaracteristic(
            final java.lang.String caracteristic) {
        this._caracteristic = caracteristic;
    }

    /**
     * Sets the value of field 'programNum'.
     * 
     * @param programNum the value of field 'programNum'.
     */
    public void setProgramNum(
            final java.lang.String programNum) {
        this._programNum = programNum;
    }

    /**
     * Sets the value of field 'state'.
     * 
     * @param state the value of field 'state'.
     */
    public void setState(
            final turbomeca.gamme.assembly.services.model.data.State state) {
        this._state = state;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.MeasureRdd
     */
    public static turbomeca.gamme.assembly.services.model.data.MeasureRdd unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.MeasureRdd) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.MeasureRdd.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
