/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class Pictures.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class Pictures implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _showGallery.
     */
    private turbomeca.gamme.assembly.services.model.data.types.BooleanType _showGallery;

    /**
     * Field _showWindow.
     */
    private turbomeca.gamme.assembly.services.model.data.types.BooleanType _showWindow;

    /**
     * Field _width.
     */
    private int _width;

    /**
     * keeps track of state for field: _width
     */
    private boolean _has_width;

    /**
     * Field _pictureList.
     */
    private java.util.Vector<turbomeca.gamme.assembly.services.model.data.Picture> _pictureList;


      //----------------/
     //- Constructors -/
    //----------------/

    public Pictures() {
        super();
        this._pictureList = new java.util.Vector<turbomeca.gamme.assembly.services.model.data.Picture>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vPicture
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addPicture(
            final turbomeca.gamme.assembly.services.model.data.Picture vPicture)
    throws java.lang.IndexOutOfBoundsException {
        this._pictureList.addElement(vPicture);
    }

    /**
     * 
     * 
     * @param index
     * @param vPicture
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addPicture(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.Picture vPicture)
    throws java.lang.IndexOutOfBoundsException {
        this._pictureList.add(index, vPicture);
    }

    /**
     */
    public void deleteWidth(
    ) {
        this._has_width= false;
    }

    /**
     * Method enumeratePicture.
     * 
     * @return an Enumeration over all
     * turbomeca.gamme.assembly.services.model.data.Picture elements
     */
    public java.util.Enumeration<? extends turbomeca.gamme.assembly.services.model.data.Picture> enumeratePicture(
    ) {
        return this._pictureList.elements();
    }

    /**
     * Method getPicture.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * turbomeca.gamme.assembly.services.model.data.Picture at the
     * given index
     */
    public turbomeca.gamme.assembly.services.model.data.Picture getPicture(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._pictureList.size()) {
            throw new IndexOutOfBoundsException("getPicture: Index value '" + index + "' not in range [0.." + (this._pictureList.size() - 1) + "]");
        }

        return (turbomeca.gamme.assembly.services.model.data.Picture) _pictureList.get(index);
    }

    /**
     * Method getPicture.Returns the contents of the collection in
     * an Array.  <p>Note:  Just in case the collection contents
     * are changing in another thread, we pass a 0-length Array of
     * the correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public turbomeca.gamme.assembly.services.model.data.Picture[] getPicture(
    ) {
        turbomeca.gamme.assembly.services.model.data.Picture[] array = new turbomeca.gamme.assembly.services.model.data.Picture[0];
        return (turbomeca.gamme.assembly.services.model.data.Picture[]) this._pictureList.toArray(array);
    }

    /**
     * Method getPictureAsReference.Returns a reference to
     * '_pictureList'. No type checking is performed on any
     * modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<turbomeca.gamme.assembly.services.model.data.Picture> getPictureAsReference(
    ) {
        return this._pictureList;
    }

    /**
     * Method getPictureCount.
     * 
     * @return the size of this collection
     */
    public int getPictureCount(
    ) {
        return this._pictureList.size();
    }

    /**
     * Returns the value of field 'showGallery'.
     * 
     * @return the value of field 'ShowGallery'.
     */
    public turbomeca.gamme.assembly.services.model.data.types.BooleanType getShowGallery(
    ) {
        return this._showGallery;
    }

    /**
     * Returns the value of field 'showWindow'.
     * 
     * @return the value of field 'ShowWindow'.
     */
    public turbomeca.gamme.assembly.services.model.data.types.BooleanType getShowWindow(
    ) {
        return this._showWindow;
    }

    /**
     * Returns the value of field 'width'.
     * 
     * @return the value of field 'Width'.
     */
    public int getWidth(
    ) {
        return this._width;
    }

    /**
     * Method hasWidth.
     * 
     * @return true if at least one Width has been added
     */
    public boolean hasWidth(
    ) {
        return this._has_width;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllPicture(
    ) {
        this._pictureList.clear();
    }

    /**
     * Method removePicture.
     * 
     * @param vPicture
     * @return true if the object was removed from the collection.
     */
    public boolean removePicture(
            final turbomeca.gamme.assembly.services.model.data.Picture vPicture) {
        boolean removed = _pictureList.remove(vPicture);
        return removed;
    }

    /**
     * Method removePictureAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public turbomeca.gamme.assembly.services.model.data.Picture removePictureAt(
            final int index) {
        java.lang.Object obj = this._pictureList.remove(index);
        return (turbomeca.gamme.assembly.services.model.data.Picture) obj;
    }

    /**
     * 
     * 
     * @param index
     * @param vPicture
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setPicture(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.Picture vPicture)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._pictureList.size()) {
            throw new IndexOutOfBoundsException("setPicture: Index value '" + index + "' not in range [0.." + (this._pictureList.size() - 1) + "]");
        }

        this._pictureList.set(index, vPicture);
    }

    /**
     * 
     * 
     * @param vPictureArray
     */
    public void setPicture(
            final turbomeca.gamme.assembly.services.model.data.Picture[] vPictureArray) {
        //-- copy array
        _pictureList.clear();

        for (int i = 0; i < vPictureArray.length; i++) {
                this._pictureList.add(vPictureArray[i]);
        }
    }

    /**
     * Sets the value of '_pictureList' by copying the given
     * Vector. All elements will be checked for type safety.
     * 
     * @param vPictureList the Vector to copy.
     */
    public void setPicture(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.Picture> vPictureList) {
        // copy vector
        this._pictureList.clear();

        this._pictureList.addAll(vPictureList);
    }

    /**
     * Sets the value of '_pictureList' by setting it to the given
     * Vector. No type checking is performed.
     * @deprecated
     * 
     * @param pictureVector the Vector to set.
     */
    public void setPictureAsReference(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.Picture> pictureVector) {
        this._pictureList = pictureVector;
    }

    /**
     * Sets the value of field 'showGallery'.
     * 
     * @param showGallery the value of field 'showGallery'.
     */
    public void setShowGallery(
            final turbomeca.gamme.assembly.services.model.data.types.BooleanType showGallery) {
        this._showGallery = showGallery;
    }

    /**
     * Sets the value of field 'showWindow'.
     * 
     * @param showWindow the value of field 'showWindow'.
     */
    public void setShowWindow(
            final turbomeca.gamme.assembly.services.model.data.types.BooleanType showWindow) {
        this._showWindow = showWindow;
    }

    /**
     * Sets the value of field 'width'.
     * 
     * @param width the value of field 'width'.
     */
    public void setWidth(
            final int width) {
        this._width = width;
        this._has_width = true;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.Pictures
     */
    public static turbomeca.gamme.assembly.services.model.data.Pictures unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.Pictures) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.Pictures.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
