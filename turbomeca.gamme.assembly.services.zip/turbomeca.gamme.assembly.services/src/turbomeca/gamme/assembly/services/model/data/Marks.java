/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class Marks.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class Marks implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _markList.
     */
    private java.util.Vector<turbomeca.gamme.assembly.services.model.data.Mark> _markList;


      //----------------/
     //- Constructors -/
    //----------------/

    public Marks() {
        super();
        this._markList = new java.util.Vector<turbomeca.gamme.assembly.services.model.data.Mark>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vMark
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addMark(
            final turbomeca.gamme.assembly.services.model.data.Mark vMark)
    throws java.lang.IndexOutOfBoundsException {
        this._markList.addElement(vMark);
    }

    /**
     * 
     * 
     * @param index
     * @param vMark
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addMark(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.Mark vMark)
    throws java.lang.IndexOutOfBoundsException {
        this._markList.add(index, vMark);
    }

    /**
     * Method enumerateMark.
     * 
     * @return an Enumeration over all
     * turbomeca.gamme.assembly.services.model.data.Mark elements
     */
    public java.util.Enumeration<? extends turbomeca.gamme.assembly.services.model.data.Mark> enumerateMark(
    ) {
        return this._markList.elements();
    }

    /**
     * Method getMark.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * turbomeca.gamme.assembly.services.model.data.Mark at the
     * given index
     */
    public turbomeca.gamme.assembly.services.model.data.Mark getMark(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._markList.size()) {
            throw new IndexOutOfBoundsException("getMark: Index value '" + index + "' not in range [0.." + (this._markList.size() - 1) + "]");
        }

        return (turbomeca.gamme.assembly.services.model.data.Mark) _markList.get(index);
    }

    /**
     * Method getMark.Returns the contents of the collection in an
     * Array.  <p>Note:  Just in case the collection contents are
     * changing in another thread, we pass a 0-length Array of the
     * correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public turbomeca.gamme.assembly.services.model.data.Mark[] getMark(
    ) {
        turbomeca.gamme.assembly.services.model.data.Mark[] array = new turbomeca.gamme.assembly.services.model.data.Mark[0];
        return (turbomeca.gamme.assembly.services.model.data.Mark[]) this._markList.toArray(array);
    }

    /**
     * Method getMarkAsReference.Returns a reference to
     * '_markList'. No type checking is performed on any
     * modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<turbomeca.gamme.assembly.services.model.data.Mark> getMarkAsReference(
    ) {
        return this._markList;
    }

    /**
     * Method getMarkCount.
     * 
     * @return the size of this collection
     */
    public int getMarkCount(
    ) {
        return this._markList.size();
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllMark(
    ) {
        this._markList.clear();
    }

    /**
     * Method removeMark.
     * 
     * @param vMark
     * @return true if the object was removed from the collection.
     */
    public boolean removeMark(
            final turbomeca.gamme.assembly.services.model.data.Mark vMark) {
        boolean removed = _markList.remove(vMark);
        return removed;
    }

    /**
     * Method removeMarkAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public turbomeca.gamme.assembly.services.model.data.Mark removeMarkAt(
            final int index) {
        java.lang.Object obj = this._markList.remove(index);
        return (turbomeca.gamme.assembly.services.model.data.Mark) obj;
    }

    /**
     * 
     * 
     * @param index
     * @param vMark
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setMark(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.Mark vMark)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._markList.size()) {
            throw new IndexOutOfBoundsException("setMark: Index value '" + index + "' not in range [0.." + (this._markList.size() - 1) + "]");
        }

        this._markList.set(index, vMark);
    }

    /**
     * 
     * 
     * @param vMarkArray
     */
    public void setMark(
            final turbomeca.gamme.assembly.services.model.data.Mark[] vMarkArray) {
        //-- copy array
        _markList.clear();

        for (int i = 0; i < vMarkArray.length; i++) {
                this._markList.add(vMarkArray[i]);
        }
    }

    /**
     * Sets the value of '_markList' by copying the given Vector.
     * All elements will be checked for type safety.
     * 
     * @param vMarkList the Vector to copy.
     */
    public void setMark(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.Mark> vMarkList) {
        // copy vector
        this._markList.clear();

        this._markList.addAll(vMarkList);
    }

    /**
     * Sets the value of '_markList' by setting it to the given
     * Vector. No type checking is performed.
     * @deprecated
     * 
     * @param markVector the Vector to set.
     */
    public void setMarkAsReference(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.Mark> markVector) {
        this._markList = markVector;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.Marks
     */
    public static turbomeca.gamme.assembly.services.model.data.Marks unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.Marks) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.Marks.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
