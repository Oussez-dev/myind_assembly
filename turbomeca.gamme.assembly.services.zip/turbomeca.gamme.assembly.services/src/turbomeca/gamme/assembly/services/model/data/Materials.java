/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class Materials.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class Materials implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _materialList.
     */
    private java.util.Vector<turbomeca.gamme.assembly.services.model.data.Material> _materialList;


      //----------------/
     //- Constructors -/
    //----------------/

    public Materials() {
        super();
        this._materialList = new java.util.Vector<turbomeca.gamme.assembly.services.model.data.Material>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vMaterial
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addMaterial(
            final turbomeca.gamme.assembly.services.model.data.Material vMaterial)
    throws java.lang.IndexOutOfBoundsException {
        this._materialList.addElement(vMaterial);
    }

    /**
     * 
     * 
     * @param index
     * @param vMaterial
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addMaterial(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.Material vMaterial)
    throws java.lang.IndexOutOfBoundsException {
        this._materialList.add(index, vMaterial);
    }

    /**
     * Method enumerateMaterial.
     * 
     * @return an Enumeration over all
     * turbomeca.gamme.assembly.services.model.data.Material element
     */
    public java.util.Enumeration<? extends turbomeca.gamme.assembly.services.model.data.Material> enumerateMaterial(
    ) {
        return this._materialList.elements();
    }

    /**
     * Method getMaterial.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * turbomeca.gamme.assembly.services.model.data.Material at the
     * given index
     */
    public turbomeca.gamme.assembly.services.model.data.Material getMaterial(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._materialList.size()) {
            throw new IndexOutOfBoundsException("getMaterial: Index value '" + index + "' not in range [0.." + (this._materialList.size() - 1) + "]");
        }

        return (turbomeca.gamme.assembly.services.model.data.Material) _materialList.get(index);
    }

    /**
     * Method getMaterial.Returns the contents of the collection in
     * an Array.  <p>Note:  Just in case the collection contents
     * are changing in another thread, we pass a 0-length Array of
     * the correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public turbomeca.gamme.assembly.services.model.data.Material[] getMaterial(
    ) {
        turbomeca.gamme.assembly.services.model.data.Material[] array = new turbomeca.gamme.assembly.services.model.data.Material[0];
        return (turbomeca.gamme.assembly.services.model.data.Material[]) this._materialList.toArray(array);
    }

    /**
     * Method getMaterialAsReference.Returns a reference to
     * '_materialList'. No type checking is performed on any
     * modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<turbomeca.gamme.assembly.services.model.data.Material> getMaterialAsReference(
    ) {
        return this._materialList;
    }

    /**
     * Method getMaterialCount.
     * 
     * @return the size of this collection
     */
    public int getMaterialCount(
    ) {
        return this._materialList.size();
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllMaterial(
    ) {
        this._materialList.clear();
    }

    /**
     * Method removeMaterial.
     * 
     * @param vMaterial
     * @return true if the object was removed from the collection.
     */
    public boolean removeMaterial(
            final turbomeca.gamme.assembly.services.model.data.Material vMaterial) {
        boolean removed = _materialList.remove(vMaterial);
        return removed;
    }

    /**
     * Method removeMaterialAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public turbomeca.gamme.assembly.services.model.data.Material removeMaterialAt(
            final int index) {
        java.lang.Object obj = this._materialList.remove(index);
        return (turbomeca.gamme.assembly.services.model.data.Material) obj;
    }

    /**
     * 
     * 
     * @param index
     * @param vMaterial
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setMaterial(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.Material vMaterial)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._materialList.size()) {
            throw new IndexOutOfBoundsException("setMaterial: Index value '" + index + "' not in range [0.." + (this._materialList.size() - 1) + "]");
        }

        this._materialList.set(index, vMaterial);
    }

    /**
     * 
     * 
     * @param vMaterialArray
     */
    public void setMaterial(
            final turbomeca.gamme.assembly.services.model.data.Material[] vMaterialArray) {
        //-- copy array
        _materialList.clear();

        for (int i = 0; i < vMaterialArray.length; i++) {
                this._materialList.add(vMaterialArray[i]);
        }
    }

    /**
     * Sets the value of '_materialList' by copying the given
     * Vector. All elements will be checked for type safety.
     * 
     * @param vMaterialList the Vector to copy.
     */
    public void setMaterial(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.Material> vMaterialList) {
        // copy vector
        this._materialList.clear();

        this._materialList.addAll(vMaterialList);
    }

    /**
     * Sets the value of '_materialList' by setting it to the given
     * Vector. No type checking is performed.
     * @deprecated
     * 
     * @param materialVector the Vector to set.
     */
    public void setMaterialAsReference(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.Material> materialVector) {
        this._materialList = materialVector;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.Materials
     */
    public static turbomeca.gamme.assembly.services.model.data.Materials unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.Materials) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.Materials.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
