/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class TaskChoiceItem.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class TaskChoiceItem implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _taskMark.
     */
    private turbomeca.gamme.assembly.services.model.data.TaskMark _taskMark;

    /**
     * Field _taskPara.
     */
    private turbomeca.gamme.assembly.services.model.data.TaskPara _taskPara;

    /**
     * Field _taskAction.
     */
    private turbomeca.gamme.assembly.services.model.data.TaskAction _taskAction;

    /**
     * Field _taskActionMeasure.
     */
    private turbomeca.gamme.assembly.services.model.data.TaskActionMeasure _taskActionMeasure;

    /**
     * Field _taskActionTable.
     */
    private turbomeca.gamme.assembly.services.model.data.TaskActionTable _taskActionTable;

    /**
     * Field _taskPiloting.
     */
    private turbomeca.gamme.assembly.services.model.data.TaskPiloting _taskPiloting;


      //----------------/
     //- Constructors -/
    //----------------/

    public TaskChoiceItem() {
        super();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'taskAction'.
     * 
     * @return the value of field 'TaskAction'.
     */
    public turbomeca.gamme.assembly.services.model.data.TaskAction getTaskAction(
    ) {
        return this._taskAction;
    }

    /**
     * Returns the value of field 'taskActionMeasure'.
     * 
     * @return the value of field 'TaskActionMeasure'.
     */
    public turbomeca.gamme.assembly.services.model.data.TaskActionMeasure getTaskActionMeasure(
    ) {
        return this._taskActionMeasure;
    }

    /**
     * Returns the value of field 'taskActionTable'.
     * 
     * @return the value of field 'TaskActionTable'.
     */
    public turbomeca.gamme.assembly.services.model.data.TaskActionTable getTaskActionTable(
    ) {
        return this._taskActionTable;
    }

    /**
     * Returns the value of field 'taskMark'.
     * 
     * @return the value of field 'TaskMark'.
     */
    public turbomeca.gamme.assembly.services.model.data.TaskMark getTaskMark(
    ) {
        return this._taskMark;
    }

    /**
     * Returns the value of field 'taskPara'.
     * 
     * @return the value of field 'TaskPara'.
     */
    public turbomeca.gamme.assembly.services.model.data.TaskPara getTaskPara(
    ) {
        return this._taskPara;
    }

    /**
     * Returns the value of field 'taskPiloting'.
     * 
     * @return the value of field 'TaskPiloting'.
     */
    public turbomeca.gamme.assembly.services.model.data.TaskPiloting getTaskPiloting(
    ) {
        return this._taskPiloting;
    }

    /**
     * Sets the value of field 'taskAction'.
     * 
     * @param taskAction the value of field 'taskAction'.
     */
    public void setTaskAction(
            final turbomeca.gamme.assembly.services.model.data.TaskAction taskAction) {
        this._taskAction = taskAction;
    }

    /**
     * Sets the value of field 'taskActionMeasure'.
     * 
     * @param taskActionMeasure the value of field
     * 'taskActionMeasure'.
     */
    public void setTaskActionMeasure(
            final turbomeca.gamme.assembly.services.model.data.TaskActionMeasure taskActionMeasure) {
        this._taskActionMeasure = taskActionMeasure;
    }

    /**
     * Sets the value of field 'taskActionTable'.
     * 
     * @param taskActionTable the value of field 'taskActionTable'.
     */
    public void setTaskActionTable(
            final turbomeca.gamme.assembly.services.model.data.TaskActionTable taskActionTable) {
        this._taskActionTable = taskActionTable;
    }

    /**
     * Sets the value of field 'taskMark'.
     * 
     * @param taskMark the value of field 'taskMark'.
     */
    public void setTaskMark(
            final turbomeca.gamme.assembly.services.model.data.TaskMark taskMark) {
        this._taskMark = taskMark;
    }

    /**
     * Sets the value of field 'taskPara'.
     * 
     * @param taskPara the value of field 'taskPara'.
     */
    public void setTaskPara(
            final turbomeca.gamme.assembly.services.model.data.TaskPara taskPara) {
        this._taskPara = taskPara;
    }

    /**
     * Sets the value of field 'taskPiloting'.
     * 
     * @param taskPiloting the value of field 'taskPiloting'.
     */
    public void setTaskPiloting(
            final turbomeca.gamme.assembly.services.model.data.TaskPiloting taskPiloting) {
        this._taskPiloting = taskPiloting;
    }

}
