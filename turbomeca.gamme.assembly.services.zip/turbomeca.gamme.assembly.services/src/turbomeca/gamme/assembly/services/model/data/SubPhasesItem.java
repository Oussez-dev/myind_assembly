/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class SubPhasesItem.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class SubPhasesItem implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Internal choice value storage
     */
    private java.lang.Object _choiceValue;

    /**
     * Field _subPhase.
     */
    private turbomeca.gamme.assembly.services.model.data.SubPhase _subPhase;

    /**
     * Field _subPhaseGroup.
     */
    private turbomeca.gamme.assembly.services.model.data.SubPhaseGroup _subPhaseGroup;


      //----------------/
     //- Constructors -/
    //----------------/

    public SubPhasesItem() {
        super();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'choiceValue'. The field
     * 'choiceValue' has the following description: Internal choice
     * value storage
     * 
     * @return the value of field 'ChoiceValue'.
     */
    public java.lang.Object getChoiceValue(
    ) {
        return this._choiceValue;
    }

    /**
     * Returns the value of field 'subPhase'.
     * 
     * @return the value of field 'SubPhase'.
     */
    public turbomeca.gamme.assembly.services.model.data.SubPhase getSubPhase(
    ) {
        return this._subPhase;
    }

    /**
     * Returns the value of field 'subPhaseGroup'.
     * 
     * @return the value of field 'SubPhaseGroup'.
     */
    public turbomeca.gamme.assembly.services.model.data.SubPhaseGroup getSubPhaseGroup(
    ) {
        return this._subPhaseGroup;
    }

    /**
     * Sets the value of field 'subPhase'.
     * 
     * @param subPhase the value of field 'subPhase'.
     */
    public void setSubPhase(
            final turbomeca.gamme.assembly.services.model.data.SubPhase subPhase) {
        this._subPhase = subPhase;
        this._choiceValue = subPhase;
    }

    /**
     * Sets the value of field 'subPhaseGroup'.
     * 
     * @param subPhaseGroup the value of field 'subPhaseGroup'.
     */
    public void setSubPhaseGroup(
            final turbomeca.gamme.assembly.services.model.data.SubPhaseGroup subPhaseGroup) {
        this._subPhaseGroup = subPhaseGroup;
        this._choiceValue = subPhaseGroup;
    }

}
