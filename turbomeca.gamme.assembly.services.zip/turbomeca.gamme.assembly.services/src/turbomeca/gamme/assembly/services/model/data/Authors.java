/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class Authors.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class Authors implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _corporate.
     */
    private turbomeca.gamme.assembly.services.model.data.Corporate _corporate;

    /**
     * Field _delegateList.
     */
    private java.util.Vector<turbomeca.gamme.assembly.services.model.data.Delegate> _delegateList;

    /**
     * Field _redactor.
     */
    private turbomeca.gamme.assembly.services.model.data.Redactor _redactor;


      //----------------/
     //- Constructors -/
    //----------------/

    public Authors() {
        super();
        this._delegateList = new java.util.Vector<turbomeca.gamme.assembly.services.model.data.Delegate>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vDelegate
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addDelegate(
            final turbomeca.gamme.assembly.services.model.data.Delegate vDelegate)
    throws java.lang.IndexOutOfBoundsException {
        this._delegateList.addElement(vDelegate);
    }

    /**
     * 
     * 
     * @param index
     * @param vDelegate
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addDelegate(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.Delegate vDelegate)
    throws java.lang.IndexOutOfBoundsException {
        this._delegateList.add(index, vDelegate);
    }

    /**
     * Method enumerateDelegate.
     * 
     * @return an Enumeration over all
     * turbomeca.gamme.assembly.services.model.data.Delegate element
     */
    public java.util.Enumeration<? extends turbomeca.gamme.assembly.services.model.data.Delegate> enumerateDelegate(
    ) {
        return this._delegateList.elements();
    }

    /**
     * Returns the value of field 'corporate'.
     * 
     * @return the value of field 'Corporate'.
     */
    public turbomeca.gamme.assembly.services.model.data.Corporate getCorporate(
    ) {
        return this._corporate;
    }

    /**
     * Method getDelegate.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * turbomeca.gamme.assembly.services.model.data.Delegate at the
     * given index
     */
    public turbomeca.gamme.assembly.services.model.data.Delegate getDelegate(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._delegateList.size()) {
            throw new IndexOutOfBoundsException("getDelegate: Index value '" + index + "' not in range [0.." + (this._delegateList.size() - 1) + "]");
        }

        return (turbomeca.gamme.assembly.services.model.data.Delegate) _delegateList.get(index);
    }

    /**
     * Method getDelegate.Returns the contents of the collection in
     * an Array.  <p>Note:  Just in case the collection contents
     * are changing in another thread, we pass a 0-length Array of
     * the correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public turbomeca.gamme.assembly.services.model.data.Delegate[] getDelegate(
    ) {
        turbomeca.gamme.assembly.services.model.data.Delegate[] array = new turbomeca.gamme.assembly.services.model.data.Delegate[0];
        return (turbomeca.gamme.assembly.services.model.data.Delegate[]) this._delegateList.toArray(array);
    }

    /**
     * Method getDelegateAsReference.Returns a reference to
     * '_delegateList'. No type checking is performed on any
     * modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<turbomeca.gamme.assembly.services.model.data.Delegate> getDelegateAsReference(
    ) {
        return this._delegateList;
    }

    /**
     * Method getDelegateCount.
     * 
     * @return the size of this collection
     */
    public int getDelegateCount(
    ) {
        return this._delegateList.size();
    }

    /**
     * Returns the value of field 'redactor'.
     * 
     * @return the value of field 'Redactor'.
     */
    public turbomeca.gamme.assembly.services.model.data.Redactor getRedactor(
    ) {
        return this._redactor;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllDelegate(
    ) {
        this._delegateList.clear();
    }

    /**
     * Method removeDelegate.
     * 
     * @param vDelegate
     * @return true if the object was removed from the collection.
     */
    public boolean removeDelegate(
            final turbomeca.gamme.assembly.services.model.data.Delegate vDelegate) {
        boolean removed = _delegateList.remove(vDelegate);
        return removed;
    }

    /**
     * Method removeDelegateAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public turbomeca.gamme.assembly.services.model.data.Delegate removeDelegateAt(
            final int index) {
        java.lang.Object obj = this._delegateList.remove(index);
        return (turbomeca.gamme.assembly.services.model.data.Delegate) obj;
    }

    /**
     * Sets the value of field 'corporate'.
     * 
     * @param corporate the value of field 'corporate'.
     */
    public void setCorporate(
            final turbomeca.gamme.assembly.services.model.data.Corporate corporate) {
        this._corporate = corporate;
    }

    /**
     * 
     * 
     * @param index
     * @param vDelegate
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setDelegate(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.Delegate vDelegate)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._delegateList.size()) {
            throw new IndexOutOfBoundsException("setDelegate: Index value '" + index + "' not in range [0.." + (this._delegateList.size() - 1) + "]");
        }

        this._delegateList.set(index, vDelegate);
    }

    /**
     * 
     * 
     * @param vDelegateArray
     */
    public void setDelegate(
            final turbomeca.gamme.assembly.services.model.data.Delegate[] vDelegateArray) {
        //-- copy array
        _delegateList.clear();

        for (int i = 0; i < vDelegateArray.length; i++) {
                this._delegateList.add(vDelegateArray[i]);
        }
    }

    /**
     * Sets the value of '_delegateList' by copying the given
     * Vector. All elements will be checked for type safety.
     * 
     * @param vDelegateList the Vector to copy.
     */
    public void setDelegate(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.Delegate> vDelegateList) {
        // copy vector
        this._delegateList.clear();

        this._delegateList.addAll(vDelegateList);
    }

    /**
     * Sets the value of '_delegateList' by setting it to the given
     * Vector. No type checking is performed.
     * @deprecated
     * 
     * @param delegateVector the Vector to set.
     */
    public void setDelegateAsReference(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.Delegate> delegateVector) {
        this._delegateList = delegateVector;
    }

    /**
     * Sets the value of field 'redactor'.
     * 
     * @param redactor the value of field 'redactor'.
     */
    public void setRedactor(
            final turbomeca.gamme.assembly.services.model.data.Redactor redactor) {
        this._redactor = redactor;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.Authors
     */
    public static turbomeca.gamme.assembly.services.model.data.Authors unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.Authors) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.Authors.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
