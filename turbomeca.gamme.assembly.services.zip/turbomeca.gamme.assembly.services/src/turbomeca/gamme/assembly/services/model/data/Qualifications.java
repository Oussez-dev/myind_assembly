/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class Qualifications.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class Qualifications implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _qualificationList.
     */
    private java.util.Vector<turbomeca.gamme.assembly.services.model.data.Qualification> _qualificationList;


      //----------------/
     //- Constructors -/
    //----------------/

    public Qualifications() {
        super();
        this._qualificationList = new java.util.Vector<turbomeca.gamme.assembly.services.model.data.Qualification>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vQualification
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addQualification(
            final turbomeca.gamme.assembly.services.model.data.Qualification vQualification)
    throws java.lang.IndexOutOfBoundsException {
        this._qualificationList.addElement(vQualification);
    }

    /**
     * 
     * 
     * @param index
     * @param vQualification
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addQualification(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.Qualification vQualification)
    throws java.lang.IndexOutOfBoundsException {
        this._qualificationList.add(index, vQualification);
    }

    /**
     * Method enumerateQualification.
     * 
     * @return an Enumeration over all
     * turbomeca.gamme.assembly.services.model.data.Qualification
     * elements
     */
    public java.util.Enumeration<? extends turbomeca.gamme.assembly.services.model.data.Qualification> enumerateQualification(
    ) {
        return this._qualificationList.elements();
    }

    /**
     * Method getQualification.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * turbomeca.gamme.assembly.services.model.data.Qualification
     * at the given index
     */
    public turbomeca.gamme.assembly.services.model.data.Qualification getQualification(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._qualificationList.size()) {
            throw new IndexOutOfBoundsException("getQualification: Index value '" + index + "' not in range [0.." + (this._qualificationList.size() - 1) + "]");
        }

        return (turbomeca.gamme.assembly.services.model.data.Qualification) _qualificationList.get(index);
    }

    /**
     * Method getQualification.Returns the contents of the
     * collection in an Array.  <p>Note:  Just in case the
     * collection contents are changing in another thread, we pass
     * a 0-length Array of the correct type into the API call. 
     * This way we <i>know</i> that the Array returned is of
     * exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public turbomeca.gamme.assembly.services.model.data.Qualification[] getQualification(
    ) {
        turbomeca.gamme.assembly.services.model.data.Qualification[] array = new turbomeca.gamme.assembly.services.model.data.Qualification[0];
        return (turbomeca.gamme.assembly.services.model.data.Qualification[]) this._qualificationList.toArray(array);
    }

    /**
     * Method getQualificationAsReference.Returns a reference to
     * '_qualificationList'. No type checking is performed on any
     * modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<turbomeca.gamme.assembly.services.model.data.Qualification> getQualificationAsReference(
    ) {
        return this._qualificationList;
    }

    /**
     * Method getQualificationCount.
     * 
     * @return the size of this collection
     */
    public int getQualificationCount(
    ) {
        return this._qualificationList.size();
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllQualification(
    ) {
        this._qualificationList.clear();
    }

    /**
     * Method removeQualification.
     * 
     * @param vQualification
     * @return true if the object was removed from the collection.
     */
    public boolean removeQualification(
            final turbomeca.gamme.assembly.services.model.data.Qualification vQualification) {
        boolean removed = _qualificationList.remove(vQualification);
        return removed;
    }

    /**
     * Method removeQualificationAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public turbomeca.gamme.assembly.services.model.data.Qualification removeQualificationAt(
            final int index) {
        java.lang.Object obj = this._qualificationList.remove(index);
        return (turbomeca.gamme.assembly.services.model.data.Qualification) obj;
    }

    /**
     * 
     * 
     * @param index
     * @param vQualification
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setQualification(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.Qualification vQualification)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._qualificationList.size()) {
            throw new IndexOutOfBoundsException("setQualification: Index value '" + index + "' not in range [0.." + (this._qualificationList.size() - 1) + "]");
        }

        this._qualificationList.set(index, vQualification);
    }

    /**
     * 
     * 
     * @param vQualificationArray
     */
    public void setQualification(
            final turbomeca.gamme.assembly.services.model.data.Qualification[] vQualificationArray) {
        //-- copy array
        _qualificationList.clear();

        for (int i = 0; i < vQualificationArray.length; i++) {
                this._qualificationList.add(vQualificationArray[i]);
        }
    }

    /**
     * Sets the value of '_qualificationList' by copying the given
     * Vector. All elements will be checked for type safety.
     * 
     * @param vQualificationList the Vector to copy.
     */
    public void setQualification(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.Qualification> vQualificationList) {
        // copy vector
        this._qualificationList.clear();

        this._qualificationList.addAll(vQualificationList);
    }

    /**
     * Sets the value of '_qualificationList' by setting it to the
     * given Vector. No type checking is performed.
     * @deprecated
     * 
     * @param qualificationVector the Vector to set.
     */
    public void setQualificationAsReference(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.Qualification> qualificationVector) {
        this._qualificationList = qualificationVector;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.Qualifications
     */
    public static turbomeca.gamme.assembly.services.model.data.Qualifications unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.Qualifications) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.Qualifications.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
