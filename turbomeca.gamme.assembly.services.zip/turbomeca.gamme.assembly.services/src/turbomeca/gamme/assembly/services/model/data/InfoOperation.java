/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class InfoOperation.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class InfoOperation implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _standardTime.
     */
    private turbomeca.gamme.assembly.services.model.data.StandardTime _standardTime;

    /**
     * Field _workstation.
     */
    private java.lang.String _workstation;

    /**
     * Field _autoControl.
     */
    private turbomeca.gamme.assembly.services.model.data.AutoControl _autoControl;

    /**
     * Field _mnemonic.
     */
    private java.lang.String _mnemonic;

    /**
     * Field _statusInst.
     */
    private turbomeca.gamme.assembly.services.model.data.StatusInst _statusInst;

    /**
     * Field _scheduleUse.
     */
    private turbomeca.gamme.assembly.services.model.data.ScheduleUse _scheduleUse;


      //----------------/
     //- Constructors -/
    //----------------/

    public InfoOperation() {
        super();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'autoControl'.
     * 
     * @return the value of field 'AutoControl'.
     */
    public turbomeca.gamme.assembly.services.model.data.AutoControl getAutoControl(
    ) {
        return this._autoControl;
    }

    /**
     * Returns the value of field 'mnemonic'.
     * 
     * @return the value of field 'Mnemonic'.
     */
    public java.lang.String getMnemonic(
    ) {
        return this._mnemonic;
    }

    /**
     * Returns the value of field 'scheduleUse'.
     * 
     * @return the value of field 'ScheduleUse'.
     */
    public turbomeca.gamme.assembly.services.model.data.ScheduleUse getScheduleUse(
    ) {
        return this._scheduleUse;
    }

    /**
     * Returns the value of field 'standardTime'.
     * 
     * @return the value of field 'StandardTime'.
     */
    public turbomeca.gamme.assembly.services.model.data.StandardTime getStandardTime(
    ) {
        return this._standardTime;
    }

    /**
     * Returns the value of field 'statusInst'.
     * 
     * @return the value of field 'StatusInst'.
     */
    public turbomeca.gamme.assembly.services.model.data.StatusInst getStatusInst(
    ) {
        return this._statusInst;
    }

    /**
     * Returns the value of field 'workstation'.
     * 
     * @return the value of field 'Workstation'.
     */
    public java.lang.String getWorkstation(
    ) {
        return this._workstation;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     * Sets the value of field 'autoControl'.
     * 
     * @param autoControl the value of field 'autoControl'.
     */
    public void setAutoControl(
            final turbomeca.gamme.assembly.services.model.data.AutoControl autoControl) {
        this._autoControl = autoControl;
    }

    /**
     * Sets the value of field 'mnemonic'.
     * 
     * @param mnemonic the value of field 'mnemonic'.
     */
    public void setMnemonic(
            final java.lang.String mnemonic) {
        this._mnemonic = mnemonic;
    }

    /**
     * Sets the value of field 'scheduleUse'.
     * 
     * @param scheduleUse the value of field 'scheduleUse'.
     */
    public void setScheduleUse(
            final turbomeca.gamme.assembly.services.model.data.ScheduleUse scheduleUse) {
        this._scheduleUse = scheduleUse;
    }

    /**
     * Sets the value of field 'standardTime'.
     * 
     * @param standardTime the value of field 'standardTime'.
     */
    public void setStandardTime(
            final turbomeca.gamme.assembly.services.model.data.StandardTime standardTime) {
        this._standardTime = standardTime;
    }

    /**
     * Sets the value of field 'statusInst'.
     * 
     * @param statusInst the value of field 'statusInst'.
     */
    public void setStatusInst(
            final turbomeca.gamme.assembly.services.model.data.StatusInst statusInst) {
        this._statusInst = statusInst;
    }

    /**
     * Sets the value of field 'workstation'.
     * 
     * @param workstation the value of field 'workstation'.
     */
    public void setWorkstation(
            final java.lang.String workstation) {
        this._workstation = workstation;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.InfoOperation
     */
    public static turbomeca.gamme.assembly.services.model.data.InfoOperation unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.InfoOperation) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.InfoOperation.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
