package turbomeca.gamme.assembly.services.model;

import org.springframework.stereotype.Service;
import org.w3c.dom.Document;

import turbomeca.gamme.ecran.services.publication.bean.SynthesisBean;
import turbomeca.gamme.ecran.services.synthesis.synchronization.GenericScheduleSynthesisBuilder;

@Service
public class AssemblyScheduleAnalyzerService extends GenericScheduleSynthesisBuilder {

	@Override
	protected SynthesisBean updateSynthesisFromDocument(Document scheduleDoc, final SynthesisBean synthesisBean) {
		SynthesisBean updatedBean = new SynthesisBean(synthesisBean);
		return updatedBean;
	}

}

