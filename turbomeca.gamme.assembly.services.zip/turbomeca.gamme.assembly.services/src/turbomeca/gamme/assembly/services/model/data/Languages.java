/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3</a>, using an XML
 * Schema.
 * $Id$
 */

package turbomeca.gamme.assembly.services.model.data;

/**
 * Class Languages.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class Languages implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _languageList.
     */
    private java.util.Vector<turbomeca.gamme.assembly.services.model.data.Language> _languageList;


      //----------------/
     //- Constructors -/
    //----------------/

    public Languages() {
        super();
        this._languageList = new java.util.Vector<turbomeca.gamme.assembly.services.model.data.Language>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vLanguage
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addLanguage(
            final turbomeca.gamme.assembly.services.model.data.Language vLanguage)
    throws java.lang.IndexOutOfBoundsException {
        this._languageList.addElement(vLanguage);
    }

    /**
     * 
     * 
     * @param index
     * @param vLanguage
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addLanguage(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.Language vLanguage)
    throws java.lang.IndexOutOfBoundsException {
        this._languageList.add(index, vLanguage);
    }

    /**
     * Method enumerateLanguage.
     * 
     * @return an Enumeration over all
     * turbomeca.gamme.assembly.services.model.data.Language element
     */
    public java.util.Enumeration<? extends turbomeca.gamme.assembly.services.model.data.Language> enumerateLanguage(
    ) {
        return this._languageList.elements();
    }

    /**
     * Method getLanguage.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * turbomeca.gamme.assembly.services.model.data.Language at the
     * given index
     */
    public turbomeca.gamme.assembly.services.model.data.Language getLanguage(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._languageList.size()) {
            throw new IndexOutOfBoundsException("getLanguage: Index value '" + index + "' not in range [0.." + (this._languageList.size() - 1) + "]");
        }

        return (turbomeca.gamme.assembly.services.model.data.Language) _languageList.get(index);
    }

    /**
     * Method getLanguage.Returns the contents of the collection in
     * an Array.  <p>Note:  Just in case the collection contents
     * are changing in another thread, we pass a 0-length Array of
     * the correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public turbomeca.gamme.assembly.services.model.data.Language[] getLanguage(
    ) {
        turbomeca.gamme.assembly.services.model.data.Language[] array = new turbomeca.gamme.assembly.services.model.data.Language[0];
        return (turbomeca.gamme.assembly.services.model.data.Language[]) this._languageList.toArray(array);
    }

    /**
     * Method getLanguageAsReference.Returns a reference to
     * '_languageList'. No type checking is performed on any
     * modifications to the Vector.
     * 
     * @return a reference to the Vector backing this class
     */
    public java.util.Vector<turbomeca.gamme.assembly.services.model.data.Language> getLanguageAsReference(
    ) {
        return this._languageList;
    }

    /**
     * Method getLanguageCount.
     * 
     * @return the size of this collection
     */
    public int getLanguageCount(
    ) {
        return this._languageList.size();
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllLanguage(
    ) {
        this._languageList.clear();
    }

    /**
     * Method removeLanguage.
     * 
     * @param vLanguage
     * @return true if the object was removed from the collection.
     */
    public boolean removeLanguage(
            final turbomeca.gamme.assembly.services.model.data.Language vLanguage) {
        boolean removed = _languageList.remove(vLanguage);
        return removed;
    }

    /**
     * Method removeLanguageAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public turbomeca.gamme.assembly.services.model.data.Language removeLanguageAt(
            final int index) {
        java.lang.Object obj = this._languageList.remove(index);
        return (turbomeca.gamme.assembly.services.model.data.Language) obj;
    }

    /**
     * 
     * 
     * @param index
     * @param vLanguage
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setLanguage(
            final int index,
            final turbomeca.gamme.assembly.services.model.data.Language vLanguage)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._languageList.size()) {
            throw new IndexOutOfBoundsException("setLanguage: Index value '" + index + "' not in range [0.." + (this._languageList.size() - 1) + "]");
        }

        this._languageList.set(index, vLanguage);
    }

    /**
     * 
     * 
     * @param vLanguageArray
     */
    public void setLanguage(
            final turbomeca.gamme.assembly.services.model.data.Language[] vLanguageArray) {
        //-- copy array
        _languageList.clear();

        for (int i = 0; i < vLanguageArray.length; i++) {
                this._languageList.add(vLanguageArray[i]);
        }
    }

    /**
     * Sets the value of '_languageList' by copying the given
     * Vector. All elements will be checked for type safety.
     * 
     * @param vLanguageList the Vector to copy.
     */
    public void setLanguage(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.Language> vLanguageList) {
        // copy vector
        this._languageList.clear();

        this._languageList.addAll(vLanguageList);
    }

    /**
     * Sets the value of '_languageList' by setting it to the given
     * Vector. No type checking is performed.
     * @deprecated
     * 
     * @param languageVector the Vector to set.
     */
    public void setLanguageAsReference(
            final java.util.Vector<turbomeca.gamme.assembly.services.model.data.Language> languageVector) {
        this._languageList = languageVector;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * turbomeca.gamme.assembly.services.model.data.Languages
     */
    public static turbomeca.gamme.assembly.services.model.data.Languages unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (turbomeca.gamme.assembly.services.model.data.Languages) org.exolab.castor.xml.Unmarshaller.unmarshal(turbomeca.gamme.assembly.services.model.data.Languages.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
