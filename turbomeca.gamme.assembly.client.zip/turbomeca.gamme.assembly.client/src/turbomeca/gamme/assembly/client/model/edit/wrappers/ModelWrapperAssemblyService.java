package turbomeca.gamme.assembly.client.model.edit.wrappers;

import java.util.Vector;

import turbomeca.gamme.assembly.services.model.data.Assembly;
import turbomeca.gamme.assembly.services.model.data.Compounds;
import turbomeca.gamme.assembly.services.model.data.DerogationMarks;
import turbomeca.gamme.assembly.services.model.data.DeviationsFromRef;
import turbomeca.gamme.assembly.services.model.data.ElectronicPostIt;
import turbomeca.gamme.assembly.services.model.data.Historical;
import turbomeca.gamme.assembly.services.model.data.HistoricalPassing;
import turbomeca.gamme.assembly.services.model.data.Identification;
import turbomeca.gamme.assembly.services.model.data.Instanciation;
import turbomeca.gamme.assembly.services.model.data.ObjectsToSynchronize;
import turbomeca.gamme.assembly.services.model.data.Operation;
import turbomeca.gamme.assembly.services.model.data.Operations;
import turbomeca.gamme.assembly.services.model.data.Parameters;
import turbomeca.gamme.assembly.services.model.data.PostGeneralities;
import turbomeca.gamme.assembly.services.model.data.PreGeneralities;
import turbomeca.gamme.assembly.services.model.data.Qualifications;
import turbomeca.gamme.assembly.services.model.data.Rework;
import turbomeca.gamme.assembly.services.model.data.State;

public class ModelWrapperAssemblyService extends AModelWrapperAssemblyScheduleService {

	/** */
	private Assembly assembly;
	
	public ModelWrapperAssemblyService() {
	}
	
	@Override
	public void setObject(Object object) {
		this.assembly = (Assembly) object;
	}
	
    public Assembly getAssembly() {
        return assembly;
    }
	
    @Override
    public Object getObject() {
        return getAssembly();
    }
    
	@Override
	public Identification getIdentification() {		
		return getAssembly().getIdentification();
	}

	@Override
	public Historical getHistorical() {
		return getAssembly().getHistorical();
	}

	@Override
	public Parameters getParameters() {
		return getAssembly().getParameters();
	}
	
	@Override
	public Instanciation getInstantiation() {
		return getAssembly().getInstanciation();
	}

	@Override
	public Operations getOperations() {
		return getAssembly().getOperations();
	}

	@Override
	public State getState() {
		return getInstantiation().getState();
	}

	@Override
	public DeviationsFromRef[] getDeviationFromRef() {
		return getAssembly().getDeviationsFromRef();
	}
	
	@Override
	public String getId() {
		return null;
	}

	@Override
    public Qualifications getExecutionQualifications() {
        return getAssembly().getQualifications();
    }

    @Override
    public Qualifications getValidationQualifications() {
        return getAssembly().getQualifications();
    }
    
	@Override
	public void setId(String id) {
	}

    @Override
    public ElectronicPostIt getElectronicPostIt() {
        return getAssembly().getElectronicPostIt();
    }
    
    @Override
    public void setElectronicPostIt(ElectronicPostIt electronicPostIt) {
        getAssembly().setElectronicPostIt(electronicPostIt);
    }
    
    @Override
    public Integer getPassingId() {
        return getInstantiation().getPassing();
    }

    @Override
    public void setPassingId(Integer passingId) {
        getInstantiation().setPassing(passingId);
    }

    @Override
    public Rework getRework() {
        return getAssembly().getRework();
    }

    @SuppressWarnings("unchecked")
	@Override
    public void setOperations(Vector<?> operations) {
        getAssembly().getOperations().setOperation((Vector<Operation>)operations);
    }

    @Override
    public Compounds getCompounds() {
        return getAssembly().getCompounds();
    }

    @Override
    public PreGeneralities getPreGenerality() {
        return getAssembly().getPreGeneralities();
    }
    
    @Override
    public  PostGeneralities getPostGenerality() {
        return getAssembly().getPostGeneralities();
    }

	@Override
	public DerogationMarks getDerogationMarks() {
		return getAssembly().getDerogationMarks();
	}

	@Override
	public void setDerogationMarks(DerogationMarks derogationMarks) {
		 getAssembly().setDerogationMarks(derogationMarks);
	}

    @Override
    public boolean hasGenerality() {
        return ((getAssembly() != null && getAssembly().getPostGeneralities() != null)
        		||
        		(getAssembly() != null && getAssembly().getPreGeneralities() != null));
    }

    @Override
    public boolean hasDeviationFromRef() {
        return (getAssembly() != null && getAssembly().getDeviationsFromRef() != null 
        		&& getAssembly().getDeviationsFromRef().length > 0);
    }

    @Override
    public boolean hasCompounds() {
        return (getAssembly() != null && getAssembly().getCompounds() != null);
    }

    @Override
    public boolean hasElectronicPostIt() {
        return (getAssembly() != null && getAssembly().getElectronicPostIt() != null);
    }

	@Override
	public HistoricalPassing getHistoricalPassing() {
		HistoricalPassing historicalPassing = null;
		if(getAssembly() != null){
			historicalPassing = getAssembly().getHistoricalPassing();
		}
		return historicalPassing;
	}

	@Override
	public void setHistoricalPassing(Object historicalPassing) {
		if(getAssembly() != null) {
			getAssembly().setHistoricalPassing((HistoricalPassing)historicalPassing);
		}
		
	}

	@Override
	public ObjectsToSynchronize getObjectsToSynchronize() {
		ObjectsToSynchronize objectsToSynchronize = null;
		if(getAssembly() != null) {
			objectsToSynchronize = getAssembly().getObjectsToSynchronize();
		}
		return objectsToSynchronize;
	}

	@Override
	public void setObjectsToSynchronize(
			ObjectsToSynchronize objectsToSynchronize) {
		if(getAssembly() != null) {
			getAssembly().setObjectsToSynchronize(objectsToSynchronize);
		}
	}
	
	@Override
	public String getSuffix() {
		String result = null;
		if (getAssembly() != null) {
			result = getAssembly().getSuffix();
		}
		return result;
	}

}
