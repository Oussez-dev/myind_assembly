package turbomeca.gamme.assembly.client.model.edit.status;

import java.util.List;

import turbomeca.gamme.assembly.services.model.data.types.StatusType;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public interface IModelStatusBuilderService {

	public boolean setState(StatusType status, String comment, boolean force, List<String> instancesId) throws ClientException;

	public void setComment(String comment, List<String> instancesId) throws ClientException;
	
	public boolean resetState(boolean force, List<String> instancesId) throws ClientException;
	
	public StatusType checkStatusChange(StatusType currentStatus, StatusType newStatus);

	public String getStatus(String instanceId) throws ClientException;

	public void setAlterable(IModelObjectService duplicableService, List<String> instancesId) throws ClientException, ClientInterruption;

	public void setActive(boolean active, boolean delete, List<String> instancesId) throws ClientException, ClientInterruption;

	public void cloneService(int passingId, int iterationId, List<String> instancesId) throws ClientException;

	public void updateId(int passingId, int iterationId, List<String> instancesId);
	
}
