package turbomeca.gamme.assembly.client.model.edit.loader;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelToolService;
import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperToolService;
import turbomeca.gamme.assembly.services.model.data.PN;
import turbomeca.gamme.assembly.services.model.data.SN;
import turbomeca.gamme.assembly.services.model.data.Tool;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.interfaces.IModelLoaderService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.model.provider.ModelXmlProvider;

public class ModelLoaderToolService extends AModelAssemblyLoader implements IModelLoaderService {

	public ModelLoaderToolService(IModelObjectService modelService) {
		super(modelService);
	}

	 @Override
	    public ModelWrapperToolService getWrapperService() {
	        return (ModelWrapperToolService) super.getWrapperService();
	    }
	
	@Override
    public ModelToolService getModelService() {
        return (ModelToolService) super.getModelService();
    }

	@Override
	public void load(ModelXmlProvider modelProvider) throws ClientException, ClientInterruption {
		   Tool tool = getWrapperService().getTool();
		   String toolId = tool.getUniqueId() + "_" 
                   + getModelService().getParent().getParent().getIdentifier();
		   
		   ModelSubPhaseService subPhaseService = (ModelSubPhaseService) getModelService().getAncestor(ModelSubPhaseService.class);
		   
		   if(subPhaseService != null) {
			   toolId = tool.getUniqueId() + "_"+ subPhaseService.getIdentifier();
		   }
           
           PN pn = tool.getPN();
           if (pn != null) {
    		   loadTaskAction(modelProvider, toolId, pn.getTaskAction());
           }
           SN sn = tool.getSN();
           if (sn != null) {
               loadTaskAction(modelProvider, toolId, sn.getTaskAction());
           }
           loadTaskAction(modelProvider, toolId, tool.getTaskAction());
       
       if (modelProvider != null) {
           modelProvider.addModelService(getModelService().getIdentifier(), getModelService());
       }
	}

}
