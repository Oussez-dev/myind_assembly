package turbomeca.gamme.assembly.client.model.edit.status;

import java.util.List;
import java.util.Vector;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.config.AssemblyConstants;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskActionMeasureService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskActionService;
import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperTaskActionService;
import turbomeca.gamme.assembly.services.model.data.InputAction;
import turbomeca.gamme.assembly.services.model.data.InputActionChoice;
import turbomeca.gamme.assembly.services.model.data.InputChoice;
import turbomeca.gamme.assembly.services.model.data.InputComputed;
import turbomeca.gamme.assembly.services.model.data.InputRef;
import turbomeca.gamme.assembly.services.model.data.InputValue;
import turbomeca.gamme.assembly.services.model.data.StringValue;
import turbomeca.gamme.assembly.services.model.data.TaskAction;
import turbomeca.gamme.assembly.services.model.data.types.StatusType;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.services.common.constants.GlobalConstants;
import turbomeca.gamme.ecran.services.common.utils.misc.FormatUtils;

public class ModelStatusTaskActionService extends ModelStatusService {

	/** logger for current class */
	private static Logger logger = Logger.getLogger(ModelStatusTaskActionService.class);

	public ModelStatusTaskActionService(IModelObjectService modelService) {
		super(modelService);
	}

	@Override
	public ModelWrapperTaskActionService getWrapperService() {
		return (ModelWrapperTaskActionService) super.getWrapperService();
	}

	protected TaskAction getTaskAction() {
		return getWrapperService().getTaskAction();
	}

	@Override
	public ModelTaskActionService getModelService() {
		return (ModelTaskActionService) super.getModelService();
	}

	@Override
	public String getStatus() throws ClientException {
		StatusType status = StatusType.TODO;
		InputValue inputValue = getTaskAction().getInputAction().getInputValue();
		if (inputValue != null) {
			try {
				if (getTaskAction().getDoubleValidation() && inputValue.getUserMarkValidation() == null) {
					status = StatusType.WAIT;
				}else{
					if (getModelService().checkValue(inputValue.getValue())) {
						status = StatusType.OK;
					} else {
						status = StatusType.KO;
					}
				}
			} catch (ClientInterruption e) {
			}
		}
		else if (getModelService().getRunnableService().isOptional()) {
		    status = StatusType.OK;
		}
		return status.value();
	}

	@Override
	public void clean(List<String> instancesId) throws ClientException, ClientInterruption {
		logger.debug("clean : " + getModelService() + "(" + FormatUtils.getStringValues(instancesId));
		InputAction inputAction = getTaskAction().getInputAction();
		
	    // Check if inputAction is an String inputChoice
        cleanInputChoice();
        
        // Remove force editable flag
        getTaskAction().deleteForceEditable();
        
        // Remove all notifications
        getTaskAction().removeAllElectronicNotificationRef();
        
        // If there is a value
		if (inputAction.getInputValue() != null) {
		    InputActionChoice inputActionChoice = inputAction.getInputActionChoice();
		    
		    // If inputAction is an inputField and has a default value,
		    // Everything is commented because it is useless to replace
		    // the value and delete its userMark
			if (   inputAction.getDefaultValue() != null) {
			    // Set default value and remove user information except when the userMark input is SAP
			    //inputAction.getInputValue().setValue(inputAction.getDefaultValue());
			    //if(inputAction.getInputValue().getUserMark() != null 
			    //		&& inputAction.getInputValue().getUserMark().getUser() != null
			    //		&& inputAction.getInputValue().getUserMark().getUser().getLogin() != null
			    //		&& !inputAction.getInputValue().getUserMark().getUser().getLogin().equals(GlobalConstants.SAP_LOGIN)) {
			    //	inputAction.getInputValue().setUserMark(null);
			    //}
			}
			// If inputAction in an inputComputed with only inputRef, check if reference is erasable
			else if (    inputActionChoice.getInputComputed() != null
			        &&   inputActionChoice.getInputComputed().getInputRef() != null) {
                InputRef inputRef = inputActionChoice.getInputComputed().getInputRef();
                if (inputRef.getRefId() instanceof TaskAction) {
                    TaskAction taskAction = (TaskAction) inputRef.getRefId();
                    if (taskAction.isEditable()) {
                        inputAction.setInputValue(null);
                    }
                }
            }
			// If it is an SAP task action and it is a completion value, keep value
			else if (getModelService().isSapTaskAction()) {
				if (getTaskAction().getSapValue() != null
						&& ((inputActionChoice.getInputSap() != null && inputActionChoice.getInputSap().isCompletion())
								|| (inputActionChoice.getInputControlSap() != null
										&& inputActionChoice.getInputControlSap().isCompletion()))) {
					inputAction.getInputValue().setValue(getTaskAction().getSapValue().getValue());
				} else {
					inputAction.setInputValue(null);
				}
			}
			// Otherwise remove current value if input is not a constant
			else if (inputActionChoice.getInputConstant() == null) {
			    inputAction.setInputValue(null);
			}
			
			// Set flag modified for updating references
			getModelService().setServiceModified(true);
		} 
		else if (inputAction.getDefaultValue() != null) {
		    InputValue inputValue = new InputValue();
		    inputValue.setValue(inputAction.getDefaultValue());
		    inputValue.setUserMark(null);
		    inputAction.setInputValue(inputValue);
		    
            // Set flag modified for updating references
            getModelService().setServiceModified(true);
		}
	}

	private void cleanInputChoice() {
	    InputChoice inputChoice = getTaskAction().getInputAction().getInputActionChoice().getInputChoice();
        if (inputChoice != null && inputChoice.getStringValueCount() > 0) {
            // Remove string value choice added by user
            Vector<StringValue> stringValues = new Vector<StringValue>();
            for (StringValue value : inputChoice.getStringValue()) {
                if (value.isManual()) {
                    value = null;
                }
                else {
                    stringValues.add(value);
                }
            }
            inputChoice.setStringValue(stringValues);
        }
	}
	
	@Override
	public void update() throws ClientException, ClientInterruption {
		logger.debug("updateService : " + getModelService());
		boolean needComputeSubPhase = false;
		if (!isAlterable()) {
			setAlterable(null);
		}
		
		InputComputed inputComputed = getTaskAction().getInputAction().getInputActionChoice().getInputComputed();
		if (inputComputed != null) {
			InputRef inputRef = inputComputed.getInputRef();
			if (inputRef != null) {
				ModelTaskActionService taskActionService = (ModelTaskActionService) getModelProvider().getModelService(((TaskAction) inputRef.getRefId()).getId());
				getModelService().setValue(taskActionService.getTextValue(), true);
			} else {
				int precision = AssemblyConstants.DEFAULT_DIGIT_PRECISION;
				if (inputComputed.hasDigitPrecision()) {
					precision = inputComputed.getDigitPrecision();
				}
				String newValue = getModelService().computeFormula(inputComputed.getFormula(), precision);
				if (newValue != null && (getModelService().getTextValue() == null || newValue.compareTo(getModelService().getTextValue()) != 0)) {
					getModelService().setValue(newValue, true);
				}
			}
			
			needComputeSubPhase = true;
		}
		getModelService().getParent().getStatusService().computeStatus(false);
		if(needComputeSubPhase){
			((ModelSubPhaseService) getModelService().getAncestor(ModelSubPhaseService.class)).getStatusService().computeStatus(false);
		}
		
		// Patch for delivery
		if (getModelService().getParent() instanceof ModelTaskActionMeasureService) {
		    getModelService().getParent().getStatusService().resetState(false, true, null);
		    getModelService().getParent().getStatusService().clean(null);
		}
		super.update();
	}

	@Override
	public void archive(int passingId, int iterationId, List<String> instancesId)
			throws ClientException {
		logger.debug("archiveService : " + getModelService());
	}

	@Override
	public void updateActivity(boolean recursive, boolean delete, List<String> instancesId)
			throws ClientException {
		logger.debug("updateActivity : nothing to do");
	}
	
	@Override
	public void resetState(boolean recursively, boolean force, List<String> instancesId)
			throws ClientException {
		logger.debug("resetState (" + instancesId + ") : " + getModelService());
	}
	
	@Override
    public boolean isInProgress() throws ClientException {
	    boolean isInProgress = true;
	    InputAction inputAction = getTaskAction().getInputAction();
	    InputActionChoice inputActionChoice = inputAction.getInputActionChoice();
	    if (   inputActionChoice.getInputComputed() != null
	        || inputActionChoice.getInputConstant() != null
	        || !getTaskAction().isEditable()) {
	        isInProgress = false;
	    } else {
	        InputValue inputValue = inputAction.getInputValue();
	        if (inputValue == null || inputValue.getUserMark() == null) {
	            isInProgress = false;
	        }
	    }
        return isInProgress;
    }
}
