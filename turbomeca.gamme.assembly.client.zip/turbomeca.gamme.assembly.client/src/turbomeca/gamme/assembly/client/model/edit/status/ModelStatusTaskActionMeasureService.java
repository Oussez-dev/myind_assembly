package turbomeca.gamme.assembly.client.model.edit.status;

import java.util.List;

import turbomeca.gamme.assembly.client.model.edit.utils.ModelUtils;
import turbomeca.gamme.assembly.services.model.data.State;
import turbomeca.gamme.assembly.services.model.data.TaskActionMeasure;
import turbomeca.gamme.assembly.services.model.data.types.StatusType;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public class ModelStatusTaskActionMeasureService extends ModelStatusService {

	public ModelStatusTaskActionMeasureService(IModelObjectService modelService) {
		super(modelService);
	}

	@Override
	public String getStatus() throws ClientException {
		TaskActionMeasure taskMeasure = (TaskActionMeasure) getModelService().getWrapperService().getObject();
		return getModelProvider().getModelService(taskMeasure.getTaskAction().getId()).getStatusService().getStatus();
	}
	
	@Override
	public void resetState(boolean recursively, boolean force, List<String> instancesId) throws ClientException, ClientInterruption {
		TaskActionMeasure taskMeasure = (TaskActionMeasure) getModelService().getWrapperService().getObject();
		boolean hasChanged = false;
		if (taskMeasure.getMeasureSap() != null) {
		    hasChanged |= resetUnitState(taskMeasure.getMeasureSap().getState(), force);
		}
		if (taskMeasure.getMeasureRdd() != null) {
		    hasChanged |= resetUnitState(taskMeasure.getMeasureRdd().getState(), force);
		}
		if (taskMeasure.getMeasureTool() != null) {
		    hasChanged |= resetUnitState(taskMeasure.getMeasureTool().getState(), force);
		}
		
		if (hasChanged) {
    		setModified(force);
		}
	}
	
	/**
	 * 
	 * @throws ClientException
	 * @throws ClientInterruption 
	 */
	public void updateStateToolsMeasure() throws ClientException, ClientInterruption{
		TaskActionMeasure taskMeasure = (TaskActionMeasure) getModelService().getWrapperService().getObject();
		if (resetUnitState(taskMeasure.getMeasureTool().getState(), false)) {
			setModified(true);
		}
	}
	
	@Override
	public void updateState(String status, boolean force, String comment, List<String> instancesId)
			throws ClientException, ClientInterruption {
		getNotifications().notifyStatusChanged(getModelService());
		setServiceModified();
	}
	
	@Override
    public void clean(List<String> instancesId) throws ClientException, ClientInterruption {
	    TaskActionMeasure taskMeasure = (TaskActionMeasure) getModelService().getWrapperService().getObject();
	    getModelProvider().getModelService(taskMeasure.getTaskAction().getId()).getStatusService().clean(instancesId);
    }
	
	/**
	 * @throws ClientException 
	 * @throws ClientInterruption 
	 * 
	 */
	private void setModified(boolean force) throws ClientException, ClientInterruption {
	    getNotifications().notifyStatusChanged(getModelService());
        if (getModelService().getParent().getStatusService().getStatus() != StatusType.TODO.value()) {
            getModelService().getParent().getStatusService().resetState(false, force, null);
        }
	}
	
	/**
	 * 
	 * @param state
	 * @param force
	 * @return
	 */
	private boolean resetUnitState(State state, boolean force){
        boolean updated = false;
        if (force || state.getStatus() != StatusType.TODO) {
            ModelUtils.initState(state);
            updated = true;
        }
        return updated;
    }
}