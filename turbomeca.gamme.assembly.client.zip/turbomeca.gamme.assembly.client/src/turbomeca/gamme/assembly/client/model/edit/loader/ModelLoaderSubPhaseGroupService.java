package turbomeca.gamme.assembly.client.model.edit.loader;

import java.util.Enumeration;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseGroupService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperSubPhaseGroupService;
import turbomeca.gamme.assembly.services.model.data.SubPhase;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.interfaces.IModelLoaderService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.model.provider.ModelXmlProvider;

public class ModelLoaderSubPhaseGroupService extends AModelAssemblyLoader implements
        IModelLoaderService {

    public ModelLoaderSubPhaseGroupService(IModelObjectService modelService) {
        super(modelService);
    }

    @Override
    public ModelWrapperSubPhaseGroupService getWrapperService() {
        return (ModelWrapperSubPhaseGroupService) super.getWrapperService();
    }

    @Override
    public ModelSubPhaseGroupService getModelService() {
        return (ModelSubPhaseGroupService) super.getModelService();
    }

    public void load(ModelXmlProvider modelProvider) throws ClientException, ClientInterruption {
        Enumeration<? extends SubPhase> enumSubPhase = getWrapperService().getSubPhaseGroup().enumerateSubPhase();
        while (enumSubPhase.hasMoreElements()) {
            ModelSubPhaseService subPhaseService = new ModelSubPhaseService(getModelService(), enumSubPhase.nextElement());
            subPhaseService.getLoaderService().load(modelProvider);
            getModelService().addChild(subPhaseService);
        }
        if (modelProvider != null) {
            modelProvider.addModelService(getModelService().getIdentifier(), getModelService());
        }
    }
}
