package turbomeca.gamme.assembly.client.model.edit.notifications;

import java.util.UUID;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.services.model.data.ElectronicNotification;
import turbomeca.gamme.assembly.services.model.data.types.NotificationOriginType;
import turbomeca.gamme.assembly.services.model.data.types.NotificationType;
import turbomeca.gamme.ecran.client.constants.PropertyConstants;

public class ModelNotificationUserService extends AModelNotificationService {

    /**
     * 
     * @param electronicNotification
     */
    public ModelNotificationUserService(ModelNotificationsService modelNotificationService,
            ElectronicNotification electronicNotification) {
        super(modelNotificationService, electronicNotification);
    }
    
    /**
     * 
     * @param comment
     */
    public ModelNotificationUserService(ModelSubPhaseService subPhaseService, String comment) {
        super(subPhaseService.getDomain(), UUID.randomUUID().toString());
        initService();
        
        String message = String.format(
                getConfiguration().getProperty(
                		PropertyConstants.PROPERTY_MESSAGE_NOTIFICATION_USER), comment);
        createElectronicNotification(NotificationType.METHOD, NotificationOriginType.USER, message);
    }

    @Override
    public boolean isCleanable() {
    	switch (getElectronicNotification().getStatusNotification()) {
		case CANCELED:
			return true;
		default:
			return false;
		}
    }
    
    @Override
    public boolean isBlockingSign() {
    	switch (getElectronicNotification().getStatusNotification()) {
		case CREATED:
			return true;
		case CANCELED:
			return false;
		case ACCEPTED:
		case ACCEPTED_NCR:
			return true;
		case REFUSED:
			return true;
		case REFUSED_ACCEPTED:
		case ACCEPTED_ACCEPTED:
			return false;
		default:
			return false;
		}
    }
}
