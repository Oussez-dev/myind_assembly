package turbomeca.gamme.assembly.client.model.edit.utils;

import java.math.BigDecimal;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.ClientAssemblyException;
import turbomeca.gamme.assembly.services.model.data.ChoiceItem;
import turbomeca.gamme.assembly.services.model.data.DataValue;
import turbomeca.gamme.assembly.services.model.data.DataValueChoice;
import turbomeca.gamme.assembly.services.model.data.InputAction;
import turbomeca.gamme.assembly.services.model.data.InputChoice;
import turbomeca.gamme.assembly.services.model.data.InputRef;
import turbomeca.gamme.assembly.services.model.data.InputValue;
import turbomeca.gamme.assembly.services.model.data.Interval;
import turbomeca.gamme.assembly.services.model.data.Max;
import turbomeca.gamme.assembly.services.model.data.Min;
import turbomeca.gamme.assembly.services.model.data.StringValue;
import turbomeca.gamme.assembly.services.model.data.TaskAction;
import turbomeca.gamme.assembly.services.model.data.Test;
import turbomeca.gamme.ecran.client.ClientInterruption;

/**
 * 
 * @author Sopra Group
 * 
 */
public class ModelComparatorService {

	/** logger for current class */
	private static Logger logger = Logger.getLogger(ModelComparatorService.class);

	/**
	 * Compare a value with a data (can be an interval, a graph or a value)
	 * 
	 * @param value
	 *            user input value
	 * @param inputAction
	 * @param data
	 *            data to compare
	 * @return true : value is valid false : otherwise
	 * @throws ClientInterruption 
	 */
	public boolean compareValueToData(String value, InputAction inputAction, Test[] tests, int precision)
			throws ClientAssemblyException, ClientInterruption {
		boolean isValid = true;
		
		if (value != null) {
			if (tests == null || tests.length == 0) {
				isValid = true;
			} else {
				String valueText = value;
				InputChoice inputChoice = inputAction.getInputActionChoice().getInputChoice();
				if (inputChoice != null) {
					int index = Integer.valueOf(value) - 1;
					if (inputChoice.getItemParaCount() != 0) {
						valueText = inputChoice.getItemPara(index).getPara(0).getContent();
					}
					else if (inputChoice.getStringValueCount() != 0) {
						valueText = inputChoice.getStringValue(index).getContent();
					}
					else  if (inputChoice.getValCount() != 0) {
						valueText = inputChoice.getVal(index).toString();
					}
					else {
						throw new ClientAssemblyException(ClientAssemblyException.EXCEPTION_INCOMPATIBLE_INPUT_AND_TEST);
					}
				}
				
				for (Test test : tests) {
					isValid &= isValid(valueText, value, test, precision);
				}
			}
		}
		return isValid;
	}
	
	private boolean isValid(String valueText, String value, Test test, int precision) throws ClientAssemblyException, ClientInterruption {
		boolean isValid = false;
		
		Object choiceDataValue = test.getChoiceValue();
		if (choiceDataValue instanceof DataValue) {
			isValid = comparAssemblyueToDataValue(valueText, test.getDataValue(),precision);
		} else if (choiceDataValue instanceof Interval) {
			isValid = compareValueToInterval(valueText, test.getInterval());
		} else if (choiceDataValue instanceof ChoiceItem) {
			isValid = compareValueToChoice(value, test.getChoiceItem());
		} else if (choiceDataValue instanceof StringValue) {
			isValid = valueText.equals(test.getStringValue().getContent());
		} else if (test.getParaCount() != 0) {
			isValid = valueText.equals(test.getPara(0).getContent());
		} else {
			isValid = false;
			logger.error("Error : current case is not managed");
		}
		
		return isValid;
	}

    /**
	 * 
	 * @param value
	 * @param choiceItem
	 * @return
	 */
	private boolean compareValueToChoice(String value, ChoiceItem choiceItem) {
		return (choiceItem.getPosition() == Integer.parseInt(value));
	}

	/**
	 * Compare a value with an interval
	 * 
	 * @param value
	 *            user input value
	 * @param interval
	 *            interval to compare
	 * @param itemId 
	 * @return true : value is valid false : otherwise
	 * @throws ClientInterruption 
	 */
	private boolean compareValueToInterval(String value, Interval interval)
			throws ClientAssemblyException, ClientInterruption {

		double uncertainly = 0;
		boolean isMinValid = false;
		boolean isMaxValid = false;

		Min minInterval = interval.getMin();
		Max maxInterval = interval.getMax();

		try {
			// Convert string value to double value
			double doublAssemblyue = Double.parseDouble(value);

			if (minInterval != null) {
				double minValue = Double.parseDouble(computeDataValue(minInterval.getDataValue()));

				BigDecimal uncertainlyBig = minInterval.getDataValue().getUncertainty();
				if (uncertainlyBig != null) {
					uncertainly = uncertainlyBig.doubleValue();
				} else {
					uncertainly = 0;
				}

				switch (minInterval.getOperator()) {
				case STRICT:
					if (doublAssemblyue > (minValue - uncertainly)) {
						isMinValid = true;
					}
					;
					break;
				case LARGE:
					if (doublAssemblyue >= (minValue - uncertainly)) {
						isMinValid = true;
					}
					break;
				default:
					if (doublAssemblyue >= (minValue - uncertainly)
							&& doublAssemblyue <= (minValue + uncertainly)) {
						isMinValid = true;
					}
					;
					break;
				}
			} else {
				isMinValid = true;
			}

			if (maxInterval != null) {
				double maxValue = Double.parseDouble(computeDataValue(maxInterval.getDataValue()));

				BigDecimal uncertainlyBig = maxInterval.getDataValue().getUncertainty();
				if (uncertainlyBig != null) {
					uncertainly = uncertainlyBig.doubleValue();
				} else {
					uncertainly = 0;
				}

				switch (maxInterval.getOperator()) {
				case STRICT:
					if (doublAssemblyue < (maxValue + uncertainly)) {
						isMaxValid = true;
					}
					;
					break;
				case LARGE:
					if (doublAssemblyue <= (maxValue + uncertainly)) {
						isMaxValid = true;
					}
					;
					break;
				default:
					if (doublAssemblyue >= (maxValue - uncertainly)
							&& doublAssemblyue <= (maxValue + uncertainly)) {
						isMaxValid = true;
					}
					break;
				}
			} else {
				isMaxValid = true;
			}

			return (isMinValid && isMaxValid);
		} catch (NumberFormatException e) {
			throw new ClientAssemblyException(ClientAssemblyException.EXCEPTION_VALUE_BAD_FORMAT);
		}
	}

	/**
	 * Compare a value with a value
	 * 
	 * @param value
	 *            user input value
	 * @param dataValue
	 *            value to compare
	 * @param itemId 
	 * @return true : value is valid false : otherwise
	 * @throws ClientInterruption 
	 */
	private boolean comparAssemblyueToDataValue(String value, DataValue dataValue, int precision)
			throws ClientAssemblyException, ClientInterruption {

		boolean isValid = false;

		
		try {
			
			double valueReference = Double.parseDouble(computeDataValue(dataValue));
			double doublAssemblyue = Double.parseDouble(value);

			if (dataValue.getUncertainty() != null) {

				double doubleUncertainty = 0;
				BigDecimal uncertainlyBig = dataValue.getUncertainty();
				if (uncertainlyBig != null) {
					doubleUncertainty = uncertainlyBig.doubleValue();
				}
				BigDecimal bigUncertainty = BigDecimal.valueOf(doubleUncertainty);
				BigDecimal bigDecimal = BigDecimal.valueOf(valueReference);
				BigDecimal bigDecimalAdd = bigDecimal.add(bigUncertainty);
				BigDecimal bigDecimalSoustract = bigDecimal.subtract(uncertainlyBig);
			
				double doubleAdd = bigDecimalAdd.doubleValue();
				double doubleSubstrat= bigDecimalSoustract.doubleValue();
				double doubleAddTrunc = BigDecimal.valueOf(doubleAdd).setScale(precision, BigDecimal.ROUND_HALF_UP).doubleValue();
				double doubleSubstractTrunc = BigDecimal.valueOf(doubleSubstrat).setScale(precision, BigDecimal.ROUND_HALF_UP).doubleValue();

				if ((doublAssemblyue >= doubleSubstractTrunc) && (doublAssemblyue <= doubleAddTrunc)) {
					isValid = true;
				}
			} else {
				isValid = (doublAssemblyue == valueReference);
			}
			return isValid;
		} catch (NumberFormatException e) {
			throw new ClientAssemblyException(ClientAssemblyException.EXCEPTION_VALUE_BAD_FORMAT);
		}
	}

	/**
	 * Compute a dataValue (a dataValue can contain operator with different
	 * references : record, contract, display, ...)
	 * 
	 * @param dataValue
	 *            value to compute
	 * @return value computed
	 * @throws ClientInterruption 
	 */
	public String computeDataValue(DataValue dataValue) throws ClientAssemblyException, ClientInterruption {
		String value = null;
		DataValueChoice dataValueChoice = dataValue.getDataValueChoice();
		BigDecimal val = dataValueChoice.getVal();
		InputRef inputRef = dataValueChoice.getInputRef();
		if (val != null) {
			value = String.valueOf(val);
		} else if (inputRef != null) {
			TaskAction taskAction = (TaskAction) inputRef.getRefId();
			InputValue inputValue = taskAction.getInputAction().getInputValue();
			if (inputValue != null) {
				value = inputValue.getValue();
			}
			
			if (value == null) {
				throw new ClientInterruption(ClientInterruption.INTERRUPTION_REFERENCE_NO_VALUE);
			}
		}
		return value;
	}
}
