package turbomeca.gamme.assembly.client.model.edit.runnable;

import java.util.Enumeration;

import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperTaskService;
import turbomeca.gamme.assembly.services.model.data.QuantityPn;
import turbomeca.gamme.assembly.services.model.data.TaskChoiceItem;
import turbomeca.gamme.assembly.services.model.data.TaskMark;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public class ModelRunnableTaskService extends ModelRunnableStatusDefaultService {

	public ModelRunnableTaskService(IModelObjectService modelService) {
		super(modelService);
	}

	@Override
	public ModelWrapperTaskService getWrapperService() {
		return (ModelWrapperTaskService) super.getWrapperService();
	}


	@Override
	public boolean isRunnable() {
		boolean isRunnable = false;
		if(getWrapperService() != null && getWrapperService().getTask() != null 
				&& getWrapperService().getTask().getTaskChoice() != null){
			Enumeration<? extends TaskChoiceItem> enumChoice = getWrapperService().getTask().getTaskChoice().enumerateTaskChoiceItem();
			while(enumChoice.hasMoreElements()) {
				TaskChoiceItem taskChoiceItem = enumChoice.nextElement();
				if (   taskChoiceItem.getTaskActionMeasure() != null
						|| taskChoiceItem.getTaskPiloting() != null
						|| taskChoiceItem.getTaskAction() != null
						|| taskChoiceItem.getTaskActionTable() != null
						|| hasTaskMarkRunnable(taskChoiceItem)) {
					isRunnable = true;
					break;
				}
			}
		}
		return super.isRunnable() && isRunnable;
	}

	/**
	 * Check if the taskchoiceItem has taskMark with quantity or taskAction to be runnable
	 * @param taskChoiceItem
	 * @return
	 */
	private boolean hasTaskMarkRunnable(TaskChoiceItem taskChoiceItem){
		boolean isRunnable = false;
		TaskMark taskMark = taskChoiceItem.getTaskMark();
		if(taskMark != null){
			QuantityPn[] listquantityPn = taskMark.getQuantityPn();
			if(listquantityPn != null && listquantityPn.length > 0){
				isRunnable = true;
			}
			if(!isRunnable){
				isRunnable = taskMark.getTaskAction() != null;
			}
		}
		return isRunnable;
	}
}
