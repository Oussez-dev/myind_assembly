package turbomeca.gamme.assembly.client.model.edit.wrappers;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import turbomeca.gamme.assembly.client.ClientAssemblyException;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.services.model.data.Operation;
import turbomeca.gamme.assembly.services.model.data.Qualifications;
import turbomeca.gamme.assembly.services.model.data.State;
import turbomeca.gamme.assembly.services.model.data.SubPhase;
import turbomeca.gamme.assembly.services.model.data.SubPhasesItem;
import turbomeca.gamme.ecran.client.model.edit.wrappers.IModelWrapperOperationService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public class ModelWrapperOperationService extends AModelWrapperAssemblyService implements IModelWrapperOperationService {

	/** CASTOR operation object */
	private Operation operation;

	/**
	 * Constructor
	 * 
	 * @param scheduleService
	 * @param operation
	 */
	public ModelWrapperOperationService(Operation operation) {
		setOperation(operation);
	}

	@Override
	public Object getObject() {
		return operation;
	}

	/**
	 * @param operation
	 *            the operation to set
	 */
	public void setOperation(Operation operation) {
		this.operation = operation;
	}

	/**
	 * @return the operation
	 */
	public Operation getOperation() {
		return operation;
	}

	@Override
	public Qualifications getExecutionQualifications() {
		return getOperation().getQualifications();
	}

	@Override
	public Qualifications getValidationQualifications() {
		return getOperation().getQualifications();
	}

	@Override
	public State getState() {
		return getOperation().getState();
	}
	
	@Override
	public Integer getPassingId() {
		return 1;
	}

	@Override
	public String getId() {
		return getOperation().getId();
	}
	
	@Override
	public void setDisplayId (int index) {
		getOperation().setDisplayId(String.valueOf(index));
	}
	
	@Override
	public void setId(String id) {
		getOperation().setId(id);
	}
	
	@Override
	public List<String> getPredecessors() {
	    List<String> listId = new ArrayList<String>();
	    for(Object operationObject : getOperation().getPredecessors()) {
	        listId.add(((Operation) operationObject).getId());
	    }
	    return listId;
	}
	
	@Override
    public boolean isForcePredecessorsValid() {
        return getOperation().isForcePredecessorsValid();
    }
	
	@Override
	public void addChild(IModelObjectService nextChild, IModelObjectService newChild) throws ClientAssemblyException {
		if (newChild instanceof ModelSubPhaseService) {
			Vector<SubPhasesItem> subPhasesItem = new Vector<SubPhasesItem>();
			for (SubPhasesItem subPhaseItem : getOperation().getSubPhases().getSubPhasesItem()) {
			    if (subPhaseItem.getSubPhase() != null) {
			        SubPhase subPhase = subPhaseItem.getSubPhase();
    				if (subPhase.getId().equals(nextChild.getWrapperService().getId())) {
    				    SubPhasesItem subPhaseItemNew = new SubPhasesItem();
    				    subPhaseItemNew.setSubPhase((SubPhase) newChild.getWrapperService().getObject());
    				    subPhasesItem.add(subPhaseItemNew);
    				}
			    }
			    subPhasesItem.add(subPhaseItem);
			}
			getOperation().getSubPhases().setSubPhasesItem(subPhasesItem);
		}
		else {
			throw new ClientAssemblyException(ClientAssemblyException.EXCEPTION_INTERNAL);
		}
	}

	@Override
	public void setForcePredecessorsValid(boolean valid) {
		getOperation().setForcePredecessorsValid(valid);
	}

	@Override
	public void setUnlockComment(String comment) {
		getOperation().setUnlockComment(comment);
	}

	@Override
	public boolean isReworkActivation() {
		return getOperation().isReworkActivation();
	}

	@Override
	public boolean isRework() {
		return getOperation().isRework();
	}
	
	public boolean isLastOperationClosed() {
		return getOperation().isLastOperationClosed();
	}
	
	public void setLastOperationClosed(boolean lastOperationClosed) {
		getOperation().setLastOperationClosed(lastOperationClosed);
	}
	
	@Override
	public void setForceConditionsValid(boolean valid) {
		//do nothing on assembly
	}
	
	@Override
	public void setValidConditionComment(String comment) {
		//do nothing on assembly
	}

	@Override
	public int getNumber() {
		return getOperation().getNumber();
	}
	
}
