package turbomeca.gamme.assembly.client.model.edit.loader;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelDerogationMarksService;
import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperDerogationMarksService;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.interfaces.IModelLoaderService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.model.provider.ModelXmlProvider;

public class ModelLoaderDerogationMarksService extends AModelAssemblyLoader implements IModelLoaderService {

	
    public ModelLoaderDerogationMarksService(IModelObjectService modelService) {
        super(modelService);
    }

    @Override
    public ModelWrapperDerogationMarksService getWrapperService() {
        return (ModelWrapperDerogationMarksService) super.getWrapperService();
    }

    @Override
    public ModelDerogationMarksService getModelService() {
        return (ModelDerogationMarksService) super.getModelService();
    }

    public void load(ModelXmlProvider modelProvider) throws ClientException {
        if (modelProvider != null) {
			modelProvider.addModelService(ModelWrapperDerogationMarksService.DEROGATION_ID, getModelService());
        }
    }

    @Override
    public void link() throws ClientException, ClientInterruption {
    
    }
}
