package turbomeca.gamme.assembly.client.model.edit.status;

import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.edit.instructions.IModelSubPhaseGroupService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public class ModelStatusSubPhaseGroupService extends ModelStatusService {

	public ModelStatusSubPhaseGroupService(IModelObjectService modelService) {
		super(modelService);
	}

	@Override
	public boolean isAlterable() throws ClientException {
		return true;
	}
	
	@Override
	public void computeStatus(boolean recursively) throws ClientException, ClientInterruption {
		boolean hasNoneSignature = ((IModelSubPhaseGroupService) getModelService()).hasNoneSignature();
		if(!hasNoneSignature) {
			super.computeStatus(recursively);
		}
	}
}
