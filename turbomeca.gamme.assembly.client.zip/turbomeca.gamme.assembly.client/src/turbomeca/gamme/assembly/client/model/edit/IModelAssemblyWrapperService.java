package turbomeca.gamme.assembly.client.model.edit;

import java.util.List;

import turbomeca.gamme.assembly.services.model.data.Conditions;
import turbomeca.gamme.assembly.services.model.data.Identification;
import turbomeca.gamme.assembly.services.model.data.Instanciation;
import turbomeca.gamme.assembly.services.model.data.Qualifications;
import turbomeca.gamme.assembly.services.model.data.References;
import turbomeca.gamme.assembly.services.model.data.State;
import turbomeca.gamme.ecran.client.model.interfaces.IModelWrapperService;

public interface IModelAssemblyWrapperService extends IModelWrapperService {

	public Qualifications getExecutionQualifications();

	public Qualifications getValidationQualifications();

	public Conditions getConditions();

	public References getReferences();

	public State getState();
	
	public Instanciation getInstantiation();
	
	public Identification getIdentification();
	
	public boolean isAlternative();

    public List<String> getPredecessors();

    public boolean isForcePredecessorsValid();
}
