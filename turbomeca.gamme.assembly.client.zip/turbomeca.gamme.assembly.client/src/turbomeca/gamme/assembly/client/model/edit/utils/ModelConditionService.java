package turbomeca.gamme.assembly.client.model.edit.utils;

import java.util.Enumeration;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskService;
import turbomeca.gamme.assembly.services.model.data.ConditionInput;
import turbomeca.gamme.assembly.services.model.data.ConditionTask;
import turbomeca.gamme.assembly.services.model.data.Conditions;
import turbomeca.gamme.assembly.services.model.data.ConditionsItem;
import turbomeca.gamme.assembly.services.model.data.InputValue;
import turbomeca.gamme.assembly.services.model.data.Task;
import turbomeca.gamme.assembly.services.model.data.TaskAction;
import turbomeca.gamme.assembly.services.model.data.types.ComparatorType;
import turbomeca.gamme.assembly.services.model.data.types.StatusType;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.model.provider.ModelXmlProvider;

/**
 * Class manages conditions
 * 
 * @author Sopra Group
 * 
 */
public class ModelConditionService {

	/** logger for current class */
	private static Logger logger = Logger.getLogger(ModelConditionService.class);
	
	
	/**
	 * Check if conditions are valid
	 * 
	 * @param conditions
	 *            : list of conditions
	 * 
	 * @return true : all conditions are valid false : at least one condition is
	 *         invalid
	 */
	public boolean isConditionsValid(Conditions conditions, String instanceId) {
		boolean isConditionsValid = true;
		try {
			if (conditions != null) {
				Enumeration<?> enumConditions = conditions.enumerateConditionsItem();
				while (enumConditions.hasMoreElements()) {
					ConditionsItem condition = (ConditionsItem) enumConditions.nextElement();
					isConditionsValid &= isConditionValid(condition, instanceId);
				}
			}
		} catch (Exception e) {
			logger.error("Error during conditions computation", e);
			isConditionsValid = false;
		}
		return isConditionsValid;
	}

	/**
	 * Check if a condition is valid
	 * 
	 * @param condition
	 *            : condition to check
	 * 
	 * @return true : condition is valid false : condition is invalid
	 * @throws ClientException
	 */
	private boolean isConditionValid(ConditionsItem condition, String instanceId)
			throws ClientException {
		boolean isConditionValid = true;
		if (condition == null) {
			return isConditionValid;
		}
		Object conditionObject = condition.getChoiceValue();
		if (conditionObject instanceof ConditionInput) {
			isConditionValid = isConditionValid((ConditionInput) conditionObject, instanceId);
		} else if (conditionObject instanceof ConditionTask) {
			isConditionValid = isConditionValid((ConditionTask) conditionObject, instanceId);
		}
		return isConditionValid;
	}

	/**
	 * Check if an task condition is valid
	 * 
	 * @param condition
	 *            : task condition
	 * @return true : condition is valid false : condition is invalid
	 * @throws ClientException
	 */
	static boolean isConditionValid(ConditionTask condition, String instanceId)
			throws ClientException {
		boolean isConditionValid = false;
		Object taskObject = condition.getRefId();
		if (taskObject instanceof Task) {
			Task task = (Task) taskObject;
			ModelTaskService taskService = (ModelTaskService) ModelXmlProvider.getInstance().getModelService(task.getId());
			StatusType statusTask = taskService.getWrapperService().getState().getStatus();
			
			if (instanceId != null) {
				statusTask = taskService.getStatus(instanceId);
			}

			switch (condition.getStatus()) {
			case OK:
				switch (statusTask) {
				case OK:
				case PARTIAL:
					isConditionValid = true;
				}
				break;
			case KO:
				switch (statusTask) {
				case KO:
				case PARTIAL:
					isConditionValid = true;
				}
				break;
			default:
				logger.error("Status not manage in task condition");
				break;
			}
		}
		return isConditionValid;
	}

	/**
	 * Check if an record condition is valid
	 * 
	 * @param condition
	 *            : record condition
	 * @return true : condition is valid false : condition is invalid
	 */
	private boolean isConditionValid(ConditionInput condition, String instanceId) {
		boolean isConditionValid = false;
		Object taskActionObject = condition.getRefId();
		if (taskActionObject instanceof TaskAction) {
			InputValue inputValue = ((TaskAction) taskActionObject).getInputAction().getInputValue();
			if (inputValue != null) {
				isConditionValid = isValueValid(condition.getValue(), inputValue.getValue(),
						condition.getComparator());
			}
		}
		return isConditionValid;
	}

	/**
	 * Check if a value is valid with the expected value
	 * 
	 * @param valueRef
	 *            : value expected
	 * @param value
	 *            : current value
	 * @param operateurType
	 *            : operator
	 * 
	 * @return true : value is valid false : value is invalid
	 */
	private boolean isValueValid(String valueRef, String value, ComparatorType comparatorType) {
		boolean isValueValid = false;
		if (value != null) {
			Double doubleValue = null;
			Double doubleValueRef = null;
			try {
				doubleValue = Double.valueOf(value);
				doubleValueRef = Double.valueOf(valueRef);
			} catch (NumberFormatException e) {
				logger.info("Error : Conversion values [ " + value + " ; " + valueRef + " ] to double failed");
				doubleValue = null;
				doubleValueRef = null;
			}
			if (doubleValue != null && doubleValueRef != null) {
				isValueValid = isValueCorrect(doubleValue.doubleValue(), doubleValueRef
						.doubleValue(), comparatorType);
			} else {
				double result = value.compareTo(valueRef);
				isValueValid = isValueCorrect(result, 0, comparatorType);
			}
		}
		return isValueValid;
	}

	/**
	 * 
	 * @param value
	 * @param valueRef
	 * @param comparatorType
	 * @return
	 */
	public boolean isValueCorrect(double value, double valueRef, ComparatorType comparatorType) {
		boolean isValueValid = false;
		switch (comparatorType) {
		case EQUAL:
			isValueValid = (value == valueRef);
			break;
		case INFLARGE:
			isValueValid = (value <= valueRef);
			break;
		case INFSTRICT:
			isValueValid = (value < valueRef);
			break;
		case SUPLARGE:
			isValueValid = (value >= valueRef);
			break;
		case SUPSTRICT:
			isValueValid = (value > valueRef);
			break;
		case DIFFERENT:
			isValueValid = (value != valueRef);
			break;
		}
		return isValueValid;
	}
}
