package turbomeca.gamme.assembly.client.model.edit.wrappers;

import turbomeca.gamme.assembly.services.model.data.Tools;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public class ModelWrapperToolsService extends AModelWrapperAssemblyService {

	/** */
	private Tools tools;

	/**
	 * Constructor for task object
	 * 
	 * @param subPhaseService
	 *            parent service
	 * @param task
	 *            task object
	 */
	public ModelWrapperToolsService(Tools tools) {
		setTools(tools);
	}


	@Override
	public Object getObject() {
		return tools;
	}

	/**
	 * @return the tools
	 */
	public Tools getTools() {
		return tools;
	}

	/**
	 * @param tools
	 *            the tools to set
	 */
	public void setTools(Tools tools) {
		this.tools = tools;
	}


	@Override
	public String getId() {
		return null;
	}


	@Override
	public void setId(String id) {
	}


	@Override
	public void addChild(IModelObjectService nextChild, IModelObjectService newChild)
			throws ClientException {
	}

	@Override
	public boolean isApplicable() {
		return true;
	}

	@Override
	public void setApplicable(boolean applicable) {
	}
}
