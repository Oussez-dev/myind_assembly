package turbomeca.gamme.assembly.client.model.edit.status;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.client.model.edit.notifications.AModelNotificationService;
import turbomeca.gamme.assembly.client.model.edit.notifications.ModelNotificationsService;
import turbomeca.gamme.assembly.client.model.edit.provider.ModelNotificationProvider;
import turbomeca.gamme.assembly.client.model.edit.utils.ModelUtils;
import turbomeca.gamme.assembly.services.model.data.ElectronicNotification;
import turbomeca.gamme.assembly.services.model.data.ElectronicNotifications;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.context.ContextRequest;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public class ModelStatusNotificationsService extends ModelStatusNoneService {

    /** logger for current class */
    private static Logger logger = Logger.getLogger(ModelStatusNotificationsService.class);
    
    public ModelStatusNotificationsService(IModelObjectService modelService) {
        super(modelService);
    }
    
    @Override
    public void computeStatus(boolean recursively) throws ClientException {
    	super.computeStatus(recursively);
    	// Update can validate on suphase by checkin notifications status
        ModelSubPhaseService subPhaseService = getModelService().getSubPhase();
        subPhaseService.getWrapperService().getSubPhase().setValidable(subPhaseService.getRunnableService().canValidate());
    }

    @Override
    public ModelNotificationsService getModelService() {
        return (ModelNotificationsService) super.getModelService();
    }
    
    @Override
    public boolean isInProgress() throws ClientException {
        ElectronicNotifications electNotifications = getModelService().getWrapperService().getElectronicNotifications();
        return (electNotifications != null && electNotifications.getElectronicNotificationCount() != 0);
    }
    
    @Override
    public void clean(List<String> instancesId) throws ClientException, ClientInterruption {
        logger.debug("clean (" + instancesId + ") : " + getModelService());
        
        List<AModelNotificationService> notificationToRemove = new ArrayList<AModelNotificationService>();
        for(IModelObjectService childService : getModelService().getChildren()) {
            AModelNotificationService notificationService = (AModelNotificationService) childService;
            ElectronicNotification electronicNotification = notificationService.getElectronicNotification();
            
            if (electronicNotification.isActive()) {
                boolean cleanNotif = getRequestContext().getRequestType() != ContextRequest.STARTUP_CLEAR  
                || notificationService.isCleanable();
                if (cleanNotif) {
                    if (cleanNotification(notificationService)) {
                        notificationToRemove.add(notificationService);
                    }
                }
            }
        }
    
        for(AModelNotificationService notif : notificationToRemove) {
            ((ModelNotificationsService) notif.getParent()).removeInactiveNotifications();
        }
    }
    
    protected boolean cleanNotification(AModelNotificationService notificationService) throws ClientException, ClientInterruption {
        logger.debug("cleanNotification : " + notificationService);
        
        boolean removeNotification = false;
        ElectronicNotification electronicNotification = notificationService.getElectronicNotification();
        List<AModelNotificationService> notifications = getModelNotificationProvider().getNotifications(notificationService.getIdentifier());
        
        electronicNotification.setActive(false);
        if (electronicNotification.getRefId() != null) {
            IModelObjectService referenceService = ModelUtils.getModelServiceReferenced(getModelProvider(), electronicNotification.getRefId());
            referenceService.getStatusService().clean(null);
        }
        
        if (notifications != null) {
            if (notifications.size() == 1) {
                ModelNotificationProvider.getInstance().addNotificationServiceToErase(notificationService);
            } else if (getRequestContext().getRequestType() == ContextRequest.NEW_PASSING){
                for(AModelNotificationService noticationReference : notifications) {
                    ElectronicNotification notif = noticationReference.getElectronicNotification();
                    notif.setActive(false);
                    if (notif.getRefId() != null) {
                        IModelObjectService referenceService = ModelUtils.getModelServiceReferenced(getModelProvider(), notif.getRefId());
                        referenceService.getStatusService().clean(null);
                    }
                }
                
                // Add notification to list for remove
                ModelNotificationProvider.getInstance().addNotificationServiceToErase(notificationService);
            } else if (getRequestContext().getRequestType() == ContextRequest.ACTIVITY_UPDATE){
                removeNotification = true;
            }
        }
        return removeNotification;
    }
    
    private ModelNotificationProvider getModelNotificationProvider() {
        return ModelNotificationProvider.getInstance();
    }
}
