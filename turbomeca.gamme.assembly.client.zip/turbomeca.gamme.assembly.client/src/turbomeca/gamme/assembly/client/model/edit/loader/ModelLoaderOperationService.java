package turbomeca.gamme.assembly.client.model.edit.loader;

import java.util.Enumeration;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.model.edit.AModelAssemblyService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelOperationService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseGroupService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperOperationService;
import turbomeca.gamme.assembly.services.model.data.SubPhasesItem;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.interfaces.IModelLoaderService;
import turbomeca.gamme.ecran.client.model.provider.ModelXmlProvider;
import turbomeca.gamme.ecran.client.tuning.utils.TuningUtils;

public class ModelLoaderOperationService extends AModelAssemblyLoader implements
		IModelLoaderService {
	
    private static Logger logger = Logger.getLogger(ModelLoaderOperationService.class);


	/**
	 * Constructor
	 * 
	 * @param scheduleService
	 * @param operation
	 */
	public ModelLoaderOperationService(AModelAssemblyService operationService) {
		super(operationService);
	}

	@Override
	public ModelWrapperOperationService getWrapperService() {
		return (ModelWrapperOperationService) super.getWrapperService();
	}
	
	@Override
    public ModelOperationService getModelService() {
        return (ModelOperationService) super.getModelService();
    }

	@Override
	public void load(ModelXmlProvider modelProvider) throws ClientException, ClientInterruption {
		Enumeration<? extends SubPhasesItem> enumSubPhaseItem = getWrapperService().getOperation().getSubPhases().enumerateSubPhasesItem();
		int indexDisplay = 0;
		String previousSubPhaseId = "";
		while (enumSubPhaseItem.hasMoreElements()) {
            boolean isApplicable = false;
            String currentSubPhaseId = "";
		    SubPhasesItem subPhaseItem = enumSubPhaseItem.nextElement();
		    if (subPhaseItem.getSubPhase() != null) {
    			ModelSubPhaseService subPhaseService = new ModelSubPhaseService(getModelService(), subPhaseItem.getSubPhase());
    			subPhaseService.getLoaderService().load(modelProvider);
    			getModelService().addChild(subPhaseService);
    			isApplicable = subPhaseItem.getSubPhase().isApplicable();
    			currentSubPhaseId = subPhaseItem.getSubPhase().getId();
    		    if (isApplicable && isNotNewPassingOfPreviousSubPhase(previousSubPhaseId, currentSubPhaseId )) {
                    indexDisplay++ ;
                }
    			logger.debug("setDisplayId = " + indexDisplay + " for subPhase " + currentSubPhaseId);
    			subPhaseService.getWrapperService().setDisplayId(indexDisplay);
                
		    }
		    else if (subPhaseItem.getSubPhaseGroup() != null) {
		        ModelSubPhaseGroupService subPhaseGroupService = new ModelSubPhaseGroupService(getModelService(), subPhaseItem.getSubPhaseGroup());
		        subPhaseGroupService.getLoaderService().load(modelProvider);
                getModelService().addChild(subPhaseGroupService);
                isApplicable = subPhaseItem.getSubPhaseGroup().isApplicable();
                currentSubPhaseId = subPhaseItem.getSubPhaseGroup().getId();
                if (isApplicable && isNotNewPassingOfPreviousSubPhase(previousSubPhaseId, currentSubPhaseId )) {
                    indexDisplay++ ;
                }    
                logger.debug("setDisplayId = " + indexDisplay + " for subPhaseGroup " + currentSubPhaseId);
                subPhaseGroupService.getWrapperService().setDisplayId(indexDisplay);     
		    }
		    
		    previousSubPhaseId = currentSubPhaseId;
		}	
		
		if (modelProvider != null) {
			modelProvider.addModelService(getModelService().getIdentifier(), getModelService());
		}
	}

	private boolean isNotNewPassingOfPreviousSubPhase(String previousSubPhaseId, String currentSubPhaseId) {
		return !TuningUtils.getUnarchivedId(currentSubPhaseId).equals(TuningUtils.getUnarchivedId(previousSubPhaseId));
	}
}
