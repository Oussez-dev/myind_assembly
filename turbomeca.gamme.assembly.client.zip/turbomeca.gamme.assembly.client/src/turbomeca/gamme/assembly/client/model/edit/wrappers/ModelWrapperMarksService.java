package turbomeca.gamme.assembly.client.model.edit.wrappers;

import turbomeca.gamme.assembly.services.model.data.Marks;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public class ModelWrapperMarksService extends AModelWrapperAssemblyService {

	/** */
	private Marks marks;

	/**
	 * Constructor for task object
	 * 
	 * @param subPhaseService
	 *            parent service
	 * @param task
	 *            task object
	 */
	public ModelWrapperMarksService(Marks marks) {
		setMarks(marks);
	}


	@Override
	public Object getObject() {
		return marks;
	}

	/**
	 * @return the tools
	 */
	public Marks getMarks() {
		return marks;
	}

	/**
	 * @param tools
	 *            the tools to set
	 */
	public void setMarks(Marks marks) {
		this.marks = marks;
	}


	@Override
	public String getId() {
		return null;
	}


	@Override
	public void setId(String id) {
	}


	@Override
	public void addChild(IModelObjectService nextChild, IModelObjectService newChild)
			throws ClientException {
	}

	@Override
	public boolean isApplicable() {
		return true;
	}

	@Override
	public void setApplicable(boolean applicable) {
	}
}
