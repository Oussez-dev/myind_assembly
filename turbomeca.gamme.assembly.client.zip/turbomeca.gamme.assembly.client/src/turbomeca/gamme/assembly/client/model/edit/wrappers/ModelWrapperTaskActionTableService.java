package turbomeca.gamme.assembly.client.model.edit.wrappers;

import turbomeca.gamme.assembly.services.model.data.Entry;
import turbomeca.gamme.assembly.services.model.data.InputValue;
import turbomeca.gamme.assembly.services.model.data.Row;
import turbomeca.gamme.assembly.services.model.data.TaskAction;
import turbomeca.gamme.assembly.services.model.data.TaskActionTable;
import turbomeca.gamme.assembly.services.model.data.Test;

/**
 * TaskActionTable wrapper service for assembly.
 * 
 * @author ademartin
 *
 */
public class ModelWrapperTaskActionTableService extends AModelWrapperAssemblyService{

	/** TaskActionTable object */
	private TaskActionTable taskActionTable;
	
	public ModelWrapperTaskActionTableService(TaskActionTable taskActionTable) {
		this.taskActionTable = taskActionTable;
	}
	
	/**
	 * @return the taskActionTable
	 */
	public TaskActionTable getTaskActionTable() {
		return taskActionTable;
	}
	
	@Override
	public Object getObject() {
		return taskActionTable;
	}

	@Override
	public String getId() {
		return taskActionTable.getId();
	}

	@Override
	public void setId(String id) {
		taskActionTable.setId(id);
	}
	
	/**
	 * Reads the taskActionTable cell at row and column coordinate and returns
	 * the <b>FIRST</b> taskAction inputValue found.
	 * 
	 * @param row
	 *            the selected row
	 * @param col
	 *            the selected column
	 * @return the cell first taskAction inputValue
	 */
	public String getCellFirstValue(int row, int col) {
		// Bad row coordinate
		if(taskActionTable.getTgroup()[0].getTbody().getRow().length < row) {
			return null;
		}
		
		Row rowObject = taskActionTable.getTgroup()[0].getTbody().getRow()[row];
		
		// Bad column coordinate
		if(rowObject.getEntry().length < col) {
			return null;
		}
		
		Entry entryObject = rowObject.getEntry()[col];
		
		// No taskAction
		if(entryObject.getTaskAction() == null || entryObject.getTaskAction().length == 0) {
			return null;
		}
		
		TaskAction taskAction = entryObject.getTaskAction()[0];
		InputValue inputValue = taskAction.getInputAction().getInputValue();
		
		if (inputValue == null) {
			return null;
		}
		
		return inputValue.getValue();
	}

	/**
	 * Reads the taskActionTable cell at row and column coordinate and returns
	 * the <b>FIRST</b> test found.
	 * 
	 * @param row
	 *            the selected row
	 * @param col
	 *            the selected column
	 * @return the cell first test found
	 */
	public Test getCellFirstTest(int row, int col) {
		// Bad row coordinate
		if (taskActionTable.getTgroup()[0].getTbody().getRow().length < row) {
			return null;
		}
		
		Row rowObject = taskActionTable.getTgroup()[0].getTbody().getRow()[row];

		// Bad column coordinate
		if (rowObject.getEntry().length < col) {
			return null;
		}

		Entry entryObject = rowObject.getEntry()[col];

		// No test
		if(entryObject.getTest() == null) {
			return null;
		}
		
		return entryObject.getTest();
	}
	
	/**
	 * Returns the length of the table row at the specified index.
	 * 
	 * If the row is not found, it returns -1.
	 * 
	 * @param row
	 * @return the specified row length, or -1 if row not found
	 */
	public int getRowLength(int row) {
		// Bad row coordinate
		if (taskActionTable.getTgroup()[0].getTbody().getRow().length < row) {
			return -1;
		}

		Row rowObject = taskActionTable.getTgroup()[0].getTbody().getRow()[row];

		return rowObject.getEntryCount();
	}
}
