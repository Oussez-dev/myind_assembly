package turbomeca.gamme.assembly.client.model.edit.wrappers;


public interface IModelInstanceIdWrapper {
    
    /**
     * 
     * @return
     */
    public int getInstanceId();
    
    /**
     * 
     * @return
     */
    public boolean hasInstanceId();
}
