package turbomeca.gamme.assembly.client.model.edit.wrappers;

import java.util.UUID;

import turbomeca.gamme.assembly.client.model.edit.IModelAssemblyWrapperScheduleService;
import turbomeca.gamme.assembly.client.model.edit.utils.ModelUtils;
import turbomeca.gamme.assembly.services.model.data.Historical;
import turbomeca.gamme.assembly.services.model.data.HistoricalPassing;
import turbomeca.gamme.assembly.services.model.data.Issue;
import turbomeca.gamme.assembly.services.model.data.IssueModification;
import turbomeca.gamme.assembly.services.model.data.ModifDescript;
import turbomeca.gamme.assembly.services.model.data.ModifDescriptItem;
import turbomeca.gamme.assembly.services.model.data.ObjectToSynchronize;
import turbomeca.gamme.assembly.services.model.data.ObjectsToSynchronize;
import turbomeca.gamme.assembly.services.model.data.Passing;
import turbomeca.gamme.assembly.services.model.data.UserMark;
import turbomeca.gamme.ecran.client.model.edit.wrappers.IModelWrapperScheduleService;

public abstract class AModelWrapperAssemblyScheduleService extends AModelWrapperAssemblyService implements
IModelWrapperScheduleService, IModelAssemblyWrapperScheduleService {


	@Override
	public void updateHistoricalPassing(Integer passingId, String comment) {
		boolean passingExisting = false;
		UserMark userMark = ModelUtils.buildUserMark();
		HistoricalPassing historicalPassingUpdated = (HistoricalPassing) getHistoricalPassing();
		Passing passing = new Passing();
		if(historicalPassingUpdated == null) {
			historicalPassingUpdated = new HistoricalPassing();
		} else {
			for(Passing currentPassing : historicalPassingUpdated.getPassing()) {
				if(currentPassing.getNumber().equals(String.valueOf(passingId))) {
					passing = currentPassing;
					passingExisting = true;
				}
			}
		}
		
		if(comment == null || comment.isEmpty()){
			comment = " ";
		} else {
			passing.setUserMark(userMark);
		}
		passing.setComment(comment);
		passing.setId(UUID.randomUUID().toString());
		passing.setNumber(String.valueOf(passingId));
		if(!passingExisting) {
			historicalPassingUpdated.addPassing(passing);
		}
		setHistoricalPassing(historicalPassingUpdated);
	}

	/**
	 * Init HistoricalPassing if not exist
	 */
	@Override
	public boolean loadHistoricalPassing() {
		boolean hasChanged = false;
		HistoricalPassing historicalPassing = (HistoricalPassing) getHistoricalPassing();
		if(historicalPassing == null) {
			historicalPassing = new HistoricalPassing();
			Passing newPassing = new Passing();
			newPassing.setComment(" ");
			newPassing.setId(UUID.randomUUID().toString());
			newPassing.setNumber("1");
			UserMark userMark = ModelUtils.buildUserMark();
			newPassing.setUserMark(userMark);
			historicalPassing.addPassing(newPassing);
			setHistoricalPassing(historicalPassing);
			hasChanged = true;
		}
		return hasChanged;
	}
	
	@Override
	public void updateObjectsToSynchronize(String idObjectToSynchronize,
			String synchronizeAction, String objectType) {
		ObjectsToSynchronize objectsToSynchronize = getObjectsToSynchronize();
		if(objectsToSynchronize == null) {
			objectsToSynchronize = new ObjectsToSynchronize();
		}
		ObjectToSynchronize objectToSynchronize = new ObjectToSynchronize();
		objectToSynchronize.setRefId(idObjectToSynchronize);
		objectToSynchronize.setSynchronize(synchronizeAction);
		objectToSynchronize.setObjectType(objectType);
		ObjectToSynchronize objectWithSameId = getObjectToSynchronizeWithId(idObjectToSynchronize);
		if(objectWithSameId != null){
			objectsToSynchronize.removeObjectToSynchronize(objectWithSameId);
		}
		objectsToSynchronize.addObjectToSynchronize(objectToSynchronize);
		setObjectsToSynchronize(objectsToSynchronize);
	}

	private ObjectToSynchronize getObjectToSynchronizeWithId(String id) {
		ObjectToSynchronize objectWithSameId = null;
		if(getObjectsToSynchronize() != null){
			for(ObjectToSynchronize objectToSynchronize : getObjectsToSynchronize().getObjectToSynchronize()) {
				if(objectToSynchronize.getRefId().equals(id)) {
					objectWithSameId = objectToSynchronize;
					break;
				}
			}
		}
		return objectWithSameId;
	}
	
	@Override
	public boolean hasDifferences() {
		Historical historical = getHistorical();
		
		if(historical == null) {
			return false;
		}
		
		Issue[] issues = historical.getIssue();
		
		if(issues == null || issues.length == 0) {
			return false;
		}
		
		for(Issue issue : issues) {
			IssueModification[] issueModifs = issue.getIssueModification();
			
			if(issueModifs == null || issueModifs.length == 0) {
				continue;
			}
			
			for(IssueModification issueModif : issueModifs) {
				ModifDescript[] modifDescripts = issueModif.getModifDescript();
				
				if(modifDescripts == null || modifDescripts.length == 0) {
					continue;
				}
				
				for(ModifDescript modifDescript : modifDescripts) {
					ModifDescriptItem[] modifDescriptItems = modifDescript.getModifDescriptItem();
					
					if(modifDescriptItems == null || modifDescriptItems.length == 0) {
						continue;
					}
					
					for(ModifDescriptItem modifDescriptItem : modifDescriptItems) {
						// Has at least one para to show
						if(modifDescriptItem.getPara() != null && modifDescriptItem.getPara().length > 0) {
							return true;
						}
					}
				}
			}
		}
		
		return false;
	}
	
}
