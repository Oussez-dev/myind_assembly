package turbomeca.gamme.assembly.client.model.edit.instructions;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.ClientAssemblyControllersProvider;
import turbomeca.gamme.assembly.client.model.edit.AModelAssemblyService;
import turbomeca.gamme.assembly.client.model.edit.hmi.updater.ModelHmiUpdaterService;
import turbomeca.gamme.assembly.client.model.edit.loader.ModelLoaderMarkService;
import turbomeca.gamme.assembly.client.model.edit.provider.ModelMarkProvider;
import turbomeca.gamme.assembly.client.model.edit.runnable.ModelRunnableStatusNoneService;
import turbomeca.gamme.assembly.client.model.edit.status.ModelStatusMarkService;
import turbomeca.gamme.assembly.client.model.edit.utils.ModelUtils;
import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperAssemblyService;
import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperMarkService;
import turbomeca.gamme.assembly.client.module.intervention.InterventionController;
import turbomeca.gamme.assembly.services.model.data.Dirty;
import turbomeca.gamme.assembly.services.model.data.InputChoice;
import turbomeca.gamme.assembly.services.model.data.InputField;
import turbomeca.gamme.assembly.services.model.data.Mark;
import turbomeca.gamme.assembly.services.model.data.Resources;
import turbomeca.gamme.assembly.services.model.data.SubPhase;
import turbomeca.gamme.assembly.services.model.data.TaskAction;
import turbomeca.gamme.assembly.services.model.data.TaskMark;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.model.provider.ModelXmlProvider;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.services.common.enumtypes.StatusType;

public class ModelMarkService extends AModelAssemblyService {

	private static final Logger logger = Logger.getLogger(ModelMarkService.class);

	public static final String TASK_ACTION_CHECK_TYPE = "mark_check";
	public static final String TASK_ACTION_PN_TYPE = "mark_pn";
	public static final String TASK_ACTION_SN_TYPE = "mark_sn";
	public static final String TASK_ACTION_DEROG_TYPE = "mark_derogation";
	public static final String TASK_ACTION_ADDITIONAL_RECORD_TYPE = "mark_additionalRecord";

	private static final String TOP_START_SUBPHASE_ID = "subphase_marks";
	
	private final int NOTHING_TODO = 0;
	private final int REOPEN = 1;
	private final int TUNE = 2;

	/**
	 * Constructor for task object
	 * 
	 * @param subPhaseService parent service
	 * @param task            task object
	 */
	public ModelMarkService(ModelMarksService marksService, Mark mark) {
		super(marksService.getDomain(), mark.getId());
		setParent(marksService);

		setWrapperService(new ModelWrapperMarkService(mark));
		setLoaderService(new ModelLoaderMarkService(this));
		setHmiUpdaterService(new ModelHmiUpdaterService());
		setStatusService(new ModelStatusMarkService(this));
		setRunnableService(new ModelRunnableStatusNoneService(this));
		getMarkProvider().addMarkService(this);
	}

	@Override
	public ModelWrapperMarkService getWrapperService() {
		return (ModelWrapperMarkService) super.getWrapperService();
	}

	public ModelTaskActionService getTaskActionPn(String instanceId, String alternativeId) {
		return getTaskActionType(TASK_ACTION_PN_TYPE, instanceId, alternativeId, null);
	}

	public ModelTaskActionService getTaskActionSn(String instanceId, String alternativeId, Integer duplicationId) {
		return getTaskActionType(TASK_ACTION_SN_TYPE, instanceId, alternativeId, null);
	}

	public ModelTaskActionService getTaskActionDerogation(String instanceId, String alternativeId,
			Integer duplicationId) {
		return getTaskActionType(TASK_ACTION_DEROG_TYPE, instanceId, alternativeId, duplicationId);
	}

	public List<ModelTaskActionService> getTaskActionsType(String type, String instanceId, String alternativeId) {
		List<ModelTaskActionService> taServices = new ArrayList<ModelTaskActionService>();
		for (IModelObjectService childService : getChildren()) {
			if (type.equals(childService.getType())) {
				ModelTaskActionService childTaskActionService = (ModelTaskActionService) childService;
				if (isTaskActionCompliant(childTaskActionService.getTaskAction(), instanceId, alternativeId, null)) {
					taServices.add((ModelTaskActionService) childService);
					break;
				}
			}
		}
		return taServices;
	}

	public ModelTaskActionService getTaskActionType(String type, String instanceId, String alternativeId,
			Integer duplicationId) {
		ModelTaskActionService taskActionService = null;
		for (IModelObjectService childService : getChildren()) {
			if (type.equals(childService.getType())) {
				ModelTaskActionService childTaskActionService = (ModelTaskActionService) childService;
				if (isTaskActionCompliant(childTaskActionService.getTaskAction(), instanceId, alternativeId,
						duplicationId)) {
					taskActionService = (ModelTaskActionService) childService;
					break;
				}
			}
		}
		return taskActionService;
	}

	private boolean isTaskActionCompliant(TaskAction taskAction, String instanceId, String alternativeId,
			Integer duplicationId) {
		boolean isCompliant = true;
		if (instanceId != null && !instanceId.isEmpty()) {
			isCompliant &= (taskAction.getInstance() == Integer.parseInt(instanceId));
		}

		if (alternativeId != null && !alternativeId.isEmpty()) {
			isCompliant &= (taskAction.getAlternative() == Integer.parseInt(alternativeId));
		}
		if (duplicationId != null && duplicationId >= 1) {
			isCompliant &= (taskAction.getDuplicationIndex() == duplicationId);
		}
		return isCompliant;
	}

	/**
	 * 
	 * @param isDirty
	 * @param comment
	 * @throws ClientException
	 */
	public void setDirty(boolean isDirty, String comment) throws ClientException {
		Mark markObject = getWrapperService().getMark();
		if (isDirty) {
			if (markObject.getDirty() != null) {
				String currentComment = markObject.getDirty().getComment();
				if (currentComment == null || !currentComment.equals(comment)) {
					markObject.getDirty().setUserMark(ModelUtils.buildUserMark());
					markObject.getDirty().setComment(comment);
					setModified();
				}
			} else {
				Dirty dirty = new Dirty();
				dirty.setUserMark(ModelUtils.buildUserMark());
				dirty.setComment(comment);
				markObject.setDirty(dirty);
				setModified();
			}
		} else if (markObject.getDirty() != null) {
			markObject.setDirty(null);
			setModified();
		}

		// Update dirty status of its marks references in task
		for (TaskMark taskMark : getMarkTaskReferences()) {
			setDirty(taskMark, isDirty, comment);
		}
	}

	protected void setDirty(TaskMark taskMark, boolean isDirty, String comment) throws ClientException {
		if (isDirty) {
			if (taskMark.getDirty() != null) {
				String currentComment = taskMark.getDirty().getComment();
				if (currentComment == null || !currentComment.equals(comment)) {
					taskMark.getDirty().setUserMark(ModelUtils.buildUserMark());
					taskMark.getDirty().setComment(comment);
				}
			} else {
				Dirty dirty = new Dirty();
				dirty.setUserMark(ModelUtils.buildUserMark());
				dirty.setComment(comment);
				taskMark.setDirty(dirty);
			}
		} else if (taskMark.getDirty() != null) {
			taskMark.setDirty(null);
		}
	}

	/**
	 * 
	 * @return
	 */
	public List<ModelMarkService> getMarkReferences() {
		return getMarkProvider().getMarks(this);
	}

	/**
	 * 
	 * @return
	 */
	public List<TaskMark> getMarkTaskReferences() {
		return getMarkProvider().getMarkReferences(this);
	}

	/**
	 * 
	 * @return
	 */
	private ModelMarkProvider getMarkProvider() {
		return ModelMarkProvider.getInstance();
	}

	/**
	 * 
	 * @param taskActionService
	 * @throws ClientException
	 * @throws ClientInterruption
	 */
	public void applyValueToReference(IController controller, ModelTaskActionService taskActionService)
			throws ClientException, ClientInterruption {
		applyValueToReference(controller, taskActionService, null);
	}

	/**
	 * 
	 * @param taskActionService
	 * @param newValue
	 * @throws ClientException
	 * @throws ClientInterruption
	 */
	public void applyValueToReference(IController controller, ModelTaskActionService taskActionService, String newValue)
			throws ClientException, ClientInterruption {
		String taskActionType = taskActionService.getType();
		String subPhasesToTune = "";
		String instanceId = null;
		String alternativeId = null;
		TaskAction taskAction = taskActionService.getWrapperService().getTaskAction();
		Integer duplicationId = taskAction.getDuplicationIndex();
		if (taskAction.hasInstance()) {
			instanceId = String.valueOf(taskAction.getInstance());
		} else if (getWrapperService().getMark().hasInstance()) {
			instanceId = String.valueOf(getWrapperService().getMark().getInstance());
		}
		if (taskAction.hasAlternative()) {
			alternativeId = String.valueOf(taskAction.getAlternative());
		}

		List<ModelMarkService> marksLinked = getMarkProvider().getMarks(this);
		for (ModelMarkService markService : marksLinked) {
			boolean isLinkedMarkModified = false;
			ModelSubPhaseService markSubPhaseService = (ModelSubPhaseService) markService
					.getAncestor(ModelSubPhaseService.class);
			ModelTaskActionService modelTaskActionLinked = markService.getTaskActionType(taskActionType, instanceId,
					alternativeId, duplicationId);
			if (modelTaskActionLinked != null) {
				ModelSubPhaseService subPhaseService = modelTaskActionLinked.getSubPhase();

				TaskAction taskActionLinked = modelTaskActionLinked.getTaskAction();
				InputField inputField = taskAction.getInputAction().getInputActionChoice().getInputField();
				InputField inputFieldLinked = taskActionLinked.getInputAction().getInputActionChoice().getInputField();

				// Update simple value
				if (inputField != null && inputFieldLinked != null) {
					if (modelTaskActionLinked.isValueDifferent(taskActionService.getTextValue())) {
						if (!markSubPhaseService.isArchived() && subPhaseService.getRunnableService().isRunnable()) {
							modelTaskActionLinked.setValue(taskActionService.getTextValue(), true);
						}
						int actionOnSubPhase = computeActionToDoOnInpactedSubPhase(controller, markSubPhaseService,
								taskActionType);
						if (actionOnSubPhase == this.REOPEN) {
							modelTaskActionLinked.getStatusService().setAlterable(null);
							isLinkedMarkModified = true;
						}
						if (actionOnSubPhase == this.TUNE) {
							if (!subPhasesToTune.contains(markSubPhaseService.getIdentifier())) {
								subPhasesToTune += markSubPhaseService.getIdentifier() + ";";
							}
						}
					}
				} else {
					// Update choice value
					InputChoice inputChoice = taskAction.getInputAction().getInputActionChoice().getInputChoice();
					InputChoice inputChoiceLinked = taskActionLinked.getInputAction().getInputActionChoice()
							.getInputChoice();
					if (inputChoice != null && inputChoiceLinked != null) {
						if (newValue != null) {
							if (!markSubPhaseService.isArchived()
									&& subPhaseService.getRunnableService().isRunnable()) {
								modelTaskActionLinked.addChoiceValue(newValue, true);
							}
						} else if (modelTaskActionLinked.isValueDifferent(taskActionService.getValue())) {
							if (!markSubPhaseService.isArchived()
									&& subPhaseService.getRunnableService().isRunnable()) {
								modelTaskActionLinked.setValue(taskActionService.getValue(), true);
							}
							int actionOnSubPhase = computeActionToDoOnInpactedSubPhase(controller, markSubPhaseService,
									taskActionType);
							if (actionOnSubPhase == this.REOPEN) {
								modelTaskActionLinked.getStatusService().setAlterable(null);
								isLinkedMarkModified = true;
							}
							if (actionOnSubPhase == this.TUNE) {
								if (!subPhasesToTune.contains(markSubPhaseService.getIdentifier())) {
									subPhasesToTune += markSubPhaseService.getIdentifier() + ";";
								}
							}
						}
					}
				}

				// Update editable flag
				if (taskAction.isForceEditable() != taskActionLinked.isForceEditable()
						|| taskAction.hasForceEditable() != taskActionLinked.hasForceEditable()) {
					if (taskAction.isForceEditable()) {
						taskActionLinked.setForceEditable(true);
					} else {
						taskActionLinked.setForceEditable(false);
					}
					getNotifications().notifyServiceChanged(modelTaskActionLinked);
				}

				// Remove check box value
				if (isLinkedMarkModified && modelTaskActionLinked.getParent() instanceof ModelMarkService
						&& modelTaskActionLinked.getType() != ModelMarkService.TASK_ACTION_CHECK_TYPE) {
					modelTaskActionLinked.getStatusService().setAlterable(null);
					((ModelMarkService) modelTaskActionLinked.getParent()).cleanMarkCheckBox(instanceId);
				}
				// Do not update Sub-phase Status if no modification has been done
				if (isLinkedMarkModified) {
					subPhaseService.getStatusService().computeStatus(true);
				}
			}
		}

		// Remove check box value of current mark
		if (getParent() instanceof ModelMarkService && getType() != ModelMarkService.TASK_ACTION_CHECK_TYPE) {
			((ModelMarkService) getParent()).cleanMarkCheckBox(instanceId);
		}

		// create a new passing with editTuning for subphases containing SN changed but
		// not reopened
		if (controller != null && !subPhasesToTune.equals("")) {
			InterventionController interventionController = (InterventionController) controller.getControllersProvider()
					.getController(ClientAssemblyControllersProvider.INTERFACE_INTERVENTION);
			interventionController.actionEditTuning("",subPhasesToTune, "", "", "edit tuning due to mark change");
			
			try {
				applyValueToReference(controller, taskActionService, newValue);
			} catch (Exception e) {
				logger.error(e);
			}
			
		}
	}

	/**
	 * A subPhase whose status is DONE, have to be re-opened if the PN, the SN or
	 * the concession mark's field is modified
	 * 
	 * @param markSubPhaseService
	 * @param taskActionType
	 * @return true if the subPhase parent have to be re-opened
	 *
	 * @throws ClientException
	 */
	private int computeActionToDoOnInpactedSubPhase(IController controller, ModelSubPhaseService markSubPhaseService,
			String taskActionType) throws ClientException {
		
		if (ModelMarkService.TASK_ACTION_SN_TYPE.equals(taskActionType) && TOP_START_SUBPHASE_ID.equals(markSubPhaseService.getIdentifier())) {
			logger.debug("sous phase " + markSubPhaseService.getIdentifier()
			+ " => pas de nouveau passage sur la SP d'inventaire sur changement de SN");
			return this.NOTHING_TODO;
		}
		if (isNotInLastPassing(markSubPhaseService)
				&& markSubPhaseService.getStatusService().getStatus().equals(StatusType.DONE.value())) {
			logger.debug("sous phase " + markSubPhaseService.getIdentifier()
					+ " non réouverte car passage différent du passage courant  ==> créer un nouveau passage sur cette sous phase");
			return this.TUNE;
		}

		if (markSubPhaseService.getStatusService().getStatus().equals(StatusType.DONE.value())
				&& (ModelMarkService.TASK_ACTION_SN_TYPE.equals(taskActionType)
						|| ModelMarkService.TASK_ACTION_PN_TYPE.equals(taskActionType)
						|| ModelMarkService.TASK_ACTION_DEROG_TYPE.equals(taskActionType))) {
			return this.REOPEN;
		}
		return this.NOTHING_TODO;
	}

	private boolean isNotInLastPassing(ModelSubPhaseService markSubPhaseService) {
		ModelWrapperAssemblyService gamme = (ModelWrapperAssemblyService) markSubPhaseService.getParent().getParent()
				.getWrapperService();
		SubPhase sph = (SubPhase) markSubPhaseService.getWrapperService().getObject();
		int passingNumber = 0;
		if (sph.hasPassing()) {
			passingNumber = sph.getPassing();
		}

		return gamme.getPassingId() != passingNumber;
	}

	private void cleanMarkCheckBox(String instanceId) throws ClientException, ClientInterruption {
		boolean resetResources = false;
		ModelResourcesService resourcesService = (ModelResourcesService) getParent().getParent();
		Resources resources = ((Resources) resourcesService.getWrapperService().getObject());

		// Check if current resource (mark, ingredient or tool) has an associated
		// taskAction
		ModelTaskActionService taskActionService = getTaskActionType(TASK_ACTION_CHECK_TYPE, instanceId, null, null);
		if (taskActionService != null && taskActionService.getRunnableService().isFinished()) {
			taskActionService.resetValue(true);
			resetResources = true;
		}

		// Check if current resource has a global taskAction
		TaskAction taskAction = resources.getTaskAction();
		if (taskAction != null) {
			IModelObjectService modelService = ModelXmlProvider.getInstance().getModelService(taskAction.getId());
			if (modelService != null) {
				((ModelTaskActionService) modelService).resetValue(true);
				resetResources = true;
			}
		}

		// In all case, clean resources state
		if (taskActionService != null) {
			resourcesService.getStatusService().resetState(false, resetResources, null);
		}
	}

	public boolean impactedByInstance(String instanceId) {
		return (instanceId == null || !getWrapperService().getMark().hasInstance()
				|| getWrapperService().getMark().getInstance() == Integer.valueOf(instanceId));
	}
}
