package turbomeca.gamme.assembly.client.model.edit.instructions;

import turbomeca.gamme.assembly.client.model.edit.AModelAssemblyService;
import turbomeca.gamme.assembly.client.model.edit.hmi.updater.ModelHmiUpdaterService;
import turbomeca.gamme.assembly.client.model.edit.loader.ModelLoaderTaskActionMeasureService;
import turbomeca.gamme.assembly.client.model.edit.runnable.ModelRunnableTaskActionMeasureService;
import turbomeca.gamme.assembly.client.model.edit.status.ModelStatusTaskActionMeasureService;
import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperTaskActionMeasureService;
import turbomeca.gamme.assembly.services.model.data.CaracDef;
import turbomeca.gamme.assembly.services.model.data.MeasureRdd;
import turbomeca.gamme.assembly.services.model.data.MeasureSap;
import turbomeca.gamme.assembly.services.model.data.MeasureTool;
import turbomeca.gamme.assembly.services.model.data.TaskActionMeasure;
import turbomeca.gamme.assembly.services.model.data.types.StatusType;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.edit.instructions.IModelTaskActionMeasureService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public class ModelTaskActionMeasureService extends AModelAssemblyService implements IModelTaskActionMeasureService {

    /**
     * Constructor
     * 
     * @param scheduleService
     * @param operation
     */
    public ModelTaskActionMeasureService(IModelObjectService modelService, TaskActionMeasure taskActionMeasure) {
        super(modelService.getDomain(), taskActionMeasure.getId());
        setParent(modelService);
        
        setWrapperService(new ModelWrapperTaskActionMeasureService(taskActionMeasure));
        setLoaderService(new ModelLoaderTaskActionMeasureService(this));
        setHmiUpdaterService(new ModelHmiUpdaterService());
        setStatusService(new ModelStatusTaskActionMeasureService(this));
        setRunnableService(new ModelRunnableTaskActionMeasureService(this));
    }   
    
    public MeasureSap getMeasureSap(){
    	TaskActionMeasure taskActionmeasure = (TaskActionMeasure) getWrapperService().getObject();
    	return taskActionmeasure.getMeasureSap();
    }
    
    public MeasureTool getMeasureTool(){
    	TaskActionMeasure taskActionmeasure = (TaskActionMeasure) getWrapperService().getObject();
    	return taskActionmeasure.getMeasureTool();
    }
    
    public MeasureRdd getMeasureRdd(){
    	TaskActionMeasure taskActionmeasure = (TaskActionMeasure) getWrapperService().getObject();
    	return taskActionmeasure.getMeasureRdd();
    }
    
    public String getTaskActionId(){
    	TaskActionMeasure taskActionmeasure = (TaskActionMeasure) getWrapperService().getObject();
    	return taskActionmeasure.getTaskAction().getId();
    }
    
    
    /**
	 * Update List of taskMeasure on top Demarrage Action
	 * @param taskActionMeasureService
	 * @param value
	 * @param status
	 * @throws ClientException
     * @throws ClientInterruption 
	 */
	public void setStateMeasureSap(StatusType status) throws ClientException, ClientInterruption{
		getMeasureSap().getState().setStatus(status);
		getStatusService().updateState(null, false, null, null);
	}
	
	/**
	 * Fonction who retrieve caraccteristic from value
	 * @param measure
	 * @return
	 */
  private static String getCaracFromPn(MeasureSap measure){
    	String caraName=null;
    	String pn = measure.getPN().getTaskAction().getInputAction().getInputValue().getValue();
    	for (CaracDef carac : measure.getCaracDef()){
    		if( carac.getPN().equals(pn)){
    			caraName=carac.getName();
    		}
    	}
    	return caraName;
    }
  
  
  /**
   * Function who build id unique from MeasureSap
   * @param measure
   * @return
   */
    public String buildKeyForMeasureSAP(){
    	String key = null;
    	MeasureSap measureSap = getMeasureSap();
    	if(measureSap!=null){
	    	String carac = getCaracFromPn(measureSap);
	    	if(carac!=null){
	        	String pn = measureSap.getPN().getTaskAction().getInputAction().getInputValue().getValue();
	        	// FIXME : HANDLE MULTI SN DEFINITIONS
	        	if(measureSap.getSN().getTaskAction().getInputAction().getInputValue()!=null){
	        	String sn = measureSap.getSN().getTaskAction().getInputAction().getInputValue().getValue();
	    			key= pn+"_"+sn+"_"+carac;
	        	}
	    	}
    	}
    	return key;
    }

	
    
}
