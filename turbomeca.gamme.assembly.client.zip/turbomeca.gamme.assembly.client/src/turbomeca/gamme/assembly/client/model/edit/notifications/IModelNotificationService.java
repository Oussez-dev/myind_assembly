package turbomeca.gamme.assembly.client.model.edit.notifications;

import turbomeca.gamme.assembly.client.model.edit.AModelAssemblyService;
import turbomeca.gamme.assembly.services.model.data.Response;
import turbomeca.gamme.assembly.services.model.data.types.StatusNotificationType;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public interface IModelNotificationService extends IModelObjectService {
    public void bindService(AModelAssemblyService modelService) throws ClientException;
    public void update(StatusNotificationType status, Response response) throws ClientException, ClientInterruption;
}
