package turbomeca.gamme.assembly.client.model.edit.loader;

import turbomeca.gamme.assembly.client.model.edit.instructions.AModelTaskActionService;
import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperTaskActionService;
import turbomeca.gamme.assembly.services.model.data.types.StatusType;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.model.interfaces.IModelLoaderService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.model.provider.ModelXmlProvider;

public class ModelLoaderTaskActionService extends AModelAssemblyLoader implements
		IModelLoaderService {

	public ModelLoaderTaskActionService(IModelObjectService modelService) {
		super(modelService);
	}

	@Override
	public ModelWrapperTaskActionService getWrapperService() {
		return (ModelWrapperTaskActionService) super.getWrapperService();
	}

	@Override
	public AModelTaskActionService getModelService() {
		return (AModelTaskActionService) super.getModelService();
	}

	@Override
	public void load(ModelXmlProvider modelProvider) throws ClientException {
		if (modelProvider != null) {
			if (getModelService().isSapTaskAction() 
					&& getWrapperService() != null 
					&& getWrapperService().getTaskAction() != null
					&& getWrapperService().getTaskAction().getSapValue() != null
					&& getWrapperService().getTaskAction().getSapValue().getValue() != null) {
				
				// DIRTY why modifying the taskAction object at loading ?
				if(getModelService().getStatusService().isAlterable()) {
					getWrapperService().getTaskAction().getSapValue().setStatus(StatusType.valueOf(getModelService().getStatusService().getStatus()));
				}
			} else if(getWrapperService() != null && getWrapperService().getTaskAction() != null
					&& getWrapperService().getTaskAction().getInputAction() != null 
					&& getWrapperService().getTaskAction().getInputAction().getInputValue() != null) {
				
				// DIRTY why modifying the taskAction object at loading ?
				if(getModelService().getStatusService().isAlterable()) {
					getWrapperService().getTaskAction().getInputAction().getInputValue().setValueStatus(getModelService().getStatusService().getStatus());
				}
			}
			modelProvider.addModelService(getModelService().getIdentifier(), getModelService());
		}
	}
}
