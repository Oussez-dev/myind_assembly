package turbomeca.gamme.assembly.client.model.edit.instructions;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import turbomeca.gamme.assembly.client.ClientAssemblyException;
import turbomeca.gamme.assembly.client.model.edit.AModelAssemblyService;
import turbomeca.gamme.assembly.client.model.edit.hmi.updater.ModelHmiUpdaterService;
import turbomeca.gamme.assembly.client.model.edit.loader.ModelLoaderTaskActionService;
import turbomeca.gamme.assembly.client.model.edit.utils.ModelComparatorService;
import turbomeca.gamme.assembly.client.model.edit.utils.ModelUtils;
import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperTaskActionService;
import turbomeca.gamme.assembly.client.module.electronic.notification.action.ActionCreateElectronicNotificationNcr;
import turbomeca.gamme.assembly.client.module.electronic.notification.action.ActionDeleteElectronicNotificationNcr;
import turbomeca.gamme.assembly.client.module.electronic.notification.view.CreateElectronicValidationView;
import turbomeca.gamme.assembly.services.model.data.Formula;
import turbomeca.gamme.assembly.services.model.data.InputAction;
import turbomeca.gamme.assembly.services.model.data.InputActionChoice;
import turbomeca.gamme.assembly.services.model.data.InputField;
import turbomeca.gamme.assembly.services.model.data.InputValue;
import turbomeca.gamme.assembly.services.model.data.TaskAction;
import turbomeca.gamme.assembly.services.model.data.Test;
import turbomeca.gamme.assembly.services.model.data.types.InputType;
import turbomeca.gamme.assembly.services.model.data.types.StatusType;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.dispatcher.ActionDispatcherManager;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.model.voice.ModelTaskActionVoiceService;

public abstract class AModelTaskActionService extends AModelAssemblyService {
	
	private static final int DEFAULT_DIGIT_PRECISION = 3;

	/** Comparator service */
	private ModelComparatorService comparatorService;
	
	private List<ModelTaskActionService> listModelTaskActionService;

	private static final String TYPE_CHECK = "check";

	private boolean isValid = true;

	/**
	 * Constructor
	 * 
	 * @param taskService
	 *            parent service
	 * @param taskAction
	 *            current object
	 */
	public AModelTaskActionService(IModelObjectService taskService, TaskAction taskAction) {
		super(taskService.getDomain(), taskAction.getId());
		setParent(taskService);

		setWrapperService(new ModelWrapperTaskActionService(taskAction));
		setComparatorService(new ModelComparatorService());
		setLoaderService(new ModelLoaderTaskActionService(this));
		setHmiUpdaterService(new ModelHmiUpdaterService());
		setVoiceService(new ModelTaskActionVoiceService(this));
		listModelTaskActionService = new ArrayList<ModelTaskActionService>();
	}

	@Override
	public ModelWrapperTaskActionService getWrapperService() {
		return (ModelWrapperTaskActionService) super.getWrapperService();
	}

	/**
	 * Check if value is correct for current action (compare with test)
	 * 
	 * @param value
	 *            : value to compare
	 * @param index
	 * @return true value is correct, otherwise else
	 * @throws ClientException
	 * @throws ClientInterruption
	 */
	public abstract boolean checkValue(String value) throws ClientException, ClientInterruption;

	/**
	 * Reset value in current task action
	 * 
	 * @param groupId
	 *            group identifier value to save
	 * @param SNs
	 *            items associated
	 * @throws ClientException
	 * @throws ClientInterruption 
	 */
	public abstract void resetValue(boolean notify) throws ClientException, ClientInterruption;

	/**
	 * Update items selection for an current input value
	 * 
	 * @param groupId
	 * @param items
	 * @throws ClientException
	 */
	public abstract void updateComment(String comment) throws ClientException;

	/**
	 * 
	 * @param value
	 * @param groupId
	 * @param itemsId
	 * @return
	 * @throws ClientException
	 * @throws ClientInterruption 
	 */
	protected abstract boolean setInternalValue(String value) throws ClientException, ClientInterruption;

	/**
	 * 
	 * @param formula
	 * @return
	 * @throws ClientAssemblyException
	 */
	public abstract String computeFormula(Formula formula, int precision)
			throws ClientAssemblyException;

	/**
	 * 
	 * @param notify
	 * @throws ClientException
	 * @throws ClientInterruption 
	 */
	public abstract void setServiceModified(boolean notify) throws ClientException, ClientInterruption;

	/**
	 * Save value in current task action
	 * 
	 * @param value
	 *            value to save
	 * @param index
	 * @throws ClientException
	 * @throws ClientInterruption 
	 */
	public boolean setValue(String value) throws ClientException, ClientInterruption {
		return setValue(value, true);
	}

	
	public String formatValuePrecision(String value){
		
		if (value == null || value.isEmpty()) return "";
		
		InputField inputField = getTaskAction().getInputAction().getInputActionChoice().getInputField();
		
		// Valeur inchangé si le format n'est pas numérique
		if (inputField == null || !inputField.getType().value().equals(InputType.FLOAT.value()))  return value;
		
		int precision = inputField.hasDigitPrecision() ? inputField.getDigitPrecision() : DEFAULT_DIGIT_PRECISION;
		try {
			String format = "%." + precision + "f";
			double val = Double.parseDouble(value);
			return String.format(Locale.US,format, val);
		} catch (NumberFormatException e) {
			return value;
		}
	}
	
	/**
	 * Save value in current task action
	 * 
	 * @param value
	 *            value to save
	 * @param index
	 * @throws ClientException
	 * @throws ClientInterruption 
	 */
	public boolean setValue(String value, boolean notify) throws ClientException, ClientInterruption {
		boolean isValueSet = false;
		if (value == null || value.isEmpty()) {
			resetValue(notify);
		} else if (isFormatValid(value)) {
			value = formatValuePrecision(value);
			isValueSet = setInternalValue(value);
			if (isValueSet && notify) {
				getNotifications().notifyValueChanged(this);
				refreshValueValidityStatus(value,false);
			}
		}
		return isValueSet;
	}


	/***
	 * This service is used to manage the taskAction validity status:
	 *  - it update the status if required
	 *  - it raise a stamp notification if required,
	 *  - it removes obsoletes notification 
	 * 
	 * Note: It does not update the input value
	 * Note: boolean notifyIfStatusChange allow or not the function to notify ValueChanged if necessary
	 */
	public void refreshValueValidityStatus(String value, boolean notifyIfStatusChange) throws ClientException, ClientInterruption {

		if (value != null && !value.isEmpty()) {
			if (isFormatValid(value)){

				boolean isValueValid = false;

				try {
					isValueValid = checkValue(value);
					setValid(isValueValid);
				} catch(ClientInterruption e) { /** Should never happened, value has just been set (or not if just refreshing status)*/ };

				if(getTaskAction() != null && getTaskAction().getInputAction() != null && getTaskAction().getInputAction().getInputValue() != null) {
					if(isValueValid){
						getTaskAction().getInputAction().getInputValue().setValueStatus(StatusType.OK.toString());
					}
					else{
						getTaskAction().getInputAction().getInputValue().setValueStatus(StatusType.KO.toString());
					}
					if(notifyIfStatusChange){
						getNotifications().notifyValueChanged(this);
					}
				}

				if (getTaskAction().isNotification()) {
					if (!isValueValid) {
						ActionDispatcherManager.getInstance().run(new ActionCreateElectronicNotificationNcr(this));
					} else {
						ActionDispatcherManager.getInstance().run(new ActionDeleteElectronicNotificationNcr(this));
					}
				}

				if (getTaskAction().isDoubleValidation()) {
					if(getValue() != null) {
						ActionDispatcherManager.getInstance().addAction(getIdentifier(), new CreateElectronicValidationView(this));
					}
				}
			}
		}
	}

	/**
	 * Get current value of taskAction
	 * 
	 * @return current value
	 */
	public String getValue() {
		String value = null;
		InputValue inputValue = getTaskAction().getInputAction().getInputValue();
		if (inputValue != null) {
			value = inputValue.getValue();
		}
		return value;
	}

	/**
	 * Get current value of taskAction
	 * 
	 * @return current value
	 */
	public String getTextValue() {
		String value = null;
		InputValue inputValue = getTaskAction().getInputAction().getInputValue();
		if (inputValue != null) {
			value = inputValue.getValue();
		}
		return ModelUtils.getTextValue(value, getTaskAction().getInputAction());
	}

	/**
	 * Get current value of taskAction
	 * 
	 * @return current value
	 */
	public boolean isValueDifferent(String value) {
		String currentValue = getValue();
		if (value == null || value.isEmpty()) {
			return (currentValue != null);
		} else {
			return !value.equals(currentValue);
		}
	}

	/**
	 * 
	 * @param value
	 *            the input value to validate
	 * @param externalTest
	 *            if validation must be done using an external test object
	 * @return
	 * @throws ClientException
	 * @throws ClientInterruption
	 */
	public boolean isValueValid(String value, Test[] externalTest) throws ClientException, ClientInterruption {
		int precision = 3;
		InputField inputField = getTaskAction().getInputAction().getInputActionChoice().getInputField();
		if(inputField !=null) {
			if( inputField.hasDigitPrecision()) {
				precision = inputField.getDigitPrecision();
			}
		}
		
		Test[] testToUse = externalTest;
		if(testToUse == null) {
			testToUse = getTaskAction().getTest();
		}
		
		return getComparatorService().compareValueToData(value, getTaskAction().getInputAction(), testToUse, precision);
	}
	
	/**
	 * 
	 * @param value
	 * @return
	 * @throws ClientException
	 * @throws ClientInterruption 
	 */
	protected boolean isFormatValid(String value) throws ClientException, ClientInterruption {
		InputField inputField = getTaskAction().getInputAction().getInputActionChoice()
				.getInputField();
		if (inputField != null) {
			switch (inputField.getType()) {
			case INT:
				try {
					Integer.valueOf(value);
				} catch (NumberFormatException e) {
					setServiceModified(true);
					throw new ClientAssemblyException(
							ClientAssemblyException.EXCEPTION_INPUT_INT_FORMAT);
				}
				break;
			case FLOAT:
				try {
					Float.valueOf(value);
				} catch (NumberFormatException e) {
					setServiceModified(true);
					throw new ClientAssemblyException(
							ClientAssemblyException.EXCEPTION_INPUT_FLOAT_FORMAT);
				}
				break;
			case BOOLEAN:
				try {
					Boolean.valueOf(value);
				} catch (NumberFormatException e) {
					setServiceModified(true);
					throw new ClientAssemblyException(
							ClientAssemblyException.EXCEPTION_INPUT_BOOLEAN_FORMAT);
				}
				break;
			default:
				break;
			}
		}

		return true;
	}
	
	public abstract StatusType getSapStatus(int groupId);
	
	/**
	 * @return true if current taskAction is a SAP record
	 */
	public boolean isSapTaskAction() {
		boolean hasSapInput = false;
		InputAction inputAction = getTaskAction().getInputAction();
		if (inputAction != null) {
			InputActionChoice inputActionChoice = inputAction.getInputActionChoice();
			hasSapInput = (inputActionChoice.getInputSap() != null || inputActionChoice.getInputControlSap() != null);
		}
		return hasSapInput;
	}
	
	/**
	 * Test if the taskAction has checkBox
	 * @return true : it has checkBox
	 *  false : it has not checkBox
	 */
	public boolean isCheckType() {
		boolean isCheckType = false;
		TaskAction taskAction = getWrapperService().getTaskAction();
		if(taskAction != null){
			InputAction inputAction = taskAction.getInputAction();
			if(inputAction != null) {
				InputActionChoice inputActionChoice = inputAction.getInputActionChoice();
				if(inputActionChoice != null) {
					InputField inputField = inputActionChoice.getInputField();
					if(inputField != null){
						InputType type = inputField.getType();
						type.name();
						if(type != null && type.value() != null && type.value().equals(TYPE_CHECK)){
							isCheckType = true;
						}
					}
				}
			}
		}
		return isCheckType;
	}

	/**
	 * 
	 * @return
	 */
	public TaskAction getTaskAction() {
		return getWrapperService().getTaskAction();
	}

	/**
	 * @param comparatorService
	 *            the comparatorService to set
	 */
	public void setComparatorService(ModelComparatorService comparatorService) {
		this.comparatorService = comparatorService;
	}

	/**
	 * @return the comparatorService
	 */
	public ModelComparatorService getComparatorService() {
		return comparatorService;
	}

	public boolean isValid() {
		return isValid;
	}

	public void setValid(boolean isValid) {
		this.isValid = isValid;
	}
	
	public List<ModelTaskActionService> getServicesToDuplicateOnDuplication() {
		return listModelTaskActionService;
	}
}
