package turbomeca.gamme.assembly.client.model.edit.instructions;

import java.util.ArrayList;

import turbomeca.gamme.assembly.client.model.edit.AModelAssemblyService;
import turbomeca.gamme.assembly.client.model.edit.hmi.updater.ModelHmiUpdaterService;
import turbomeca.gamme.assembly.client.model.edit.loader.ModelLoaderOperationService;
import turbomeca.gamme.assembly.client.model.edit.runnable.ModelRunnableOperationService;
import turbomeca.gamme.assembly.client.model.edit.status.ModelStatusOperationService;
import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperOperationService;
import turbomeca.gamme.assembly.services.model.data.Operation;
import turbomeca.gamme.assembly.services.model.data.Qualification;
import turbomeca.gamme.assembly.services.model.data.Qualifications;
import turbomeca.gamme.ecran.client.config.Configuration;
import turbomeca.gamme.ecran.client.model.edit.instructions.IModelOperationService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public class ModelOperationService extends AModelAssemblyService implements IModelOperationService {

	/**
	 * Constructor
	 * 
	 * @param scheduleService
	 * @param operation
	 */
	public ModelOperationService(IModelObjectService scheduleService, Operation operation) {
		super(operation.getType(), operation.getId());
		setParent(scheduleService);
		
		setWrapperService(new ModelWrapperOperationService(operation));
		setLoaderService(new ModelLoaderOperationService(this));
		setHmiUpdaterService(new ModelHmiUpdaterService());
		setStatusService(new ModelStatusOperationService(this));
		setRunnableService(new ModelRunnableOperationService(this));
		
		Configuration.getInstance().getConfigRange().addAvailableDomain(operation.getType());
	}
	
	@Override
	public ModelWrapperOperationService getWrapperService() {
	    return (ModelWrapperOperationService) super.getWrapperService();
	}
	
	public boolean isRework(){
		boolean isRework = false;
		Operation operation = (Operation) getWrapperService().getObject();
		if(operation != null && operation.hasRework() && operation.isRework()){
			isRework = true;
		}
		return isRework;
	}
	
	/**
	 * Get the qualifications of the operation
	 * @return the qualifications
	 */
	public ArrayList<String> getQualifications(){
		ArrayList<String> qualificationsOperation = new ArrayList<String>();
		Operation ope = (Operation) getWrapperService().getObject();
		Qualifications qualifs = ope.getQualifications();
		if(qualifs != null){
			for(Qualification qualif : qualifs.getQualification()){
				qualificationsOperation.add(qualif.getQualification());
			}
		}
		return qualificationsOperation;
	}
}
