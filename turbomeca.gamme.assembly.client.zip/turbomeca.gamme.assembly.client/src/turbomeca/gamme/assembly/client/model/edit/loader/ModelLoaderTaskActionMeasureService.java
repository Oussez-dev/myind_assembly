package turbomeca.gamme.assembly.client.model.edit.loader;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskActionMeasureService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskActionService;
import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperTaskActionMeasureService;
import turbomeca.gamme.assembly.services.model.data.MeasureSap;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.interfaces.IModelLoaderService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.model.provider.ModelXmlProvider;

public class ModelLoaderTaskActionMeasureService extends AModelAssemblyLoader implements
        IModelLoaderService {

    public ModelLoaderTaskActionMeasureService(IModelObjectService modelService) {
        super(modelService);
    }

    @Override
    public ModelWrapperTaskActionMeasureService getWrapperService() {
        return (ModelWrapperTaskActionMeasureService) super.getWrapperService();
    }

    @Override
    public ModelTaskActionMeasureService getModelService() {
        return (ModelTaskActionMeasureService) super.getModelService();
    }

    public void load(ModelXmlProvider modelProvider) throws ClientException, ClientInterruption {
        if (getWrapperService().getTaskActionMeasure().getMeasureTool() != null) {
            ModelTaskActionService taskActionService = loadTaskAction(modelProvider, getWrapperService().getId(),
                    getWrapperService().getTaskActionMeasure().getMeasureTool().getTaskAction());
            taskActionService.setOptional(true);
        }
        
        MeasureSap measureSap = getWrapperService().getTaskActionMeasure().getMeasureSap();
        if (measureSap != null) {
           loadTaskAction(modelProvider, "", measureSap.getPN().getTaskAction());
 		   loadTaskAction(modelProvider, "", measureSap.getSN().getTaskAction());
        }
        loadTaskAction(modelProvider, getWrapperService().getTaskActionMeasure().getId(),
                getWrapperService().getTaskActionMeasure().getTaskAction());

        if (modelProvider != null) {
            modelProvider.addModelService(getModelService().getIdentifier(), getModelService());
        }
    }
}
