package turbomeca.gamme.assembly.client.model.edit.instructions;

import java.util.ArrayList;
import java.util.List;

import turbomeca.gamme.assembly.client.model.edit.AModelAssemblyService;
import turbomeca.gamme.assembly.client.model.edit.hmi.updater.ModelHmiUpdaterService;
import turbomeca.gamme.assembly.client.model.edit.loader.ModelLoaderSubPhaseGroupService;
import turbomeca.gamme.assembly.client.model.edit.runnable.ModelRunnableStatusDefaultService;
import turbomeca.gamme.assembly.client.model.edit.status.ModelStatusSubPhaseGroupService;
import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperSubPhaseGroupService;
import turbomeca.gamme.assembly.services.model.data.SubPhaseGroup;
import turbomeca.gamme.assembly.services.model.data.types.BooleanTypeWithNull;
import turbomeca.gamme.ecran.client.model.edit.instructions.IModelSubPhaseGroupService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public class ModelSubPhaseGroupService extends AModelAssemblyService implements IModelSubPhaseGroupService {

	public ModelSubPhaseGroupService(ModelOperationService operationService, SubPhaseGroup subPhaseGroup) {
		super(operationService.getDomain(), subPhaseGroup.getId());
		setParent(operationService);

		setWrapperService(new ModelWrapperSubPhaseGroupService(subPhaseGroup));
		setLoaderService(new ModelLoaderSubPhaseGroupService(this));
		setHmiUpdaterService(new ModelHmiUpdaterService());
		setStatusService(new ModelStatusSubPhaseGroupService(this));
		setRunnableService(new ModelRunnableStatusDefaultService(this));
	}

	@Override
	public ModelWrapperSubPhaseGroupService getWrapperService() {
		return (ModelWrapperSubPhaseGroupService) super.getWrapperService();
	}

	/**
	 * get the subPhase qualifications defined in the group
	 * @return the list of qualifications
	 */
	public ArrayList<String> getQualifications() {
		ArrayList<String> listQualifications = new ArrayList<String>(); 
		for(IModelObjectService subphase : getChildrenDeep(ModelSubPhaseService.class)){
			listQualifications.addAll(((ModelSubPhaseService) subphase).getQualifications());
		}
		return listQualifications;
	}

	/**
	 * check if the user is qualified for the subphaseGroup
	 * @param qualifications
	 * @param userQualificationsList
	 * @return true : the user is qualified
	 *  false : the user is not qualified
	 */
	public boolean isUserQualified(ArrayList<String> qualifications,
			List<String> userQualificationsList) {
		boolean isQualified = false;
		if(qualifications.size() != 0){
			for(String userQualif : userQualificationsList){
				isQualified = qualifications.contains(userQualif);
				if(isQualified) {
					break;
				}
			}
		}
		else{
			isQualified = true;
		}
		return isQualified;
	}

	/**
	 * check if the subphasegroup is alternative or not
	 * @return
	 */
	public boolean isAlternative() {
		boolean isAlternative = false;
		SubPhaseGroup sphgroup = (SubPhaseGroup) getWrapperService().getObject();
		if(sphgroup.hasIsAlternative()){
			isAlternative = sphgroup.isIsAlternative();
		}
		else{
			isAlternative = false;
		}
		return isAlternative;
	}

	/**
	 * check if the subphasegroup is archived or not
	 * @return
	 */
	public boolean isArchived() {
		boolean isArchived = false;
		SubPhaseGroup sphgroup = (SubPhaseGroup) getWrapperService().getObject();
		if(sphgroup.hasArchive()){
			isArchived = sphgroup.isArchive();
		}
		else{
			isArchived = false;
		}
		return isArchived;
	}

	/**
	 * Check if the subPhaseGroup is applicable or not
	 * @return
	 */
	public boolean isApplicable() {
		boolean isApplicable = false;
		SubPhaseGroup sphgroup = (SubPhaseGroup) getWrapperService().getObject();
		if(sphgroup.hasApplicable()){
			isApplicable = sphgroup.isApplicable();
		}
		else{
			isApplicable = false;
		}
		return isApplicable;
	}

	@Override
	public boolean hasNoneSignature() {
		// SubPhaseGroup object does not holds the signature attribute. Has all
		// children of a group are several instance of the same sub-phase any
		// children can be read to get group signature
		return BooleanTypeWithNull.NONE.value().equals(
				getWrapperService().getSubPhaseGroup().getSubPhase(0)
						.getSignature());
	}
}
