package turbomeca.gamme.assembly.client.model.edit.wrappers;

import turbomeca.gamme.assembly.services.model.data.ElectronicNotifications;

public class ModelWrapperElectronicNotificationsService extends AModelWrapperAssemblyService {

	/** */
	private ElectronicNotifications electronicNotifications;

	/**
	 * Constructor for task object
	 * 
	 * @param subPhaseService
	 *            parent service
	 * @param task
	 *            task object
	 */
	public ModelWrapperElectronicNotificationsService(ElectronicNotifications electronicNotifications) {
	    setElectronicNotifications(electronicNotifications);
	}


	@Override
	public Object getObject() {
		return electronicNotifications;
	}

	/**
	 * @return the tools
	 */
	public ElectronicNotifications getElectronicNotifications() {
		return electronicNotifications;
	}

	public void setElectronicNotifications(ElectronicNotifications electronicNotifications) {
	    this.electronicNotifications = electronicNotifications;
	}


    @Override
    public String getId() {
        return null;
    }

    @Override
    public void setId(String id) {
    }
    
}
