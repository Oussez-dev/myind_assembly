package turbomeca.gamme.assembly.client.model.edit.hmi.updater;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelResourcesService;
import turbomeca.gamme.ecran.client.model.edit.instructions.IModelSubPhaseService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public class ModelHmiUpdaterServiceOnTasksView extends ModelHmiUpdaterServiceOnMainView {

	public ModelHmiUpdaterServiceOnTasksView() {
		super();
	}
	public ModelHmiUpdaterServiceOnTasksView(String hmiParentId) {
		super(hmiParentId);
	}
	
	@Override
	public boolean canFocus(IModelObjectService previousModelService, IModelObjectService nextModelService) {
//		return !(nextModelService instanceof ModelResourcesService ||
//				nextModelService instanceof IModelSubPhaseService );
		return true;
	}
}
