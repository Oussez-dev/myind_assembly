package turbomeca.gamme.assembly.client.model.edit.instructions;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.model.edit.AModelAssemblyService;
import turbomeca.gamme.assembly.client.model.edit.hmi.updater.ModelHmiUpdaterService;
import turbomeca.gamme.assembly.client.model.edit.loader.ModelLoaderTaskPilotingService;
import turbomeca.gamme.assembly.client.model.edit.runnable.ModelRunnableTaskPilotingService;
import turbomeca.gamme.assembly.client.model.edit.status.ModelStatusTaskPilotingService;
import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperTaskPilotingService;
import turbomeca.gamme.assembly.services.model.data.TaskPiloting;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public class ModelTaskPilotingService extends AModelAssemblyService {
	private Logger logger = Logger.getLogger(ModelTaskPilotingService.class);

    /**
     * Constructor
     * 
     * @param scheduleService
     * @param operation
     */
    public ModelTaskPilotingService(IModelObjectService modelService, TaskPiloting taskPiloting) {
        super(modelService.getDomain(), taskPiloting.getId());
        setParent(modelService);
        
        setWrapperService(new ModelWrapperTaskPilotingService(taskPiloting));
        setLoaderService(new ModelLoaderTaskPilotingService(this));
        setHmiUpdaterService(new ModelHmiUpdaterService());
        setStatusService(new ModelStatusTaskPilotingService(this));
        setRunnableService(new ModelRunnableTaskPilotingService(this));
    }
    
    public ModelTaskActionService getChild(String id) {
    	for(IModelObjectService tas : getChildren()) {
    		if(tas.getIdentifier().equals(id) && tas instanceof ModelTaskActionService) {
    			return (ModelTaskActionService) tas;
    		}
    	}
    	return null;
    }
    
    public String getTaskActionId(){
    	TaskPiloting taskPiloting = (TaskPiloting)getWrapperService().getObject();
    	return taskPiloting.getTaskAction().getId();
    }
    
    public List<String> getTaskActionPilotingResultIds(){
    	TaskPiloting taskPiloting = (TaskPiloting)getWrapperService().getObject();
    	int taskActionResultSize = taskPiloting.getTaskActionPilotingResult().getTaskAction().length;
    	List<String> ids = new ArrayList<String>();
    	for(int i = 0 ; i<taskActionResultSize; i++) {
    		ids.add(taskPiloting.getTaskActionPilotingResult().getTaskAction(i).getId());
    	}
    	
    	return ids;
    }

	public void setAutoMode(boolean autoMode) throws ClientException {
		((TaskPiloting)getWrapperService().getObject()).setAutoMode(autoMode);
		getNotifications().notifyValueChanged(this);
	}

	public String getSnTool() {
		return ((ModelTaskActionService)this.getChildren().get(0)).getTextValue();
	}

	public void resetInputValues(String taskActionId) throws ClientException, ClientInterruption {
		logger.debug("reset all result piloting");
		for(IModelObjectService taskAction : getChildren()) {
			if(!taskAction.getIdentifier().equals(taskActionId)) {
				((ModelTaskActionService) taskAction).resetValue(true);
			}
		}
		getStatusService().computeStatus(true);
		getNotifications().notifyServiceChanged(this.getParent());
	}

	public Object getTool() {
		logger.debug("get tool type");
		return ((TaskPiloting)getWrapperService().getObject()).getTool();
	}
}
