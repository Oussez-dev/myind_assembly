package turbomeca.gamme.assembly.client.model.edit.wrappers;

import turbomeca.gamme.assembly.services.model.data.TaskAction;
import turbomeca.gamme.assembly.services.model.data.Tool;

public class ModelWrapperToolService extends AModelWrapperAssemblyService {
	
	/** */
	private Tool tool;

	/**
	 * Constructor for tool object
	 * 
	 * @param subPhaseService
	 *            parent service
	 * @param task
	 *            task object
	 */
	public ModelWrapperToolService(Tool tool) {
		setTool(tool);
	}
	
	@Override
	public Object getObject() {
		return null;
	}

	@Override
	public String getId() {
		return getTool().getId();
	}
	
	@Override
	public void setId(String id) {
		getTool().getUniqueId();
	}
	
	
	public TaskAction getTaskActionCheck() {
		return getTool().getTaskAction();
	}
	
	public String getToolRefId() {
		return getTool().getToolRefId();
	}

	public void setTool(Tool tool) {
		this.tool = tool;
	}


	public Tool getTool() {
		return tool;
	}

}
