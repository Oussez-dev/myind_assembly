package turbomeca.gamme.assembly.client.model.edit.schedule;

import turbomeca.gamme.assembly.client.model.edit.hmi.updater.ModelHmiUpdaterScheduleService;
import turbomeca.gamme.assembly.client.model.edit.loader.ModelLoaderScheduleService;
import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperDisassemblyService;
import turbomeca.gamme.assembly.services.model.data.DerogationMarks;
import turbomeca.gamme.assembly.services.model.data.Disassembly;
import turbomeca.gamme.assembly.services.model.data.types.ContextType;

public class DisassemblyScheduleService extends AAssemblyScheduleService {

    /** */
    protected static final String DISASSEMBLY_NAME = "disassembly";

    public DisassemblyScheduleService() {
        super("");
        setWrapperService(new ModelWrapperDisassemblyService());
        setLoaderService(new ModelLoaderScheduleService(this));
        setHmiUpdaterService(new ModelHmiUpdaterScheduleService());
    }
    
    @Override
    public Class<?> getClassModel() {
        return Disassembly.class;
    }
    
    @Override
    public String getName() {
        return DISASSEMBLY_NAME;
    }
    
    @Override
    public String getOfficialRangeName() {
        return getName();
    }

    @Override
    public String getReverseOfficialRangeName() {
        return AssemblyScheduleService.ASSEMBLY_NAME;
    }
    
    @Override
    public String getSubOfficialRangeName() {
        return getName();
    }
    
    @Override
    public String getReverseSubOfficialRangeName() {
        Disassembly disassembly = (Disassembly) getWrapperService().getObject();
        String reverseSubOfficialName = "";
        if (disassembly.getType() == ContextType.NEW) {
            reverseSubOfficialName = AssemblyScheduleService.ASSEMBLY_NEW_NAME;
        }
        else {
            reverseSubOfficialName = AssemblyScheduleService.ASSEMBLY_REPAIRED_NAME; 
        }
        return reverseSubOfficialName;
    }

	@Override
	public void setDerogationsMarks(DerogationMarks derogationMarks) {
		getWrapperService().setDerogationMarks(derogationMarks);
		
	}
}
