package turbomeca.gamme.assembly.client.model.edit.hmi.updater;

import turbomeca.gamme.assembly.client.model.interfaces.IAssemblyModelHmiUpdaterService;
import turbomeca.gamme.assembly.client.module.instruction.view.InstructionView;
import turbomeca.gamme.assembly.client.module.instruction.view.TasksView;
import turbomeca.gamme.ecran.client.model.edit.hmi.updater.MultipleViewModelHmiUpdaterService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelHmiUpdaterService;

public class ModelHmiUpdaterService extends MultipleViewModelHmiUpdaterService implements IAssemblyModelHmiUpdaterService {
	
	public ModelHmiUpdaterService(String hmiParentId) {
		addInstructionViewHmiUpdaterService(
				InstructionView.class.getName(),
				new ModelHmiUpdaterServiceOnMainView(hmiParentId));
		addInstructionViewHmiUpdaterService(
				TasksView.class.getName(),
				new ModelHmiUpdaterServiceOnTasksView(hmiParentId));
	}
	
	public ModelHmiUpdaterService() {
		addInstructionViewHmiUpdaterService(
				InstructionView.class.getName(),
				new ModelHmiUpdaterServiceOnMainView());
		addInstructionViewHmiUpdaterService(
				TasksView.class.getName(),
				new ModelHmiUpdaterServiceOnTasksView());
	}
	
	@Override
	public void setHasPreviousTaskPara(boolean hasPreviousTaskPara) {
		for(IModelHmiUpdaterService service : getServices()) {
			((IAssemblyModelHmiUpdaterService)service).setHasPreviousTaskPara(hasPreviousTaskPara);
		}
	}

	@Override
	public void setModeTable(boolean tableMode) {
		for(IModelHmiUpdaterService service : getServices()) {
			((IAssemblyModelHmiUpdaterService)service).setModeTable(tableMode);
		}
		
	}
}
