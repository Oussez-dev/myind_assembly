package turbomeca.gamme.assembly.client.model.edit.runnable;

import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public class ModelRunnableStatusNoneService extends ModelRunnableStatusDefaultService {

	public ModelRunnableStatusNoneService(IModelObjectService modelService) {
		super(modelService);
	}

	@Override
	public boolean isFinished() {
		boolean isFinished = true;
		for (IModelObjectService service : getModelService().getChildren()) {
			if( service.getWrapperService().isApplicable()) {
				isFinished &= service.getRunnableService().isFinished() || service.getRunnableService().isOptional();
				if (isFinished == false) {
					break;
				}
			}
		}
		return isFinished;
	}

	@Override
	public boolean isRunnable() {
		return getWrapperService().isApplicable();
	}
}
