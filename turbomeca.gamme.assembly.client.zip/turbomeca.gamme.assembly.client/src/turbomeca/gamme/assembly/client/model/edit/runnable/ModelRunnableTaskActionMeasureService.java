package turbomeca.gamme.assembly.client.model.edit.runnable;

import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperTaskActionMeasureService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public class ModelRunnableTaskActionMeasureService extends ModelRunnableStatusDefaultService {

    public ModelRunnableTaskActionMeasureService(IModelObjectService modelService) {
        super(modelService);
    }

    @Override
    public ModelWrapperTaskActionMeasureService getWrapperService() {
        return (ModelWrapperTaskActionMeasureService) super.getWrapperService();
    }

    
    @Override
    public boolean isRunnable() {
        return true;
    }
    
    @Override
    public boolean hasRunner() {
        return true;
    }
    
    @Override
    public boolean isFinished() {
        return (getWrapperService().getTaskActionMeasure().getTaskAction().getInputAction().getInputValue() != null);
    }
}
