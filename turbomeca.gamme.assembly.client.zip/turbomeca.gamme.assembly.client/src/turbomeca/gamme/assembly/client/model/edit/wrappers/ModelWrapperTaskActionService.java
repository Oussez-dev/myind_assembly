package turbomeca.gamme.assembly.client.model.edit.wrappers;

import java.util.ArrayList;
import java.util.List;

import turbomeca.gamme.assembly.services.model.data.ElectronicNotificationRef;
import turbomeca.gamme.assembly.services.model.data.Entry;
import turbomeca.gamme.assembly.services.model.data.InputAction;
import turbomeca.gamme.assembly.services.model.data.InputActionChoice;
import turbomeca.gamme.assembly.services.model.data.InputChoice;
import turbomeca.gamme.assembly.services.model.data.InputComputed;
import turbomeca.gamme.assembly.services.model.data.InputField;
import turbomeca.gamme.assembly.services.model.data.InputValue;
import turbomeca.gamme.assembly.services.model.data.ItemPara;
import turbomeca.gamme.assembly.services.model.data.Para;
import turbomeca.gamme.assembly.services.model.data.Reference;
import turbomeca.gamme.assembly.services.model.data.References;
import turbomeca.gamme.assembly.services.model.data.TaskAction;
import turbomeca.gamme.assembly.services.model.data.TaskMark;
import turbomeca.gamme.assembly.services.model.data.TaskMarkChoice;
import turbomeca.gamme.assembly.services.model.data.TaskMarkChoiceItem;
import turbomeca.gamme.assembly.services.model.data.Variable;
import turbomeca.gamme.assembly.services.model.data.types.InputType;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.model.edit.wrappers.IModelWrapperTaskActionService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public class ModelWrapperTaskActionService extends AModelWrapperAssemblyService implements IModelWrapperTaskActionService, IModelNotificationRefWrapper, IModelInstanceIdWrapper {

	/** TaskAction object */
	private TaskAction taskAction;
	/** Entry reference when taskAction is in a table*/
	private Entry entry;
	private TaskMark taskMark;

	/**
	 * Constructor
	 * 
	 * @param taskService
	 *            parent service
	 * @param taskAction
	 *            current object
	 */
	public ModelWrapperTaskActionService(TaskAction taskAction) {
		this.taskAction = taskAction;
	}


	@Override
	public Object getObject() {
		return taskAction;
	}

	/**
	 * @return the taskAction
	 */
	public TaskAction getTaskAction() {
		return taskAction;
	}

	/**
	 * @param taskAction
	 *            the taskAction to set
	 */
	public void setTaskAction(TaskAction taskAction) {
		this.taskAction = taskAction;
	}

	@Override
	public References getReferences() {
		return getTaskAction().getReferences();
	}

	@Override
	public String getId() {
		return getTaskAction().getId();
	}

	@Override
	public void setId(String id) {
		getTaskAction().setId(id);
	}
	
	@Override
    public ElectronicNotificationRef[] getElectronicNotificationRef() {
		return getTaskAction().getElectronicNotificationRef();
    }
	
	@Override
    public void removeElectronicNotificationRef() {
	    getTaskAction().removeAllElectronicNotificationRef();
    }
	
	@Override
	public void addChild(IModelObjectService nextChild, IModelObjectService newChild)
			throws ClientException {
	}

    @Override
    public int getInstanceId() {
        return getTaskAction().getInstance();
    }
    
    @Override
    public boolean hasInstanceId() {
        return getTaskAction().hasInstance();
    }

    @Override
    public boolean isForceEditable() {
        return getTaskAction().getForceEditable() || !getTaskAction().hasForceEditable();
    }

    @Override
    public boolean isDoubleValidation() {
        return getTaskAction().getDoubleValidation();
    }

    public boolean isOptional() {
		return getTaskAction().getOptional();
	}

	public void setOptional(boolean state) {
		getTaskAction().setOptional(state);
	}

    @Override
    public boolean isNotification() {
        return getTaskAction().getNotification();
    }
    
    public Integer getAlternative() {
    	return getTaskAction().getAlternative();
    }
    
	public Integer getDuplicateIndex() {
		return getTaskAction().getDuplicationIndex();
	}
	public void setDuplicateIndex(Integer duplicateIndex) {
		getTaskAction().setDuplicationIndex(duplicateIndex);
	}
	
    public boolean isDuplicable() {
		return getTaskAction().getDuplicable();
	}

	public void setDuplicable(boolean state) {
		getTaskAction().setDuplicable(state);
	}
	
	public boolean isInputComputed() {
		return getTaskAction() != null && getTaskAction().getInputAction() != null && getTaskAction().getInputAction().getInputActionChoice() != null && getTaskAction().getInputAction().getInputActionChoice().getInputComputed() != null; 
	}

    public void setEntryParent(Entry entryItem) {
        this.entry = entryItem;
    }
    
    public void setTaskMarkParent(TaskMark taskMark) {
    	this.taskMark = taskMark;
    }
    
    public TaskMark getTaskMarkParent() {
    	return taskMark;
    }
    
    public Entry getEntryParent() {
        return entry;
    }
    
    /**
	 * Get Value From taskAction Type
	 * @param ta
	 * @return
	 */
	public String getValue() {
		String value = "";
		TaskAction ta = taskAction;

		if(ta.getInputAction() !=null) {
			InputValue valueAction = ta.getInputAction().getInputValue();
			if(valueAction != null) {
				value = valueAction.getValue().toString();
				InputAction inputAction = ta.getInputAction();
				if(inputAction != null){
					InputActionChoice inputActionChoice = inputAction.getInputActionChoice();
					if(inputActionChoice != null){
						InputChoice inputChoice = inputActionChoice.getInputChoice();
						if(inputChoice != null){
							int position = Integer.parseInt(valueAction.getValue().toString());
							if(inputChoice.getStringValueCount() > 0 && inputChoice.getStringValueCount() > position -1){
								turbomeca.gamme.assembly.services.model.data.StringValue stringValue = inputChoice.getStringValue(position -1);
								if(stringValue !=null) {
									value = stringValue.getContent();
								}
								
							} else if (inputChoice.getItemParaCount() > 0 && inputChoice.getItemParaCount()  > position -1){
								ItemPara itemPara = inputChoice.getItemPara(position -1);
								if(itemPara!=null) {
									Para para = itemPara.getPara(0);
									if( para!=null ) {
										value = para.getContent();
									}
								}
							}
							if(inputChoice.getValCount() > 0 && inputChoice.getValCount() > position -1){
								value = String.valueOf(inputChoice.getVal(position -1));
							}
						}
					}

				}
			}
		}
		if(value.isEmpty()){
			TaskMark taskMark = getTaskMarkParent();
			if(taskMark != null) {
				TaskMarkChoice taskMarkChoice = taskMark.getTaskMarkChoice();
				if(taskMarkChoice != null){
					TaskMarkChoiceItem taskMarkChoiceItem = taskMarkChoice.getTaskMarkChoiceItem(0);
					if(taskMarkChoiceItem != null) {
						Para para = taskMarkChoiceItem.getPara();
						if(para != null) {
							value = para.getContent();
						}
					}
				}
			}
		}
		return value;
	}
	
	/**
	 * Get Values From taskAction Choice
	 * @param ta
	 * @return
	 */
	public List<String> getValues() {
		List<String> values = new ArrayList<String>();
		TaskAction ta = taskAction;

		if(ta.getInputAction() !=null) {
			InputValue valueAction = ta.getInputAction().getInputValue();
			if(valueAction != null) {
				InputAction inputAction = ta.getInputAction();
				if(inputAction != null){
					InputActionChoice inputActionChoice = inputAction.getInputActionChoice();
					if(inputActionChoice != null){
						InputChoice inputChoice = inputActionChoice.getInputChoice();
						if(inputChoice != null){
							int position = Integer.parseInt(valueAction.getValue().toString());
							if(inputChoice.getStringValueCount() > 0 && inputChoice.getStringValueCount() > position -1){
								turbomeca.gamme.assembly.services.model.data.StringValue[] stringValues = inputChoice.getStringValue();
								if(stringValues !=null) {
									for (turbomeca.gamme.assembly.services.model.data.StringValue str : stringValues){
										values.add(str.getContent());
									}
								}
							} 
						}
					}

				}
			}
		}
		return values;
	}
    
	@Override
	public List<String> getReferencedIdsFromInputComputed()
			throws ClientException {
		
		if(!isInputComputed()) {
			throw new ClientException();
		}
		
		List<String> refIds = new ArrayList<String>();
		
		InputComputed inputComputed = getTaskAction().getInputAction().getInputActionChoice().getInputComputed();
		
		if(inputComputed.getFormula() != null) {
			for(Variable variable : inputComputed.getFormula().getVariable()) {
				if(variable.getRefId() != null) {
					TaskAction taskAction = (TaskAction) variable.getRefId();
					refIds.add(taskAction.getId());
				}
			}
		}
		
		return refIds;
	}

	@Override
	public void addReference(IModelObjectService refObject) {
		Reference reference = new Reference();
		reference.setRefId(refObject.getWrapperService().getObject());
		
		if(taskAction.getReferences() != null) {
			// Only add the reference if not already existing
			boolean alreadyExisting = false;
			for(Reference ref : taskAction.getReferences().getReference()) {
				if(ref.getRefId().equals(reference)) {
					alreadyExisting = true;
					break;
				}
			}
			
			if(!alreadyExisting) {
				taskAction.getReferences().addReference(reference);
			}
		} else {
			References references = new References();
			references.addReference(reference);
			taskAction.setReferences(references);
		}
	}


	@Override
	public String getVoiceDescription() {
		return taskAction.getVoiceDescription() != null ? taskAction.getVoiceDescription().getContent() : "";
	}


	@Override
	public String getInputType() {
		// TODO create an enum Ecran with InputType
		
		// Check input and get its type
		if (taskAction.getInputAction() != null) {
			InputActionChoice inputActionChoice = taskAction.getInputAction().getInputActionChoice();
			if (inputActionChoice != null) {
				if (inputActionChoice.getInputChoice() != null) {
//					InputChoice inputChoice = inputActionChoice.getInputChoice();
					return "choice";
				} else if (inputActionChoice.getInputComputed() != null) {
					return null;
				} else if (inputActionChoice.getInputConstant() != null) {
					return null;
				} else if (inputActionChoice.getInputControlSap() != null) {
					return null;
				} else if (inputActionChoice.getInputDocument() != null) {
					return null;
				} else if (inputActionChoice.getInputField() != null) {
					InputField inputField = inputActionChoice.getInputField();
					InputType inputType = inputField.getType();
					return inputType.toString();
				} else if (inputActionChoice.getInputPicture() != null) {
					return null;
				} else if (inputActionChoice.getInputSap() != null) {
					return null;
				} else {
					return null;
				}
			}
		}
		
		return null;
	}


	@Override
	public String getSpecificGrammar() {
		return taskAction.getVoiceDescription() !=null ? taskAction.getVoiceDescription().getGrammar() : "";
	}
}
