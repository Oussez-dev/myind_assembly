package turbomeca.gamme.assembly.client.model.edit.wrappers;

import java.util.ArrayList;
import java.util.List;

import turbomeca.gamme.assembly.services.model.data.Conditions;
import turbomeca.gamme.assembly.services.model.data.Qualifications;
import turbomeca.gamme.assembly.services.model.data.References;
import turbomeca.gamme.assembly.services.model.data.State;
import turbomeca.gamme.assembly.services.model.data.SubPhase;
import turbomeca.gamme.assembly.services.model.data.Task;
import turbomeca.gamme.assembly.services.model.data.Tasks;
import turbomeca.gamme.assembly.services.model.data.TasksItem;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.model.edit.wrappers.IModelWrapperSubPhaseService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public class ModelWrapperSubPhaseService extends AModelWrapperAssemblyService implements IModelWrapperSubPhaseService, IModelInstanceIdWrapper {

	private SubPhase subPhase;

	public ModelWrapperSubPhaseService(SubPhase subPhase) {
		setSubPhase(subPhase);
	}

	@Override
	public Object getObject() {
		return subPhase;
	}

	/**
	 * @return the subPhase
	 */
	public SubPhase getSubPhase() {
		return subPhase;
	}

	/**
	 * @param subPhase
	 *            the subPhase to set
	 */
	public void setSubPhase(SubPhase subPhase) {
		this.subPhase = subPhase;
	}

	@Override
	public Qualifications getExecutionQualifications() {
		return getSubPhase().getQualifications();
	}

	@Override
	public Qualifications getValidationQualifications() {
		return getSubPhase().getQualifications();
	}

	@Override
	public State getState() {
		return getSubPhase().getState();
	}
	
	@Override
	public References getReferences() {
		return null;
	}
	
	@Override
	public Conditions getConditions() {
		return null;
	}
	
	@Override
	public void setPassingId(Integer passingId) {
		getSubPhase().setPassing(passingId);
	}

	@Override
	public Integer getPassingId() {
		return getSubPhase().getPassing();
	}

	@Override
	public String getId() {
		return getSubPhase().getId();
	}

	@Override
	public void setId(String id) {
		getSubPhase().setId(id);
	}
	
	
	public void setDisplayId(int position) {
		getSubPhase().setDisplayId(String.valueOf(position));
	}
	
	@Override
	public void addChild(IModelObjectService nextChild, IModelObjectService newChild)
			throws ClientException {
	}
	
	@Override
	public boolean isApplicable() {
		return getSubPhase().isApplicable();
	}

	@Override
	public void setApplicable(boolean applicable) {
		getSubPhase().setApplicable(applicable);
	}
	
	@Override
	public boolean isAlternative() {
		return getSubPhase().getIsAlternative();
	}

	@Override
	public void setAlternative(boolean isAlternative) {
		getSubPhase().setIsAlternative(isAlternative);
	}
	
	@Override
	public boolean isArchived() {
		return getSubPhase().getArchive();
	}
	
	@Override
	public void setArchived(boolean archive) {
		getSubPhase().setArchive(archive);
	}
	
	@Override
    public List<String> getPredecessors() {
        List<String> listId = new ArrayList<String>();
        for(Object subPhaseObject : getSubPhase().getPredecessors()) {
            listId.add(((SubPhase) subPhaseObject).getId());
        }
        return listId;
    }
	
	@Override
    public boolean isForcePredecessorsValid() {
        return getSubPhase().isForcePredecessorsValid();
    }
	
	/**
	 * @param task
	 */
	public void addTask(Task task) {
		Tasks tasks = subPhase.getTasks();
		if (tasks == null) {
			tasks = new Tasks();
		}
		TasksItem tasksItem = new TasksItem();
		tasksItem.setTask(task);
		tasks.addTasksItem(tasksItem);
	}

    @Override
    public int getInstanceId() {
        return getSubPhase().getInstance();
    }

    @Override
    public boolean hasInstanceId() {
        return getSubPhase().hasInstance();
    }

    @Override
    public void setForcePredecessorsValid(boolean valid) {
        getSubPhase().setForcePredecessorsValid(valid);
    }

    @Override
    public void setUnlockComment(String comment) {
        getSubPhase().setUnlockComment(comment);
    }
    
    public void setActivateComment(String comment){
    }

    @Override
    public boolean getDoubleSignature() {
        return false;
    }
    
    @Override
    public String getSapCommandType() {
        return getSubPhase().getSapCommand();
    }
    
	@Override
	public void setForceConditionsValid(boolean valid) {
	}
	
	@Override
	public void setValidConditionComment(String comment) {
	}

	@Override
	public String getComment() {
		return getSubPhase().getComment();
	}

	@Override
	public Object getDocumentJoined() {
		return null;
	}
}
