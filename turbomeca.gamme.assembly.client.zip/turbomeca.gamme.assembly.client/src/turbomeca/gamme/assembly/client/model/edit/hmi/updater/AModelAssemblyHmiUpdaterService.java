package turbomeca.gamme.assembly.client.model.edit.hmi.updater;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelResourcesService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskActionService;
import turbomeca.gamme.assembly.client.model.interfaces.IAssemblyModelHmiUpdaterService;
import turbomeca.gamme.ecran.client.model.edit.hmi.updater.AModelHmiUpdaterService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public abstract class AModelAssemblyHmiUpdaterService extends AModelHmiUpdaterService implements IAssemblyModelHmiUpdaterService  {

	private static final Logger logger = Logger.getLogger(AModelAssemblyHmiUpdaterService.class);
	
	private boolean hasPreviousTaskPara;

	@Override
	public String getXsltTemplateSynthesis() {
		return null;
	}

	@Override
	public boolean canFocus(IModelObjectService previousModelService, IModelObjectService nextModelService) {
		boolean focus = true;
		try {
			if(nextModelService != null){
				if (hasPreviousTaskPara) {
					focus = false;
				}
				if(focus){
					ModelResourcesService modelRessourceService = (ModelResourcesService) nextModelService.getAncestor(ModelResourcesService.class);
					if(modelRessourceService != null){
						focus = false;
					}
					if(nextModelService.getHmiUpdaterService() != null && nextModelService.getHmiUpdaterService().isModeTable()){
						focus = false;
					}
				}
				if(focus){
					String previousParentId = "";
					if (previousModelService != null && previousModelService.getParent() != null) {
						previousParentId = previousModelService.getParent().getIdentifier();
					}
					String nextParentId = nextModelService.getParent().getIdentifier();
					if (!previousParentId.equals(nextParentId)) {
						focus = false;
					} 
				}
				if (focus && previousModelService instanceof ModelTaskActionService){
					focus = ((ModelTaskActionService) previousModelService).canContinueNext();
				}
			}
		} catch(Exception e) {
			logger.error("Unable to compute canFocus", e);
			focus = false;
		}
		return focus;
	}

	/**
	 * @param hasPreviousTaskPara the hasPreviousTaskAction to set
	 */
	@Override
	public void setHasPreviousTaskPara(boolean hasPreviousTaskPara) {
		this.hasPreviousTaskPara = hasPreviousTaskPara;
	}
	
}
