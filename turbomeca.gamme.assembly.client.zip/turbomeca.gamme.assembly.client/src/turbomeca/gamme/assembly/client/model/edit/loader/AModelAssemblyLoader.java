package turbomeca.gamme.assembly.client.model.edit.loader;

import turbomeca.gamme.assembly.client.model.edit.ModelAssemblyServiceProvider;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskActionService;
import turbomeca.gamme.assembly.services.model.data.TaskAction;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.interfaces.IModelLoaderService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.model.provider.ModelXmlProvider;

public abstract class AModelAssemblyLoader extends ModelAssemblyServiceProvider implements IModelLoaderService {

    public AModelAssemblyLoader(IModelObjectService modelService) {
        super(modelService);
    }

    /**
     * 
     * @param modelProvider
     * @param uniqueId
     * @param taskAction
     * @throws ClientException
     * @throws ClientInterruption 
     */
    protected ModelTaskActionService loadTaskAction(ModelXmlProvider modelProvider, String parentId,
            TaskAction taskAction) throws ClientException, ClientInterruption {
        return loadTaskAction(modelProvider, parentId, taskAction, null, false);
    }

    /**
     * 
     * @param modelProvider
     * @param uniqueId
     * @param taskAction
     * @throws ClientException
     * @throws ClientInterruption 
     */
    protected ModelTaskActionService loadTaskAction(ModelXmlProvider modelProvider, String parentId,
            TaskAction taskAction, String type) throws ClientException, ClientInterruption {
        return loadTaskAction(modelProvider, parentId, taskAction, type, false);
    }

    /**
     * 
     * @param modelProvider
     * @param uniqueId
     * @param taskAction
     * @throws ClientException
     * @throws ClientInterruption 
     */
    protected ModelTaskActionService loadTaskAction(ModelXmlProvider modelProvider, String parentId,
            TaskAction taskAction, String type, boolean modeTable) throws ClientException, ClientInterruption {
        ModelTaskActionService taskActionService = null;
        if (taskAction != null) {
            taskActionService = new ModelTaskActionService(getModelService(), taskAction);
            taskActionService.getHmiUpdaterService().setHmiParentId(parentId);
            taskActionService.getLoaderService().load(modelProvider);
            taskActionService.setType(type);
            taskActionService.getHmiUpdaterService().setModeTable(modeTable);
            getModelService().addChild(taskActionService);
            modelProvider.addModelService(taskActionService.getIdentifier(), taskActionService);
        }
        return taskActionService;
    }
    
    @Override
    public void link() throws ClientException, ClientInterruption {
        for(IModelObjectService modelService : getModelService().getChildren()) {
            modelService.getLoaderService().link();
        }
    }
    
    @Override
    public void unlink() throws ClientException {
    }
}
