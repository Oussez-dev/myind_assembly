package turbomeca.gamme.assembly.client.model.edit.hmi.updater;

import turbomeca.gamme.assembly.services.constants.AssemblyXsltConstants;
import turbomeca.gamme.assembly.services.constants.ConstantsGenerationPDF;
import turbomeca.gamme.ecran.client.model.interfaces.IModelHmiUpdaterService;

public class ModelHmiUpdaterScheduleService extends AModelAssemblyHmiUpdaterService implements IModelHmiUpdaterService {

	@Override
	public String getXsltTemplate() {
		return AssemblyXsltConstants.XSLT_SCHEDULE.value();
	}

	@Override
	public int getXsltTemplatePdfType() {
		return ConstantsGenerationPDF.GENERATION_PDF_SCHEDULE	;
	}

    @Override
    public void setHmiParentId(String hmiParentId) {
    }

    @Override
    public String getHmiParentId() {
        return "";
    }

    @Override
    public boolean isModeTable() {
        return false;
    }

	@Override
	public void setModeTable(boolean tableMode) {
		// Nothing to do
	}
}
