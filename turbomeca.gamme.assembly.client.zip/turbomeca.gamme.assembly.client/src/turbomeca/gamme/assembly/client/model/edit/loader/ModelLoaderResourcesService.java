package turbomeca.gamme.assembly.client.model.edit.loader;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelIngredientsService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelMarksService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelResourcesService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelToolsService;
import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperResourcesService;
import turbomeca.gamme.assembly.services.model.data.Ingredients;
import turbomeca.gamme.assembly.services.model.data.Marks;
import turbomeca.gamme.assembly.services.model.data.Resources;
import turbomeca.gamme.assembly.services.model.data.Tools;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.interfaces.IModelLoaderService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.model.provider.ModelXmlProvider;

public class ModelLoaderResourcesService extends AModelAssemblyLoader implements
		IModelLoaderService {

	public ModelLoaderResourcesService(IModelObjectService modelService) {
		super(modelService);
	}

	@Override
	public ModelWrapperResourcesService getWrapperService() {
		return (ModelWrapperResourcesService) super.getWrapperService();
	}

	@Override
	public ModelResourcesService getModelService() {
		return (ModelResourcesService) super.getModelService();
	}

	public void load(ModelXmlProvider modelProvider) throws ClientException, ClientInterruption {
        Resources resources = getWrapperService().getResources();
        Ingredients ingredients = resources.getIngredients();
        if (ingredients != null) {
            ModelIngredientsService ingredientsService = new ModelIngredientsService(getModelService(), ingredients);
            ingredientsService.getLoaderService().load(modelProvider);
            getModelService().addChild(ingredientsService);
        }
        
        Tools tools = resources.getTools();
        if (tools != null) {
            ModelToolsService toolsService = new ModelToolsService(getModelService(), tools);
            toolsService.getLoaderService().load(modelProvider);
            getModelService().addChild(toolsService);
        }

        Marks marks = resources.getMarks();
        if (marks != null) {
            ModelMarksService marksService = new ModelMarksService(getModelService(), marks);
            marksService.getLoaderService().load(modelProvider);
            getModelService().addChild(marksService);
        }
        
        loadTaskAction(modelProvider, null, resources.getTaskAction());
        
        if (modelProvider != null) {
            modelProvider.addModelService(getModelService().getIdentifier(), getModelService());
        }
    }
}
