package turbomeca.gamme.assembly.client.model.edit.status;

import java.util.List;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelMarkService;
import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperMarkService;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.context.ContextRequest;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.services.common.utils.misc.FormatUtils;

public class ModelStatusMarkService extends ModelStatusService {

	/** logger for current class */
	private static Logger logger = Logger.getLogger(ModelStatusMarkService.class);

	public ModelStatusMarkService(IModelObjectService modelService) {
		super(modelService);
	}

	@Override
	public ModelWrapperMarkService getWrapperService() {
		return (ModelWrapperMarkService) super.getWrapperService();
	}

	@Override
	public ModelMarkService getModelService() {
		return (ModelMarkService) super.getModelService();
	}


	@Override
	public void clean(List<String> instancesId) throws ClientException, ClientInterruption {
		logger.debug("clean : " + getModelService() + "(" + FormatUtils.getStringValues(instancesId));
		getWrapperService().getMark().removeAllElectronicNotificationRef();
		if (getRequestContext().getRequestType() != ContextRequest.NEW_PASSING) {
			super.clean(instancesId);
		}
	}
}
