package turbomeca.gamme.assembly.client.model.edit.status;

import java.util.List;

import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public class ModelStatusNoneService extends ModelStatusService {

    public ModelStatusNoneService(IModelObjectService modelService) {
        super(modelService);
    }

    @Override
    public void initStatus() throws ClientException {
    }

    @Override
    public String getStatus() throws ClientException {
        return null;
    }

    @Override
    public String getStatus(String instanceId) throws ClientException {
        return null;
    }

    @Override
    public boolean isAlterable() throws ClientException {
        return true;
    }

    @Override
    public boolean isDuplicable() throws ClientException {
        return false;
    }

    @Override
    public boolean isInProgress() throws ClientException {
        return false;
    }

    @Override
    public void update() throws ClientException {
    }

    @Override
    public void setServiceModified() throws ClientException {
    }

    @Override
    public void clean(List<String> instancesId) throws ClientException, ClientInterruption {
    }

    @Override
    public void updateState(String status, boolean force, String comment, List<String> instancesId)
            throws ClientException {
    }

    @Override
    public void resetState(boolean recursively, boolean force, List<String> instancesId)
            throws ClientException {
    }

    @Override
    public void computeStatus(boolean recursively) throws ClientException {
    }

    @Override
    public void updateActivity(boolean recursively, boolean delete, List<String> instancesId)
            throws ClientException {
    }

    @Override
    public void disable(boolean recursively, List<String> instancesId) throws ClientException {
    }

    @Override
    public void enable(boolean recursively, List<String> instancesId) throws ClientException {
    }

    @Override
    public void setAlterable(List<String> instancesId) throws ClientException {
    }

    @Override
    public void reactive(boolean recursively, List<String> instancesId, boolean clean) throws ClientException {
    }

    @Override
    public void archive(int passing, int iterationId, List<String> instancesId)
            throws ClientException {
    }

    @Override
    public void setActive(boolean recursive, boolean delete, List<String> instancesId)
            throws ClientException {
    }

    @Override
    public void updateComment(String comment, List<String> instancesId) throws ClientException {
    }
}
