package turbomeca.gamme.assembly.client.model.edit.instructions;



import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.model.edit.AModelAssemblyService;
import turbomeca.gamme.assembly.client.model.edit.hmi.updater.ModelHmiUpdaterService;
import turbomeca.gamme.assembly.client.model.edit.loader.ModelLoaderTaskBenchSettingService;
import turbomeca.gamme.assembly.client.model.edit.runnable.ModelRunnableStatusDefaultService;
import turbomeca.gamme.assembly.client.model.edit.status.ModelStatusTaskBenchSettingService;
import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperTaskBenchSettingService;
import turbomeca.gamme.assembly.client.module.electronic.notification.action.ActionCreateElectronicNotificationTaskBench;
import turbomeca.gamme.assembly.client.module.electronic.notification.action.ActionDeleteElectronicNotificationTaskBench;
import turbomeca.gamme.assembly.client.module.electronic.notification.view.CreateElectronicNotificationTaskBenchView;
import turbomeca.gamme.assembly.services.model.data.TaskBenchSetting;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.edit.instructions.IModelTaskBenchSettingService;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.client.notifications.INotificationsChangedService;
import turbomeca.gamme.ecran.client.notifications.NotificationsServiceProvider;
import turbomeca.gamme.ecran.services.common.enumtypes.StatusType;


public class ModelTaskBenchSettingService extends AModelAssemblyService implements IModelTaskBenchSettingService {

	private static final Logger logger = Logger.getLogger(ModelTaskBenchSettingService.class);
	
	private static int PDF_DOCUMENT_INDEX = 0;
	private static int XML_DOCUMENT_INDEX = 1;

	public ModelTaskBenchSettingService(ModelSubPhaseService subPhaseService, TaskBenchSetting task) {
		super(subPhaseService.getDomain(), task.getId());
		setParent(subPhaseService);
		
		setWrapperService(new ModelWrapperTaskBenchSettingService(task));
		setLoaderService(new ModelLoaderTaskBenchSettingService(this));
		setHmiUpdaterService(new ModelHmiUpdaterService());
		setStatusService(new ModelStatusTaskBenchSettingService(this));
		setRunnableService(new ModelRunnableStatusDefaultService(this));
	}
	

	@Override
	public ModelWrapperTaskBenchSettingService getWrapperService() {
	    return (ModelWrapperTaskBenchSettingService) super.getWrapperService();
	}

	@Override
	public String getPdfFileName() throws ClientException {
		return getWrapperService().getDocumentFileName(PDF_DOCUMENT_INDEX);
	}
	
	@Override
	public void setPdfFile(String fileName) throws ClientException {
		 getWrapperService().setDocumentFileName(PDF_DOCUMENT_INDEX, fileName);
	}
	
	@Override
	public void clearPdfFile() throws ClientException {
		 getWrapperService().clearDocumentFileName(PDF_DOCUMENT_INDEX);
	}
	
	@Override
	public String getXmlFileName() throws ClientException {
		return getWrapperService().getDocumentFileName(XML_DOCUMENT_INDEX);
	}

	@Override
	public void setXmlFile(String fileName) throws ClientException {
		 getWrapperService().setDocumentFileName(XML_DOCUMENT_INDEX, fileName);	
	}
	
	@Override
	public void clearXmlFile() throws ClientException {
		 getWrapperService().clearDocumentFileName(XML_DOCUMENT_INDEX);
	}

	@Override
	public void setInternalStateAndUpdateTaskBenchStatus(IController controller, StatusType xmlStatus, boolean isOnlyPDF) throws ClientException, ClientInterruption {
		// DIRTY Start transcoding status enumeration from socle to the specific one from Assembly model
		turbomeca.gamme.assembly.services.model.data.types.StatusType internalState = null;
		
		String subPhaseId = getParent().getIdentifier();
		
		try {
			internalState = turbomeca.gamme.assembly.services.model.data.types.StatusType.fromValue(xmlStatus.value());
		} catch(IllegalArgumentException e) {
			logger.error("Unable to cast status type from string value", e);
			return;
		}
		
		getWrapperService().setInternalState(internalState);
		
		//in manual mode, if it's the pdf file that is to be updated then we should not create notifications
		if(!isOnlyPDF) {
			handleElectronicNotificationForTaskBench(controller, subPhaseId, internalState);
		}
		
		setServiceModified(true);
	}
	
	@Override
	public void setServiceModified(boolean notify) throws ClientException, ClientInterruption {
		getStatusService().computeStatus(false);
		if (notify) {
			getNotifications().notifyServiceChanged(this);
		}
		if (!getRunnableService().isFinished() && getParent().getStatusService().getStatus() != StatusType.TODO.value() && !getRunnableService().isOptional()) {
			getParent().getStatusService().resetState(false, true, null);
		}
	}
	
	/**
     * @return the notifications
     */
	@Override	
    public INotificationsChangedService getNotifications() {
        return NotificationsServiceProvider.getInstance();
    }


	public turbomeca.gamme.assembly.services.model.data.types.StatusType getInternalState() {
		return getWrapperService().getInternalState();
	}
	
	
	public void handleElectronicNotificationForTaskBench (IController controller, String subPhaseId, turbomeca.gamme.assembly.services.model.data.types.StatusType internalState) throws ClientException, ClientInterruption {
		controller.execute(new ActionDeleteElectronicNotificationTaskBench(subPhaseId));
		
		//if internalState is KO we have to created an electronic notification to noticed it
		if(internalState.equals(turbomeca.gamme.assembly.services.model.data.types.StatusType.KO)) {
			controller.execute(new ActionCreateElectronicNotificationTaskBench(subPhaseId));
			
			//display an acknowledgment modal to electronic notification if internalState is KO
			controller.execute(new CreateElectronicNotificationTaskBenchView(subPhaseId));
		}
	}
}
