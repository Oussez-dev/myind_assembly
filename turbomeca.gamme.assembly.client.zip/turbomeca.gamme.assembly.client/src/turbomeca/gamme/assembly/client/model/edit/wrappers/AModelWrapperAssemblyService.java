package turbomeca.gamme.assembly.client.model.edit.wrappers;

import java.util.List;

import turbomeca.gamme.assembly.client.model.edit.IModelAssemblyWrapperService;
import turbomeca.gamme.assembly.services.model.data.Conditions;
import turbomeca.gamme.assembly.services.model.data.Identification;
import turbomeca.gamme.assembly.services.model.data.Instanciation;
import turbomeca.gamme.assembly.services.model.data.Qualifications;
import turbomeca.gamme.assembly.services.model.data.References;
import turbomeca.gamme.assembly.services.model.data.State;
import turbomeca.gamme.assembly.services.model.data.User;
import turbomeca.gamme.assembly.services.model.data.UserMark;
import turbomeca.gamme.assembly.services.model.data.types.StatusType;
import turbomeca.gamme.ecran.client.config.Configuration;
import turbomeca.gamme.ecran.client.model.edit.wrappers.AModelWrapperService;
import turbomeca.gamme.ecran.services.model.utils.ModelDate;


public abstract class AModelWrapperAssemblyService extends AModelWrapperService implements IModelAssemblyWrapperService {

	@Override
	public Qualifications getExecutionQualifications() {
		return null;
	}

	@Override
	public Qualifications getValidationQualifications() {
		return null;
	}

	@Override
	public Conditions getConditions() {
		return null;
	}

	@Override
	public References getReferences() {
		return null;
	}
	
	@Override
	public State getState() {
		return null;
	}
	
	@Override
	public Instanciation getInstantiation() {
		return null;
	}
	
	@Override
	public Identification getIdentification() {
		return null;
	}

	@Override
    public List<String> getPredecessors() {
        return null;
    }
	
	@Override
    public boolean isForcePredecessorsValid() {
        return false;
    }
	
	/**
	 * 
	 * @param status
	 * @return
	 */
	public static State buildState(StatusType status) {
		State state = new State();
		state.setStatus(status);
		state.setUserMark(buildUserMark());
		return state;
	}
	
	/**
	 * 
	 * @param config
	 * @return
	 */
	public static UserMark buildUserMark() {
		Configuration configuration = getConfiguration();
		User user = new User();
		user.setLogin(configuration.getConfigUser().getUserLogin());
		user.setName(configuration.getConfigUser().getUserName());

		UserMark userMark = new UserMark();
		userMark.setDateTime(ModelDate.getInstance().getComputedDate());
		userMark.setUser(user);
		return userMark;
	}
	
	/**
	 * @return the configuration
	 */
	public static Configuration getConfiguration() {
		return Configuration.getInstance();
	}
}
