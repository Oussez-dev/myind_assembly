package turbomeca.gamme.assembly.client.model.edit.loader;

import java.util.Enumeration;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelIngredientsService;
import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperIngredientsService;
import turbomeca.gamme.assembly.services.model.data.Ingredient;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.interfaces.IModelLoaderService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.model.provider.ModelXmlProvider;

public class ModelLoaderIngredientsService extends AModelAssemblyLoader implements
		IModelLoaderService {

	public ModelLoaderIngredientsService(IModelObjectService modelService) {
		super(modelService);
	}

	@Override
	public ModelWrapperIngredientsService getWrapperService() {
		return (ModelWrapperIngredientsService) super.getWrapperService();
	}

	@Override
	public ModelIngredientsService getModelService() {
		return (ModelIngredientsService) super.getModelService();
	}

	public void load(ModelXmlProvider modelProvider) throws ClientException, ClientInterruption {
        Enumeration<? extends Ingredient> enumIngredients = getWrapperService().getIngredients().enumerateIngredient();
        while (enumIngredients.hasMoreElements()) {
            Ingredient ingredient = enumIngredients.nextElement();
            String ingredientId = ingredient.getUniqueId() + "_" 
            + getModelService().getParent().getParent().getIdentifier();
            loadTaskAction(modelProvider, ingredientId, ingredient.getTaskAction());
        }
        if (modelProvider != null) {
            modelProvider.addModelService(getModelService().getIdentifier(), getModelService());
        }
    }

	@Override
	public void link() throws ClientException {
	}
}
