package turbomeca.gamme.assembly.client.model.edit.status;

import java.util.List;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.model.edit.schedule.AAssemblyScheduleService;
import turbomeca.gamme.assembly.services.model.data.types.StatusType;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.context.Context;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public class ModelStatusScheduleService extends ModelStatusService {

	/** logger for current class */
	private static Logger logger = Logger.getLogger(ModelStatusScheduleService.class);
	
	public ModelStatusScheduleService(IModelObjectService modelService) {
		super(modelService);
	}

	@Override
	public AAssemblyScheduleService getModelService() {
		return (AAssemblyScheduleService) super.getModelService();
	}
	
	@Override
	public void updateState(String status, boolean force, String comment, List<String> instancesId)
			throws ClientException, ClientInterruption {
		logger.debug("updateState " + status + " (" + instancesId + ") : " + getModelService());
		getStatusBuilder().setState(StatusType.valueOf(status), comment, force, instancesId);
		setServiceModified();
		Context.getInstance().getContextRange().setStatus(getStatus());
	}
	
	@Override
	public void resetState(boolean recursively, boolean force, List<String> instancesId) throws ClientException, ClientInterruption {
		logger.debug("resetState (" + instancesId + ") : " + getModelService());
		super.resetState(recursively, force, instancesId);
		Context.getInstance().getContextRange().setStatus(getStatus());
	}
}
