package turbomeca.gamme.assembly.client.model.edit.loader;

import java.util.Enumeration;

import turbomeca.gamme.assembly.client.model.edit.instructions.AModelTaskActionService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskActionMeasureService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskActionService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskActionTableService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskPilotingService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskService;
import turbomeca.gamme.assembly.client.model.edit.provider.ModelMarkProvider;
import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperTaskService;
import turbomeca.gamme.assembly.client.model.interfaces.IAssemblyModelHmiUpdaterService;
import turbomeca.gamme.assembly.services.model.data.Entry;
import turbomeca.gamme.assembly.services.model.data.PN;
import turbomeca.gamme.assembly.services.model.data.QuantityPn;
import turbomeca.gamme.assembly.services.model.data.Row;
import turbomeca.gamme.assembly.services.model.data.TaskAction;
import turbomeca.gamme.assembly.services.model.data.TaskActionTable;
import turbomeca.gamme.assembly.services.model.data.TaskChoice;
import turbomeca.gamme.assembly.services.model.data.TaskChoiceItem;
import turbomeca.gamme.assembly.services.model.data.TaskMark;
import turbomeca.gamme.assembly.services.model.data.Tbody;
import turbomeca.gamme.assembly.services.model.data.Tfoot;
import turbomeca.gamme.assembly.services.model.data.Tgroup;
import turbomeca.gamme.assembly.services.model.data.Thead;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.edit.loader.ModelLoaderContext;
import turbomeca.gamme.ecran.client.model.interfaces.IModelLoaderService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.model.provider.ModelXmlProvider;

public class ModelLoaderTaskService extends AModelAssemblyLoader implements IModelLoaderService {

	public ModelLoaderTaskService(IModelObjectService modelService) {
		super(modelService);
	}

	@Override
	public ModelWrapperTaskService getWrapperService() {
		return (ModelWrapperTaskService) super.getWrapperService();
	}
	
	@Override
	public ModelTaskService getModelService() {
		return (ModelTaskService) super.getModelService();
	}

	/***
	 * Technical note:
	 * 
	 * Beware when adding any service holding an input (like a
	 * taskActionService), its associated HmiUpdaterService must be informed
	 * about a taskPara presence immediately before (see for example
	 * taskActionService.getHmiUpdaterService().setHasPreviousTaskPara(getModelLoaderContext().hasPreviousPara()); )
	 * 
	 * This is required to correctly determines if the focus engine can go next instruction or not.
	 */
	@Override
	public void load(ModelXmlProvider modelProvider) throws ClientException, ClientInterruption {
	    TaskChoice taskChoice = getWrapperService().getTask().getTaskChoice();
	    if (taskChoice != null) {
    		Enumeration<? extends TaskChoiceItem> enumTaskChoice = taskChoice.enumerateTaskChoiceItem();
    		while (enumTaskChoice.hasMoreElements()) {
    		    TaskChoiceItem taskChoiceItem = enumTaskChoice.nextElement();
    		    if (taskChoiceItem.getTaskAction() != null) {
        			AModelTaskActionService taskActionService = new ModelTaskActionService(getModelService(), taskChoiceItem.getTaskAction());
        			taskActionService.getLoaderService().load(modelProvider);
        			taskActionService.getHmiUpdaterService().setHasPreviousTaskPara(getModelLoaderContext().hasPreviousPara());
        			getModelService().addChild(taskActionService);
        			getModelLoaderContext().setHasPreviousPara(false);
    		    }
    		    else if(taskChoiceItem.getTaskActionMeasure() != null) {
    		        ModelTaskActionMeasureService taskMeasureService = new ModelTaskActionMeasureService(getModelService(), taskChoiceItem.getTaskActionMeasure());
    		        taskMeasureService.getLoaderService().load(modelProvider);
    		        taskMeasureService.getHmiUpdaterService().setHasPreviousTaskPara(getModelLoaderContext().hasPreviousPara());
                    getModelService().addChild(taskMeasureService);
                    getModelLoaderContext().setHasPreviousPara(false);
    		    }
    		    else if(taskChoiceItem.getTaskPiloting() != null) {
                    ModelTaskPilotingService taskPilotingService = new ModelTaskPilotingService(getModelService(), taskChoiceItem.getTaskPiloting());
                    taskPilotingService.getLoaderService().load(modelProvider);
                    taskPilotingService.getHmiUpdaterService().setHasPreviousTaskPara(getModelLoaderContext().hasPreviousPara());
                    getModelService().addChild(taskPilotingService);
                    getModelLoaderContext().setHasPreviousPara(false);
                }
    		    else if(taskChoiceItem.getTaskActionTable() != null) {
    		    	ModelTaskActionTableService taskActionTableService = new ModelTaskActionTableService(getModelService(), taskChoiceItem.getTaskActionTable());
    		        taskActionTableService.getLoaderService().load(modelProvider);
    		        getModelService().addChild(taskActionTableService);
    		        
    		        TaskActionTable taskActionTable = taskActionTableService.getWrapperService().getTaskActionTable();
    		        String subPhaseId = getModelService().getParent().getIdentifier();
    		        loadTaskActionTable(modelProvider, taskActionTable, subPhaseId);
    		    }
    		    else if(taskChoiceItem.getTaskMark() != null) {
    		    	TaskMark taskMark = taskChoiceItem.getTaskMark();
    		        ModelMarkProvider.getInstance().addTaskMarkReference(taskMark);
    		        Enumeration<? extends PN>  enumPn = taskMark.enumeratePN();
    		        while(enumPn.hasMoreElements()) {
    		            PN pn = enumPn.nextElement();
    		            if (pn.getTaskAction() != null) {
    		            	ModelTaskActionService taskActionService = new ModelTaskActionService(getModelService(), pn.getTaskAction());
        	                taskActionService.getLoaderService().load(modelProvider);
        	                taskActionService.getWrapperService().setTaskMarkParent(taskMark);
        	                getModelService().addChild(taskActionService);
    		            }
    		        }
    		        Enumeration<? extends QuantityPn>  enumQuantity = taskChoiceItem.getTaskMark().enumerateQuantityPn();
                    while(enumQuantity.hasMoreElements()) {
                        QuantityPn quantity = enumQuantity.nextElement();
                        if (quantity.getTaskAction() != null) {
                            AModelTaskActionService taskActionService = new ModelTaskActionService(getModelService(), quantity.getTaskAction());
                            taskActionService.getLoaderService().load(modelProvider);
                            ((IAssemblyModelHmiUpdaterService) taskActionService.getHmiUpdaterService()).setModeTable(true);
                            taskActionService.getHmiUpdaterService().setHasPreviousTaskPara(getModelLoaderContext().hasPreviousPara());
                            getModelLoaderContext().setHasPreviousPara(false);
                            taskActionService.getWrapperService().setTaskMarkParent(taskMark);
                            getModelService().addChild(taskActionService);
                        }
                    }
                    if(taskChoiceItem.getTaskMark().getTaskAction() != null) {
    	                ModelTaskActionService taskActionService = loadTaskAction(modelProvider, null, taskChoiceItem.getTaskMark().getTaskAction());
    	                taskActionService.getWrapperService().setTaskMarkParent(taskMark);
    	                taskActionService.getHmiUpdaterService().setHasPreviousTaskPara(getModelLoaderContext().hasPreviousPara());
                    }
                    getModelLoaderContext().setHasPreviousPara(true);
                }
    		    else if (taskChoiceItem.getTaskPara() != null) {
    		        getModelLoaderContext().setHasPreviousPara(true);
    		    }
    		}
	    }
	    // Also add in ModelProvider Task holding nothing (or only pictures/taskDetails, etc..)
	    if (modelProvider != null && getModelService()!=null) {
			modelProvider.addModelService(getModelService().getIdentifier(), getModelService());
		}
	}
	
    private void loadTaskActionTable(ModelXmlProvider modelProvider, TaskActionTable taskActionTable, String subPhaseId) throws ClientException, ClientInterruption {
        if (taskActionTable != null) {
            Enumeration<?> enumGroup = taskActionTable.enumerateTgroup();
            while (enumGroup.hasMoreElements()) {
                Tgroup tGroup = (Tgroup) enumGroup.nextElement();
                Thead tHead = tGroup.getThead();
                if (tHead != null) {
                    loadRows(modelProvider, tHead.enumerateRow(), subPhaseId);
                }
                Tbody tBody = tGroup.getTbody();
                if (tBody != null) {
                    loadRows(modelProvider, tBody.enumerateRow(), subPhaseId);
                }
                Tfoot tFoot = tGroup.getTfoot();
                if (tFoot != null) {
                    loadRows(modelProvider, tFoot.enumerateRow(), subPhaseId);
                }
            }
        }
    }

    /**
     * 
     * @param modelProvider
     * @param enumerateRow
     * @throws ClientException
     * @throws ClientInterruption 
     */
    private void loadRows(ModelXmlProvider modelProvider, Enumeration<? extends Row> enumerateRow, String subPhaseId)
            throws ClientException, ClientInterruption {
        while (enumerateRow.hasMoreElements()) {
            Row row = (Row) enumerateRow.nextElement();
            Enumeration<?> enumEntry = row.enumerateEntry();
            while (enumEntry.hasMoreElements()) {
                Entry rowItem = (Entry) enumEntry.nextElement();
                for (TaskAction taskAction : rowItem.getTaskAction()) {
                    if (taskAction != null) {
                        AModelTaskActionService taskActionService = new ModelTaskActionService(getModelService(), taskAction);
                        taskActionService.getWrapperService().setEntryParent(rowItem);
                        IAssemblyModelHmiUpdaterService hmiUpdater = (IAssemblyModelHmiUpdaterService) taskActionService.getHmiUpdaterService();
                        hmiUpdater.setHmiParentId(row.getId() + "_" + subPhaseId);
                        hmiUpdater.setHasPreviousTaskPara(getModelLoaderContext().hasPreviousPara());
                        hmiUpdater.setModeTable(true);
                        
                        taskActionService.getLoaderService().load(modelProvider);
                        getModelService().addChild(taskActionService);
                        getModelLoaderContext().setHasPreviousPara(false);
                    }
                }
            }
        }
    }
    
    public void loadTaskAction(ModelXmlProvider modelProvider, TaskAction taskAction) throws ClientException, ClientInterruption {
        loadTaskAction(modelProvider, null, taskAction);
    }
    
    /**
     * @return the context loader
     */
    public ModelLoaderContext getModelLoaderContext() {
        return ModelLoaderContext.getInstance();
    }
}
