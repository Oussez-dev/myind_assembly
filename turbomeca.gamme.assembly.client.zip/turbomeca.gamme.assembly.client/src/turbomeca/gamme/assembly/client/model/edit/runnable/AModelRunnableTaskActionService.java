package turbomeca.gamme.assembly.client.model.edit.runnable;

import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperTaskActionService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public class AModelRunnableTaskActionService extends ModelRunnableStatusDefaultService {

	public AModelRunnableTaskActionService(IModelObjectService modelService) {
		super(modelService);
	}

	@Override
	public ModelWrapperTaskActionService getWrapperService() {
		return (ModelWrapperTaskActionService) super.getWrapperService();
	}

	@Override
	public boolean isRunnable() {
		return getWrapperService().isApplicable() && !getWrapperService().getTaskAction().isOptionnalTools();
	}

	@Override
	public boolean isValidable() {
		return true;
	}
	
	@Override
	public boolean canRun() {
		return (getWrapperService().getTaskAction().getInputAction().getInputActionChoice()
				.getInputComputed() == null) && super.canRun();
	}
	
	
}
