package turbomeca.gamme.assembly.client.model.edit.utils;

import java.util.List;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelIngredientsService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelMarkService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelResourcesService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelToolService;
import turbomeca.gamme.assembly.client.model.edit.schedule.AAssemblyScheduleService;
import turbomeca.gamme.assembly.services.model.data.InputAction;
import turbomeca.gamme.assembly.services.model.data.InputChoice;
import turbomeca.gamme.assembly.services.model.data.InputValue;
import turbomeca.gamme.assembly.services.model.data.Mark;
import turbomeca.gamme.assembly.services.model.data.State;
import turbomeca.gamme.assembly.services.model.data.StringValue;
import turbomeca.gamme.assembly.services.model.data.SubPhase;
import turbomeca.gamme.assembly.services.model.data.Task;
import turbomeca.gamme.assembly.services.model.data.TaskAction;
import turbomeca.gamme.assembly.services.model.data.User;
import turbomeca.gamme.assembly.services.model.data.UserMark;
import turbomeca.gamme.assembly.services.model.data.UserMarkValidation;
import turbomeca.gamme.assembly.services.model.data.types.StatusType;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.config.Configuration;
import turbomeca.gamme.ecran.client.constants.PropertyConstants;
import turbomeca.gamme.ecran.client.model.edit.instructions.IModelSubPhaseService;
import turbomeca.gamme.ecran.client.model.edit.instructions.IModelTaskActionService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.model.provider.ModelXmlProvider;
import turbomeca.gamme.ecran.services.model.utils.ModelDate;

public class ModelUtils extends turbomeca.gamme.ecran.client.model.edit.utils.ModelUtils {
	
	private static final Logger logger = Logger.getLogger(ModelUtils.class);
	
	/**
	 * 
	 * @param status
	 * @return
	 */
	public static String getPropertyStatusKey(StatusType status) {
		String key = "";
		switch (status) {
		case OK:
			key = PropertyConstants.PROPERTY_LABEL_STATUS_CONFORM;
			break;
		case KO:
			key = PropertyConstants.PROPERTY_LABEL_STATUS_NOT_CONFORM;
			break;
		case TODO:
			key = PropertyConstants.PROPERTY_LABEL_STATUS_TODO;
			break;
		case NOT_TODO:
			key = PropertyConstants.PROPERTY_LABEL_STATUS_NOT_TODO;
			break;
		case DONE:
			key = PropertyConstants.PROPERTY_LABEL_STATUS_DONE;
			break;
		default:
			break;
		}
		return key;
	}

	public static boolean equals(InputValue inputValue1, InputValue inputValue2) {
		boolean equals = false;
		if (inputValue1 != null && inputValue2 != null) {
			equals = (	inputValue1.getValue().equals(inputValue2.getValue()) 
					&& inputValue1.getUserMark().getUser().getLogin().equals(inputValue2.getUserMark().getUser().getLogin()));
		}
		return equals;
	}


	public static String getTextValue(String value, InputAction inputAction) {
		InputChoice inputChoice = inputAction.getInputActionChoice().getInputChoice();
		if (inputChoice != null && value != null) {
			int index = Integer.valueOf(value) - 1;
			if (inputChoice.getItemParaCount() != 0) {
				if(inputChoice.getItemPara(index).getParaCount() > 0 ) {
					value = inputChoice.getItemPara(index).getPara(0).getContent(); 
				} else {
					// This should never be raised on a real schedule (means a combo generated with empty itemPara children)
					// But may occurs on DEV or debug 
					logger.warn("Invalid inputChoice itemPara content!");
					value = "";
				}
			} else if (inputChoice.getStringValueCount() != 0) {
				value = inputChoice.getStringValue(index).getContent();
			} else if (inputChoice.getValCount() != 0) {
				value = inputChoice.getVal(index).toString();
			}
		}
		return value;
	}

	public static UserMark buildUserMark() {
		Configuration configuration = Configuration.getInstance();
		User user = new User();
		user.setLogin(configuration.getConfigUser().getUserLogin());
		user.setName(configuration.getConfigUser().getUserName());

		UserMark userMark = new UserMark();
		userMark.setDateTime(ModelDate.getInstance().getComputedDate());
		userMark.setUser(user);
		return userMark;
	}
	
	
	public static UserMarkValidation buildUserMarkValidation(String login, String name) {
		User user = new User();
		user.setLogin(login);
		user.setName(name);

		UserMarkValidation userMark = new UserMarkValidation();
		userMark.setDateTime(ModelDate.getInstance().getComputedDate());
		userMark.setUser(user);
		return userMark;
	}
	
	public static void initState(State state) {
		state.setStatus(StatusType.TODO);
		state.setUserMark(buildUserMark());
	}
	
    public static boolean isCurrentUser(UserMark userMark) {
        Configuration configuration = Configuration.getInstance();
        boolean isCurrentUser = false;
        try {
            if (userMark != null) {
                if (userMark.getUser().getLogin().equals(configuration.getConfigUser().getUserLogin())) {
                    isCurrentUser = true;
                }
            }
        } catch (Exception e) {
            isCurrentUser = false;
        }
        return isCurrentUser;
    }
    
	/**
	 * 
	 * @param modelProvider
	 * @param referenceObject
	 * @return
	 */
	public static IModelObjectService getModelServiceReferenced(ModelXmlProvider modelProvider, Object referenceObject) {
		IModelObjectService modelService = null;
		if (referenceObject instanceof TaskAction) {
			modelService = modelProvider.getModelService(((TaskAction) referenceObject).getId());
		} else if (referenceObject instanceof Task) {
			modelService = modelProvider.getModelService(((Task) referenceObject).getId());
		} else if (referenceObject instanceof SubPhase) {
			modelService = modelProvider.getModelService(((SubPhase) referenceObject).getId());
		} else if (referenceObject instanceof Mark) {
            modelService = modelProvider.getModelService(((Mark) referenceObject).getId());
        }
		return modelService;
	}
	
	/**
	 * Check reference applicability
	 * @param refId
	 * @param level
	 * @return
	 * @throws ClientException
	 */
	public static boolean isReferenceApplicable(Object refId, String level, List<IModelObjectService> referencesList) throws ClientException {
		IModelObjectService referenceService = ModelUtils.getModelServiceReferenced(ModelXmlProvider.getInstance(), refId);
		ModelSubPhaseService subPhaseService = (ModelSubPhaseService)getSubPhaseParent(referenceService);
		if (!subPhaseService.isLevelApplicable(level)) {
			return false;
		} else {
			if (referencesList.contains(subPhaseService)) {
				referencesList.add(subPhaseService);
			}
		}
		
		return true;
	}
	
	/**
	 * Get subPhase parent
	 * @param modelService the current service
	 * @return associated subPhase parent
	 * @throws ClientException
	 */
	public static IModelSubPhaseService getSubPhaseParent(IModelObjectService modelService) {
	    IModelSubPhaseService subPhaseParent = null;
		if (modelService != null) {
			if(modelService instanceof ModelSubPhaseService) {
			    subPhaseParent = (ModelSubPhaseService) modelService;
			} else {
			    subPhaseParent = getSubPhaseParent(modelService.getParent());
			}
		}
		return subPhaseParent;
	}

	/**
	 * 
	 * @param taskActionService
	 * @return
	 */
    public static boolean isResourcesAction(IModelTaskActionService taskActionService) {
        IModelObjectService parentService = taskActionService.getParent();
        return (    parentService instanceof ModelMarkService
                || parentService instanceof ModelToolService
                || parentService instanceof ModelResourcesService
                || parentService instanceof ModelIngredientsService
                || parentService instanceof AAssemblyScheduleService);
    }
    
    /**
     * Add current value on inputchoice
     * @param inputChoice
     * @param taskActionWithValue contain the value
     */
    public static void addCurrentValue(TaskAction taskActionInputChoice, TaskAction taskActionWithValue) {
    	boolean hasValue = false;
    	if (taskActionWithValue == null || taskActionWithValue.getInputAction() == null || taskActionWithValue.getInputAction().getInputValue() == null || taskActionWithValue.getInputAction().getInputValue().getValue() == null
    			|| taskActionInputChoice == null || taskActionInputChoice.getInputAction() == null || taskActionInputChoice.getInputAction().getInputActionChoice() == null
    			|| taskActionInputChoice.getInputAction().getInputActionChoice().getInputChoice() == null) {
    		return;
    	}
    	String value = taskActionWithValue.getInputAction().getInputValue().getValue();
    	if(taskActionWithValue.getInputAction().getInputActionChoice() != null && taskActionWithValue.getInputAction().getInputActionChoice().getInputChoice() != null) {
    		value = taskActionWithValue.getInputAction().getInputActionChoice().getInputChoice().getStringValue()[Integer.parseInt(taskActionWithValue.getInputAction().getInputValue().getValue()) - 1].getContent();
    	}
    	InputChoice inputChoice = taskActionInputChoice.getInputAction().getInputActionChoice().getInputChoice();
    	Integer count = 0;
    	for (StringValue currentValue : inputChoice.getStringValue()) {
    		count = count + 1;
    		if (value.equals(currentValue.getContent())) {
    			hasValue = true;
    			break;
    		}
    	}
    	InputValue inputValue = new InputValue();
    	inputValue.setUserMark(ModelUtils.buildUserMark());
    	if (!hasValue) {
    		StringValue newValue = new StringValue();
    		newValue.setContent(value);
    		inputChoice.addStringValue(newValue);
			inputValue.setValue(Integer.toString(inputChoice.getStringValueCount()));
    	} else {
			inputValue.setValue(count.toString());
    	}
    	taskActionInputChoice.getInputAction().setInputValue(inputValue);
    }
}
