package turbomeca.gamme.assembly.client.model.edit.status;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelResourcesService;
import turbomeca.gamme.assembly.services.model.data.types.StatusType;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public class ModelStatusResourcesService extends ModelStatusService {

	public ModelStatusResourcesService(IModelObjectService modelObjectService) {
		super(modelObjectService);
	}

	@Override
	public void computeStatus(boolean recursively) throws ClientException,
	ClientInterruption {
		if (getWrapperService().getState() != null) {
			String status = StatusType.DONE.value();
				for (IModelObjectService service : getModelService().getChildren()) {
					if(!service.getRunnableService().isFinished()
							&& !service.getRunnableService().isOptional()) {
						status = StatusType.TODO.value();
						break;
					}
				}
			updateState(status, false, null, null);
		}
	}
	
	
	
	@Override
	public boolean isInProgress() throws ClientException {
		boolean isInProgressResources =super.isInProgress();
		ModelResourcesService resourcesService = (ModelResourcesService) getModelService();
		return isInProgressResources && resourcesService.hasCheck();
	}
	
	
}
