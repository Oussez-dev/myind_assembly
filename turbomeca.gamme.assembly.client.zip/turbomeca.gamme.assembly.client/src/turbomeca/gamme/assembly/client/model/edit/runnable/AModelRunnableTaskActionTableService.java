package turbomeca.gamme.assembly.client.model.edit.runnable;

import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public abstract class AModelRunnableTaskActionTableService extends ModelRunnableStatusDefaultService {

	public AModelRunnableTaskActionTableService(IModelObjectService modelService) {
		super(modelService);
	}

	@Override
	public boolean isRunnable() {
		return getWrapperService().isApplicable();
	}

	@Override
	public boolean isValidable() {
		return true;
	}
	
	@Override
	public boolean canRun() {
		return true;
	}
}
