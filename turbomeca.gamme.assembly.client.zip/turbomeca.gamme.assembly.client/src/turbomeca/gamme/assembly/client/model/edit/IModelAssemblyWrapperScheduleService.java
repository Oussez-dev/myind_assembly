package turbomeca.gamme.assembly.client.model.edit;

import turbomeca.gamme.assembly.services.model.data.Compounds;
import turbomeca.gamme.assembly.services.model.data.DerogationMarks;
import turbomeca.gamme.assembly.services.model.data.DeviationsFromRef;
import turbomeca.gamme.assembly.services.model.data.ElectronicPostIt;
import turbomeca.gamme.assembly.services.model.data.Historical;
import turbomeca.gamme.assembly.services.model.data.Identification;
import turbomeca.gamme.assembly.services.model.data.Instanciation;
import turbomeca.gamme.assembly.services.model.data.ObjectsToSynchronize;
import turbomeca.gamme.assembly.services.model.data.Operations;
import turbomeca.gamme.assembly.services.model.data.Parameters;
import turbomeca.gamme.assembly.services.model.data.PostGeneralities;
import turbomeca.gamme.assembly.services.model.data.PreGeneralities;
import turbomeca.gamme.assembly.services.model.data.Rework;
import turbomeca.gamme.ecran.client.model.edit.wrappers.IModelWrapperScheduleServiceWithPassingHistory;

public interface IModelAssemblyWrapperScheduleService extends IModelAssemblyWrapperService, IModelWrapperScheduleServiceWithPassingHistory {
	
	@Override
	public Identification getIdentification();

	public Historical getHistorical();

	@Override
	public Instanciation getInstantiation();
	
	public DerogationMarks getDerogationMarks();
	
	public void setDerogationMarks(DerogationMarks derogationMarks);
	
	public ElectronicPostIt getElectronicPostIt();

	public void setElectronicPostIt(ElectronicPostIt electronicPostIt);

	public Parameters getParameters();
	
	public Operations getOperations();
	
	public Rework getRework();
	
	public Compounds getCompounds();
	
	public PreGeneralities getPreGenerality();
	
	public PostGeneralities getPostGenerality();
	
	public void setObject(Object schedule);
	
	public DeviationsFromRef[] getDeviationFromRef();
	
	public ObjectsToSynchronize getObjectsToSynchronize();
	
	public void setObjectsToSynchronize(ObjectsToSynchronize objectsToSynchronize);
	
	public void updateObjectsToSynchronize(String idObjectToSynchronize, String synchronizeAction, String objectType);

	public boolean loadHistoricalPassing();
	
	public boolean hasDifferences();

}
