package turbomeca.gamme.assembly.client.model.edit.wrappers;

import java.text.SimpleDateFormat;
import java.util.Date;

import turbomeca.gamme.assembly.services.model.data.Conditions;
import turbomeca.gamme.assembly.services.model.data.Para;
import turbomeca.gamme.assembly.services.model.data.Qualifications;
import turbomeca.gamme.assembly.services.model.data.References;
import turbomeca.gamme.assembly.services.model.data.State;
import turbomeca.gamme.assembly.services.model.data.Task;
import turbomeca.gamme.assembly.services.model.data.TaskChoiceItem;
import turbomeca.gamme.assembly.services.model.data.TaskParaTypeItem;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.model.edit.wrappers.IModelWrapperTaskService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public class ModelWrapperTaskService extends AModelWrapperAssemblyService implements IModelInstanceIdWrapper, IModelWrapperTaskService {

	private static final String PREFIX_TASK_ID	= "task";
	private static final String PREFIX_TASK_ACTION_ID	= "taskAction";
	private static final String PREFIX_ID_INDICATION	= "Indic";

	public static final String DATE_FORMAT_FILENAME = "ddMMyyyyHHmmss";

	/** Task object */
	private Task task;

	/**
	 * Constructor for task object
	 * 
	 * @param subPhaseService
	 *            parent service
	 * @param task
	 *            task object
	 */
	public ModelWrapperTaskService(Task task) {
		setTask(task);
	}

	@Override
	public Object getObject() {
		return task;
	}

	/**
	 * @param task
	 *            the task to set
	 */
	public void setTask(Task task) {
		this.task = task;
	}

	/**
	 * @return the task
	 */
	public Task getTask() {
		return task;
	}

	@Override
	public Qualifications getExecutionQualifications() {
		return getTask().getQualifications();
	}

	@Override
	public Qualifications getValidationQualifications() {
		return null;
	}

	@Override
	public References getReferences() {
		return getTask().getReferences();
	}

	@Override
	public Conditions getConditions() {
		return getTask().getConditions();
	}

	@Override
	public State getState() {
		return getTask().getState();
	}

	@Override
	public void setPassingId(Integer passingId) {
		getTask().setPassing(passingId);
	}

	@Override
	public Integer getPassingId() {
		return getTask().getPassing();
	}

	@Override
	public boolean isActive() {
		return getTask().isActive();
	}

	@Override
	public void setActive(boolean isActive) {
		getTask().setActive(isActive);
	}

	@Override
	public String getId() {
		return getTask().getId();
	}

	@Override
	public void setId(String id) {
		getTask().setId(id);
	}

	@Override
	public void addChild(IModelObjectService nextChild, IModelObjectService newChild)
			throws ClientException {
	}

	/**
	 * @return
	 */
	public static String generateIdTask() {
		SimpleDateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT_FILENAME);
		String idGenerator = dateFormat.format(new Date().getTime());
		return PREFIX_TASK_ID.concat(PREFIX_ID_INDICATION).concat(idGenerator);
	}

	/**
	 * @return
	 */
	public static String generateIdTaskAction() {
		SimpleDateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT_FILENAME);
		String idGenerator = dateFormat.format(new Date().getTime());
		return PREFIX_TASK_ACTION_ID.concat(PREFIX_ID_INDICATION).concat(idGenerator);
	}

	@Override
	public int getInstanceId() {
		return getTask().getInstance();
	}

	@Override
	public boolean hasInstanceId() {
		return getTask().hasInstance();
	}

	@Override
	public void setForceConditionsValid(boolean valid) {
		//do nothing on assembly
	}

	@Override
	public void setValidConditionComment(String comment) {
		//do nothing on assembly
	}

	@Override
	public String getValue() {
		String value = "Valeur par défaut";
		Task ta = task;

		if(ta.getTaskChoice() !=null) {
			TaskChoiceItem[] taChoiceItems = ta.getTaskChoice().getTaskChoiceItem();
			if(taChoiceItems != null) {
				for(TaskChoiceItem taChoiceItem : taChoiceItems){
					if(taChoiceItem.getTaskPara() != null){
						TaskParaTypeItem[] taskParaTypeItems = taChoiceItem.getTaskPara().getTaskParaTypeItem();
						if(taskParaTypeItems != null){
							for(TaskParaTypeItem taskParaTypeItem : taskParaTypeItems){
								Para para = taskParaTypeItem.getPara();
								if(para != null){
									String content = para.getContent();
									if(content != null && content != ""){
										return content;
									}
								}
							}
						}

					}
				}	
			}
		}
		return value;
	}
}
