package turbomeca.gamme.assembly.client.model.edit.loader;

import java.util.Enumeration;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelMarkService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelMarksService;
import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperMarksService;
import turbomeca.gamme.assembly.services.model.data.Mark;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.interfaces.IModelLoaderService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.model.provider.ModelXmlProvider;

public class ModelLoaderMarksService extends AModelAssemblyLoader implements
		IModelLoaderService {

	public ModelLoaderMarksService(IModelObjectService modelService) {
		super(modelService);
	}

	@Override
	public ModelWrapperMarksService getWrapperService() {
		return (ModelWrapperMarksService) super.getWrapperService();
	}

	@Override
	public ModelMarksService getModelService() {
		return (ModelMarksService) super.getModelService();
	}

	public void load(ModelXmlProvider modelProvider) throws ClientException, ClientInterruption {
        Enumeration<? extends Mark> enumMarks = getWrapperService().getMarks().enumerateMark();
        while (enumMarks.hasMoreElements()) {
            ModelMarkService markService = new ModelMarkService(getModelService(), enumMarks.nextElement());
            markService.getLoaderService().load(modelProvider);
            getModelService().addChild(markService);
        }
        if (modelProvider != null) {
            modelProvider.addModelService(getModelService().getIdentifier(), getModelService());
        }
    }
}
