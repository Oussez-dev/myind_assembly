package turbomeca.gamme.assembly.client.model.edit.runnable;

import java.util.List;

import turbomeca.gamme.assembly.client.model.edit.IModelAssemblyWrapperService;
import turbomeca.gamme.assembly.client.model.edit.ModelAssemblyServiceProvider;
import turbomeca.gamme.assembly.client.model.edit.schedule.AAssemblyScheduleService;
import turbomeca.gamme.assembly.services.model.data.Qualification;
import turbomeca.gamme.assembly.services.model.data.Qualifications;
import turbomeca.gamme.assembly.services.model.data.types.StatusType;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelRunnableService;

public class ModelRunnableStatusDefaultService extends ModelAssemblyServiceProvider implements IModelRunnableService {

	/**
	 * Constructor
	 * 
	 * @param identifier
	 *            the instruction identifier
	 */
	public ModelRunnableStatusDefaultService(IModelObjectService modelService) {
		super(modelService);
	}

	@Override
	public boolean isFinished() {
		StatusType status = getWrapperService().getState().getStatus();
		return (status == StatusType.OK || status == StatusType.KO
				|| status == StatusType.DONE || status == StatusType.PARTIAL 
				|| status == StatusType.NOT_APPLICATED
				|| status == StatusType.NONE);
	}

	@Override
	public boolean isRunnable() {
	    return (    getWrapperService().isApplicable() 
                && getWrapperService().isActive() 
                && getWrapperService().getState().getStatus() != StatusType.NOT_TODO);
	}

	@Override
	public boolean isValidable() {
		return false;
	}

	@Override
	public boolean needValidation() {
		return false;
	}

	@Override
	public boolean isEditable() {
	    return true;
	}
	
	@Override
    public boolean isOptional() {
        return false;
    }

	@Override
	public boolean canRun() {
		// Check qualifications
	    boolean isQualificationValid = false;
		Qualifications qualifications = getWrapperService().getExecutionQualifications();
		if (qualifications != null) {
			isQualificationValid = isQualificationValid(qualifications.getQualification());
		} else {
			isQualificationValid = true;
		}
	    // Check predecessors
		boolean isPredecessorsValid = true;
        IModelAssemblyWrapperService wrapper = getModelService().getWrapperService();
        List<String> predecessorsId = wrapper.getPredecessors();
        if (predecessorsId != null && !wrapper.isForcePredecessorsValid()) {
            for(String predecessorId : predecessorsId) {
                IModelObjectService modelService = getModelProvider().getModelService(predecessorId);
                if (    modelService.getWrapperService().isApplicable() 
                    && !modelService.getRunnableService().isFinished()) {
                    isPredecessorsValid = false;
                    break;
                }
            }
        }
        
		boolean isCurrentCanRun = isEditable() && isQualificationValid && isPredecessorsValid;
		if (isCurrentCanRun) {
			IModelObjectService parentService = getModelService().getParent();
			if (parentService != null && !(parentService instanceof AAssemblyScheduleService)) {
				isCurrentCanRun &= parentService.getRunnableService().canRun();
			}
		}
		return isCurrentCanRun;
	}

	@Override
	public boolean canValidate() {
		boolean isQualificationValid;
		Qualifications qualifications = getWrapperService().getValidationQualifications();
		if (qualifications != null) {
			isQualificationValid = isQualificationValid(qualifications.getQualification());
		} else {
			isQualificationValid = true;
		}
		return isQualificationValid;
	}

	/**
	 * Check if user qualifications contains at least one qualification
	 * 
	 * @param qualifications
	 *            list of qualifications
	 * @return true if user has qualification
	 */
	private boolean isQualificationValid(Qualification[] qualifications) {
		boolean isQualificationValid = false;
		if (qualifications == null || qualifications.length == 0) {
			isQualificationValid = true;
		} else {
			List<String> userQualifications = getConfiguration().getConfigUser()
					.getUserQualificationsList();
			for (Qualification qualification : qualifications) {
				if (userQualifications.contains(qualification.getQualification())) {
					isQualificationValid = true;
					break;
				}
			}
		}
		return isQualificationValid;
	}

    @Override
    public boolean hasRunner() {
        return false;
    }
    
    @Override
	public boolean isIgnored() {
		return isOptional();
	}
}
