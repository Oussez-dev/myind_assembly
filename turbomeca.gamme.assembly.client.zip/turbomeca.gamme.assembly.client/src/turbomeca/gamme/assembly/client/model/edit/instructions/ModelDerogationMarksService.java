package turbomeca.gamme.assembly.client.model.edit.instructions;

import turbomeca.gamme.assembly.client.model.edit.AModelAssemblyService;
import turbomeca.gamme.assembly.client.model.edit.hmi.updater.ModelHmiUpdaterService;
import turbomeca.gamme.assembly.client.model.edit.loader.ModelLoaderDerogationMarksService;
import turbomeca.gamme.assembly.client.model.edit.runnable.ModelRunnableStatusNoneService;
import turbomeca.gamme.assembly.client.model.edit.status.ModelStatusNoneService;
import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperDerogationMarksService;
import turbomeca.gamme.assembly.services.model.data.DerogationMarks;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public class ModelDerogationMarksService extends AModelAssemblyService {
	
	/**
	 * Constructor for task object
	 * 
	 * @param subPhaseService
	 *            parent service
	 * @param task
	 *            task object
	 */
	
	public ModelDerogationMarksService(IModelObjectService scheduleService, DerogationMarks derogationMarks) {
		super(ModelWrapperDerogationMarksService.DEROGATION_ID,ModelWrapperDerogationMarksService.DEROGATION_ID);
		setParent(scheduleService);
		setWrapperService(new ModelWrapperDerogationMarksService(derogationMarks));
		setLoaderService(new ModelLoaderDerogationMarksService(this));
		setHmiUpdaterService(new ModelHmiUpdaterService(ModelWrapperDerogationMarksService.DEROGATION_ID));
		setStatusService(new ModelStatusNoneService(this));
		setRunnableService(new ModelRunnableStatusNoneService(this));
	}
	
}
