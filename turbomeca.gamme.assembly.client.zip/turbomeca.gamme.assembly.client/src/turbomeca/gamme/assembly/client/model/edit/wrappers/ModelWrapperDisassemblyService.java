package turbomeca.gamme.assembly.client.model.edit.wrappers;

import java.util.Vector;

import turbomeca.gamme.assembly.services.model.data.Compounds;
import turbomeca.gamme.assembly.services.model.data.DerogationMarks;
import turbomeca.gamme.assembly.services.model.data.DeviationsFromRef;
import turbomeca.gamme.assembly.services.model.data.Disassembly;
import turbomeca.gamme.assembly.services.model.data.ElectronicPostIt;
import turbomeca.gamme.assembly.services.model.data.Historical;
import turbomeca.gamme.assembly.services.model.data.HistoricalPassing;
import turbomeca.gamme.assembly.services.model.data.Identification;
import turbomeca.gamme.assembly.services.model.data.Instanciation;
import turbomeca.gamme.assembly.services.model.data.ObjectsToSynchronize;
import turbomeca.gamme.assembly.services.model.data.Operation;
import turbomeca.gamme.assembly.services.model.data.Operations;
import turbomeca.gamme.assembly.services.model.data.Parameters;
import turbomeca.gamme.assembly.services.model.data.PostGeneralities;
import turbomeca.gamme.assembly.services.model.data.PreGeneralities;
import turbomeca.gamme.assembly.services.model.data.Qualifications;
import turbomeca.gamme.assembly.services.model.data.Rework;
import turbomeca.gamme.assembly.services.model.data.State;

public class ModelWrapperDisassemblyService extends AModelWrapperAssemblyScheduleService {

	/** */
	private Disassembly disassembly;

	@Override
	public void setObject(Object schedule) {
		disassembly = (Disassembly) schedule;
	}

	@Override
	public Object getObject() {
		return getDisassembly();
	}

	public Disassembly getDisassembly() {
		return disassembly;
	}

	@Override
	public Identification getIdentification() {
		return getDisassembly().getIdentification();
	}

	@Override
	public Historical getHistorical() {
		return getDisassembly().getHistorical();
	}

	@Override
	public Instanciation getInstantiation() {
		return getDisassembly().getInstanciation();
	}

	@Override
	public Parameters getParameters() {
		return getDisassembly().getParameters();
	}

	@Override
	public Operations getOperations() {
		return getDisassembly().getOperations();
	}

	@Override
	public DeviationsFromRef[] getDeviationFromRef() {
		return getDisassembly().getDeviationsFromRef();
	}

	@Override
	public State getState() {
		return getInstantiation().getState();
	}

	@Override
	public String getId() {
		return null;
	}

	@Override
	public void setId(String id) {
	}

	@Override
	public Qualifications getExecutionQualifications() {
		return getDisassembly().getQualifications();
	}

	@Override
	public Qualifications getValidationQualifications() {
		return getDisassembly().getQualifications();
	}

	@Override
	public ElectronicPostIt getElectronicPostIt() {
		return getDisassembly().getElectronicPostIt();
	}

	@Override
	public void setElectronicPostIt(ElectronicPostIt electronicPostIt) {
		getDisassembly().setElectronicPostIt(electronicPostIt);
	}

	@Override
	public Integer getPassingId() {
		return getInstantiation().getPassing();
	}

	@Override
	public void setPassingId(Integer passingId) {
		getInstantiation().setPassing(passingId);
	}

	@Override
	public Rework getRework() {
		return getDisassembly().getRework();
	}

	@Override
	public Compounds getCompounds() {
		return getDisassembly().getCompounds();
	}

	@Override
	public PreGeneralities getPreGenerality() {
		return getDisassembly().getPreGeneralities();
	}

	@Override
	public PostGeneralities getPostGenerality() {
		return getDisassembly().getPostGeneralities();
	}

	@Override
	public DerogationMarks getDerogationMarks() {
		return getDisassembly().getDerogationMarks();
	}

	@Override
	public void setDerogationMarks(DerogationMarks derogationMarks) {
		getDisassembly().setDerogationMarks(derogationMarks);
	}

	@Override
	public boolean hasGenerality() {
		return ((getDisassembly() != null && getDisassembly().getPostGeneralities() != null)
				||
				(getDisassembly() != null && getDisassembly().getPreGeneralities() != null));
	}

	@Override
	public boolean hasDeviationFromRef() {
		return (getDisassembly() != null && getDisassembly().getDeviationsFromRef() != null 
				&& getDisassembly().getDeviationsFromRef().length > 0);
	}

	@Override
	public boolean hasCompounds() {
		return (getDisassembly() != null && getDisassembly().getCompounds() != null);
	}

	@Override
	public boolean hasElectronicPostIt() {
		return (getDisassembly() != null && getDisassembly().getElectronicPostIt() != null);
	}

	@SuppressWarnings("unchecked")
	@Override
	public void setOperations(Vector<?> operations) {
		getDisassembly().getOperations().setOperation((Vector<Operation>)operations);
	}

	@Override
	public Object getHistoricalPassing() {
		HistoricalPassing historicalPassing = null;
		if(getDisassembly() != null){
			historicalPassing = getDisassembly().getHistoricalPassing();
		}
		return historicalPassing;
	}

	@Override
	public void setHistoricalPassing(Object historicalPassing) {
		if(getDisassembly() != null) {
			getDisassembly().setHistoricalPassing((HistoricalPassing) historicalPassing);
		}
	}
	
	@Override
	public ObjectsToSynchronize getObjectsToSynchronize() {
		ObjectsToSynchronize objectsToSynchronize = null;
		if(getDisassembly() != null) {
			objectsToSynchronize = getDisassembly().getObjectsToSynchronize();
		}
		return objectsToSynchronize;
	}

	@Override
	public void setObjectsToSynchronize(
			ObjectsToSynchronize objectsToSynchronize) {
		if(getDisassembly() != null) {
			getDisassembly().setObjectsToSynchronize(objectsToSynchronize);
		}
	}
	
	@Override
	public String getSuffix() {
		String result = null;
		if (getDisassembly() != null) {
			result = getDisassembly().getSuffix();
		}
		return result;
	}
}
