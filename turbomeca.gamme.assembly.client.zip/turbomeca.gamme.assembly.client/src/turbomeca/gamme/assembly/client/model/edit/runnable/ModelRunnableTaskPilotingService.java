package turbomeca.gamme.assembly.client.model.edit.runnable;

import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperTaskPilotingService;
import turbomeca.gamme.assembly.services.model.data.types.StatusType;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public class ModelRunnableTaskPilotingService extends ModelRunnableStatusDefaultService {

    public ModelRunnableTaskPilotingService(IModelObjectService modelService) {
        super(modelService);
    }

    @Override
    public ModelWrapperTaskPilotingService getWrapperService() {
        return (ModelWrapperTaskPilotingService) super.getWrapperService();
    }

    @Override
	public boolean isFinished() {
		return (getWrapperService().getState().getStatus() == StatusType.OK);
	}
    
    @Override
    public boolean isRunnable() {
        return true;
    }
    
    @Override
    public boolean hasRunner() {
        return true;
    }
}
