package turbomeca.gamme.assembly.client.model.edit.status;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.services.model.data.types.StatusType;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public class ModelStatusTaskPilotingService extends ModelStatusService {
	private Logger logger = Logger.getLogger(ModelStatusTaskPilotingService.class);

	public ModelStatusTaskPilotingService(IModelObjectService modelService) {
		super(modelService);
	}

	@Override
	public String getStatus() throws ClientException {
		StatusType statusType = getWrapperService().getState().getStatus();
		if (statusType == StatusType.KO) {
			statusType = StatusType.TODO;
		}
		return statusType.value();
	}
	
	@Override
	public void computeStatus(boolean recursively) throws ClientException, ClientInterruption {
		logger.debug("computeStatus  : " + getModelService());
		super.computeStatus(recursively);
		
		boolean allChildAreOk = true;
		
		boolean oneTodo = false;
		for (IModelObjectService childModelService : getModelService().getChildren()) {
			String childStatus = childModelService.getStatusService().getStatus();
			if(StatusType.TODO.value().equals(childStatus)) {
				oneTodo = true;
				break;
			} else 
			if(!StatusType.OK.value().equals(childStatus)) {
				allChildAreOk = false;
			}
		}
		
		if(oneTodo) {
			updateState(StatusType.TODO.value(), true, null, null);
		}else if(allChildAreOk) {
			updateState(StatusType.OK.value(), true, null, null);
		}else {
			updateState(StatusType.KO.value(), true, null, null);			
		}
	}

}