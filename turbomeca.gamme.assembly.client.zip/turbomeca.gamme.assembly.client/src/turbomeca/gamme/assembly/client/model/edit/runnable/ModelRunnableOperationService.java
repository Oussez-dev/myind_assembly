package turbomeca.gamme.assembly.client.model.edit.runnable;

import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public class ModelRunnableOperationService extends ModelRunnableStatusDefaultService {

	public ModelRunnableOperationService(IModelObjectService modelService) {
		super(modelService);
	}
}
