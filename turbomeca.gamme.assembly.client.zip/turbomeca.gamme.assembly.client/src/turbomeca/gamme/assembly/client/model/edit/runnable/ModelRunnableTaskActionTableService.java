package turbomeca.gamme.assembly.client.model.edit.runnable;

import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperTaskActionTableService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public class ModelRunnableTaskActionTableService extends AModelRunnableTaskActionTableService{

	public ModelRunnableTaskActionTableService(IModelObjectService modelService) {
		super(modelService);
	}

	@Override
	public ModelWrapperTaskActionTableService getWrapperService() {
		return (ModelWrapperTaskActionTableService) super.getWrapperService();
	}
	
	@Override
	public boolean isRunnable() {
		return false;
	}
}
