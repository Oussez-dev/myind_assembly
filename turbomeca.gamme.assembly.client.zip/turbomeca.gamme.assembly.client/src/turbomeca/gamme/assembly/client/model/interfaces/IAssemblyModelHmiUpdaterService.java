package turbomeca.gamme.assembly.client.model.interfaces;

import turbomeca.gamme.ecran.client.model.interfaces.IModelHmiUpdaterService;

public interface IAssemblyModelHmiUpdaterService extends IModelHmiUpdaterService  {

	public void setHasPreviousTaskPara(boolean hasPreviousTaskPara);

	public void setModeTable(boolean tableMode);
}
