package turbomeca.gamme.assembly.client.model.edit.schedule;

import java.util.ArrayList;
import java.util.List;

import turbomeca.gamme.assembly.client.model.edit.AModelAssemblyService;
import turbomeca.gamme.assembly.client.model.edit.IModelAssemblyWrapperScheduleService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelOperationService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseGroupService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.client.model.edit.runnable.ModelRunnableScheduleService;
import turbomeca.gamme.assembly.client.model.edit.status.ModelStatusScheduleService;
import turbomeca.gamme.assembly.client.model.edit.utils.ModelUtils;
import turbomeca.gamme.assembly.services.model.data.DerogationMarks;
import turbomeca.gamme.assembly.services.model.data.Historical;
import turbomeca.gamme.assembly.services.model.data.InputAction;
import turbomeca.gamme.assembly.services.model.data.InputValue;
import turbomeca.gamme.assembly.services.model.data.Instanciation;
import turbomeca.gamme.assembly.services.model.data.Issue;
import turbomeca.gamme.assembly.services.model.data.LevelChange;
import turbomeca.gamme.assembly.services.model.data.LevelHistory;
import turbomeca.gamme.assembly.services.model.data.Levels;
import turbomeca.gamme.assembly.services.model.data.Operation;
import turbomeca.gamme.assembly.services.model.data.SN;
import turbomeca.gamme.assembly.services.model.data.SubIssue;
import turbomeca.gamme.assembly.services.model.data.TaskAction;
import turbomeca.gamme.assembly.services.model.data.UserMark;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.edit.instructions.IModelOperationService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelScheduleService;
import turbomeca.gamme.ecran.client.model.provider.ModelSourceProviderCache;

public abstract class AAssemblyScheduleService extends AModelAssemblyService implements IModelScheduleService {

	/** */
	public static final String SCHEDULE_ID = "schedule";
	public static final String ASSEMBLY_OFFICIAL_DIRECTORY = "assembly";
	
	private boolean hasSapInput;
	
	public AAssemblyScheduleService(String domain) {
		super(domain, SCHEDULE_ID);
		setParent(null);
		
		setXmlSourceProvider(new ModelSourceProviderCache());
		setStatusService(new ModelStatusScheduleService(this));
		setRunnableService(new ModelRunnableScheduleService(this));
	}

	public String getOfficialMainDirectory() {
	    return ASSEMBLY_OFFICIAL_DIRECTORY;
	}

	public abstract String getOfficialRangeName();

	public abstract String getReverseOfficialRangeName();
	
	public abstract String getSubOfficialRangeName();
	
	public abstract String getReverseSubOfficialRangeName();
	
	public abstract Class<?> getClassModel();
	
	public abstract void setDerogationsMarks(DerogationMarks derogationMarks);
	
	public String getOrder() {
		Instanciation instanciation = getWrapperService().getInstantiation();
		return instanciation == null ? null : instanciation.getOrder();
	}
	
	public String getAffair() {
		Instanciation instanciation = getWrapperService().getInstantiation();
		return instanciation == null ? null : instanciation.getAffair();
	}

	public String getPn() {
		Instanciation instanciation = getWrapperService().getInstantiation();
		return instanciation == null ? null : instanciation.getPn();
	}
	
	public String getSn() {
		Instanciation instanciation = getWrapperService().getInstantiation();
		if (instanciation==null) return null;
		SN[] snArray = instanciation.getSN();
		if ( snArray == null || snArray.length !=1) return null;
		SN sn = snArray[0];
		TaskAction taskAction = sn.getTaskAction();
		if (taskAction==null) return null;
		InputAction inputAction = taskAction.getInputAction();
		if (inputAction==null) return null;
		InputValue inputValue = inputAction.getInputValue();
		if (inputValue==null) return null;
		return inputValue.getValue();
	}
	
	public int getPassing() {
		Instanciation instanciation = getWrapperService().getInstantiation();
		return instanciation == null ? 1 : instanciation.getPassing();
	}

	
	@Override
	public IModelAssemblyWrapperScheduleService getWrapperService() {
		return (IModelAssemblyWrapperScheduleService) super.getWrapperService();
	}

	@Override
	public void setSchedule(Object object) {
		getWrapperService().setObject(object);
	}
	
	public String getVersion(boolean mainIssue) {
        String version = null;
        Historical historical = getWrapperService().getHistorical();
        Issue lastIssue = historical.getIssue(historical.getIssueCount() - 1);
        if (mainIssue) {
            version = lastIssue.getVersion();
        }
        else {
            SubIssue lastSubIssue = lastIssue.getSubIssue(lastIssue.getSubIssueCount() - 1);
            version = lastSubIssue.getVersion();
        }
        return version;
    }
	
	public String getGeodeReference() {
		String ref = getWrapperService().getIdentification().getGeode(0).getReference();
		return ref == null ? "" : ref;
	}
	
	public String getGeodeVersion() {
		String version = getWrapperService().getIdentification().getGeode(0).getVersion();
		return version == null ? "" : version;
	}

    public void prepareModel(boolean cleanNotFinished) throws ClientException, ClientInterruption {
        for(IModelObjectService operationService : getChildren()) {
            if (operationService instanceof ModelOperationService) {
                for(IModelObjectService childService : operationService.getChildren()) {
                    if (childService instanceof ModelSubPhaseGroupService) {
                        for(IModelObjectService childGroupService : childService.getChildren()) {
                            if (childGroupService instanceof ModelSubPhaseService) {
                                ModelSubPhaseService subPhaseService = (ModelSubPhaseService) childGroupService;
                                cleanSubPhaseIfInprogress(cleanNotFinished, subPhaseService);
                            }
                        }
                    }
                    else if (childService instanceof ModelSubPhaseService) {
                        ModelSubPhaseService subPhaseService = (ModelSubPhaseService) childService;
                        cleanSubPhaseIfInprogress(cleanNotFinished, subPhaseService);
                    }
                }
                operationService.getStatusService().computeStatus(false);
            }
        }
    }
    
    private void cleanSubPhaseIfInprogress(boolean cleanNotFinished, ModelSubPhaseService subPhaseService) throws ClientException, ClientInterruption {
    	if (cleanNotFinished) {
     		subPhaseService.cleanIfInProgress();
    	 }
    	 subPhaseService.getStatusService().computeStatus(true);
    }
    
    public String getScheduleContext() {
        return getWrapperService().getInstantiation().getContext();
    }
    
    /**
     * @param level
     * @param comment
     */
    public void saveLevelHistory(String[] level, String comment) {
        LevelHistory levelHistory = getWrapperService().getInstantiation().getLevelHistory();
        if (levelHistory == null) {
            levelHistory = new LevelHistory();
            getWrapperService().getInstantiation().setLevelHistory(levelHistory);
        }
        
        LevelChange levelChange = new LevelChange();
        UserMark user = ModelUtils.buildUserMark();
        levelChange.setUserMark(user);
        levelChange.setLevel(level);
        if (comment != null && !comment.isEmpty()) {
            levelChange.setComment(comment);
        }
        levelHistory.addLevelChange(0, levelChange);
    }

    public boolean hasLevelDefined() {
        boolean hasLevel = false;
        Levels levels = getWrapperService().getParameters().getLevels();
        if (levels != null) {
            hasLevel = (levels.getLevelCount() > 0);
        }
        return hasLevel;
    }

	@Override
	public List<Object> getReworkOperations(List<String> operationsIdToAdd) {
    	List<Object> listRework = new ArrayList<Object>();
    	for (Operation operationRework : getWrapperService().getRework().getOperation()) {
    		if (operationsIdToAdd.contains(operationRework.getId())) {
    			listRework.add(operationRework);
    		}
    	}
		return listRework;
	}

	/**
	 * Gets the last closed operation
	 * @return the service of the last operation closed
	 */
	public ModelOperationService getLastOperationClosed() {
		List<IModelObjectService> operationServices = getChildrenImplementDeep(IModelOperationService.class);
		ModelOperationService modelOperationService = null;
		for (IModelObjectService modelObjectService : operationServices) {
			if (modelObjectService instanceof IModelOperationService) {
				ModelOperationService operationService = (ModelOperationService) modelObjectService;
				if (operationService.getWrapperService().isLastOperationClosed()) {
					modelOperationService = operationService;
					break;
				}
			}
		}
		return modelOperationService;
	}

	/**
	 * Returns true if schedule has modifications descriptions to show, false
	 * otherwise.
	 * 
	 * @return
	 */
	public boolean hasDifferences() {
		return getWrapperService().hasDifferences();
	}
	
	/**
	 * @return the hasSapInput
	 */
	public boolean hasSapInput() {
		return hasSapInput;
	}

	/**
	 * @param hasSapInput the hasSapInput to set
	 */
	public void setHasSapInput(boolean hasSapInput) {
		this.hasSapInput = hasSapInput;
	}
}
