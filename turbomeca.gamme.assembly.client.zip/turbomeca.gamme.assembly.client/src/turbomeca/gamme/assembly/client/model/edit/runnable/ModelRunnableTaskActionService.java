package turbomeca.gamme.assembly.client.model.edit.runnable;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskActionService;
import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperTaskActionService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public class ModelRunnableTaskActionService extends AModelRunnableTaskActionService {

	public ModelRunnableTaskActionService(IModelObjectService modelService) {
		super(modelService);
	}

	@Override
	public ModelWrapperTaskActionService getWrapperService() {
		return (ModelWrapperTaskActionService) super.getWrapperService();
	}
	
	@Override
	public boolean isFinished() {
		return (getWrapperService().getTaskAction().getInputAction().getInputValue() != null);
	}
	
	@Override
    public boolean isOptional() {
		return (((ModelTaskActionService) getModelService()).getWrapperService().isOptional() 
				|| ((ModelTaskActionService) getModelService()).getWrapperService().getTaskAction().isOptionnalTools())
				|| ((ModelTaskActionService) getModelService()).isOptional();
    }

}
