package turbomeca.gamme.assembly.client.model.edit.loader;

import java.util.Enumeration;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelResourcesService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskBenchSettingService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskService;
import turbomeca.gamme.assembly.client.model.edit.notifications.ModelNotificationsService;
import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperSubPhaseService;
import turbomeca.gamme.assembly.services.model.data.ElectronicNotifications;
import turbomeca.gamme.assembly.services.model.data.Resources;
import turbomeca.gamme.assembly.services.model.data.Task;
import turbomeca.gamme.assembly.services.model.data.TaskBenchSetting;
import turbomeca.gamme.assembly.services.model.data.TaskGroup;
import turbomeca.gamme.assembly.services.model.data.Tasks;
import turbomeca.gamme.assembly.services.model.data.TasksItem;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.edit.loader.ModelLoaderContext;
import turbomeca.gamme.ecran.client.model.interfaces.IModelLoaderService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.model.provider.ModelXmlProvider;

public class ModelLoaderSubPhaseService extends AModelAssemblyLoader implements
        IModelLoaderService {

    public ModelLoaderSubPhaseService(IModelObjectService modelService) {
        super(modelService);
    }

    @Override
    public ModelWrapperSubPhaseService getWrapperService() {
        return (ModelWrapperSubPhaseService) super.getWrapperService();
    }

    @Override
    public ModelSubPhaseService getModelService() {
        return (ModelSubPhaseService) super.getModelService();
    }

    public void load(ModelXmlProvider modelProvider) throws ClientException, ClientInterruption {
        ModelLoaderContext.getInstance().setHasPreviousPara(false);
        
        // Load notifications
        ElectronicNotifications notifications = getWrapperService().getSubPhase().getElectronicNotifications();
        ModelNotificationsService notificationsService = new ModelNotificationsService(getModelService(), notifications);
        notificationsService.getLoaderService().load(modelProvider);
        getModelService().addChild(notificationsService);
        
        // Load resources
        Resources resources = getWrapperService().getSubPhase().getResources();
        if (    resources != null
            && (resources.getMarks() != null || resources.getTools() != null || resources.getIngredients() != null)) {
            ModelResourcesService resourcesService = new ModelResourcesService(getModelService(), resources);
            resourcesService.getLoaderService().load(modelProvider);
            getModelService().addChild(resourcesService);
        }

        // Load tasks
        Tasks tasks = getWrapperService().getSubPhase().getTasks();
        if (tasks != null) {
	        Enumeration<?> enumTasksItem = tasks.enumerateTasksItem();
	        while (enumTasksItem.hasMoreElements()) {
	            Object tasksItemObject = ((TasksItem) enumTasksItem.nextElement()).getChoiceValue();
	            if (tasksItemObject instanceof Task) {
	                ModelTaskService taskService = new ModelTaskService(getModelService(), (Task) tasksItemObject);
	                taskService.getLoaderService().load(modelProvider);
	                getModelService().addChild(taskService);
	            } else if (tasksItemObject instanceof TaskBenchSetting) {
	            	  ModelTaskBenchSettingService taskService = new ModelTaskBenchSettingService(getModelService(), (TaskBenchSetting) tasksItemObject);
		              taskService.getLoaderService().load(modelProvider);
		              getModelService().addChild(taskService);
	            } else if (tasksItemObject instanceof TaskGroup) {
	            	TaskGroup taskGroup = (TaskGroup)tasksItemObject;
	                Enumeration<? extends Task> enumTask = taskGroup.enumerateTask();
	                while (enumTask.hasMoreElements()) {
	                    ModelTaskService taskService = new ModelTaskService(getModelService(), enumTask.nextElement());
	                    taskService.getLoaderService().load(modelProvider);
	                    getModelService().addChild(taskService);
	                }
	                TaskBenchSetting taskBenchSetting = taskGroup.getTaskBenchSetting();
	               	if (taskBenchSetting != null) {
	               		ModelTaskBenchSettingService taskService = new ModelTaskBenchSettingService(getModelService(), taskBenchSetting);
	               		taskService.getLoaderService().load(modelProvider);
	               		getModelService().addChild(taskService);
	                }
	            }
	        }
        }
        if (modelProvider != null) {
            modelProvider.addModelService(getModelService().getIdentifier(), getModelService());
        }
    }
}
