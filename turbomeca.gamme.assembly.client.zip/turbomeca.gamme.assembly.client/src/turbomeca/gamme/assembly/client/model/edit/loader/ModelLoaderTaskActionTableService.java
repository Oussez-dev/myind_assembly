package turbomeca.gamme.assembly.client.model.edit.loader;

import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperTaskActionTableService;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.interfaces.IModelLoaderService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.model.provider.ModelXmlProvider;

public class ModelLoaderTaskActionTableService extends AModelAssemblyLoader implements IModelLoaderService {

	public ModelLoaderTaskActionTableService(IModelObjectService modelService) {
		super(modelService);
	}

	@Override
	public ModelWrapperTaskActionTableService getWrapperService() {
		return (ModelWrapperTaskActionTableService) super.getWrapperService();
	}
	
	@Override
	public void load(ModelXmlProvider modelXmlProvider) throws ClientException,
			ClientInterruption {
		modelXmlProvider.addModelService(getModelService().getIdentifier(), getModelService());
	}
}
