package turbomeca.gamme.assembly.client.model.edit;

import java.util.ArrayList;
import java.util.List;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.client.model.interfaces.IAssemblyModelHmiUpdaterService;
import turbomeca.gamme.assembly.services.model.data.types.StatusType;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.model.AModelObjectService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public abstract class AModelAssemblyService extends AModelObjectService {

	public AModelAssemblyService(String domain, String identifier) {
		super(domain, identifier);
	}

	@Override
	public IModelAssemblyWrapperService getWrapperService() {
		return (IModelAssemblyWrapperService) super.getWrapperService();
	}
	
	@Override
    public IAssemblyModelHmiUpdaterService getHmiUpdaterService() {
        return (IAssemblyModelHmiUpdaterService) super.getHmiUpdaterService();
    }

	
	public StatusType getStatus(String instanceId) throws ClientException {
		return StatusType.valueOf(getStatusService().getStatus(instanceId));
	}
	
	public ModelSubPhaseService getSubPhase() {
	    return (ModelSubPhaseService) getAncestor(ModelSubPhaseService.class);
	}
	
	/**
	 * @param referencesList
	 */
	public boolean checkReferencesByLevel(List<IModelObjectService> referencesList, List<String> level) throws ClientException {
		boolean isValid = true;
		for (IModelObjectService modelService : getChildren()) {
			isValid &= ((AModelAssemblyService)modelService).checkReferencesByLevel(referencesList, level);
			if (!isValid) {
				break;
			}
		}
		return isValid;
	}
	
	public boolean hasApplicablePredecessors(List<String> level) {
		return true;
	}
	
	/**
	 * check if the user is qualified for the subphase
	 * @param qualifications
	 * @param userQualificationsList
	 * @return true : the user is qualified
	 *  false : the user is not qualified
	 */
	public boolean isUserQualified(ArrayList<String> qualifications,
			List<String> userQualificationsList) {
		boolean isQualified = false;
		if(qualifications.size() != 0){
			for(String userQualif : userQualificationsList){
				isQualified = qualifications.contains(userQualif);
				if(isQualified) {
					break;
				}
			}
		}
		else{
			isQualified = true;
		}
		return isQualified;
	}
}
