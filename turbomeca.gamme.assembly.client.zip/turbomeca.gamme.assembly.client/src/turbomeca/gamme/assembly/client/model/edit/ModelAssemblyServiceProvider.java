package turbomeca.gamme.assembly.client.model.edit;

import turbomeca.gamme.ecran.client.model.ModelServiceProvider;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public abstract class ModelAssemblyServiceProvider extends ModelServiceProvider {

	/**
	 * Constructor
	 * 
	 * @param modelService
	 */
	public ModelAssemblyServiceProvider(IModelObjectService modelService) {
		super(modelService);
	}

	@Override
	public AModelAssemblyService getModelService() {
		return (AModelAssemblyService) super.getModelService();
	}
	
	public IModelAssemblyWrapperService getWrapperService() {
		return (IModelAssemblyWrapperService) getModelService().getWrapperService();
	}
}
