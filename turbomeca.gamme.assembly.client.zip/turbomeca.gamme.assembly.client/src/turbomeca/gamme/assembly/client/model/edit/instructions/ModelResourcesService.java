package turbomeca.gamme.assembly.client.model.edit.instructions;

import java.util.List;

import turbomeca.gamme.assembly.client.model.edit.AModelAssemblyService;
import turbomeca.gamme.assembly.client.model.edit.hmi.updater.ModelHmiUpdaterService;
import turbomeca.gamme.assembly.client.model.edit.loader.ModelLoaderResourcesService;
import turbomeca.gamme.assembly.client.model.edit.runnable.ModelRunnableStatusDefaultService;
import turbomeca.gamme.assembly.client.model.edit.status.ModelStatusResourcesService;
import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperResourcesService;
import turbomeca.gamme.assembly.services.model.data.Resources;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public class ModelResourcesService extends AModelAssemblyService {

	public static final String RESOURCES_PREFIX_ID = "resources_";

	/**
	 * Constructor for task object
	 * 
	 * @param subPhaseService
	 *            parent service
	 * @param task
	 *            task object
	 */
	public ModelResourcesService(ModelSubPhaseService subPhaseService, Resources resources) {
		super(subPhaseService.getDomain(), RESOURCES_PREFIX_ID + subPhaseService.getIdentifier());
		setParent(subPhaseService);

		setWrapperService(new ModelWrapperResourcesService(resources));
		setLoaderService(new ModelLoaderResourcesService(this));
		setHmiUpdaterService(new ModelHmiUpdaterService());
		setStatusService(new ModelStatusResourcesService(this));
		setRunnableService(new ModelRunnableStatusDefaultService(this));
	}

	public boolean hasCheck() {
		boolean hasCheck = false;
		for(IModelObjectService child : getChildren()){
			if(child instanceof ModelTaskActionService){
				ModelTaskActionService modelTaskAction = (ModelTaskActionService) child;
				if(modelTaskAction.isCheckType()){
					hasCheck = true;
					break;
				}
			}
		}
		if(!hasCheck){
			List<IModelObjectService> children = getChildren();
			for(IModelObjectService child : children){
				if(hasCheck(child)){
					hasCheck = true;
					break;
				}
			}
		}
		return hasCheck;
	}

	private boolean hasCheck(IModelObjectService service){
		boolean hasCheck = false;
		List<IModelObjectService> childrenTaskAction = service.getChildrenDeep(ModelTaskActionService.class);
		if(childrenTaskAction != null){
			for(IModelObjectService taskAction : childrenTaskAction){
				if(taskAction instanceof ModelTaskActionService){
					ModelTaskActionService modelTaskAction = (ModelTaskActionService) taskAction;
					if(modelTaskAction.isCheckType()){
						hasCheck = true;
						break;
					}
				}
			}
		}
		return hasCheck;
	}
}
