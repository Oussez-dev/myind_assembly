package turbomeca.gamme.assembly.client.model.edit.instructions;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.Vector;

import org.apache.log4j.Logger;

import com.rits.cloning.Cloner;

import turbomeca.gamme.assembly.client.ClientAssemblyException;
import turbomeca.gamme.assembly.client.model.edit.runnable.ModelRunnableTaskActionService;
import turbomeca.gamme.assembly.client.model.edit.status.ModelStatusTaskActionService;
import turbomeca.gamme.assembly.client.model.edit.utils.ModelFormulaService;
import turbomeca.gamme.assembly.client.model.edit.utils.ModelUtils;
import turbomeca.gamme.assembly.client.module.electronic.notification.action.ActionDeleteElectronicNotificationNcr;
import turbomeca.gamme.assembly.services.model.data.DataValue;
import turbomeca.gamme.assembly.services.model.data.DataValueChoice;
import turbomeca.gamme.assembly.services.model.data.Entry;
import turbomeca.gamme.assembly.services.model.data.Formula;
import turbomeca.gamme.assembly.services.model.data.InputAction;
import turbomeca.gamme.assembly.services.model.data.InputActionChoice;
import turbomeca.gamme.assembly.services.model.data.InputChoice;
import turbomeca.gamme.assembly.services.model.data.InputComputed;
import turbomeca.gamme.assembly.services.model.data.InputField;
import turbomeca.gamme.assembly.services.model.data.InputRef;
import turbomeca.gamme.assembly.services.model.data.InputValue;
import turbomeca.gamme.assembly.services.model.data.Interval;
import turbomeca.gamme.assembly.services.model.data.ItemPara;
import turbomeca.gamme.assembly.services.model.data.Max;
import turbomeca.gamme.assembly.services.model.data.Min;
import turbomeca.gamme.assembly.services.model.data.SapValue;
import turbomeca.gamme.assembly.services.model.data.StringValue;
import turbomeca.gamme.assembly.services.model.data.TaskAction;
import turbomeca.gamme.assembly.services.model.data.TaskChoiceItem;
import turbomeca.gamme.assembly.services.model.data.TaskMark;
import turbomeca.gamme.assembly.services.model.data.Test;
import turbomeca.gamme.assembly.services.model.data.UserMarkValidation;
import turbomeca.gamme.assembly.services.model.data.Variable;
import turbomeca.gamme.assembly.services.model.data.types.InputType;
import turbomeca.gamme.assembly.services.model.data.types.StatusType;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.dispatcher.ActionDispatcherManager;
import turbomeca.gamme.ecran.client.model.edit.instructions.IModelTaskActionService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.model.provider.ModelXmlProvider;
import turbomeca.gamme.ecran.services.common.constants.GlobalConstants;

public class ModelTaskActionService extends AModelTaskActionService implements IModelTaskActionService {

	/** logger for current class */
	private static Logger logger = Logger.getLogger(ModelTaskActionService.class);

	private boolean optional;

	public ModelTaskActionService(IModelObjectService modelService, TaskAction taskAction) {
		super(modelService, taskAction);
		setStatusService(new ModelStatusTaskActionService(this));
		setRunnableService(new ModelRunnableTaskActionService(this));
	}

	@Override
	public boolean checkValue(String value) throws ClientException, ClientInterruption {
		return isFormatValid(value) && isValueValid(value, null);
	}

	public boolean checkValue(String value, Test[] test) throws ClientException, ClientInterruption {
		return isFormatValid(value) && isValueValid(value, test);
	}

	@Override
	public void setServiceModified(boolean notify) throws ClientException, ClientInterruption {
		getStatusService().setServiceModified();
		// Build SAP status if needed
		buildSapStatus();
		if (notify) {
			getNotifications().notifyValueChanged(this);
		}
		if (	!getRunnableService().isFinished()
				&&	(getParent().getStatusService().getStatus() != StatusType.TODO.value()
				|| getParent() instanceof ModelTaskActionMeasureService) && !getRunnableService().isOptional()) {
			getParent().getStatusService().resetState(false, true, null);
		}

		if(getParent() instanceof ModelToolService) {
			logger.debug("Parent is instanceof ModelToolService ********** calling linkTools **********");
			linkTools();
		}
	}

	private void buildSapStatus() throws ClientException {
		InputAction inputAction = getTaskAction().getInputAction();
		if (inputAction != null) {
			SapValue sapData = getTaskAction().getSapValue();
			if (sapData != null) {
				String sapValue = sapData.getValue();
				String currentValue = getValue();

				StatusType currentSapStatus = sapData.getStatus();
				StatusType sapStatus = StatusType.TODO;
				if (currentValue != null) {
					if (currentValue.equals(sapValue)) {
						sapStatus = StatusType.OK;
					} else {
						sapStatus = StatusType.KO;
					}
				}
				if (currentSapStatus == null || currentSapStatus != sapStatus) {
					getTaskAction().getSapValue().setStatus(sapStatus);
					getNotifications().notifyStatusChanged(this);
				}
			}
		}
	}

	@Override
	public StatusType getSapStatus(int groupId) {
		StatusType sapStatus = null;
		SapValue sapValue = getTaskAction().getSapValue();
		if (sapValue != null) {
			sapStatus = sapValue.getStatus();
		}
		return sapStatus;
	}

	/**
	 * Method used to compute tools status when using alternative tools
	 * @throws ClientException
	 */
	private void linkTools() throws ClientException {

		if(getRunnableService().canRun()) {
			ModelToolService currentToolService = (ModelToolService)getParent();

			boolean isChecked = isCheckboxChecked(currentToolService);

			//enable current tool service
			for(IModelObjectService object : currentToolService.getChildren()) {
				AModelTaskActionService taskActionTool = (AModelTaskActionService)object;
				taskActionTool.getWrapperService().getTaskAction().setForceEditable(true);
			}

			if(currentToolService.getWrapperService().getId()!=null && !currentToolService.getWrapperService().getId().isEmpty()) {

				String toolId = currentToolService.getWrapperService().getId();
				logger.debug("linkTools ********** Checking links on tool " + toolId);

				// First step : if the tool has alternatives and is checked, we deactivate all alternatives
				if (currentToolService.getWrapperService().getToolRefId() != null) {

					logger.debug("linkTools ********** tool " + toolId + " has alternatives !");

					String[] toolRefIds = currentToolService.getWrapperService().getToolRefId().split(GlobalConstants.SEPARATOR_SPACE);
					updateAlternativeTools(toolId, toolRefIds, isChecked);

				} else {

					// Second step : the tool has no alternatives, but is maybe referenced in another tool as an alternative
					// We search for that case by polling all tools on the subphase
					ModelToolsService  ancestorService = (ModelToolsService) getAncestor(ModelToolsService.class);

					// For all tools of the subphase...
					for(IModelObjectService currentTool : ancestorService.getChildren()) {

						ModelToolService toolService = (ModelToolService)currentTool;
						logger.debug("linkTools ********** Processing tool " + toolService.getWrapperService().getId());

						//If the current tool has alternatives, and contains our tool id in the references,
						//we need to deactivate it AND ALL ITS ALTERNATIVES
						if(toolService.getWrapperService().getToolRefId() != null
								&& toolService.getWrapperService().getToolRefId().contains(toolId)) {

							logger.debug("linkTools ********** tool has toolref " + toolService.getWrapperService().getToolRefId());

							String[] toolRefIds = toolService.getWrapperService().getToolRefId().split(GlobalConstants.SEPARATOR_SPACE);
							updateAlternativeTool(currentTool, isChecked);
							updateAlternativeTools(toolId, toolRefIds, isChecked);

						}
					}
				}
			}
		} else {
			//reset force editable Flags
			getWrapperService().getTaskAction().setForceEditable(true);
		}

	}

	/**
	 * 
	 */
	private boolean isCheckboxChecked(ModelToolService currentToolService) {

		//Is the checkbox checked?
		boolean isChecked = false;
		if(currentToolService != null && currentToolService.getWrapperService() != null 
				&& currentToolService.getWrapperService().getTaskActionCheck() != null 
				&& currentToolService.getWrapperService().getTaskActionCheck().getInputAction() != null
				&& currentToolService.getWrapperService().getTaskActionCheck().getInputAction().getInputValue()!=null)
			isChecked = true;

		return isChecked;
	}

	/**
	 * Update status of all alternative tools of a tool
	 * @param toolId
	 * @param toolRefIds
	 * @param isChecked
	 * @throws ClientException
	 */
	private void updateAlternativeTools(String toolId, String[] toolRefIds, boolean isChecked) throws ClientException {

		ModelToolsService ancestorService = (ModelToolsService) getAncestor(ModelToolsService.class);

		for (int i=0; i<toolRefIds.length; i++) {

			if (!toolRefIds[i].equals(toolId)) {

				for(IModelObjectService current : ancestorService.getChildren()) {

					ModelToolService toolServ = (ModelToolService)current;

					if (toolServ.getWrapperService().getId().equals(toolRefIds[i])) {

						logger.debug("linkTools ********** processing alternative tool " + toolRefIds[i]);

						updateAlternativeTool(current, isChecked);

					}
				}
			}
		}

	}

	/*
	 * Update status of all children of an alternative tool
	 */
	private void updateAlternativeTool(IModelObjectService modelObjectService, boolean isChecked) throws ClientException {

		ModelToolService toolServ = (ModelToolService)modelObjectService;

		for(IModelObjectService object : toolServ.getChildren()) {
			AModelTaskActionService taskActionTool = (AModelTaskActionService)object;
			taskActionTool.getWrapperService().getTaskAction().setForceEditable(!isChecked);
			taskActionTool.getWrapperService().getTaskAction().setOptionnalTools(isChecked);
			if (taskActionTool.getWrapperService().getTaskAction().getInputAction().getInputValue() != null
					&& isChecked) {
				taskActionTool.getWrapperService().getTaskAction().getInputAction().getInputValue().setValue(GlobalConstants.EMPTY_STRING);
			}

			getNotifications().notifyValueChanged(taskActionTool);
		}

	}


	/**
	 * Update comment associated of an input value
	 * 
	 * @param groupId
	 *            group identifier
	 * @param sNs
	 *            new associated items
	 * @throws ClientException
	 */
	@Override
	public void updateComment(String comment) throws ClientException {
		InputValue inputValue = getTaskAction().getInputAction().getInputValue();
		if (inputValue != null) {
			inputValue.setComment(comment);
			getNotifications().notifyServiceChanged(this);
		}
		else {
			throw new ClientAssemblyException(ClientAssemblyException.EXCEPTION_COMMENT_WITHOUT_VALUE);
		}
	}

	@Override
	protected boolean setInternalValue(String value) throws ClientException, ClientInterruption {
		getTaskAction().getInputAction().setInputValue(null);
		if (isInputFieldCheck() && value.equals(Boolean.FALSE.toString())) { 
			// Nothing to do
		}
		else {
			InputValue inputValue = new InputValue();
			inputValue.setUserMark(ModelUtils.buildUserMark());
			inputValue.setValue(value);
			getTaskAction().getInputAction().setInputValue(inputValue);
		}
		setServiceModified(false);
		return true;
	}

	@Override
	public void resetValue(boolean notify) throws ClientException, ClientInterruption {
		boolean refreshService = false;
		getTaskAction().getInputAction().setInputValue(null);
		InputChoice inputChoice = getTaskAction().getInputAction().getInputActionChoice().getInputChoice();
		if (inputChoice != null && inputChoice.getStringValueCount() > 0) {
			Vector<StringValue> stringValues = new Vector<StringValue>();
			for (StringValue stringValue : inputChoice.getStringValue()) {
				if (stringValue.isManual()) {
					refreshService = true;
				}
				else {
					stringValues.add(stringValue);
				}
			}
			inputChoice.setStringValue(stringValues);
		}

		if (refreshService) {
			getNotifications().notifyServiceChanged(this);
		} 
		if (getTaskAction().isDoubleValidation()) {
			getNotifications().notifyElectronicNotificationChanged(this);
		}
		if (getTaskAction().isNotification()) {
			ActionDispatcherManager.getInstance().run(new ActionDeleteElectronicNotificationNcr(this));
		}
		setServiceModified(notify);
	}

	public void addChoiceValue(String value, boolean cleanable) throws ClientException, ClientInterruption {
		InputChoice inputChoice = getTaskAction().getInputAction().getInputActionChoice().getInputChoice();
		if (inputChoice == null) {
			throw new ClientAssemblyException();
		}
		else {
			if (inputChoice.getStringValueCount() > 0) {
				Vector<StringValue> stringValues = new Vector<StringValue>();
				for(StringValue stringValue : inputChoice.getStringValue()) {
					if (!stringValue.isManual()) {
						stringValues.add(stringValue);
					}
				}
				StringValue stringValue = new StringValue();
				stringValue.setContent(value);
				if (cleanable) {
					stringValue.setManual(true);
				}
				stringValues.add(stringValue);
				inputChoice.setStringValue(stringValues);

				int position = inputChoice.getStringValueCount();
				setValue(String.valueOf(position));
				setServiceModified(false);

				getNotifications().notifyServiceChanged(this);
			}
		}
	}

	public ModelTaskActionService cloneServiceInParent(IModelObjectService parentService) throws ClientException, ClientInterruption {
		Cloner cloner = new Cloner();
		TaskAction taskActionCloned = cloner.deepClone(getTaskAction());
		taskActionCloned.setId(taskActionCloned.getId() + UUID.randomUUID().toString());
		taskActionCloned.getInputAction().setInputValue(null);
		taskActionCloned.setDuplicated(true);
		return new ModelTaskActionService(parentService, taskActionCloned);
	}

	/**
	 * 
	 * @return
	 * @throws ClientInterruption 
	 * @throws ClientException 
	 */
	public ModelTaskActionService cloneService() throws ClientException, ClientInterruption {
		return cloneService(getParent(), this);
	}

	public ModelTaskActionService cloneService(IModelObjectService parentService, ModelTaskActionService previousTaskAction) throws ClientException, ClientInterruption {
		Cloner cloner = new Cloner();
		TaskAction taskActionCloned = cloner.deepClone(getTaskAction());
		taskActionCloned.setId(taskActionCloned.getId() + UUID.randomUUID().toString());
		taskActionCloned.getInputAction().setInputValue(null);
		taskActionCloned.setDuplicated(true);

		ModelTaskActionService taskActionServiceCloned = new ModelTaskActionService(parentService, taskActionCloned);

		if (getWrapperService().getEntryParent() != null) {
			Entry currentEntry = getWrapperService().getEntryParent();
			Vector<TaskAction> newTaskActionsList = new Vector<TaskAction>();
			for(TaskAction taskAction : getWrapperService().getEntryParent().getTaskActionAsReference()) {
				newTaskActionsList.add(taskAction);
				if (taskAction.getId().equals(getTaskAction().getId())) {
					taskActionServiceCloned.getWrapperService().setEntryParent(getWrapperService().getEntryParent());
					newTaskActionsList.add(taskActionCloned);
				}
			}
			currentEntry.setTaskAction(newTaskActionsList);
		} else if (parentService instanceof ModelTaskService){
			ModelTaskService modelTaskService = (ModelTaskService) parentService;
			Vector<TaskChoiceItem> newTaskChoiceItemList = new Vector<TaskChoiceItem>();
			for(TaskChoiceItem taskChoiceItem : modelTaskService.getTask().getTaskChoice().getTaskChoiceItemAsReference()) {
				newTaskChoiceItemList.add(taskChoiceItem);
				TaskAction taskAction = taskChoiceItem.getTaskAction();
				if (taskAction != null && taskAction.getId().equals(getTaskAction().getId())) {
					TaskChoiceItem itemTaskTypeToAdd = new TaskChoiceItem();
					itemTaskTypeToAdd.setTaskAction(taskActionCloned);
					newTaskChoiceItemList.add(itemTaskTypeToAdd);
				}
			}
			modelTaskService.getTask().getTaskChoice().setTaskChoiceItem(newTaskChoiceItemList);
		} else if (parentService instanceof ModelMarkService) {
			ModelMarkService modelMarkService = (ModelMarkService) parentService;

			Integer index = ((ModelMarkService) getParent()).getWrapperService().getIndex(getType(), getIdentifier());
			if (getParent().getIdentifier().equals(parentService.getIdentifier())) {
				index = index + 1;
			}
			modelMarkService.getWrapperService().addElement(getType(), taskActionCloned, index);
			taskActionServiceCloned.setType(getType());
		}

		// Add service to parent children
		parentService.addChildAfter(taskActionServiceCloned, previousTaskAction);

		// Reset status parent if needed
		if (!StatusType.TODO.value().equals(parentService.getStatusService().getStatus())) {
			parentService.getStatusService().resetState(false, false, null);
		}

		parentService.setModified();
		getNotifications().notifyServiceChanged(parentService);
		return taskActionServiceCloned;
	}

	/**
	 * 
	 */
	public void destroyService() {
		// Remove object from model
		if (getWrapperService().getEntryParent() != null) {
			Entry currentEntry = getWrapperService().getEntryParent();
			Vector<TaskAction> newTaskActionsList = new Vector<TaskAction>();
			for(TaskAction taskAction : getWrapperService().getEntryParent().getTaskActionAsReference()) {
				if (!taskAction.getId().equals(getTaskAction().getId())) {
					newTaskActionsList.add(taskAction);
				}
			}
			currentEntry.setTaskAction(newTaskActionsList);
		} else if (getParent() instanceof ModelTaskService){
			ModelTaskService modelTaskService = (ModelTaskService) getParent();
			Vector<TaskChoiceItem> newTaskChoiceItemList = new Vector<TaskChoiceItem>();
			for(TaskChoiceItem taskChoiceItem : modelTaskService.getTask().getTaskChoice().getTaskChoiceItemAsReference()) {
				TaskAction taskAction = taskChoiceItem.getTaskAction();
				if (taskAction == null || !taskAction.getId().equals(getTaskAction().getId())) {
					newTaskChoiceItemList.add(taskChoiceItem);
				}
			}
			modelTaskService.getTask().getTaskChoice().setTaskChoiceItem(newTaskChoiceItemList);
		}

		// Remove from parent children list
		getParent().getChildren().remove(this);
	}

	public boolean isInputChoice() {
		return (getTaskAction().getInputAction().getInputActionChoice().getInputChoice() != null);
	}

	@Override
	public String computeFormula(Formula formula, int precision) throws ClientAssemblyException {
		return new ModelFormulaService(formula, precision).compute();
	}

	public void setDoubleValidation(UserMarkValidation userMarkValidation) {
		InputValue inputValue = getTaskAction().getInputAction().getInputValue();
		if (inputValue != null) {
			inputValue.setUserMarkValidation(userMarkValidation);
		}
	}

	/**
	 * @throws ClientException 
	 * 
	 */
	public void setDefaultValue(String defaultValue) throws ClientException {
		InputAction inputAction = getTaskAction().getInputAction();
		if (inputAction != null) {
			inputAction.setInputValue(null);
			InputValue inputValue = new InputValue();
			inputValue.setUserMark(ModelUtils.buildUserMark());
			inputValue.setValue(defaultValue);
			inputAction.setInputValue(inputValue);
		}
	}

	/**
	 * 
	 * @return
	 */
	private boolean isInputFieldCheck() {
		InputField inputField = getTaskAction().getInputAction().getInputActionChoice().getInputField();
		return (inputField != null && inputField.getType() == InputType.CHECK);
	}

	/**
	 * 
	 * @param editable
	 * @param notify
	 * @throws ClientException
	 */
	public void setForceEditable(boolean editable, boolean notify) throws ClientException {
		getTaskAction().setForceEditable(editable);
		if (notify) {
			if (isInputChoice()) {
				getNotifications().notifyServiceChanged(this);
			} else {
				getNotifications().notifyStatusChanged(this);
			}
		}
	}

	/* (non-Javadoc)
	 * @see turbomeca.gamme.assembly.client.model.edit.AModelAssemblyService#checkDeepReferences(java.util.List)
	 */
	public boolean checkReferencesByLevel(List<IModelObjectService> referencesList, String level) throws ClientException {
		InputAction inputAction = getTaskAction().getInputAction();
		if (inputAction != null) {
			InputActionChoice inputChoice = inputAction.getInputActionChoice();
			if (inputChoice != null) {
				// InputComputed
				InputComputed inputComputed = inputChoice.getInputComputed();
				if (inputComputed != null) {
					InputRef inputRefComputed = inputComputed.getInputRef();
					if (inputRefComputed != null) {
						Object refId = inputRefComputed.getRefId();
						if (refId != null) {
							if (!ModelUtils.isReferenceApplicable(refId, level, referencesList)) {
								return false;
							}
						}
					} 
					// Formula
					Formula formula = inputComputed.getFormula();
					if (formula != null) {
						Variable[] variables =  formula.getVariable();
						if (variables != null) {
							for (Variable variable : variables) {
								if (variable != null) {
									Object refId = variable.getRefId();
									if (refId != null) {
										if (!ModelUtils.isReferenceApplicable(refId, level, referencesList)) {
											return false;
										}
									}
								}
							}
						}
					}
				}
			}
		} 
		// Test
		Test[] tests = getTaskAction().getTest();
		if (tests != null) {
			for (Test test : tests) {
				// DataValue
				DataValue dataValue = test.getDataValue();
				if (dataValue != null) {
					DataValueChoice dataValueChoice = dataValue.getDataValueChoice();
					if (dataValueChoice != null) {
						InputRef inputRef = dataValueChoice.getInputRef();
						if (inputRef != null) {
							Object refId = inputRef.getRefId();
							if (refId != null) {
								if (!ModelUtils.isReferenceApplicable(refId, level, referencesList)) {
									return false;
								}
							}
						}
					}
				}
				// Interval
				Interval interval = test.getInterval();
				if (interval != null) {
					Min min = interval.getMin();
					if (min != null) {
						DataValue minValue = min.getDataValue();
						if (minValue != null) {
							DataValueChoice dataValueChoice = minValue.getDataValueChoice();
							if (dataValueChoice != null) {
								InputRef inputRef = dataValueChoice.getInputRef();
								if (inputRef != null) {
									Object refId = inputRef.getRefId();
									if (refId != null) {
										if (!ModelUtils.isReferenceApplicable(refId, level, referencesList)) {
											return false;
										}
									}
								}
							}
						}
					}
					Max max = interval.getMax();
					if (max != null) {
						DataValue maxValue = max.getDataValue();
						if (maxValue != null) {
							DataValueChoice dataValueChoice = maxValue.getDataValueChoice();
							if (dataValueChoice != null) {
								InputRef inputRef = dataValueChoice.getInputRef();
								if (inputRef != null) {
									Object refId = inputRef.getRefId();
									if (refId != null) {
										if (!ModelUtils.isReferenceApplicable(refId, level, referencesList)) {
											return false;
										}
									}
								}
							}
						}
					}
				}
			}
		}

		return true;
	}

	/**
	 * @param optional the optional to set
	 */
	public void setOptional(boolean optional) {
		this.optional = optional;
	}

	/**
	 * @return the optional
	 */
	public boolean isOptional() {
		return optional;
	}

	public boolean isTaskActionLinked(ModelTaskActionService taskActionService) {
		return getType().equals(taskActionService.getType())
				&& getWrapperService().getInstanceId() == taskActionService.getWrapperService().getInstanceId()
				&& getWrapperService().getAlternative() == taskActionService.getWrapperService().getAlternative()
				&& getWrapperService().getDuplicateIndex() == taskActionService.getWrapperService().getDuplicateIndex();
	}

	@Override
	public void computeDefaultValue() throws ClientException, ClientInterruption {

		Test[] tests = getTaskAction().getTest();
		String defaultValue = null;

		if (tests != null && tests.length > 0) {
			for (Test test : tests) {
				if (test.getChoiceItem() != null) {
					int position = test.getChoiceItem().getPosition();
					// Item Para
					defaultValue = String.valueOf(position);
					break;
				} else if (test.getPara() != null && test.getPara().length > 0) {
					if (test.getPara(0) != null ) {
						String attemptPara =  test.getPara(0).getContent();
						InputActionChoice inputActionChoice = getTaskAction().getInputAction().getInputActionChoice();
						if (inputActionChoice != null) {
							InputChoice inputChoice = inputActionChoice.getInputChoice();
							ItemPara[] itemParas = inputChoice.getItemPara();
							if (itemParas != null && itemParas.length > 0) {
								for (int i = 0;i< itemParas.length;i++) {
									if (itemParas[i].getPara(0).getContent().equals(attemptPara)) {
										defaultValue = String.valueOf(i+1);
										break;
									}
								}
							} else {
								throw new ClientAssemblyException(ClientAssemblyException.EXCEPTION_RAS_DEFINITION_TASK);
							} 
						} else {
							throw new ClientAssemblyException(ClientAssemblyException.EXCEPTION_RAS_DEFINITION_TASK);
						}
					} else {
						throw new ClientAssemblyException(ClientAssemblyException.EXCEPTION_RAS_DEFINITION_TASK);
					}
				} else {
					throw new ClientAssemblyException(ClientAssemblyException.EXCEPTION_RAS_DEFINITION_TASK);
				}
			}
			if (defaultValue == null) {
				throw new ClientAssemblyException(ClientAssemblyException.EXCEPTION_RAS_DEFINITION_TASK);
			}
			else {
				setDefaultValue(defaultValue);
				setServiceModified(true);
			}
		} else {
			throw new ClientAssemblyException(ClientAssemblyException.EXCEPTION_RAS_DEFINITION_TASK);
		}


	}

	public boolean canContinueNext(){
		boolean canContinue = true;
		TaskMark taskMark = getWrapperService().getTaskMarkParent();
		if (taskMark != null){
			canContinue = false;
		}
		return canContinue;
	}

	/**
	 * Return true if inputChoice is inputConstant type
	 * @return
	 */
	public boolean isInputConstantType() {
		InputAction inputAction = getTaskAction().getInputAction();
		if (inputAction != null) {
			InputActionChoice inputChoice = inputAction.getInputActionChoice();
			if (inputChoice != null) {
				return inputChoice.getInputConstant() != null;
			}
		}
		return false;
	}

	@Override
	public boolean hasInputComputed() {
		return getWrapperService().isInputComputed();
	}

	@Override
	public List<IModelTaskActionService> getReferencedTaskActionsFromInputComputed() {

		List<IModelTaskActionService> taskActionsServices = new ArrayList<IModelTaskActionService>();

		// Reading all refIds from this taskAction
		List<String> refIds;

		try {
			refIds = getWrapperService().getReferencedIdsFromInputComputed();
		} catch(ClientException e) {
			logger.debug("No referenced taskActions in TaskAction[id=" + getIdentifier() + "] (not an inputComputed object?)");
			return taskActionsServices;
		}

		// Getting all taskActions services
		for(String refId : refIds) {
			IModelObjectService refObjectService = ModelXmlProvider.getInstance().getModelService(refId);

			// This formula variable refId references a TaskAction, we create a new reference into it
			if(refObjectService instanceof IModelTaskActionService) {
				IModelTaskActionService refTaskActionService = (IModelTaskActionService) refObjectService;
				taskActionsServices.add(refTaskActionService);
			}	
		}

		return taskActionsServices;
	}

	@Override
	public void addReference(IModelObjectService refObject) {
		getWrapperService().addReference(refObject);
	}

	@Override
	public String formatValue(String value) {

		InputField inputField = getTaskAction().getInputAction().getInputActionChoice() .getInputField();
		String formattedValue = value;

		if (inputField != null) {

			switch (inputField.getType()) {
			case FLOAT:
				logger.debug("Value=" + value + " is formatted to formattedValue=" + formattedValue);
				formattedValue = value.replace(',', '.');
				break;
			default:
				// Nothing to do
				break;
			}
		}

		return formattedValue;
	}

	@Override
	public boolean setValueWithNotificationComment(String value, String notificationComment)
			throws ClientException, ClientInterruption {
		// Empty method : functionality not yet implemented on Assembly
		return false;
	}

}
