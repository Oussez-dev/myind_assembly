package turbomeca.gamme.assembly.client.model.edit.wrappers;

import turbomeca.gamme.assembly.client.model.edit.utils.ModelUtils;
import turbomeca.gamme.assembly.services.model.data.InputAction;
import turbomeca.gamme.assembly.services.model.data.InputValue;
import turbomeca.gamme.assembly.services.model.data.Qualifications;
import turbomeca.gamme.assembly.services.model.data.State;
import turbomeca.gamme.assembly.services.model.data.TaskBenchSetting;
import turbomeca.gamme.assembly.services.model.data.types.StatusType;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public class ModelWrapperTaskBenchSettingService extends AModelWrapperAssemblyService   {
	
	
	/** Task object */
	private TaskBenchSetting taskBench;

	/**
	 * Constructor for task object
	 * 
	 * @param subPhaseService
	 *            parent service
	 * @param task
	 *            task object
	 */
	public ModelWrapperTaskBenchSettingService(TaskBenchSetting task) {
		setTaskBench(task);
	}

	@Override
	public TaskBenchSetting getObject() {
		return taskBench;
	}

	/**
	 * @param task the task to set
	 */
	public void setTaskBench(TaskBenchSetting task) {
		this.taskBench = task;
	}

	public void setDocumentFileName(int index, String fileName) throws ClientException {
		InputValue inputValue = retrieveInputDocumentValue(index, true);
		inputValue.setUserMark(ModelUtils.buildUserMark());
		inputValue.setValue(fileName);
	}
	
	public String getDocumentFileName(int index) throws ClientException {
		InputValue inputValue = retrieveInputDocumentValue(index, false);
		if (inputValue == null) return "";
		String fileName = inputValue.getValue();
		return fileName == null ? "" : fileName;
	}
	
	public void clearDocumentFileName(int index) throws ClientException {
		InputAction inputAction = retrieveInputDocumentAction(index);
		if (inputAction.getInputValue() != null) {
			inputAction.setInputValue(null);
		}
	}
	
	public StatusType getInternalState() {
		return taskBench.getInternalState();
	}
	
	public void setInternalState(StatusType internalState) {
		taskBench.setInternalState(internalState);
	}
	
	private InputValue retrieveInputDocumentValue(int index, boolean create) throws ClientException {
		InputAction inputAction = retrieveInputDocumentAction(index);
		InputValue inputValue = inputAction.getInputValue();
		if (create && inputValue == null) {
			inputValue = new InputValue();
			inputAction.setInputValue(inputValue);
		}
		return inputValue;
	}

	private InputAction retrieveInputDocumentAction(int index) throws ClientException {
		InputAction[] inputActions = taskBench.getInputAction();
		if (inputActions == null || index >= inputActions.length) {
			throw new ClientException(ClientException.EXCEPTION_INTERNAL, "missing inputAction nodes in taskBenchSetting node");
		}
		return inputActions[index];
	}
	
	@Override
	public Qualifications getValidationQualifications() {
		return null;
	}
	
	@Override
	public State getState() {
		return getObject().getState();
	}
	
	
	@Override
	public String getId() {
		return getObject().getId();
	}

	@Override
	public void setId(String id) {
		getObject().setId(id);
	}

	@Override
	public void addChild(IModelObjectService nextChild, IModelObjectService newChild)
			throws ClientException {
		// No child wrapper
	}

}
