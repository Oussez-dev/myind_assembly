package turbomeca.gamme.assembly.client.model.edit.status;

import java.util.Enumeration;
import java.util.List;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelResourcesService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskActionService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskService;
import turbomeca.gamme.assembly.services.model.data.SubPhase;
import turbomeca.gamme.assembly.services.model.data.TaskChoiceItem;
import turbomeca.gamme.assembly.services.model.data.types.StatusType;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.context.ContextRequest;
import turbomeca.gamme.ecran.client.model.edit.instructions.IModelSubPhaseService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public class ModelStatusSubPhaseService extends ModelStatusService {

	/** logger for current class */
	private static Logger logger = Logger
			.getLogger(ModelStatusSubPhaseService.class);

	/**
	 * 
	 * @param modelService
	 */
	public ModelStatusSubPhaseService(IModelObjectService modelService) {
		super(modelService);
	}

	@Override
	public boolean isDuplicable() throws ClientException {
		return true;
	}

	/**
	 * For the moment a sub-phase has forced a status "DONE" but in the future a sub-phase could be archived and not finished.
	 */
	@Override
	public boolean isAlterable() throws ClientException {
		return (getModelService().getParent().getStatusService().isAlterable() && !getStatus()
				.equals(StatusType.DONE.value()) && !getModelService().getWrapperService().isArchived());
	}

	@Override
	public void archive(int passingId, int iterationId, List<String> instancesId)
			throws ClientException {
		logger.debug("archive (" + instancesId + ") : " + getModelService());
		getStatusBuilder().cloneService(passingId, iterationId, instancesId);
	}

	@Override
	public void computeStatus(boolean recursively) throws ClientException, ClientInterruption {
		if(((ModelSubPhaseService) getModelService()).getSubPhase().isArchived()) return;
		logger.debug("computeStatus  : " + getModelService());
		boolean hasNoneSignature = ((IModelSubPhaseService) getModelService()).hasNoneSignature();
		
		/* When the sub phase has no child (only NotificationService, no task), 
		 	 its status must be updated to be signed (TO_SIGN), if predecessors are valid */
		boolean hasNoChildOrOnlyNotificationService = true;
		boolean statusMustNotBeComputedAgain = false;
		
		if (getInitStatus() == StatusType.TODO && recursively){
			for (IModelObjectService childModelService : getModelService().getChildren()) {
				childModelService.getStatusService().computeStatus(true);
				if (!(childModelService.getStatusService() instanceof ModelStatusNotificationsService)) {
					hasNoChildOrOnlyNotificationService = false;
				}
			}
			if (hasNoChildOrOnlyNotificationService) {
				boolean isPredecessorsValid = true;
		        ModelSubPhaseService subPhaseService = (ModelSubPhaseService) getModelService();
		        if (subPhaseService != null) {
		        	/* For assembly, the subphase service is runnable only if
					   subphase is editable, qualifications are valid and all its predecessors are signed */
		        	isPredecessorsValid = subPhaseService.getRunnableService().canRun();
		        }
				if (isPredecessorsValid) {
					updateState(StatusType.TO_SIGN.value(), false, null, null);
					statusMustNotBeComputedAgain = true;
				}
			}
		}

		/* A subPhase holding its @signature set to none must not update its status */
		if(hasNoneSignature) {
			updateState(StatusType.NONE.value(), false, null, null);
			
		/* If subPhase status has been set to TO_SIGN, doesn't compute Status again */
		} else if (!(statusMustNotBeComputedAgain)) {
			computeStatusForSignedSubphase();
		}
	}

	private void computeStatusForSignedSubphase() throws ClientException, ClientInterruption {
		if (!getModelService().getRunnableService().isFinished()) {
			StatusType currentStatus = getInitStatus();
			
			// Check if predecessors subphase are valid by checking runnable
			boolean isPredecessorsValid = getModelService().getRunnableService().canRun();
			
			if (currentStatus == StatusType.TODO) {
				for (IModelObjectService modelService : getModelService().getChildren()) {
					String status = modelService.getStatusService().getStatus();
					if (status != null && !status.equals(StatusType.NONE.value()) &&
							(modelService.getRunnableService().isRunnable() || isOnlyTaskPara(modelService))
							&& isPredecessorsValid) {
						if (status.equals(StatusType.TODO.value())) {
							currentStatus = StatusType.TODO;
							break;
						} else if (!StatusType.DONE.value().equals(getStatus())) {
							currentStatus = StatusType.TO_SIGN;
						} else {
							currentStatus = StatusType.DONE;
						}
					}
				}
			}
			if (getWrapperService().getState() != null) {
				updateState(currentStatus.value(), false, null, null);
			}
		}
	}

	/**
	 * check if the modelTaskservice contain only taskPara
	 * 
	 * FIXME: In fact it should be a better solution to return a NONE status for
	 * ModelTaskService for such objects but it's require a little refactor
	 * 
	 * @param modelService
	 *            : the modelTaskService
	 * @return
	 */
	private boolean isOnlyTaskPara(IModelObjectService modelService) {
		boolean isOnlyTaskPara = false;
		if(modelService instanceof ModelTaskService){
			isOnlyTaskPara = true;
			ModelTaskService taskService = (ModelTaskService) modelService;
			if(taskService.getTask() != null && taskService.getTask().getTaskChoice() != null){
				Enumeration<? extends TaskChoiceItem> enumChoice = taskService.getTask().getTaskChoice().enumerateTaskChoiceItem();
				if(enumChoice != null){
					while(enumChoice.hasMoreElements()) {
						TaskChoiceItem taskChoiceItem = enumChoice.nextElement();
						if (   taskChoiceItem.getTaskActionMeasure() != null
								|| taskChoiceItem.getTaskPiloting() != null
								|| taskChoiceItem.getTaskMark() != null
								|| taskChoiceItem.getTaskAction() != null
								|| taskChoiceItem.getTaskActionTable() != null) {
							isOnlyTaskPara = false;
							break;
						}
					}
				}
			}
		}
		return isOnlyTaskPara;
	}

	@Override
	public void clean(List<String> instancesId) throws ClientException, ClientInterruption {
		logger.debug("clean (" + instancesId + ") : " + getModelService());
		SubPhase subPhase = (SubPhase) getModelService().getWrapperService().getObject();
		if (getRequestContext().getRequestType() == ContextRequest.NEW_PASSING) {
			subPhase.setForcePredecessorsValid(false);
			subPhase.setUnlockComment(null);
		}
		subPhase.setDocumentsJoined(null);
		super.clean(instancesId);
	}

	@Override
	public boolean isInProgress() throws ClientException {
		boolean isInProgress = false;
		if (!getModelService().getRunnableService().isFinished()) {
			for (IModelObjectService modelService : getModelService().getChildren()) {
				isInProgress |= modelService.getStatusService().isInProgress();
				if (isInProgress) {
					break;
				}
			}
		}
		return isInProgress;
	}

	/**
	 * Check if resources has a taskAction in progress 
	 * and the taskAction is not inputConstant for changing level
	 * 
	 * @return
	 * @throws ClientException
	 */
	public boolean checkRessourcesToChangeLevel() throws ClientException {
		boolean hasTaskActionInProgress = false;
		if (!getModelService().getRunnableService().isFinished()) {
			for(IModelObjectService modelResourceService : getModelService().getChildrenDeep(ModelResourcesService.class)) {
				if(modelResourceService != null) {
					for (IModelObjectService modelObjectTaskActionService : modelResourceService.getChildrenDeep(ModelTaskActionService.class)) {
						ModelTaskActionService taskActionService = (ModelTaskActionService) modelObjectTaskActionService;
						if(!taskActionService.isInputConstantType() && modelObjectTaskActionService.getStatusService().isInProgress()) {
							hasTaskActionInProgress = true;
							break;
						}
					}
				}
			}
		}
		return hasTaskActionInProgress;
	}

	/**
	 *  Check if subphase has a taskAction in progress 
	 *  and the taskAction is not inputConstant 
	 *  for changing level
	 *  
	 * @return
	 */
	public boolean checkTasksToChangeLevel() throws ClientException {
		boolean hasTaskInProgress = false;
		if (!getModelService().getRunnableService().isFinished()) {
			for (IModelObjectService modelObjectTaskService : getModelService().getChildrenDeep(ModelTaskService.class)) {
				for (IModelObjectService modelObjectTaskActionService : modelObjectTaskService.getChildrenDeep(ModelTaskActionService.class)) {
					modelObjectTaskActionService.getStatusService().isInProgress();
					ModelTaskActionService taskActionService = (ModelTaskActionService) modelObjectTaskActionService;
					if(!taskActionService.isInputConstantType() && modelObjectTaskActionService.getStatusService().isInProgress()) {
						hasTaskInProgress = true;
						break;
					}
				}
				
			}
		}
		return hasTaskInProgress;
	}

	@Override
	public void updateActivity(boolean recursive, boolean delete, List<String> instancesId)
			throws ClientException, ClientInterruption {
		super.updateActivity(recursive, delete, instancesId);
		computeStatus(recursive);
	}
	
	@Override
	public void resetState(boolean recursively, boolean force, List<String> instancesId) throws ClientException, ClientInterruption {
		if(!((IModelSubPhaseService) getModelService()).hasNoneSignature()) {
			super.resetState(recursively, force, instancesId);
		}
	}

}
