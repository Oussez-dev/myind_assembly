package turbomeca.gamme.assembly.client.model.edit.runnable;

import turbomeca.gamme.ecran.client.model.interfaces.IModelRunnableService;

public class ModelRunnableNoneService implements IModelRunnableService {

	@Override
	public boolean isFinished() {
		return true;
	}

	@Override
	public boolean isRunnable() {
		return false;
	}

	@Override
	public boolean isValidable() {
		return false;
	}

	@Override
	public boolean isEditable() {
		return false;
	}

	@Override
    public boolean isOptional() {
        return false;
    }
	
	@Override
	public boolean canRun() {
		return false;
	}

	@Override
	public boolean canValidate() {
		return false;
	}

	@Override
	public boolean needValidation() {
		return false;
	}

    @Override
    public boolean hasRunner() {
        return false;
    }

	@Override
	public boolean isIgnored() {
		return false;
	}
}
