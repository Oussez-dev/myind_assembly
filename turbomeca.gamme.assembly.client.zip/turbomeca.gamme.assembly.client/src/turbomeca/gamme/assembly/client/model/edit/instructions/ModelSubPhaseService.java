package turbomeca.gamme.assembly.client.model.edit.instructions;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.activation.MimetypesFileTypeMap;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.model.edit.AModelAssemblyService;
import turbomeca.gamme.assembly.client.model.edit.hmi.updater.ModelHmiUpdaterService;
import turbomeca.gamme.assembly.client.model.edit.loader.ModelLoaderSubPhaseService;
import turbomeca.gamme.assembly.client.model.edit.notifications.AModelNotificationService;
import turbomeca.gamme.assembly.client.model.edit.notifications.ModelNotificationsService;
import turbomeca.gamme.assembly.client.model.edit.runnable.ModelRunnableSubPhaseService;
import turbomeca.gamme.assembly.client.model.edit.schedule.AssemblyScheduleService;
import turbomeca.gamme.assembly.client.model.edit.status.ModelStatusSubPhaseService;
import turbomeca.gamme.assembly.client.model.edit.utils.ModelUtils;
import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperSubPhaseService;
import turbomeca.gamme.assembly.services.model.data.DocumentJoined;
import turbomeca.gamme.assembly.services.model.data.DocumentsJoined;
import turbomeca.gamme.assembly.services.model.data.InfoSubPhase;
import turbomeca.gamme.assembly.services.model.data.Level;
import turbomeca.gamme.assembly.services.model.data.Matrix;
import turbomeca.gamme.assembly.services.model.data.MatrixMethod;
import turbomeca.gamme.assembly.services.model.data.Qualification;
import turbomeca.gamme.assembly.services.model.data.Qualifications;
import turbomeca.gamme.assembly.services.model.data.StatusInst;
import turbomeca.gamme.assembly.services.model.data.SubPhase;
import turbomeca.gamme.assembly.services.model.data.SubPhaseGroup;
import turbomeca.gamme.assembly.services.model.data.types.BooleanTypeWithNull;
import turbomeca.gamme.assembly.services.model.data.types.DocumentJoinType;
import turbomeca.gamme.assembly.services.model.data.types.StatusInstType;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.edit.instructions.IModelOperationService;
import turbomeca.gamme.ecran.client.model.edit.instructions.IModelSubPhaseService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.model.provider.ModelXmlProvider;
import turbomeca.gamme.ecran.client.model.voice.ModelSubPhaseVoiceService;

public class ModelSubPhaseService extends AModelAssemblyService implements IModelSubPhaseService {

	/** logger for current class */
	private static Logger logger = Logger.getLogger(ModelSubPhaseService.class);

	public ModelSubPhaseService(IModelObjectService parentModelService, SubPhase subPhase) {
		super(parentModelService.getDomain(), subPhase.getId());
		setParent(parentModelService);

		setWrapperService(new ModelWrapperSubPhaseService(subPhase));
		setLoaderService(new ModelLoaderSubPhaseService(this));
		setHmiUpdaterService(new ModelHmiUpdaterService());
		setStatusService(new ModelStatusSubPhaseService(this));
		setRunnableService(new ModelRunnableSubPhaseService(this));
		setVoiceService(new ModelSubPhaseVoiceService(this));
	}


	@Override
	public ModelWrapperSubPhaseService getWrapperService() {
		return (ModelWrapperSubPhaseService) super.getWrapperService();
	}


	/**
	 * @param level
	 * @return
	 */
	public boolean hasApplicablePredecessors(String level) {
		List<String> predecessors = getWrapperService().getPredecessors();
		for (String idPredecessor : predecessors) {
			IModelObjectService predecessor = ModelXmlProvider.getInstance().getModelService(idPredecessor);
			if (!((ModelSubPhaseService)predecessor).isLevelApplicable(level)) {
				return false;
			}
		}
		return true;
	}

	public boolean isLevelApplicable(List<String> currentLevels) {
		boolean isApplicable = false;
		for (String currentLevel : currentLevels) {
			isApplicable = isLevelApplicable(currentLevel);
			if (isApplicable == true) {
				break;
			}
		}
		return isApplicable;
	}

	/**
	 * @param sousPhaseService
	 * @return
	 */
	public boolean isLevelApplicable(String currentLevel) {
		Matrix matrix = ((SubPhase) getWrapperService().getObject()).getMatrix();
		if (matrix == null) {
			return true;
		}
		MatrixMethod matrixMethod = matrix.getMatrixMethod(0);
		if (matrixMethod == null) {
			return true;
		}
		Level[] levels = matrixMethod.getLevel();
		if (levels == null || levels.length == 0) {
			return false;
		}
		for (int i=0;i<levels.length;i++) {
			Level level = levels[i];
			if (currentLevel.equals(level.getLevel())) {
				return true;
			}
		}
		return false;
	}

	/**
	 * 
	 * @return
	 */
	public ModelNotificationsService getNotificationsService() {
		ModelNotificationsService notificationsService = null;
		if (getChildren().size() > 1) {
			IModelObjectService modelService = getChildren().get(0);
			if (modelService instanceof ModelNotificationsService) {
				notificationsService  = (ModelNotificationsService) modelService;
			}
		}
		return notificationsService;
	}


	/**
	 * 
	 * @return
	 */
	public ModelResourcesService getResourcesService() {
		ModelResourcesService resourcesService = null;
		if (getChildren().size() > 1) {
			IModelObjectService modelService = getChildren().get(1);
			if (modelService instanceof ModelResourcesService) {
				resourcesService = (ModelResourcesService) modelService;
			}
		}
		return resourcesService;
	}

	/**
	 * 
	 * @throws ClientException
	 */
	public void cleanIfInProgress() throws ClientException {
		ModelNotificationsService notificationsService = getNotificationsService();
		boolean canCleanSubPhase = getRunnableService().isRunnable() && getStatusService().isInProgress() && !belongToCurrentUser();
		if(notificationsService != null) {
			for (IModelObjectService notification : notificationsService.getChildren()) { 
				AModelNotificationService electronicNotif = (AModelNotificationService) notification;
				canCleanSubPhase = canCleanSubPhase && electronicNotif.isSubPhaseCleanable();
			}
		}

		if (canCleanSubPhase) {
			try {
				getStatusService().clean(null);
				getStatusService().resetState(true, true, null);
				getStatusService().computeStatus(false);
				ModelXmlProvider.getInstance().setModelStatus(ModelXmlProvider.MODEL_STATUS_MODIFIED);
			} catch (ClientInterruption e) {
				logger.error(e);
			}
		}
	}
	
	/**
	 * 
	 * @throws ClientException
	 */
	public void cleanSubPhase() throws ClientException {
		ModelNotificationsService notificationsService = getNotificationsService();
		boolean canCleanSubPhase = true;
		if(notificationsService != null) {
			for (IModelObjectService notification : notificationsService.getChildren()) { 
				AModelNotificationService electronicNotif = (AModelNotificationService) notification;
				canCleanSubPhase = canCleanSubPhase && electronicNotif.isSubPhaseCleanable();
			}
		}

		if (canCleanSubPhase) {
			try {
				getStatusService().clean(null);
				getStatusService().resetState(true, true, null);
				ModelXmlProvider.getInstance().setModelStatus(ModelXmlProvider.MODEL_STATUS_MODIFIED);
			} catch (ClientInterruption e) {
				logger.error(e);
			}
		}
	}

	public boolean isAssemblySubPhase() {
		boolean isAssemblySubPhase = false;
		String subPhaseType = getWrapperService().getSubPhase().getType();
		if (getAncestor(AssemblyScheduleService.class) != null) {
			if (subPhaseType == null || subPhaseType.equals("assembly_subphase")) {
				isAssemblySubPhase = true;
			}
		} else if (subPhaseType != null && subPhaseType.equals("assembly_subphase")) {
			isAssemblySubPhase = true;
		}
		return isAssemblySubPhase;
	}

	@Override
	public IModelOperationService getOperation() {
		return (IModelOperationService) getAncestor(ModelOperationService.class);
	}


	@Override
	public void switchToReplacement(IModelObjectService replaceService,
			String comment) throws ClientException, ClientInterruption {

		SubPhase currentSubPhaseObjBecomingAlternative = getWrapperService().getSubPhase();
		SubPhase newSubPhaseObjAlternative = ((ModelWrapperSubPhaseService) replaceService.getWrapperService()).getSubPhase();

		// Configure alternative for new subPhase
		newSubPhaseObjAlternative.removeAllAlternatives();
		for(Object alternativeRef : currentSubPhaseObjBecomingAlternative.getAlternatives()) {
			SubPhase subPhase = (SubPhase) alternativeRef;
			if (!subPhase.getId().equals(newSubPhaseObjAlternative.getId())) {
				newSubPhaseObjAlternative.addAlternatives(alternativeRef);
			}
		}

		// Set active subPhase become alternative
		getStatusService().clean(null);
		currentSubPhaseObjBecomingAlternative.setIsAlternative(true);
		IModelObjectService parentService = getParent();
		if (parentService instanceof ModelSubPhaseGroupService) {
			ModelSubPhaseGroupService subPhaseGroupService = (ModelSubPhaseGroupService) parentService;

			// Check if there is at least one subPhaseGroup not alternative for updated flag
			boolean hasSubPhaseNotAlternative = false;
			for(IModelObjectService subPhaseObjectService : subPhaseGroupService.getChildren()) {
				hasSubPhaseNotAlternative |= !((SubPhase) subPhaseObjectService.getWrapperService().getObject()).isIsAlternative();
			}
			subPhaseGroupService.getWrapperService().getSubPhaseGroup().setIsAlternative(!hasSubPhaseNotAlternative);
		}

		newSubPhaseObjAlternative.addAlternatives(currentSubPhaseObjBecomingAlternative);
		setModified();

		newSubPhaseObjAlternative.setIsAlternative(false);
		IModelObjectService parentNewService = replaceService.getParent();
		if (parentNewService instanceof ModelSubPhaseGroupService) {
			SubPhaseGroup subPhaseGroup = (SubPhaseGroup) parentNewService.getWrapperService().getObject();
			subPhaseGroup.setIsAlternative(false);
		}
		replaceService.getLoaderService().link();
		replaceService.setModified();

	}

	@Override
	public void addJoinedDocuments(File fileExport, String serverFileName,
			String comment) {
		SubPhase subPhase = getWrapperService().getSubPhase();
		if (subPhase.getDocumentsJoined() == null) {
			subPhase.setDocumentsJoined(new DocumentsJoined());
		}

		DocumentJoined document = new DocumentJoined();
		document.setName(fileExport.getName());
		document.setId(serverFileName);
		document.setUserMark(ModelUtils.buildUserMark());
		document.setDescription(comment);

		MimetypesFileTypeMap mimetypesFileTypeMap = new MimetypesFileTypeMap();
		mimetypesFileTypeMap.addMimeTypes("image/png png PNG");
		mimetypesFileTypeMap.addMimeTypes("image/svg svg SVG");
		mimetypesFileTypeMap.addMimeTypes("image/gif gif GIF");
		mimetypesFileTypeMap.addMimeTypes("image/ief ief");
		mimetypesFileTypeMap.addMimeTypes("image/jpeg jpeg jpg jpe JPG");
		mimetypesFileTypeMap.addMimeTypes("image/tiff tiff tif");
		mimetypesFileTypeMap.addMimeTypes("image/x-xwindowdump xwd");
		String mimetype= mimetypesFileTypeMap.getContentType(fileExport);
		String type = mimetype.split("/")[0];
		logger.info("AddjoinedDocument name : "+ serverFileName +" type :" +type);
		if(type.equals("image")) {
			document.setType(DocumentJoinType.IMAGE);
		}
		subPhase.getDocumentsJoined().addDocumentJoined(document);

	}

	@Override
	public void removeJoinedDocument(String documentId) {
		DocumentsJoined documents = getWrapperService().getSubPhase().getDocumentsJoined();
		Vector<DocumentJoined> subPhaseDocuments = new Vector<DocumentJoined>();
		for(DocumentJoined document : documents.getDocumentJoined()) {
			if (!document.getId().equals(documentId)) {
				subPhaseDocuments.add(document);
			}
		}
		getWrapperService().getSubPhase().getDocumentsJoined().setDocumentJoined(subPhaseDocuments);
	}

	@Override
	public boolean belongToCurrentUser() {
		return ModelUtils.isCurrentUser(getWrapperService().getState().getUserMark());
	}

	/**
	 * check if the statusInst of the subphase is setup
	 * @return
	 */
	public boolean isSetupSubPhase() {
		boolean isSetup = false;
		SubPhase sph = (SubPhase) getWrapperService().getObject();
		InfoSubPhase infosph = sph.getInfoSubPhase();
		if(infosph != null){
			StatusInst statusInstSph = infosph.getStatusInst();
			if(statusInstSph != null){
				if(statusInstSph.getStatusInst() != null){
					isSetup = statusInstSph.getStatusInst().equals(StatusInstType.SETUP);
				}
			}
		}
		return isSetup;
	}


	/**
	 * check if the subphase is alternative or not
	 * @return
	 */
	public boolean isAlternative() {
		boolean isAlternative = false;
		SubPhase sph = (SubPhase) getWrapperService().getObject();
		if(sph.hasIsAlternative()){
			isAlternative = sph.isIsAlternative();
		}
		else{
			isAlternative = false;
		}
		return isAlternative;
	}

	/**
	 * check if the subphase is archived or not
	 * @return
	 */
	public boolean isArchived() {
		boolean isArchived = false;
		SubPhase sph = (SubPhase) getWrapperService().getObject();
		if(sph.hasArchive()){
			isArchived = sph.isArchive();
		}
		else{
			isArchived = false;
		}
		return isArchived;
	}

	/**
	 * Get the qualifications of the subphase
	 * @return the qualifications
	 */
	public ArrayList<String> getQualifications(){
		ArrayList<String> qualificationsSubphase = new ArrayList<String>();
		SubPhase sph = (SubPhase) getWrapperService().getObject();
		Qualifications qualifs = sph.getQualifications();
		if(qualifs != null){
			for(Qualification qualif : qualifs.getQualification()){
				qualificationsSubphase.add(qualif.getQualification());
			}
		}
		return qualificationsSubphase;
	}


	/**
	 * Check if the subPhase is applicable or not
	 * @return
	 */
	public boolean isApplicable() {
		boolean isApplicable = false;
		SubPhase sph = (SubPhase) getWrapperService().getObject();
		if(sph.hasApplicable()){
			isApplicable = sph.isApplicable();
		}
		else{
			isApplicable = false;
		}
		return isApplicable;
	}
	
	@Override
	public boolean hasNoneSignature() {
		BooleanTypeWithNull signature = getWrapperService().getSubPhase()
				.getSignature();
		return BooleanTypeWithNull.NONE.equals(signature);
	}

	@Override
	public boolean hasFalseSignature() {
		BooleanTypeWithNull signature = getWrapperService().getSubPhase()
				.getSignature();
		return BooleanTypeWithNull.FALSE.equals(signature);
	}


	@Override
	public void updateComment(String comment) {
		SubPhase subPhase = getWrapperService().getSubPhase();
		subPhase.setComment(comment);
	}


	public boolean hasAlternatives() {
		boolean hasAlternative;
		SubPhase sph = (SubPhase) getWrapperService().getObject();
		if(sph.getAlternativesCount()>0){
			hasAlternative = true;
		}
		else{
			hasAlternative = false;
		}
		return hasAlternative;
	}
	
	public List<IModelObjectService> getAlternatives() {
		List<IModelObjectService> list = new ArrayList<IModelObjectService>();
		SubPhase sph = getWrapperService().getSubPhase();
		if (null != sph.getAlternatives()) {
			for (Object alternativeSubPhase : sph.getAlternatives()) {
				String id = ((SubPhase) alternativeSubPhase).getId();
				list.add(getModelProvider().getModelService(id));
			}
		}
		return list;
	}
	
	private ModelXmlProvider getModelProvider() {
		return ModelXmlProvider.getInstance();
	}
	
}
