package turbomeca.gamme.assembly.client.model.edit.wrappers;

import turbomeca.gamme.assembly.services.model.data.State;
import turbomeca.gamme.assembly.services.model.data.TaskPiloting;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public class ModelWrapperTaskPilotingService extends AModelWrapperAssemblyService {

	/** */
	private TaskPiloting taskPiloting;

	/**
	 * Constructor for task object
	 * 
	 * @param subPhaseService
	 *            parent service
	 * @param task
	 *            task object
	 */
	public ModelWrapperTaskPilotingService(TaskPiloting taskPiloting) {
		setTaskPiloting(taskPiloting);
	}


	@Override
	public Object getObject() {
		return taskPiloting;
	}

	/**
	 * @return the tools
	 */
	public TaskPiloting getTaskPiloting() {
		return taskPiloting;
	}

	/**
	 * @param tools
	 *            the tools to set
	 */
	public void setTaskPiloting(TaskPiloting taskPiloting) {
		this.taskPiloting = taskPiloting;
	}


	@Override
	public String getId() {
		return getTaskPiloting().getId();
	}


	@Override
	public void setId(String id) {
	    getTaskPiloting().setId(id);
	}


	@Override
	public void addChild(IModelObjectService nextChild, IModelObjectService newChild)
			throws ClientException {
	}

	@Override
    public State getState() {
        return getTaskPiloting().getState();
    }
}
