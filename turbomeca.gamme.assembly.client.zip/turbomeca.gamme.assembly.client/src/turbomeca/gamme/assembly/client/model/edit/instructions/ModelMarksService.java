package turbomeca.gamme.assembly.client.model.edit.instructions;

import turbomeca.gamme.assembly.client.model.edit.AModelAssemblyService;
import turbomeca.gamme.assembly.client.model.edit.hmi.updater.ModelHmiUpdaterService;
import turbomeca.gamme.assembly.client.model.edit.loader.ModelLoaderMarksService;
import turbomeca.gamme.assembly.client.model.edit.runnable.ModelRunnableStatusNoneService;
import turbomeca.gamme.assembly.client.model.edit.status.ModelStatusService;
import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperMarksService;
import turbomeca.gamme.assembly.services.model.data.Marks;

public class ModelMarksService extends AModelAssemblyService {

	public static final String MARKS_SUFFIX_ID = "_marks";

	/**
	 * Constructor for task object
	 * 
	 * @param subPhaseService
	 *            parent service
	 * @param task
	 *            task object
	 */
	public ModelMarksService(ModelResourcesService resourcesService, Marks marks) {
		super(resourcesService.getDomain(), resourcesService.getIdentifier() + MARKS_SUFFIX_ID);
		setParent(resourcesService);
		
		setWrapperService(new ModelWrapperMarksService(marks));
		setLoaderService(new ModelLoaderMarksService(this));
		setHmiUpdaterService(new ModelHmiUpdaterService());
		setStatusService(new ModelStatusService(this));
		setRunnableService(new ModelRunnableStatusNoneService(this));
	}
	
	@Override
    public boolean isInnerContentHtml() {
		return true;
	}

}
