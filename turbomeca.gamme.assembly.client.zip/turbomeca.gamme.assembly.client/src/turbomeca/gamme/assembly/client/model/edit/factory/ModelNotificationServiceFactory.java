package turbomeca.gamme.assembly.client.model.edit.factory;

import turbomeca.gamme.assembly.client.model.edit.notifications.IModelNotificationService;
import turbomeca.gamme.assembly.client.model.edit.notifications.ModelNotificationMarkService;
import turbomeca.gamme.assembly.client.model.edit.notifications.ModelNotificationNcrService;
import turbomeca.gamme.assembly.client.model.edit.notifications.ModelNotificationTaskBenchService;
import turbomeca.gamme.assembly.client.model.edit.notifications.ModelNotificationUserService;
import turbomeca.gamme.assembly.client.model.edit.notifications.ModelNotificationsService;
import turbomeca.gamme.assembly.services.model.data.ElectronicNotification;

public class ModelNotificationServiceFactory {

	public static IModelNotificationService create(ModelNotificationsService notificationsService, ElectronicNotification electronicNotification) {
	    IModelNotificationService modelNotificationService = null;
	    if (electronicNotification != null) {
    		switch (electronicNotification.getOrigin()) {
    		case USER:
    		    modelNotificationService = new ModelNotificationUserService(notificationsService, electronicNotification);
                break;
    		case MARK:
                modelNotificationService = new ModelNotificationMarkService(notificationsService, electronicNotification);
                break;
    		case NCR:
                modelNotificationService = new ModelNotificationNcrService(notificationsService, electronicNotification);
                break;
    		case TASK_BENCH:
                modelNotificationService = new ModelNotificationTaskBenchService(notificationsService, electronicNotification);
                break;  
			default:
				break;
    		}
	    }
		return modelNotificationService;
	}
}
