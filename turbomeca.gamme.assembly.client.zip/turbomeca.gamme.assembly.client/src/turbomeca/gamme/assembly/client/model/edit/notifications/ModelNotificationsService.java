package turbomeca.gamme.assembly.client.model.edit.notifications;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.model.edit.AModelAssemblyService;
import turbomeca.gamme.assembly.client.model.edit.hmi.updater.ModelHmiUpdaterService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.client.model.edit.loader.ModelLoaderElectronicNotificationsService;
import turbomeca.gamme.assembly.client.model.edit.provider.ModelNotificationProvider;
import turbomeca.gamme.assembly.client.model.edit.runnable.ModelRunnableNoneService;
import turbomeca.gamme.assembly.client.model.edit.status.ModelStatusNotificationsService;
import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperElectronicNotificationsService;
import turbomeca.gamme.assembly.services.model.data.ElectronicNotification;
import turbomeca.gamme.assembly.services.model.data.ElectronicNotifications;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public class ModelNotificationsService extends AModelAssemblyService {

    /** logger for current class */
    private static Logger logger = Logger.getLogger(ModelNotificationsService.class);
    
    /** */
    private static final String PREFIX_NOTIFICATIONS = "notif_";
    
    /**
     * 
     * @param subPhaseService
     * @param electronicNotifications
     */
    public ModelNotificationsService(ModelSubPhaseService subPhaseService, 
                                     ElectronicNotifications electronicNotifications) {
        super(subPhaseService.getDomain(), PREFIX_NOTIFICATIONS + subPhaseService.getIdentifier());
        setParent(subPhaseService);
        setRunnableService(new ModelRunnableNoneService());
        setLoaderService(new ModelLoaderElectronicNotificationsService(this));
        setHmiUpdaterService(new ModelHmiUpdaterService());
        setStatusService(new ModelStatusNotificationsService(this));
        setWrapperService(new ModelWrapperElectronicNotificationsService(electronicNotifications));
    }
    
    @Override
    public ModelWrapperElectronicNotificationsService getWrapperService() {
        return (ModelWrapperElectronicNotificationsService) super.getWrapperService();
    }
   
    /**
     * 
     * @param modelService
     * @throws ClientException
     */
    public void addNotificationChild(IModelObjectService modelService) throws ClientException {
        logger.debug("addNotificationChild " + modelService);
        
        AModelNotificationService notificationService = (AModelNotificationService) modelService;
        notificationService.setParent(this);
        
        ModelSubPhaseService subPhaseService = (ModelSubPhaseService) getParent();
        ElectronicNotifications notifications = getWrapperService().getElectronicNotifications();
        if (notifications == null) {
            logger.debug("No child exist, create object");
            notifications = new ElectronicNotifications();
            subPhaseService.getWrapperService().getSubPhase().setElectronicNotifications(notifications);
            getWrapperService().setElectronicNotifications(notifications);
        } else {
            logger.debug("Search existed child with same reference");
            String referenceId = notificationService.getIdentifierReferenced();
            if (referenceId != null) {
                for(IModelObjectService childService : getChildren()) {
                    AModelNotificationService childNotificationService = (AModelNotificationService) childService;
                    if (notificationService.equals(childNotificationService)) {
                        childNotificationService.getElectronicNotification().setActive(false);
                        logger.debug("Set unactive notification : " + childNotificationService);
                        ModelNotificationProvider.getInstance().addNotificationServiceToErase(childNotificationService);
                    }
                }
            }
        }
        
        notifications.addElectronicNotification(notificationService.getElectronicNotification());
        getModelNotificationProvider().addNotificationService(notificationService);
        
        setModified();
        super.addChild(notificationService);
    }
    
    /**
     * remove all notification with flag active at false
     * @param notificationService
     * @throws ClientException
     */
    public void removeInactiveNotifications() throws ClientException {
        ElectronicNotifications notifications = getWrapperService().getElectronicNotifications();
        if (notifications != null) {
            Vector<ElectronicNotification> electNotif = new Vector<ElectronicNotification>();
            List<IModelObjectService> notificationServiceList = new ArrayList<IModelObjectService>();
            for(IModelObjectService childService : getChildren()) {
                AModelNotificationService childNotificationService = (AModelNotificationService) childService;
                if (childNotificationService.getElectronicNotification().isActive()) {
                    electNotif.add(childNotificationService.getElectronicNotification());
                    notificationServiceList.add(childNotificationService);
                }
            }
            notifications.setElectronicNotification(electNotif);
            getChildren().clear();
            getChildren().addAll(notificationServiceList);
            setModified();
        }
    }
    
    /**
     * 
     * @return
     */
    public ModelNotificationProvider getModelNotificationProvider() {
        return ModelNotificationProvider.getInstance();
    }
}
