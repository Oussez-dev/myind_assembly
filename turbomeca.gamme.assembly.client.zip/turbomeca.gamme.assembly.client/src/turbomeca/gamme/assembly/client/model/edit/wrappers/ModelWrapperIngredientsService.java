package turbomeca.gamme.assembly.client.model.edit.wrappers;

import turbomeca.gamme.assembly.services.model.data.Ingredients;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public class ModelWrapperIngredientsService extends AModelWrapperAssemblyService {

	/** */
	private Ingredients ingredients;

	/**
	 * Constructor for task object
	 * 
	 * @param subPhaseService
	 *            parent service
	 * @param task
	 *            task object
	 */
	public ModelWrapperIngredientsService(Ingredients ingredients) {
		setIngredients(ingredients);
	}


	@Override
	public Object getObject() {
		return ingredients;
	}

	/**
	 * @return the tools
	 */
	public Ingredients getIngredients() {
		return ingredients;
	}

	/**
	 * @param tools
	 *            the tools to set
	 */
	public void setIngredients(Ingredients ingredients) {
		this.ingredients = ingredients;
	}


	@Override
	public String getId() {
		return null;
	}


	@Override
	public void setId(String id) {
	}


	@Override
	public void addChild(IModelObjectService nextChild, IModelObjectService newChild)
			throws ClientException {
	}

	@Override
	public boolean isApplicable() {
		return true;
	}

	@Override
	public void setApplicable(boolean applicable) {
	}
}
