package turbomeca.gamme.assembly.client.model.edit.runnable;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.client.model.edit.notifications.AModelNotificationService;
import turbomeca.gamme.assembly.client.model.edit.notifications.ModelNotificationsService;
import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperSubPhaseService;
import turbomeca.gamme.assembly.services.model.data.ElectronicNotifications;
import turbomeca.gamme.assembly.services.model.data.types.BooleanTypeWithNull;
import turbomeca.gamme.assembly.services.model.data.types.StatusType;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.services.common.constants.OpenMode;
import turbomeca.gamme.ecran.services.common.utils.misc.FormatUtils;

public class ModelRunnableSubPhaseService extends
		ModelRunnableStatusDefaultService {
	
	public ModelRunnableSubPhaseService(IModelObjectService modelService) {
		super(modelService);
	}

	@Override
	public ModelWrapperSubPhaseService getWrapperService() {
		return (ModelWrapperSubPhaseService) super.getWrapperService();
	}

	@Override
	public boolean needValidation() {
		return BooleanTypeWithNull.TRUE.equals(getWrapperService().getSubPhase().getSignature());
	}

	@Override
	public boolean isValidable() {
		return (getWrapperService().getState().getStatus() == StatusType.TO_SIGN)
				&& needValidation();
	}

	@Override
	public boolean isRunnable() {
		return super.isRunnable()
				&& !getWrapperService().getSubPhase().isIsAlternative() && !getWrapperService().getSubPhase().isArchive();
	}

	@Override
	public boolean canValidate() {
		boolean canValidate = super.canValidate() ;
		ModelSubPhaseService subPhase = (ModelSubPhaseService) getModelService();
		canValidate = canValidate && !subPhase.hasNoneSignature();
		if (canValidate) {
			
			ModelNotificationsService notificationsService = subPhase.getNotificationsService();
			ElectronicNotifications notifications = getWrapperService().getSubPhase().getElectronicNotifications();
			if (notifications != null) {
				for (IModelObjectService notification : 		notificationsService.getChildren()) {
					AModelNotificationService electronicNotif = (AModelNotificationService) notification;
					canValidate = canValidate && !electronicNotif.isBlockingSign();
				}
			}
		}
		if (canValidate) {
		    getWrapperService().getSubPhase().setValidable(true);
		}
		return canValidate;
	}

	@Override
	public boolean canRun() {
		boolean canRun = super.canRun();
		if (canRun) {
			if (getUserContext() != null) {
				switch (getUserContext().getWritingMode()) {
				case OpenMode.OPEN_MODE_MULTI_EDIT:
					canRun = FormatUtils.contains(getEditingContext()
							.getObjectEdited(), getModelService()
							.getIdentifier());
					break;
				case OpenMode.OPEN_MODE_EDIT:
					canRun = true;
					break;
				case OpenMode.OPEN_MODE_READ:
					canRun = false;
					break;
				}
			}
		}
		return canRun;
	}
}
