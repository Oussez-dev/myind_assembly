package turbomeca.gamme.assembly.client.model.edit.loader;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

import com.rits.cloning.Cloner;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelMarkService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskActionService;
import turbomeca.gamme.assembly.client.model.edit.notifications.AModelNotificationService;
import turbomeca.gamme.assembly.client.model.edit.notifications.ModelNotificationMarkService;
import turbomeca.gamme.assembly.client.model.edit.provider.ModelMarkProvider;
import turbomeca.gamme.assembly.client.model.edit.provider.ModelNotificationProvider;
import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperMarkService;
import turbomeca.gamme.assembly.services.model.data.AdditionalRecord;
import turbomeca.gamme.assembly.services.model.data.Derogation;
import turbomeca.gamme.assembly.services.model.data.Dirty;
import turbomeca.gamme.assembly.services.model.data.ElectronicNotification;
import turbomeca.gamme.assembly.services.model.data.ElectronicNotificationRef;
import turbomeca.gamme.assembly.services.model.data.InputAction;
import turbomeca.gamme.assembly.services.model.data.InputField;
import turbomeca.gamme.assembly.services.model.data.Mark;
import turbomeca.gamme.assembly.services.model.data.PN;
import turbomeca.gamme.assembly.services.model.data.SN;
import turbomeca.gamme.assembly.services.model.data.TaskAction;
import turbomeca.gamme.assembly.services.model.data.TaskMark;
import turbomeca.gamme.assembly.services.model.data.types.BooleanType;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.interfaces.IModelLoaderService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.model.provider.ModelXmlProvider;

public class ModelLoaderMarkService extends AModelAssemblyLoader implements IModelLoaderService {

    public ModelLoaderMarkService(IModelObjectService modelService) {
        super(modelService);
    }

    @Override
    public ModelWrapperMarkService getWrapperService() {
        return (ModelWrapperMarkService) super.getWrapperService();
    }

    @Override
    public ModelMarkService getModelService() {
        return (ModelMarkService) super.getModelService();
    }

    public void load(ModelXmlProvider modelProvider) throws ClientException, ClientInterruption {
        Mark mark = getWrapperService().getMark();
        
        List<ModelTaskActionService> derogsTaskActionService = new ArrayList<ModelTaskActionService>();
        
        // Load PN (if exist)
        Enumeration<? extends PN> enumPn = mark.enumeratePN();
        while (enumPn.hasMoreElements()) {
            loadTaskAction(modelProvider, mark.getId(), enumPn.nextElement().getTaskAction(),
                    ModelMarkService.TASK_ACTION_PN_TYPE, true);
        }
        // Load SN (if exist)
        if (mark.getSN() != null) {
	     	for (SN sn : mark.getSN()) {
	            loadTaskAction(modelProvider, mark.getId(), sn.getTaskAction(), ModelMarkService.TASK_ACTION_SN_TYPE, true);
	        }
        }
        // Load derogation
     	if (mark.getDerogation() != null) {
	        for (Derogation derogation : mark.getDerogation()) {
	        	if(derogation.getTaskAction() != null ) {
	        		derogation.getTaskAction().setDuplicable(true);
	        	
		            ModelTaskActionService taskActionService = loadTaskAction(modelProvider, mark.getId(), derogation.getTaskAction(),
		                    ModelMarkService.TASK_ACTION_DEROG_TYPE, true);
		            taskActionService.setOptional(true);
		            derogsTaskActionService.add(taskActionService);
	        	}
	     	}
     	}
        // Load additionalRecord
     	if (mark.getAdditionalRecord() != null) {
	        for (AdditionalRecord additionalRecord : mark.getAdditionalRecord()) {
	        	if(additionalRecord.getTaskAction() != null ) {
		            ModelTaskActionService taskActionService = loadTaskAction(modelProvider, mark.getId(), additionalRecord.getTaskAction(),
		            		ModelMarkService.TASK_ACTION_ADDITIONAL_RECORD_TYPE + "_" + additionalRecord.getType(), true);
		            
		            if(BooleanType.FALSE.equals(additionalRecord.getOptional())){
		            	taskActionService.setOptional(false);
		            } else {
		            	taskActionService.setOptional(true);
		            }
		            
		            if( derogsTaskActionService.size() != 0 && additionalRecord.getTaskAction().hasDuplicable() 
		            		&& additionalRecord.getTaskAction().isDuplicable() ) {
		            	if(additionalRecord.getTaskAction().getInstance() != 0 && additionalRecord.getTaskAction().getInstance() == derogsTaskActionService.get(additionalRecord.getTaskAction().getInstance()-1).getTaskAction().getInstance()){
		            		//multi-instance
		            		//TODO : AdditionalRecords were created for SPU and for SPU there are only mono-instance, so this case doesn't happen yet.
		            		derogsTaskActionService.get(additionalRecord.getTaskAction().getInstance()-1).getServicesToDuplicateOnDuplication().add(taskActionService);
		            	} else if(additionalRecord.getTaskAction().getInstance() == derogsTaskActionService.get(additionalRecord.getTaskAction().getInstance()).getTaskAction().getInstance()
		            			&& !additionalRecord.getTaskAction().getDuplicated()) {
		            		//mono-instance treatment
		            		int i = 0;
		            		int indexAssociatedDerogation;
		            		
		            		//we have to find the index of the derog associated with this additionalRecord
		            		for (i = 0; i < derogsTaskActionService.size(); i++){
		            			if(derogsTaskActionService.get(i).getTaskAction().getDuplicationIndex() == additionalRecord.getTaskAction().getDuplicationIndex()){
		            				indexAssociatedDerogation = i;
		            				derogsTaskActionService.get(indexAssociatedDerogation).getServicesToDuplicateOnDuplication().add(taskActionService);
		            				break;
		            			}
		            		}
		            	}
		            }
	            }
	     	}
     	}
     	
        // Load checkBox
        loadTaskAction(modelProvider, mark.getId(), mark.getTaskAction(), ModelMarkService.TASK_ACTION_CHECK_TYPE);
        
        mark.enumerateAdditionalRecord();
        
        if (modelProvider != null) {
            modelProvider.addModelService(mark.getId(), getModelService());
        }
    }

    
    /***
	 * 
	 * Architecture Note:
	 * <p>
	 * <code>link</code> method aims to manage relationship between ModelService and
	 * associated instance relational Services for EVAL UFI
	 * <p>
	 * Here the method is used to perform schedule update at schedule startup
	 * 
	 * This is not the right place to put this code.
	 * <p>
	 * => It should be re-factored to be moved inside a standard action launched
	 * only after schedule model is loaded (not while it is loaded).
	 * <p>
	 * This may lead to un-consistent model loading/reload (a model reload may be
	 * requested on any event)
	 * 
	 * 
	 */
    @Override
    public void link() throws ClientException, ClientInterruption {
        List<ModelMarkService> marks = ModelMarkProvider.getInstance().getMarks(getWrapperService().getMark().getNameId());
        Mark mark = getModelService().getWrapperService().getMark();
        
        // Update dirty
        updateDirtyWithExistingMarks(marks);
        
        // Update mark references
        if (mark.getPN() != null) {
            for(PN pn : mark.getPN()) {
                String notificationId = updateWithExistingMarks(marks, pn.getTaskAction(), ModelMarkService.TASK_ACTION_PN_TYPE);
                if (notificationId != null) {
                    List<AModelNotificationService> associatedNotifications = ModelNotificationProvider.getInstance().getNotifications(notificationId);
                    if (associatedNotifications != null && associatedNotifications.size() != 0) {
                        ModelNotificationMarkService associatedNotification = (ModelNotificationMarkService) associatedNotifications.get(0);
                        
                        Cloner cloner = new Cloner(); 
                        ElectronicNotification notificationCloned = cloner.deepClone(associatedNotification.getElectronicNotification());
                        
                        AModelNotificationService notificationService = new ModelNotificationMarkService(getModelService(), notificationCloned);
                        notificationService.bindService(getModelService());
                    }
                }
            }
            
            if (mark.getSN() != null) {
            	for (SN sn : mark.getSN()) {
            		updateWithExistingMarks(marks, sn.getTaskAction(), ModelMarkService.TASK_ACTION_SN_TYPE);
            	}
            }
            
            if (mark.getDerogation() != null) {
            	for (Derogation derogation : mark.getDerogation()) {
            		updateWithExistingMarks(marks, derogation.getTaskAction(), ModelMarkService.TASK_ACTION_DEROG_TYPE);
            	}
            }
        }
    }
    
    private void updateDirtyWithExistingMarks(List<ModelMarkService> marks) {
        if (marks != null && marks.size() != 0) {
            Mark markReference = marks.get(0).getWrapperService().getMark();
            if (markReference.getDirty() != null) {
                Cloner cloner = new Cloner(); 
                Dirty dirty = cloner.deepClone(markReference.getDirty());
                getModelService().getWrapperService().getMark().setDirty(dirty);
                
                // Update dirty status of its marks references in task
                for(TaskMark taskMark : getModelService().getMarkTaskReferences()) {
                    Dirty dirtyRef = cloner.deepClone(markReference.getDirty());
                    taskMark.setDirty(dirtyRef); 
                }
            }
        }
    }
    
    private String updateWithExistingMarks(List<ModelMarkService> marks, TaskAction taskAction, String type) throws ClientException, ClientInterruption {
        if (marks != null && marks.size() != 0) {
            String instanceId = null;
            if (taskAction.hasInstance()) {
                instanceId = String.valueOf(taskAction.getInstance());
            } else if (getWrapperService().getMark().hasInstance()) {
                instanceId = String.valueOf(getWrapperService().getMark().getInstance());
            }
            
            String alternativeId = null;
            if (taskAction.hasAlternative()) {
                alternativeId = String.valueOf(taskAction.getAlternative());
            }
            
            for (ModelMarkService markService : marks) {
                ModelTaskActionService modelTaskActionLinked = markService.getTaskActionType(type, instanceId, alternativeId, null);
                if (    modelTaskActionLinked != null 
                    &&  modelTaskActionLinked.getAncestor(ModelSubPhaseService.class).getRunnableService().isRunnable()) {
                    
                    TaskAction taskActionReference = modelTaskActionLinked.getTaskAction();
                    
                    Cloner cloner = new Cloner(); 
                    
                    InputAction inputAction = cloner.deepClone(taskActionReference.getInputAction());
                    taskAction.setInputAction(inputAction);
                    
                    if (taskActionReference.hasForceEditable()) {
                        taskAction.setForceEditable(taskActionReference.getForceEditable());
                    }
                    
                    if (taskActionReference.hasEditable()) {
                        taskAction.setEditable(taskActionReference.getEditable());
                    }
                    
                    // Update references
                    IModelObjectService modelService = getModelProvider().getModelService(taskAction.getId());
                    if (modelService != null) {
                        modelService.getStatusService().setServiceModified();
                    } 
                    
                    // Check notification
                    ElectronicNotificationRef[] notifRefs = markService.getWrapperService().getElectronicNotificationRef();
                    if (notifRefs != null) {
                        for(ElectronicNotificationRef notifRef : notifRefs) {
                            boolean isNotifCompliant = true;
                            if (alternativeId != null) {
                                isNotifCompliant |= alternativeId.equals(notifRef.getAlternative());
                            }
                            if (instanceId != null) {
                                isNotifCompliant |= instanceId.equals(notifRef.getInstance());
                            }
                            
                            if (isNotifCompliant) {
                                return notifRef.getRefId();
                            }
                        }
                    }
                    return null;
                } else {
                    // No mark was found, so update editable flag according input type
                    InputField inputField = taskAction.getInputAction().getInputActionChoice().getInputField();
                    if (inputField != null) {
                        if (    taskAction.getInputAction().getInputValue() != null
                             && taskAction.getInputAction().getInputValue().getValue() != null) {
                            taskAction.getInputAction().setDefaultValue(
                                    taskAction.getInputAction().getInputValue().getValue());
                            taskAction.setEditable(false);
                        }
                    }
                }
            }
        }
        return null;
    }
}
