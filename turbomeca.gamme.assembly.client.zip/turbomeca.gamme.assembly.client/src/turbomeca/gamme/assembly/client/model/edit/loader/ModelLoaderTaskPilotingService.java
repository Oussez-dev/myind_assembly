package turbomeca.gamme.assembly.client.model.edit.loader;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskPilotingService;
import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperTaskPilotingService;
import turbomeca.gamme.assembly.services.model.data.TaskAction;
import turbomeca.gamme.assembly.services.model.data.TaskActionPilotingResult;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.interfaces.IModelLoaderService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.model.provider.ModelXmlProvider;
import turbomeca.gamme.ecran.services.model.tool.TaskPilotingConstants;

public class ModelLoaderTaskPilotingService extends AModelAssemblyLoader implements IModelLoaderService {

	public ModelLoaderTaskPilotingService(IModelObjectService modelService) {
		super(modelService);
	}

	@Override
	public ModelWrapperTaskPilotingService getWrapperService() {
		return (ModelWrapperTaskPilotingService) super.getWrapperService();
	}

	@Override
	public ModelTaskPilotingService getModelService() {
		return (ModelTaskPilotingService) super.getModelService();
	}

	@Override
	public void load(ModelXmlProvider modelProvider) throws ClientException, ClientInterruption {
		loadTaskAction(modelProvider, getWrapperService().getId(),
				getWrapperService().getTaskPiloting().getTaskAction());

		// load TaskActionPilotingResult
		if (TaskPilotingConstants.TOOL_TYPE_SCREW_DRIVER.equals(getWrapperService().getTaskPiloting().getTool())) {
			TaskActionPilotingResult tapr = getWrapperService().getTaskPiloting().getTaskActionPilotingResult();
			if (tapr != null) {
				TaskAction[] taskActionPilotingResults = tapr.getTaskAction();
				for (int i = 0; i < taskActionPilotingResults.length; i++) {
					loadTaskAction(modelProvider, getWrapperService().getId(), taskActionPilotingResults[i]);
				}
			}
		}

		if (modelProvider != null) {
			modelProvider.addModelService(getModelService().getIdentifier(), getModelService());
		}
	}
}
