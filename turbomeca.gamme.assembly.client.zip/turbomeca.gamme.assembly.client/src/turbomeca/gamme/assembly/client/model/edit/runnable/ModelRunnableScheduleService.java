package turbomeca.gamme.assembly.client.model.edit.runnable;

import java.util.ArrayList;
import java.util.Collections;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseGroupService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.client.model.edit.schedule.AAssemblyScheduleService;
import turbomeca.gamme.assembly.client.module.edition.AssemblyEditionController;
import turbomeca.gamme.assembly.client.utils.AssemblyUtils;
import turbomeca.gamme.assembly.services.model.data.types.StatusType;
import turbomeca.gamme.ecran.client.constants.PropertyConstants;
import turbomeca.gamme.ecran.client.hmi.HmiLogger;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.services.common.constants.GlobalConstants;
import turbomeca.gamme.ecran.services.common.constants.OpenMode;

public class ModelRunnableScheduleService extends ModelRunnableStatusDefaultService {

	public ModelRunnableScheduleService(IModelObjectService modelService) {
		super(modelService);
	}

	@Override
	public AAssemblyScheduleService getModelService() {
		return (AAssemblyScheduleService) super.getModelService();
	}

	@Override
	public boolean isFinished() {
		return super.isFinished()
				&& (getWrapperService().getState().getStatus() == StatusType.TO_SIGN);
	}

	@Override
	public boolean canValidate() {
		return hasAllSubphaseInEdition() && AssemblyUtils.isAdminForCloseSchedule(getConfiguration(), getContextConfig());
	}

	public boolean hasAllSubphaseInEdition() {
		boolean hasAllSubhaseInEdition = false;
		ArrayList<String> listSubPhaseEdited = new ArrayList<String>();
		if(getEditingContext() != null && getEditingContext().getObjectEdited() != null){
			Collections.addAll(listSubPhaseEdited, getEditingContext().getObjectEdited()); 
			hasAllSubhaseInEdition = true;
		}
		for(IModelObjectService service : getModelService().getChildrenDeep(ModelSubPhaseService.class)){
			ModelSubPhaseService subPhaseService = (ModelSubPhaseService) service;
			if(!listSubPhaseEdited.contains(subPhaseService.getIdentifier()) && (!subPhaseService.isAlternative() && !subPhaseService.isArchived() && subPhaseService.isApplicable())){
				hasAllSubhaseInEdition = false;
				break;
			}
		}
		if(hasAllSubhaseInEdition){
			for(IModelObjectService service : getModelService().getChildrenDeep(ModelSubPhaseGroupService.class)){
				ModelSubPhaseGroupService subPhaseGroupService = (ModelSubPhaseGroupService) service;
				if(!listSubPhaseEdited.contains(service.getIdentifier()) && (!subPhaseGroupService.isAlternative() && !subPhaseGroupService.isArchived() && subPhaseGroupService.isApplicable())){
					hasAllSubhaseInEdition = false;
					break;
				}
			}
		}
		return hasAllSubhaseInEdition;
	}

	public boolean canRunForMultiEdition(AssemblyEditionController editionController, boolean outOfDate){
		boolean canRun = false;
		if(getConfiguration().getConfigRange().getWritingMode() != OpenMode.OPEN_MODE_EDIT){
			boolean allSubphaseInEdition = editionController.updateAllSubPhaseInEdition(false);
			if(allSubphaseInEdition){
				if(hasAllSubphaseInEdition()){
					if(outOfDate){
						HmiLogger.getInstance().error(PropertyConstants.PROPERTY_ERROR_RANGE_OUT_OF_DATE);
					}
					else{
						canRun = true;
					}
				}
				else{
					HmiLogger.getInstance().error(PropertyConstants.PROPERTY_ERROR_UPDATE_EDITION_ALL_SUBPHASE);
				}
			}
			else{
				HmiLogger.getInstance().error(PropertyConstants.PROPERTY_ERROR_UPDATE_EDITION_ALL_SUBPHASE);
			}
		}
		else{
			canRun = true;
		}
		return canRun;
	}

	public boolean hasAllObjectInEditionWithList(String listObjectId) {
		boolean hasAllObjectInEdition = true;
		String[] listIdOject = listObjectId.split(GlobalConstants.SEPARATOR_DOT_COMA);
		ArrayList<String> listSubPhaseEdited = new ArrayList<String>();
		if(listIdOject != null){
			Collections.addAll(listSubPhaseEdited, listIdOject); 
		}
		for(IModelObjectService service : getModelService().getChildrenDeep(ModelSubPhaseService.class)){
			ModelSubPhaseService subPhaseService = (ModelSubPhaseService) service;
			if(!listSubPhaseEdited.contains(subPhaseService.getIdentifier()) && (!subPhaseService.isAlternative() && !subPhaseService.isArchived() && subPhaseService.isApplicable())){
				hasAllObjectInEdition = false;
				break;
			}
		}
		if(hasAllObjectInEdition){
			for(IModelObjectService service : getModelService().getChildrenDeep(ModelSubPhaseGroupService.class)){
				ModelSubPhaseGroupService subPhaseGroupService = (ModelSubPhaseGroupService) service;
				if(!listSubPhaseEdited.contains(service.getIdentifier()) && (!subPhaseGroupService.isAlternative() && !subPhaseGroupService.isArchived() && subPhaseGroupService.isApplicable())){
					hasAllObjectInEdition = false;
					break;
				}
			}
		}
		return hasAllObjectInEdition;
	}
}
