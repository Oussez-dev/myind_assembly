package turbomeca.gamme.assembly.client.model.edit.instructions;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.model.edit.AModelAssemblyService;
import turbomeca.gamme.assembly.client.model.edit.loader.ModelLoaderTaskActionTableService;
import turbomeca.gamme.assembly.client.model.edit.runnable.ModelRunnableTaskActionTableService;
import turbomeca.gamme.assembly.client.model.edit.status.ModelStatusNoneService;
import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperTaskActionTableService;
import turbomeca.gamme.assembly.services.model.data.TaskActionTable;
import turbomeca.gamme.assembly.services.model.data.Test;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public class ModelTaskActionTableService extends AModelAssemblyService{

	/** logger for current class */
	private static Logger logger = Logger.getLogger(ModelTaskActionTableService.class);
	
	public ModelTaskActionTableService(IModelObjectService parentService, TaskActionTable taskActionTable) {
		super(parentService.getDomain(), taskActionTable.getId());
		
		setParent(parentService);
		setLoaderService(new ModelLoaderTaskActionTableService(this));
		setRunnableService(new ModelRunnableTaskActionTableService(this));
		setWrapperService(new ModelWrapperTaskActionTableService(taskActionTable));
		setStatusService(new ModelStatusNoneService(this));
	}
	
	public ModelTaskActionTableService(String domain, String identifier) {
		super(domain, identifier);
	}
	
	@Override
	public ModelWrapperTaskActionTableService getWrapperService() {
		return (ModelWrapperTaskActionTableService) super.getWrapperService();
	}

	/**
	 * .
	 * 
	 * If the tests row doesn't exist, returns -1.
	 * 
	 * @param testsRowIndex
	 * @param taskActionService 
	 * @return
	 */
	public int getColumnValidTest(int testsRowIndex, ModelTaskActionService taskActionService) {
		
		// Read test by test until the value validates one of them
		int testsRowSize = getWrapperService().getRowLength(testsRowIndex);
		
		// The tests row is incorrect
		if(testsRowSize == -1) {
			return -1;
		}
		
		for(int i = 0; i < testsRowSize; i++) {
			Test currTest = getWrapperService().getCellFirstTest(testsRowIndex, i);

			// Current cell has no tests, next
			if(currTest == null) {
				continue;
			}
			
			boolean isValid = false;
			
			try {
				isValid = taskActionService.isValueValid(taskActionService.getValue(), new Test[] {currTest});
			} catch (Exception e) {
				logger.debug("Unable to validate value!");
			}
			
			if(isValid) {
				return i;
			}
		}
		
		// No tests or value validates nothing
		return -1;
	}

	/**
	 * Reads the taskActionTable cell at row and column coordinate and returns
	 * the <b>FIRST</b> taskAction inputValue.
	 * 
	 * @param row
	 *            the selected row
	 * @param col
	 *            the selected column
	 * @return the cell first taskAction inputValue
	 */
	public String getCellValue(int row, int col) {
		return getWrapperService().getCellFirstValue(row, col);
	}
}
