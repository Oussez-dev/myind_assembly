package turbomeca.gamme.assembly.client.model.edit.loader;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskBenchSettingService;
import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperTaskBenchSettingService;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.interfaces.IModelLoaderService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.model.provider.ModelXmlProvider;

public class ModelLoaderTaskBenchSettingService extends AModelAssemblyLoader implements IModelLoaderService {

	public ModelLoaderTaskBenchSettingService(IModelObjectService modelService) {
		super(modelService);
	}

	@Override
	public ModelWrapperTaskBenchSettingService getWrapperService() {
		return (ModelWrapperTaskBenchSettingService) super.getWrapperService();
	}
	
	@Override
	public ModelTaskBenchSettingService getModelService() {
		return (ModelTaskBenchSettingService) super.getModelService();
	}

	
	@Override
	public void load(ModelXmlProvider modelProvider) throws ClientException, ClientInterruption {
	    if (modelProvider != null && getModelService()!=null) {
			modelProvider.addModelService(getModelService().getIdentifier(), getModelService());
		}
	}
	
}
