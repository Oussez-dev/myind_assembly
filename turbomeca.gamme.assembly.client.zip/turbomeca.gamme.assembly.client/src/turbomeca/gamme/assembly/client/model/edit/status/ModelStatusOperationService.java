package turbomeca.gamme.assembly.client.model.edit.status;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelOperationService;
import turbomeca.gamme.assembly.client.model.edit.schedule.AAssemblyScheduleService;
import turbomeca.gamme.assembly.services.model.data.types.StatusType;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public class ModelStatusOperationService extends ModelStatusService {
	
	/** logger for current class */
	private static Logger logger = Logger
			.getLogger(ModelStatusOperationService.class);

	public ModelStatusOperationService(IModelObjectService modelService) {
		super(modelService);
	}

	@Override
	public boolean isAlterable() throws ClientException {
		return true;
	}
	
	@Override
	public void computeStatus(boolean recursively) throws ClientException, ClientInterruption {
		logger.debug("computeStatus  : " + getModelService());
		
		StatusType initStatus = getInitStatus();
		boolean operationDone = true;
		
		for (IModelObjectService childModelService : getModelService().getChildren()) {
			if(childModelService.getWrapperService().isArchived())
				continue;
			if (recursively) {
				childModelService.getStatusService().computeStatus(recursively);
			}
			String childStatus = childModelService.getStatusService().getStatus();
			if (operationDone && childStatus != null && childStatus != StatusType.NONE.value() && childStatus != StatusType.NOT_APPLICATED.value() 
					&& childStatus != StatusType.DONE.value() && childStatus != StatusType.NOT_TODO.value() && childStatus != StatusType.OK.value() 
					&& childModelService.getRunnableService().isRunnable()) {
						operationDone = false;
			}
		}
		
		if (getWrapperService().getState() != null) {
			if (operationDone) {
				updateState(StatusType.DONE.value(), true, null, null);
				if (initStatus != StatusType.DONE) {
					operationFinished((ModelOperationService) this.getModelService());
				}
			} else {
				updateState(StatusType.TODO.value(), true, null, null);
			}
		}
	}
	
	private void operationFinished(ModelOperationService currentOperationService) {
		AAssemblyScheduleService scheduleService = (AAssemblyScheduleService) currentOperationService.getAncestor(AAssemblyScheduleService.class);
		if (scheduleService != null) {
			ModelOperationService lastOperationService = scheduleService.getLastOperationClosed();
			if (lastOperationService != null) {
				lastOperationService.getWrapperService().setLastOperationClosed(false);
			}
			currentOperationService.getWrapperService().setLastOperationClosed(true);
		}
	}
	
}
