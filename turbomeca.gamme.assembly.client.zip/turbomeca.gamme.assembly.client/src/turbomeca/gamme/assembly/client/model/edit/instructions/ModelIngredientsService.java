package turbomeca.gamme.assembly.client.model.edit.instructions;

import turbomeca.gamme.assembly.client.model.edit.AModelAssemblyService;
import turbomeca.gamme.assembly.client.model.edit.hmi.updater.ModelHmiUpdaterService;
import turbomeca.gamme.assembly.client.model.edit.loader.ModelLoaderIngredientsService;
import turbomeca.gamme.assembly.client.model.edit.runnable.ModelRunnableStatusNoneService;
import turbomeca.gamme.assembly.client.model.edit.status.ModelStatusService;
import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperIngredientsService;
import turbomeca.gamme.assembly.services.model.data.Ingredients;

public class ModelIngredientsService extends AModelAssemblyService {

    private static final String INGREDIENTS_SUFFIX_ID = "_ingredients";
    
	/**
	 * Constructor for task object
	 * 
	 * @param marksService
	 *            parent service
	 * @param task
	 *            task object
	 */
	public ModelIngredientsService(ModelResourcesService resourcesService, Ingredients ingredients) {
		super(resourcesService.getDomain(), resourcesService.getIdentifier() + INGREDIENTS_SUFFIX_ID);
		setParent(resourcesService);
		
		setWrapperService(new ModelWrapperIngredientsService(ingredients));
		setLoaderService(new ModelLoaderIngredientsService(this));
		setHmiUpdaterService(new ModelHmiUpdaterService());
		setStatusService(new ModelStatusService(this));
		setRunnableService(new ModelRunnableStatusNoneService(this));
	}

}
