package turbomeca.gamme.assembly.client.model.edit.instructions;

import java.util.Enumeration;
import java.util.List;

import turbomeca.gamme.assembly.client.model.edit.AModelAssemblyService;
import turbomeca.gamme.assembly.client.model.edit.hmi.updater.ModelHmiUpdaterService;
import turbomeca.gamme.assembly.client.model.edit.loader.ModelLoaderTaskService;
import turbomeca.gamme.assembly.client.model.edit.runnable.ModelRunnableTaskService;
import turbomeca.gamme.assembly.client.model.edit.status.ModelStatusTaskService;
import turbomeca.gamme.assembly.client.model.edit.utils.ModelUtils;
import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperTaskService;
import turbomeca.gamme.assembly.services.model.data.ConditionInput;
import turbomeca.gamme.assembly.services.model.data.ConditionTask;
import turbomeca.gamme.assembly.services.model.data.Conditions;
import turbomeca.gamme.assembly.services.model.data.ConditionsItem;
import turbomeca.gamme.assembly.services.model.data.Task;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.model.edit.instructions.IModelTaskService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public class ModelTaskService extends AModelAssemblyService implements IModelTaskService {

	/**
	 * Constructor for task object
	 * @param subPhaseService parent service
	 * @param task task object
	 */
	public ModelTaskService(ModelSubPhaseService subPhaseService, Task task) {
		super(subPhaseService.getDomain(), task.getId());
		setParent(subPhaseService);
		
		setWrapperService(new ModelWrapperTaskService(task));
		setLoaderService(new ModelLoaderTaskService(this));
		setHmiUpdaterService(new ModelHmiUpdaterService());
		setStatusService(new ModelStatusTaskService(this));
		setRunnableService(new ModelRunnableTaskService(this));
	}
	
	public Task getTask() {
		return (Task)getWrapperService().getObject();
	}
	
	/* (non-Javadoc)
	 * @see turbomeca.gamme.assembly.client.model.edit.AModelAssemblyService#checkDeepReferences(java.util.List)
	 */
	public boolean checkReferencesByLevel(List<IModelObjectService> referencesList, String level) throws ClientException {
		
		Conditions conditions = getWrapperService().getConditions();
		if (conditions != null) {
			Enumeration<?> enumConditions = conditions.enumerateConditionsItem();
			while (enumConditions.hasMoreElements()) {
				ConditionsItem condition = (ConditionsItem) enumConditions.nextElement();
				ConditionInput conditionInput = condition.getConditionInput();
				if (conditionInput != null) {
					Object refId = conditionInput.getRefId();
					if (refId != null) {
						if (!ModelUtils.isReferenceApplicable(refId, level, referencesList)) {
							return false;
						}
					}
				}
				
				ConditionTask conditionTask = condition.getConditionTask();
				if (conditionTask != null) {
					Object refId = conditionTask.getRefId();
					if (refId != null) {
						if (!ModelUtils.isReferenceApplicable(refId, level, referencesList)) {
							return false;
						}
					}
				}
			}
		}

		return true;
	}

	@Override
	public ModelWrapperTaskService getWrapperService() {
	    return (ModelWrapperTaskService) super.getWrapperService();
	}

	@Override
	public String getValue() {
		// TODO Auto-generated method stub
		return null;
	}
}
