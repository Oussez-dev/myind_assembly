package turbomeca.gamme.assembly.client.model.edit.factory;

import turbomeca.gamme.assembly.client.model.edit.schedule.AAssemblyScheduleService;
import turbomeca.gamme.assembly.client.model.edit.schedule.AssemblyScheduleService;
import turbomeca.gamme.assembly.client.model.edit.schedule.DisassemblyScheduleService;
import turbomeca.gamme.assembly.services.constants.Constants;

public class ModelScheduleServiceFactory {

	public static AAssemblyScheduleService create(int rangeType) {
		AAssemblyScheduleService scheduleService = null;
		switch (rangeType) {
		case Constants.SCHEDULE_TYPE_ASSEMBLY:
            scheduleService = new AssemblyScheduleService();
            break;
		case Constants.SCHEDULE_TYPE_DISASSEMBLY:
			scheduleService = new DisassemblyScheduleService();
			break;
		}
		return scheduleService;
	}
}
