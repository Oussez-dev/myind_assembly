package turbomeca.gamme.assembly.client.model.edit.loader;

import turbomeca.gamme.assembly.client.model.edit.factory.ModelNotificationServiceFactory;
import turbomeca.gamme.assembly.client.model.edit.notifications.IModelNotificationService;
import turbomeca.gamme.assembly.client.model.edit.notifications.ModelNotificationsService;
import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperElectronicNotificationsService;
import turbomeca.gamme.assembly.services.model.data.ElectronicNotification;
import turbomeca.gamme.assembly.services.model.data.ElectronicNotifications;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.model.interfaces.IModelLoaderService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.model.provider.ModelXmlProvider;

public class ModelLoaderElectronicNotificationsService extends AModelAssemblyLoader implements
        IModelLoaderService {

    public ModelLoaderElectronicNotificationsService(IModelObjectService modelService) {
        super(modelService);
    }

    @Override
    public ModelWrapperElectronicNotificationsService getWrapperService() {
        return (ModelWrapperElectronicNotificationsService) super.getWrapperService();
    }

    @Override
    public ModelNotificationsService getModelService() {
        return (ModelNotificationsService) super.getModelService();
    }

    public void load(ModelXmlProvider modelProvider) throws ClientException {
        ElectronicNotifications notifications = getWrapperService().getElectronicNotifications();
        if (notifications != null) {
            for(ElectronicNotification notification : notifications.getElectronicNotification()) {
                IModelNotificationService notificationService = ModelNotificationServiceFactory.create(getModelService(), notification);
                if (modelProvider != null) {
                    modelProvider.addModelService(notificationService.getIdentifier(), notificationService);
                }
                getModelService().addChild(notificationService);
            }
        }
        if (modelProvider != null) {
            modelProvider.addModelService(getModelService().getIdentifier(), getModelService());
        }
    }

    @Override
    public void link() throws ClientException {
    }
}
