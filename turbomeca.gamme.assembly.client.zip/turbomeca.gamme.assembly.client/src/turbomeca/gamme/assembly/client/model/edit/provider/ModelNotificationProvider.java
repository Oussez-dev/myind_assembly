package turbomeca.gamme.assembly.client.model.edit.provider;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.model.edit.notifications.AModelNotificationService;

public class ModelNotificationProvider {

    /** logger for current class */
    private static Logger logger = Logger.getLogger(ModelNotificationProvider.class);
    
    /** */
    private static ModelNotificationProvider instance;
    
    /** */
    private HashMap<String, List<AModelNotificationService>> notifications;
    
    /** */
    private Set<String> notificationsIdToErase;
    
    /**
     * Singleton
     * @return the instance
     */
    public static ModelNotificationProvider getInstance() {
        if (instance == null) {
            instance = new ModelNotificationProvider();
        }
        return instance;
    }

    public void destroy() {
        instance = null;
        notifications = null;
        notificationsIdToErase = null;
    }
    
    private ModelNotificationProvider() {
        setNotifications(new HashMap<String, List<AModelNotificationService>>());
        setNotificationsToErase(new HashSet<String>());
    }
    
    /**
     * Add a notification 
     * @param notificationService the notification to add
     */
    public void addNotificationService(AModelNotificationService notificationService) {
        logger.debug("addNotificationService : " + notificationService);
        
        List<AModelNotificationService> notifications = getNotifications().get(notificationService.getIdentifier());
        if (notifications == null) {
            getNotifications().put(notificationService.getIdentifier(), new ArrayList<AModelNotificationService>());
        }
        getNotifications().get(notificationService.getIdentifier()).add(notificationService);
    }
    
    /**
     * Add a notification for erasing
     * @param notificationService the notification to add
     */
    public void addNotificationServiceToErase(AModelNotificationService notificationService) {
        logger.debug("addNotificationServiceToErase : " + notificationService);
        getNotificationsToErase().add(notificationService.getIdentifier());
    }
    
    /**
     * Get all notification instances for an identifier 
     * @param id the notification identifier
     * @return the notifications list with same identifier
     */
    public List<AModelNotificationService> getNotifications(String id) {
        return getNotifications().get(id);
    }
    
    /**
     * @return the notifications
     */
    public HashMap<String, List<AModelNotificationService>> getNotifications() {
        return notifications;
    }

    /**
     * @param notifications the notifications to set
     */
    public void setNotifications(HashMap<String, List<AModelNotificationService>> notifications) {
        this.notifications = notifications;
    }

    /**
     * @return the notificationsToErase
     */
    public Set<String> getNotificationsToErase() {
        return notificationsIdToErase;
    }

    /**
     * @param notificationsToErase the notificationsToErase to set
     */
    public void setNotificationsToErase(Set<String> notificationsIdToErase) {
        this.notificationsIdToErase = notificationsIdToErase;
    }
}
