package turbomeca.gamme.assembly.client.model.edit.status;

import java.util.List;

import org.apache.log4j.Logger;

import com.rits.cloning.Cloner;

import turbomeca.gamme.assembly.client.model.edit.ModelAssemblyServiceProvider;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.client.model.edit.utils.ModelConditionService;
import turbomeca.gamme.assembly.client.model.edit.utils.ModelUtils;
import turbomeca.gamme.assembly.services.model.data.State;
import turbomeca.gamme.assembly.services.model.data.SubPhase;
import turbomeca.gamme.assembly.services.model.data.types.StatusType;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.context.ContextRequest;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public class ModelStatusBuilderService extends ModelAssemblyServiceProvider implements
		IModelStatusBuilderService {

	/** logger for current class */
	private static Logger logger = Logger.getLogger(ModelStatusBuilderService.class);

	/** */
	private ModelConditionService conditionService;

	/**
	 * Constructor
	 * 
	 * @param identifier
	 *            the instruction identifier
	 */
	public ModelStatusBuilderService(IModelObjectService modelObjectService) {
		super(modelObjectService);
		setConditionService(new ModelConditionService());
	}

	/**
	 * @param conditionService
	 *            the conditionService to set
	 */
	public void setConditionService(ModelConditionService conditionService) {
		this.conditionService = conditionService;
	}

	/**
	 * @return the conditionService
	 */
	public ModelConditionService getConditionService() {
		return conditionService;
	}

	@Override
	public boolean setState(StatusType status, String comment, boolean force,
			List<String> instancesId) throws ClientException {
		
		boolean change = false;
		String state = getStatus(null);
		if (state != null) {
			change = !state.equals(status.value());
			if(change) {
				setState(status, comment);
			}
		}
		return change;
	}

	@Override
	public boolean resetState(boolean force, List<String> instancesId) throws ClientException {
		StatusType status = StatusType.NOT_TODO;
		if (getConditionService().isConditionsValid(getWrapperService().getConditions(), null)) {
			status = StatusType.TODO;
		}
		
		State state = getWrapperService().getState();
		if (state != null) {
			state.setComment(null);
		}
		
		return setState(status, null, false, null);
	}

	protected void setState(StatusType status, String comment) {
		State state = getWrapperService().getState();
		if (state != null) {
			state.setUserMark(ModelUtils.buildUserMark());
			state.setStatus(status);
			if (comment != null && !comment.isEmpty()) {
				setComment(state, comment);
			}
		}
	}

	@Override
	public StatusType checkStatusChange(StatusType currentStatus, StatusType newStatus) {
		switch (currentStatus) {
		case NONE:
			break;
		case TODO:
			switch (newStatus) {
			case OK:
			case KO:
			case TO_SIGN:
			case DONE:
				currentStatus = newStatus;
				break;
			default:
				break;
			}
			break;
		case OK:
			switch (newStatus) {
			case KO:
				currentStatus = newStatus;
				break;
			default:
				break;
			}
			break;
		case TO_SIGN:
			switch (newStatus) {
			case DONE:
				currentStatus = newStatus;
				break;
			default:
				break;
			}
			break;
		case DONE:
			switch (newStatus) {
			case TO_SIGN:
				currentStatus = newStatus;
				break;
			default:
				break;
			}
			break;
		default:
			switch (newStatus) {
			case TODO:
				currentStatus = newStatus;
				break;
			default:
				break;
			}
			break;
		}
		return currentStatus;
	}

	@Override
	public String getStatus(String instanceId) throws ClientException {
	    String status = null;
	    State state = getModelService().getWrapperService().getState();
	    if (state != null) {
	        status = state.getStatus().value();
	    }
		return status;
	}

	@Override
	public void setComment(String comment, List<String> instancesId) throws ClientException {
		if (comment != null && !comment.isEmpty()) {
			setComment(getWrapperService().getState(), comment);
		}
	}

	protected void setComment(State state, String comment) {
	    state.setComment(comment);
	}

	@Override
	public void setAlterable(IModelObjectService duplicableService, List<String> instancesId)
			throws ClientException, ClientInterruption {
		logger.debug("setAlterable : " + getModelService());
		if (!duplicableService.getStatusService().isAlterable()) {
		    getNotifications().setModelReload();
            getNotifications().setDisableDynamicNotifications(true);
            
			if (getRequestContext().getRequestType() == ContextRequest.NEW_PASSING) {
				duplicableService.getStatusService().archive((getRequestContext().getPassingId() - 1), 1, instancesId);
	            updatePassingId(duplicableService, getRequestContext().getPassingId());
	            duplicableService.getStatusService().updateActivity(false, false, instancesId);
	            duplicableService.getStatusService().clean(instancesId);
			} else {
			    //TODO check impact
			    duplicableService.getStatusService().resetState(false, true, instancesId);
			}
			
			// Set alterable of all followers
			ModelSubPhaseService subPhaseService = (ModelSubPhaseService) duplicableService;
			for(Object subPhaseObject : subPhaseService.getWrapperService().getSubPhase().getFollowers()) {
			    getModelProvider().getModelService(((SubPhase) subPhaseObject).getId()).getStatusService().setAlterable(instancesId);
			}
			
			resetParents(duplicableService, instancesId);
		} else if (getRequestContext().getRequestType() == ContextRequest.NEW_PASSING) {
		    duplicableService.getStatusService().clean(instancesId);
		}
	}

	private void updatePassingId(IModelObjectService modelService, int passingId) {
        modelService.getWrapperService().setPassingId(passingId);
        for(IModelObjectService child : modelService.getChildren()) {
            updatePassingId(child, passingId);
        }
    }
	
	protected void resetParents(IModelObjectService modelService, List<String> instancesId)
			throws ClientException, ClientInterruption {
		if (modelService != null) {
			IModelObjectService parent = modelService.getParent();
			if (parent != null) {
				parent.getStatusService().resetState(false, false, instancesId);
				resetParents(parent, instancesId);
			}
		}
	}

	@Override
	public void setActive(boolean active, boolean delete, List<String> instancesId)
			throws ClientException, ClientInterruption {
		if (active) {
			if (!getWrapperService().isActive()) {
				if (delete) {
					getModelService().getStatusService().clean(instancesId);
				}
				IModelObjectService duplicableService = getParentDuplicable();
				if (duplicableService != null) {
				    int passingId = duplicableService.getWrapperService().getPassingId();
					if (       getRequestContext().getRequestType() == ContextRequest.NEW_PASSING
							&& getWrapperService().getPassingId() == passingId) {
						duplicableService.getWrapperService().setPassingId(getRequestContext().getPassingId());
					}
					getWrapperService().setPassingId(passingId);
				}
			}
		}
		getWrapperService().setActive(active);
	}

	protected IModelObjectService getParentDuplicable() throws ClientException {
		IModelObjectService duplicableService = null;
		if (getModelService().getStatusService().isDuplicable()) {
			duplicableService = getModelService();
		} else {
			IModelObjectService parentService = getModelService().getParent();
			while (parentService != null) {
				if (parentService.getStatusService().isDuplicable()) {
					duplicableService = parentService;
					break;
				} else {
					parentService = parentService.getParent();
				}
			}
		}
		return duplicableService;
	}

	@Override
	public void cloneService(int passingId, int iterationId, List<String> instancesId) throws ClientException {
		IModelObjectService parentService = getModelService().getParent();
		if (parentService != null) {
			Cloner cloner = new Cloner();
			/**
			 * ModelService holds a reference to it's parent, so Deep clone also clone parent and associated objects...
			 * To avoid to clone useless objects stop the cloning process to the parentModelService 
			 */
			cloner.dontClone(getModelService().getParent().getClass());
			IModelObjectService subPhaseServiceCloned = cloner.deepClone(getModelService()); 
			subPhaseServiceCloned.getStatusService().updateDeepId(passingId, iterationId, instancesId);
			subPhaseServiceCloned.getWrapperService().setArchived(true);
			parentService.getWrapperService().addChild(getModelService(), subPhaseServiceCloned);
			getModelService().getParent().addChild(subPhaseServiceCloned);
		}
		
	}

	@Override
	public void updateId(int passingId, int iterationId, List<String> instancesId) {
		String currentId = getWrapperService().getId();
		if (currentId != null) {
			getWrapperService().setId(getWrapperService().getId() + "_" + passingId + "_" + iterationId);
			getModelService().setIdentifier(getWrapperService().getId());
		}
	}
}
