package turbomeca.gamme.assembly.client.model.edit.wrappers;

import turbomeca.gamme.assembly.services.model.data.TaskActionMeasure;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public class ModelWrapperTaskActionMeasureService extends AModelWrapperAssemblyService {

	/** */
	private TaskActionMeasure taskActionMeasure;

	/**
	 * Constructor for task object
	 * 
	 * @param subPhaseService
	 *            parent service
	 * @param task
	 *            task object
	 */
	public ModelWrapperTaskActionMeasureService(TaskActionMeasure taskActionMeasure) {
		setTaskActionMeasure(taskActionMeasure);
	}


	@Override
	public Object getObject() {
		return taskActionMeasure;
	}

	/**
	 * @return the tools
	 */
	public TaskActionMeasure getTaskActionMeasure() {
		return taskActionMeasure;
	}

	/**
	 * @param tools
	 *            the tools to set
	 */
	public void setTaskActionMeasure(TaskActionMeasure taskActionMeasure) {
		this.taskActionMeasure = taskActionMeasure;
	}


	@Override
	public String getId() {
		return getTaskActionMeasure().getId();
	}


	@Override
	public void setId(String id) {
	    getTaskActionMeasure().setId(id);
	}


	@Override
	public void addChild(IModelObjectService nextChild, IModelObjectService newChild)
			throws ClientException {
	}
}
