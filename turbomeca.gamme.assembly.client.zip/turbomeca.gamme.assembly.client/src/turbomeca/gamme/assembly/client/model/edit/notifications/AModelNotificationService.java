package turbomeca.gamme.assembly.client.model.edit.notifications;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.model.edit.AModelAssemblyService;
import turbomeca.gamme.assembly.client.model.edit.IModelAssemblyWrapperScheduleService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.client.model.edit.provider.ModelNotificationProvider;
import turbomeca.gamme.assembly.client.model.edit.runnable.ModelRunnableNoneService;
import turbomeca.gamme.assembly.client.model.edit.status.ModelStatusNoneService;
import turbomeca.gamme.assembly.client.model.edit.utils.ModelUtils;
import turbomeca.gamme.assembly.client.model.edit.wrappers.IModelNotificationRefWrapper;
import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperElectronicNotificationService;
import turbomeca.gamme.assembly.services.model.data.ElectronicNotification;
import turbomeca.gamme.assembly.services.model.data.ElectronicNotificationRef;
import turbomeca.gamme.assembly.services.model.data.Mark;
import turbomeca.gamme.assembly.services.model.data.Request;
import turbomeca.gamme.assembly.services.model.data.Response;
import turbomeca.gamme.assembly.services.model.data.TaskAction;
import turbomeca.gamme.assembly.services.model.data.types.NotificationOriginType;
import turbomeca.gamme.assembly.services.model.data.types.NotificationType;
import turbomeca.gamme.assembly.services.model.data.types.StatusNotificationType;
import turbomeca.gamme.assembly.services.model.data.types.StatusType;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.model.provider.ModelXmlProvider;
import turbomeca.gamme.ecran.services.common.constants.GlobalConstants;

public abstract class AModelNotificationService extends AModelAssemblyService implements IModelNotificationService {

    /** logger for current class */
    private static Logger logger = Logger.getLogger(AModelNotificationService.class);

    public AModelNotificationService(String domain, String identifier) {
        super(domain, identifier);
    }

    /**
     * 
     * @param electronicNotification
     */
    public AModelNotificationService(ModelNotificationsService modelNotificationService, ElectronicNotification electronicNotification) {
        super(modelNotificationService.getDomain(), electronicNotification.getId());
        setParent(modelNotificationService);

        setRunnableService(new ModelRunnableNoneService());
        setWrapperService(new ModelWrapperElectronicNotificationService(electronicNotification));

        getModelNotificationProvider().addNotificationService(this);
        if (!getElectronicNotification().isActive()) {
            getModelNotificationProvider().addNotificationServiceToErase(this);
        }
    }

    /**
     * 
     * @param modelService
     */
    protected void initService() {
        setRunnableService(new ModelRunnableNoneService());
        setStatusService(new ModelStatusNoneService(this));
        setWrapperService(new ModelWrapperElectronicNotificationService(new ElectronicNotification()));
    }

    /**
     * 
     * @param request
     * @param type
     * @param origin
     */
    protected void createElectronicNotification(NotificationType type, NotificationOriginType origin, String description) {
        Request request = new Request();
        request.setUserMark(ModelUtils.buildUserMark());
        request.setComment(description);
        
        getElectronicNotification().setActive(true);
        getElectronicNotification().setStatusNotification(StatusNotificationType.CREATED);
        getElectronicNotification().setId(getIdentifier());
        getElectronicNotification().setRequest(request);
        getElectronicNotification().setType(type);
        getElectronicNotification().setOrigin(origin);
        getElectronicNotification().setUpdated(false);
    }

    /**
     * 
     * @param modelService
     * @param createOnServer 
     * @throws ClientException
     */
    public void bindService(AModelAssemblyService modelService, String mustSynchronize) throws ClientException {
        ModelSubPhaseService subPhaseService = modelService.getSubPhase();
        
        boolean isValidable = subPhaseService.getWrapperService().getSubPhase().isValidable();
        if (isBlockingSign()) {
            subPhaseService.getWrapperService().getSubPhase().setValidable(false);
        }
        boolean refreshService = subPhaseService.getStatusService().getStatus().equals(StatusType.TO_SIGN.value()) && isValidable;
        if (!(modelService instanceof ModelSubPhaseService)) {
            getElectronicNotification().setRefId(modelService.getWrapperService().getObject());
            if (!refreshService) {
                getNotifications().notifyElectronicNotificationChanged(modelService);
            }
        }

        if(mustSynchronize != null){
        	IModelAssemblyWrapperScheduleService wrapper = (IModelAssemblyWrapperScheduleService) getModelProvider().getModelScheduleService().getWrapperService();
			wrapper.updateObjectsToSynchronize(getElectronicNotification().getId(), mustSynchronize, GlobalConstants.ELECTRONIC_NOTIFICATION);
        }
        ModelNotificationsService notificationsService = (ModelNotificationsService) subPhaseService.getFirstChild(ModelNotificationsService.class);
        getModelProvider().addModelService(this.getIdentifier(), this);
        notificationsService.addNotificationChild(this);
        setParent(notificationsService);

        //As the notification is bind to the subphase, notify that this subphase has changed
        getNotifications().notifyServiceChanged(subPhaseService);

    }
    
    /**
     * 
     * @param modelService
     * @param createOnServer 
     * @throws ClientException
     */
    @Override
	public void bindService(AModelAssemblyService modelService) throws ClientException {
    	bindService(modelService, null);
    }


    public abstract boolean isBlockingSign();

    /**
     * 
     * @return
     */
    protected ElectronicNotificationRef createNotificationReference() {
        ElectronicNotificationRef electNotifRef = new ElectronicNotificationRef();
        electNotifRef.setRefId(getElectronicNotification().getId());
        electNotifRef.setInstance(getElectronicNotification().getInstance());
        electNotifRef.setAlternative(getElectronicNotification().getAlternative());
        electNotifRef.setStatusNotification(getElectronicNotification().getStatusNotification());
        return electNotifRef;
    }

    /**
     * 
     * @param status
     * @throws ClientException
     * @throws ClientInterruption
     */
    @Override
	public void update(StatusNotificationType status, Response response)
            throws ClientException, ClientInterruption {
        logger.debug("updateNotification " + getIdentifier() + " : status=" + status);
        // FIXME : almost same code as DUF --> Need to be moved in Ecran
		
        IModelObjectService referenceService = null;
        getElectronicNotification().setStatusNotification(status);
        if (getElectronicNotification().getRefId() != null) {
            referenceService = ModelUtils.getModelServiceReferenced(getModelProvider(),
                    getElectronicNotification().getRefId());
        }

        if (status == StatusNotificationType.CANCELED) {
            getElectronicNotification().setActive(false);
            getModelNotificationProvider().addNotificationServiceToErase(this);
            if (referenceService != null) {
                referenceService.getStatusService().clean(null);
                notifyCancelElectronicNotification(referenceService);
            }
        } else {
            getElectronicNotification().setStatusNotification(status);
            if (response != null && status != StatusNotificationType.CREATED) {
                getElectronicNotification().setResponse(response);
            }

            if (referenceService != null) {
                IModelNotificationRefWrapper wrapper = (IModelNotificationRefWrapper) referenceService.getWrapperService();
                for (ElectronicNotificationRef electronicNotificationRef : wrapper.getElectronicNotificationRef()) {
                    if (getIdentifier().equals(electronicNotificationRef.getRefId())) {
                        electronicNotificationRef.setStatusNotification(status);
                    }
                }
                getNotifications().notifyElectronicNotificationChanged(referenceService);
            }
        }

        // Update notifications service
        setModified();
        ModelSubPhaseService subPhaseService = (ModelSubPhaseService) getAncestor(ModelSubPhaseService.class);
        getNotifications().notifyServiceChanged(subPhaseService);
        //Set model status modified in case update has been called on init of controller 
		getModelProvider().setModelStatus(ModelXmlProvider.MODEL_STATUS_MODIFIED);

        // Check if status allow subPhase sign
        if (status != StatusNotificationType.CREATED && status != StatusNotificationType.REFUSED) {
            subPhaseService.getStatusService().computeStatus(true);
            // Update status if subPhase is waiting notification update
            if (subPhaseService.getStatusService().getStatus().equals(StatusType.TO_SIGN.value())) {
            	if (subPhaseService.getRunnableService().canValidate()) {
            		getNotifications().notifyStatusChanged(subPhaseService);
            	}
            }
        }
    }

    protected void notifyCancelElectronicNotification(IModelObjectService referenceService) throws ClientException {
    }

    public abstract boolean isCleanable();
    
    public boolean isSubPhaseCleanable() {
    	switch (getElectronicNotification().getStatusNotification()) {
		case CANCELED:
			return true;
		default:
			return !getElectronicNotification().getRequest().getUserMark().getUser().getLogin()
                .equals(getConfiguration().getConfigUser().getUserLogin());
    	}
    }
    
    /**
     * @return the electronicNotification
     */
    public ElectronicNotification getElectronicNotification() {
        return (ElectronicNotification) getWrapperService().getObject();
    }
    
    /**
     * Get the identifier of reference object
     * 
     * @return
     */
    public String getIdentifierReferenced() {
        String id = null;
        Object object = getElectronicNotification().getRefId();
        if (object != null) {
            if (object instanceof Mark) {
                id = ((Mark) object).getId();
            } else if (object instanceof TaskAction) {
                id = ((TaskAction) object).getId();
            }
        }
        return id;
    }

    public boolean isNotificationReference(ElectronicNotificationRef electronicNotifRef) {
        boolean isNotifReference = false;
        ElectronicNotification electronicNotif = getElectronicNotification();
        if (electronicNotif != null) {
            isNotifReference = electronicNotifRef.getRefId().equals(electronicNotif.getId());
            if (electronicNotif.getInstance() != null) {
                isNotifReference &= electronicNotif.getInstance().equals(electronicNotifRef.getInstance());
            }
            if (electronicNotif.getAlternative() != null) {
                isNotifReference &= electronicNotif.getAlternative().equals(
                        electronicNotifRef.getAlternative());
            }
        }
        return isNotifReference;
    }
    

    public boolean equals(AModelNotificationService notificationService) {
        boolean isEqual = false;
        ElectronicNotification notif = notificationService.getElectronicNotification();
        if (notif != null) {
            isEqual = getIdentifierReferenced().equals(notificationService.getIdentifierReferenced());
            if (getElectronicNotification().getInstance() != null) {
                isEqual &= getElectronicNotification().getInstance().equals(notif.getInstance());
            }
            if (getElectronicNotification().getAlternative() != null) {
                isEqual &= getElectronicNotification().getAlternative().equals(notif.getAlternative());
            }
        }
        return isEqual;
    }
    
    /**
     * 
     * @return
     */
    protected ModelNotificationProvider getModelNotificationProvider() {
        return ModelNotificationProvider.getInstance();
    }

    /**
     * 
     * @return
     */
    protected ModelXmlProvider getModelProvider() {
        return ModelXmlProvider.getInstance();
    }
}
