package turbomeca.gamme.assembly.client.model.edit.wrappers;

import turbomeca.gamme.assembly.services.model.data.ElectronicNotification;

public class ModelWrapperElectronicNotificationService extends AModelWrapperAssemblyService {

	/** */
	private ElectronicNotification electronicNotification;

	/**
	 * Constructor for task object
	 * 
	 * @param subPhaseService
	 *            parent service
	 * @param task
	 *            task object
	 */
	public ModelWrapperElectronicNotificationService(ElectronicNotification electronicNotification) {
	    setElectronicNotification(electronicNotification);
	}


	@Override
	public Object getObject() {
		return electronicNotification;
	}

	/**
	 * @return the tools
	 */
	public ElectronicNotification getElectronicNotification() {
		return electronicNotification;
	}

	public void setElectronicNotification(ElectronicNotification electronicNotification) {
	    this.electronicNotification = electronicNotification;
	}
	@Override
	public String getId() {
		return getElectronicNotification().getId();
	}


	@Override
	public void setId(String id) {
	    getElectronicNotification().setId(id);
	}
}
