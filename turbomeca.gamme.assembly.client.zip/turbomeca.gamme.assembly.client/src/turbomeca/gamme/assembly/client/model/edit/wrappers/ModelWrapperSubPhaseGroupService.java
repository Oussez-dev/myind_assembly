package turbomeca.gamme.assembly.client.model.edit.wrappers;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import turbomeca.gamme.assembly.client.ClientAssemblyException;
import turbomeca.gamme.assembly.services.model.data.Qualifications;
import turbomeca.gamme.assembly.services.model.data.State;
import turbomeca.gamme.assembly.services.model.data.SubPhase;
import turbomeca.gamme.assembly.services.model.data.SubPhaseGroup;
import turbomeca.gamme.ecran.client.model.edit.wrappers.IModelWrapperSubPhaseGroupService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public class ModelWrapperSubPhaseGroupService extends AModelWrapperAssemblyService implements IModelWrapperSubPhaseGroupService {

	/** CASTOR operation object */
	private SubPhaseGroup subPhaseGroup;

	/**
	 * Constructor
	 * 
	 * @param scheduleService
	 * @param operation
	 */
	public ModelWrapperSubPhaseGroupService(SubPhaseGroup subPhaseGroup) {
	    setSubPhaseGroup(subPhaseGroup);
	}

	@Override
	public Object getObject() {
		return subPhaseGroup;
	}

	/**
	 * @param operation
	 *            the operation to set
	 */
	public void setSubPhaseGroup(SubPhaseGroup subPhaseGroup) {
		this.subPhaseGroup = subPhaseGroup;
	}

	/**
	 * @return the operation
	 */
	public SubPhaseGroup getSubPhaseGroup() {
		return subPhaseGroup;
	}

	@Override
	public Qualifications getExecutionQualifications() {
		return null;
	}

	@Override
	public Qualifications getValidationQualifications() {
	    return null;
	}

	@Override
	public State getState() {
		return getSubPhaseGroup().getState();
	}
	
	@Override
	public Integer getPassingId() {
		return 1;
	}

	@Override
	public String getId() {
		return getSubPhaseGroup().getId();
	}

	@Override
	public void setId(String id) {
	    getSubPhaseGroup().setId(id);
	}
	
	public void setDisplayId(int position) {
		getSubPhaseGroup().setDisplayId(String.valueOf(position));
	}
	
	@Override
	public List<String> getPredecessors() {
	    return new ArrayList<String>();
	}
	
	@Override
	public void addChild(IModelObjectService nextChild, IModelObjectService newChild) throws ClientAssemblyException {
	    SubPhaseGroup subPhaseGroup = getSubPhaseGroup();
        Vector<SubPhase> subPhases = new Vector<SubPhase>();
        for(SubPhase subPhase : subPhaseGroup.getSubPhase()) {
            if (subPhase.getId().equals(nextChild.getWrapperService().getId())) {
                subPhases.add((SubPhase) newChild.getWrapperService().getObject());
            }
            subPhases.add(subPhase);
        }
        subPhaseGroup.setSubPhase(subPhases);
	}
}
