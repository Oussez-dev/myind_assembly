package turbomeca.gamme.assembly.client.model.edit.notifications;

import java.util.UUID;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.services.model.data.ElectronicNotification;
import turbomeca.gamme.assembly.services.model.data.types.NotificationOriginType;
import turbomeca.gamme.assembly.services.model.data.types.NotificationType;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.constants.PropertyConstants;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public class ModelNotificationTaskBenchService extends AModelNotificationService {

    /**
     * 
     * @param electronicNotification
     */
    public ModelNotificationTaskBenchService(ModelNotificationsService modelNotificationService,
            ElectronicNotification electronicNotification) {
        super(modelNotificationService, electronicNotification);
    }
    
    /**
     * 
     * @param comment
     */
    public ModelNotificationTaskBenchService(ModelSubPhaseService subPhaseService) {
        super(subPhaseService.getDomain(), UUID.randomUUID().toString());
        initService();
        
        String message = String.format(
                getConfiguration().getProperty(
                		PropertyConstants.PROPERTY_MESSAGE_NOTIFICATION_TASK_BENCH));
        
        createElectronicNotification(NotificationType.METHOD, NotificationOriginType.TASK_BENCH, message);
    }
    
    @Override
    protected void notifyCancelElectronicNotification(IModelObjectService referenceService)
            throws ClientException {
        getNotifications().notifyElectronicNotificationChanged(referenceService);
    }

    @Override
    public boolean isCleanable() {
    	switch (getElectronicNotification().getStatusNotification()) {
		case CANCELED:
			return true;
		default:
			return false;
		}
    }
    
    @Override
    public boolean isBlockingSign() {
    	switch (getElectronicNotification().getStatusNotification()) {
		case CREATED:
			return true;
		case CANCELED:
			return false;
		case ACCEPTED:
		case ACCEPTED_NCR:
			return true;
		case REFUSED:
			return true;
		case REFUSED_ACCEPTED:
		case ACCEPTED_ACCEPTED:
			return false;
		default:
			return false;
		}
    }
}
