package turbomeca.gamme.assembly.client.model.edit.instructions;

import turbomeca.gamme.assembly.client.model.edit.AModelAssemblyService;
import turbomeca.gamme.assembly.client.model.edit.hmi.updater.ModelHmiUpdaterService;
import turbomeca.gamme.assembly.client.model.edit.loader.ModelLoaderToolService;
import turbomeca.gamme.assembly.client.model.edit.runnable.ModelRunnableStatusNoneService;
import turbomeca.gamme.assembly.client.model.edit.status.ModelStatusService;
import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperToolService;
import turbomeca.gamme.assembly.services.model.data.Tool;

public class ModelToolService extends AModelAssemblyService {
	/**
	 * Constructor for task object
	 * 
	 * @param subPhaseService
	 *            parent service
	 * @param task
	 *            task object
	 */
	public ModelToolService(ModelToolsService toolsService, Tool tool) {
		super(toolsService.getDomain(), tool.getUniqueId());
		setParent(toolsService);
		setWrapperService(new ModelWrapperToolService(tool));
		setLoaderService(new ModelLoaderToolService(this));
		setHmiUpdaterService(new ModelHmiUpdaterService());
		setStatusService(new ModelStatusService(this));
		setRunnableService(new ModelRunnableStatusNoneService(this));
	}
	
	
	@Override
	public ModelWrapperToolService getWrapperService() {
		return (ModelWrapperToolService) super.getWrapperService();
	}
}
