package turbomeca.gamme.assembly.client.model.edit.wrappers;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelMarkService;
import turbomeca.gamme.assembly.services.model.data.AdditionalRecord;
import turbomeca.gamme.assembly.services.model.data.Derogation;
import turbomeca.gamme.assembly.services.model.data.ElectronicNotificationRef;
import turbomeca.gamme.assembly.services.model.data.Mark;
import turbomeca.gamme.assembly.services.model.data.TaskAction;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public class ModelWrapperMarkService extends AModelWrapperAssemblyService implements IModelNotificationRefWrapper {

	/** */
	private Mark mark;

	/**
	 * Constructor for task object
	 * 
	 * @param subPhaseService
	 *            parent service
	 * @param task
	 *            task object
	 */
	public ModelWrapperMarkService(Mark mark) {
		setMark(mark);
	}


	@Override
	public Object getObject() {
		return mark;
	}

	/**
	 * @return the tools
	 */
	public Mark getMark() {
		return mark;
	}

	/**
	 * @param tools
	 *            the tools to set
	 */
	public void setMark(Mark mark) {
		this.mark = mark;
	}


	@Override
	public String getId() {
		return getMark().getId();
	}


	@Override
	public void setId(String id) {
	    getMark().setId(id);
	}

	@Override
    public ElectronicNotificationRef[] getElectronicNotificationRef() {
		return getMark().getElectronicNotificationRef();
    }
	
	@Override
    public void removeElectronicNotificationRef() {
        getMark().removeAllElectronicNotificationRef();
    }
	
	@Override
	public void addChild(IModelObjectService nextChild, IModelObjectService newChild)
			throws ClientException {
	}
	
	public Integer getIndex(String type, String taskActionId) {
		Integer index = -1;
		int count = 0;
		if(type.equals(ModelMarkService.TASK_ACTION_DEROG_TYPE)){
			for (Derogation derogation : getMark().getDerogation()) {
				if (derogation.getTaskAction() != null && taskActionId.equals(derogation.getTaskAction().getId())) {
					index = count;
					break;
				}
				count++;
			}
		} else if (type.startsWith(ModelMarkService.TASK_ACTION_ADDITIONAL_RECORD_TYPE)){
			for (AdditionalRecord additionalRecord : getMark().getAdditionalRecord()) {
				if (additionalRecord.getTaskAction() != null && taskActionId.equals(additionalRecord.getTaskAction().getId())) {
					index = count;
					break;
				}
				count++;
			}
		} else {
			//TODO ??
		}

		return index;
	}
	
	public void addElement(String type, TaskAction taskAction, int index) {
		Integer next = 0;
		
		if(type.equals(ModelMarkService.TASK_ACTION_DEROG_TYPE)){
			for (Derogation derogation : getMark().getDerogation()) {
				if (derogation.getTaskAction().getDuplicationIndex() > next) {
					next = derogation.getTaskAction().getDuplicationIndex();
				}
			}
			next = next + 1;
			Derogation derogation = new Derogation();
			taskAction.setDuplicationIndex(next);
			derogation.setTaskAction(taskAction);
			if (index < getMark().getDerogationCount()) {
				getMark().addDerogation(index, derogation);
			} else {
				getMark().addDerogation(derogation);
			}
		} else if (type.startsWith(ModelMarkService.TASK_ACTION_ADDITIONAL_RECORD_TYPE)){
			for (AdditionalRecord additionalRecord : getMark().getAdditionalRecord()) {
				if (additionalRecord.getTaskAction().getDuplicationIndex() > next) {
					next = additionalRecord.getTaskAction().getDuplicationIndex();
				}
			}
			next = next + 1;
			AdditionalRecord additionalRecord = new AdditionalRecord();
			taskAction.setDuplicationIndex(next);
			additionalRecord.setTaskAction(taskAction);
			additionalRecord.setType(type.replaceFirst(ModelMarkService.TASK_ACTION_ADDITIONAL_RECORD_TYPE + "_", ""));
			if (index < getMark().getAdditionalRecordCount()) {
				getMark().addAdditionalRecord(index, additionalRecord);
			} else {
				getMark().addAdditionalRecord(additionalRecord);
			}
		} else {
			//TODO ??
		}
		

	}
	
	@Override
	public boolean isApplicable() {
		return !getMark().hasApplicable() || getMark().isApplicable();
	}

	@Override
	public void setApplicable(boolean applicable) {
		getMark().setApplicable(applicable);
	}
}
