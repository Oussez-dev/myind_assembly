package turbomeca.gamme.assembly.client.model.edit.loader;

import java.util.Enumeration;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelToolService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelToolsService;
import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperToolsService;
import turbomeca.gamme.assembly.services.model.data.Tool;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.interfaces.IModelLoaderService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.model.provider.ModelXmlProvider;

public class ModelLoaderToolsService extends AModelAssemblyLoader implements
		IModelLoaderService {

	public ModelLoaderToolsService(IModelObjectService modelService) {
		super(modelService);
	}

	@Override
	public ModelWrapperToolsService getWrapperService() {
		return (ModelWrapperToolsService) super.getWrapperService();
	}

	@Override
	public ModelToolsService getModelService() {
		return (ModelToolsService) super.getModelService();
	}
	
	@SuppressWarnings("unchecked")
	public void load(ModelXmlProvider modelProvider) throws ClientException, ClientInterruption {
		Enumeration<Tool> enumTool = (Enumeration<Tool>) getWrapperService().getTools().enumerateTool();
	        while (enumTool.hasMoreElements()) {
	            ModelToolService toolService = new ModelToolService(getModelService(), enumTool.nextElement());
	            toolService.getLoaderService().load(modelProvider);
	            getModelService().addChild(toolService);
	        }
	        if (modelProvider != null) {
	            modelProvider.addModelService(getModelService().getIdentifier(), getModelService());
	        }
    }
}
