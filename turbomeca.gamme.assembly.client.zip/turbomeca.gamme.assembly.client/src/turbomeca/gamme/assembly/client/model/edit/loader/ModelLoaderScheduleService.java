package turbomeca.gamme.assembly.client.model.edit.loader;

import java.util.Enumeration;

import turbomeca.gamme.assembly.client.model.edit.IModelAssemblyWrapperScheduleService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelDerogationMarksService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelOperationService;
import turbomeca.gamme.assembly.client.model.edit.provider.ModelMarkProvider;
import turbomeca.gamme.assembly.client.model.edit.schedule.AAssemblyScheduleService;
import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperDerogationMarksService;
import turbomeca.gamme.assembly.services.model.data.DerogationMarks;
import turbomeca.gamme.assembly.services.model.data.Instanciation;
import turbomeca.gamme.assembly.services.model.data.Operation;
import turbomeca.gamme.assembly.services.model.data.SN;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.interfaces.IModelLoaderService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.model.provider.ModelXmlProvider;

public class ModelLoaderScheduleService extends AModelAssemblyLoader implements IModelLoaderService {

	/**
	 * 
	 * @param modelService
	 */
	public ModelLoaderScheduleService(IModelObjectService modelService) {
		super(modelService);
	}
	
	@Override
	public IModelAssemblyWrapperScheduleService getWrapperService() {
		return (IModelAssemblyWrapperScheduleService) getModelService().getWrapperService();
	}
	
	@Override
	public AAssemblyScheduleService getModelService() {
		return (AAssemblyScheduleService) super.getModelService();
	}

	@Override
	public void load(ModelXmlProvider modelXmlProvider) throws ClientException, ClientInterruption {
		DerogationMarks derogationMarks = getWrapperService().getDerogationMarks();
		
		//Initialize an empty derogationMarks if null, to help binding between xml and html (FE89 - "refresh rework")
		if(derogationMarks == null) {
			derogationMarks = new DerogationMarks();
			getWrapperService().setDerogationMarks(derogationMarks);
		}
		derogationMarks.setId(ModelWrapperDerogationMarksService.DEROGATION_ID);
		
		Enumeration<? extends Operation> enumOp = getWrapperService().getOperations().enumerateOperation();
		int opDisplayId = 1 ;
		getModelService().removeAllChildren();
		
		if(getWrapperService().loadHistoricalPassing()) {
			getModelProvider().setModelStatus(ModelXmlProvider.MODEL_STATUS_MODIFIED);
		}

		
		// Clear mark references to reload them 
		ModelMarkProvider.getInstance().getMarks().clear();
		
		while (enumOp.hasMoreElements()) {
			ModelOperationService operationService = new ModelOperationService(getModelService(), enumOp.nextElement());
			operationService.getLoaderService().load(modelXmlProvider);
			operationService.getWrapperService().setDisplayId(opDisplayId*10);
			getModelService().addChild(operationService);
			
			Instanciation instanciation = getModelService().getWrapperService().getInstantiation();
			Enumeration<? extends SN> enumSn = instanciation.enumerateSN();
			while (enumSn.hasMoreElements()) {
			    SN sn = enumSn.nextElement();
			    if (sn.getTaskAction() != null) {
			    	loadTaskAction(modelXmlProvider, "", sn.getTaskAction());
			    }
			}
			opDisplayId++;
		}

		ModelDerogationMarksService derogationMarksService = new ModelDerogationMarksService(getModelService(), derogationMarks);
		derogationMarksService.getLoaderService().load(modelXmlProvider);
	}
}
