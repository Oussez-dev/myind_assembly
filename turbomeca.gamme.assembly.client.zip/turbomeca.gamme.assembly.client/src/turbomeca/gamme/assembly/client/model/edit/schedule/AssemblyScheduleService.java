package turbomeca.gamme.assembly.client.model.edit.schedule;

import turbomeca.gamme.assembly.client.model.edit.hmi.updater.ModelHmiUpdaterScheduleService;
import turbomeca.gamme.assembly.client.model.edit.loader.ModelLoaderScheduleService;
import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperAssemblyService;
import turbomeca.gamme.assembly.services.model.data.Assembly;
import turbomeca.gamme.assembly.services.model.data.DerogationMarks;
import turbomeca.gamme.assembly.services.model.data.types.ContextType;

public class AssemblyScheduleService extends AAssemblyScheduleService {

	/** */
	protected static final String ASSEMBLY_NAME = "assembly";
	protected static final String ASSEMBLY_REPAIRED_NAME = "assembly_repaired";
	protected static final String ASSEMBLY_NEW_NAME = "assembly_new";

	public AssemblyScheduleService() {
		super("");
		setWrapperService(new ModelWrapperAssemblyService());
		setLoaderService(new ModelLoaderScheduleService(this));
		setHmiUpdaterService(new ModelHmiUpdaterScheduleService());
	}
	
	@Override
	public Class<?> getClassModel() {
		return Assembly.class;
	}
	
	@Override
	public String getName() {
		return ASSEMBLY_NAME;
	}
	
	@Override
	public String getOfficialRangeName() {
		return getName();
	}

	@Override
    public String getReverseOfficialRangeName() {
        return DisassemblyScheduleService.DISASSEMBLY_NAME;
    }

    @Override
    public String getSubOfficialRangeName() {
        Assembly assembly = (Assembly) getWrapperService().getObject();
        String subOfficialName = "";
        if (assembly.getType() == ContextType.NEW) {
            subOfficialName = ASSEMBLY_NEW_NAME;
        }
        else {
            subOfficialName = ASSEMBLY_REPAIRED_NAME; 
        }
        return subOfficialName;
    }
    
    @Override
    public String getReverseSubOfficialRangeName() {
        return DisassemblyScheduleService.DISASSEMBLY_NAME;
    }

	@Override
	public void setDerogationsMarks(DerogationMarks derogationMarks) {
		getWrapperService().setDerogationMarks(derogationMarks);
		
	}
}
