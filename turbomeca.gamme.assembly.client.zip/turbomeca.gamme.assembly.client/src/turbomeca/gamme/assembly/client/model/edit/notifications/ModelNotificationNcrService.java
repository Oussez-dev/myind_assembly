package turbomeca.gamme.assembly.client.model.edit.notifications;

import java.util.UUID;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.model.edit.AModelAssemblyService;
import turbomeca.gamme.assembly.client.model.edit.instructions.AModelTaskActionService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperTaskActionService;
import turbomeca.gamme.assembly.services.model.data.ElectronicNotification;
import turbomeca.gamme.assembly.services.model.data.Response;
import turbomeca.gamme.assembly.services.model.data.TaskAction;
import turbomeca.gamme.assembly.services.model.data.types.NotificationOriginType;
import turbomeca.gamme.assembly.services.model.data.types.NotificationType;
import turbomeca.gamme.assembly.services.model.data.types.StatusNotificationType;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.constants.PropertyConstants;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public class ModelNotificationNcrService extends AModelNotificationService {

    /** logger for current class */
    private static Logger logger = Logger.getLogger(ModelNotificationNcrService.class);

    /**
     * 
     * @param electronicNotification
     */
    public ModelNotificationNcrService(ModelNotificationsService modelNotificationService,
            ElectronicNotification electronicNotification) {
        super(modelNotificationService, electronicNotification);
    }

    /**
     * 
     * @param taskActionService
     */
    public ModelNotificationNcrService(AModelTaskActionService taskActionService) {
        super(taskActionService.getDomain(), UUID.randomUUID().toString());
        initService();

        ModelSubPhaseService subPhaseService = taskActionService.getSubPhase();
        ModelWrapperTaskActionService wrapperTaskActionService = taskActionService.getWrapperService();
        TaskAction taskAction = (TaskAction) wrapperTaskActionService.getObject();
        String name = "";
        if (taskAction.getValue() != null) {
            name = taskAction.getValue().getName();
        }
        String message = String.format(
                getConfiguration().getProperty(
                		PropertyConstants.PROPERTY_MESSAGE_NOTIFICATION_NCR), name,
                subPhaseService.getWrapperService().getSubPhase().getDisplayId(), wrapperTaskActionService.getValue());

        createElectronicNotification(NotificationType.METHOD, NotificationOriginType.NCR, message);
    }

    @Override
    public void bindService(AModelAssemblyService modelService, String mustSynchronize) throws ClientException {
        super.bindService(modelService, mustSynchronize);
        AModelTaskActionService taskActionService = (AModelTaskActionService) modelService;
        getSubPhase().getWrapperService().getSubPhase().setValidable(false);
        taskActionService.getWrapperService().getTaskAction().removeAllElectronicNotificationRef();
        taskActionService.getWrapperService().getTaskAction()
                .addElectronicNotificationRef(createNotificationReference());
    }

    @Override
    public void update(StatusNotificationType status, Response response) throws ClientException,
            ClientInterruption {
        logger.debug("updateNotification " + getIdentifier() + " : status=" + status);

        switch (status) {
        case REFUSED_ACCEPTED: {
            ModelSubPhaseService subPhaseService = getSubPhase();
            subPhaseService.getStatusService().setAlterable(null);
            subPhaseService.getStatusService().clean(null);
            getNotifications().notifyServiceChanged(subPhaseService);
        }; break;
        case REFUSED: {
            ModelSubPhaseService subPhaseService = getSubPhase();
            subPhaseService.getStatusService().setAlterable(null);
            getNotifications().notifyServiceChanged(subPhaseService);
            super.update(status, response);
        }; break;
        default:
            super.update(status, response);
            break;
        }
    }

    @Override
    protected void notifyCancelElectronicNotification(IModelObjectService referenceService)
            throws ClientException {
        getNotifications().notifyElectronicNotificationChanged(referenceService);
    }

    @Override
    public boolean isCleanable() {
    	switch (getElectronicNotification().getStatusNotification()) {
		case CANCELED:
			return true;
		default:
			return !getElectronicNotification().getRequest().getUserMark().getUser().getLogin()
            .equals(getConfiguration().getConfigUser().getUserLogin());
		}
    }

    @Override
    public boolean isBlockingSign() {
    	switch (getElectronicNotification().getStatusNotification()) {
		case CREATED:
			return true;
		case CANCELED:
			return false;
		case ACCEPTED:
		case ACCEPTED_NCR:
			return false;
		case REFUSED:
			return true;
		default:
			return false;
		}
    }
}
