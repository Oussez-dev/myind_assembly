package turbomeca.gamme.assembly.client.model.edit.status;

import java.util.Enumeration;
import java.util.List;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.model.edit.AModelAssemblyService;
import turbomeca.gamme.assembly.client.model.edit.IModelAssemblyWrapperService;
import turbomeca.gamme.assembly.client.model.edit.ModelAssemblyServiceProvider;
import turbomeca.gamme.assembly.client.model.edit.factory.ModelStatusBuilderServiceFactory;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelMarkService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelOperationService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseGroupService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskActionService;
import turbomeca.gamme.assembly.client.model.edit.utils.ModelConditionService;
import turbomeca.gamme.assembly.client.model.edit.utils.ModelUtils;
import turbomeca.gamme.assembly.services.model.data.Reference;
import turbomeca.gamme.assembly.services.model.data.References;
import turbomeca.gamme.assembly.services.model.data.State;
import turbomeca.gamme.assembly.services.model.data.types.StatusType;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.context.ContextRequest;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelStatusService;

public class ModelStatusService extends ModelAssemblyServiceProvider implements IModelStatusService {

	/** logger for current class */
	private static Logger logger = Logger.getLogger(ModelStatusService.class);

	/** Status builder */
	private IModelStatusBuilderService statusBuilder;

	/** Condition service */
	private ModelConditionService conditionService;
	
	/**
	 * Constructor
	 * 
	 * @param identifier
	 *            the instruction identifier
	 */
	public ModelStatusService(IModelObjectService modelObjectService) {
		super(modelObjectService);
		setStatusBuilder(ModelStatusBuilderServiceFactory.create((AModelAssemblyService) modelObjectService));
		setConditionService(new ModelConditionService());
	}

	/**
	 * @param statusBuilder
	 *            the statusBuilder to set
	 */
	public void setStatusBuilder(IModelStatusBuilderService statusBuilder) {
		this.statusBuilder = statusBuilder;
	}

	/**
	 * @return the statusBuilder
	 */
	public IModelStatusBuilderService getStatusBuilder() {
		return statusBuilder;
	}

	@Override
	public boolean isDuplicable() throws ClientException {
		return false;
	}

	@Override
	public boolean isAlterable() throws ClientException {
		boolean alterable = false;
		IModelObjectService parentService = getModelService().getParent();
		if (parentService != null) {
			alterable = getModelService().getParent().getStatusService().isAlterable();
		}
		return alterable;
	}

	@Override
	public String getStatus() throws ClientException {
		String status = null;
		State state = getWrapperService().getState();
		if (state != null) {
			status = state.getStatus().value();
		}
		return status;
	}

	@Override
	public void initStatus() throws ClientException {
	}

	@Override
	public String getStatus(String instanceId) throws ClientException {
		return getStatusBuilder().getStatus(instanceId);
	}

	@Override
	public void updateState(String status, boolean force, String comment, List<String> instancesId)
			throws ClientException, ClientInterruption {
		logger.debug("updateState " + status + " (" + instancesId + ") : " + getModelService());
		if (getStatusBuilder().setState(StatusType.valueOf(status), comment, force, instancesId)) {
			getNotifications().notifyStatusChanged(getModelService());
		}
		setServiceModified();
	} 

	@Override
	public void setServiceModified() throws ClientException, ClientInterruption {
		getModelService().setModified();
		References references = getWrapperService().getReferences();
		if (references != null) {
			Enumeration<? extends Reference> enumReferences = references.enumerateReference();
			while (enumReferences.hasMoreElements()) {
				Reference reference = enumReferences.nextElement();
				IModelObjectService modelService = ModelUtils.getModelServiceReferenced(
						getModelProvider(), reference.getRefId());
				if (modelService != null) {
					//Update Status
					modelService.getStatusService().update();
					
					if(modelService instanceof ModelTaskActionService) {
						ModelTaskActionService modelTaskActionService = (ModelTaskActionService) modelService;
						//Update Electronic notification
						modelTaskActionService.refreshValueValidityStatus(modelTaskActionService.getTextValue(),true);
					}
					
				} else {
					logger.error("Reference on not manage element");
				}
			}
		}
	}
	
	
	@Override
	public void update() throws ClientException, ClientInterruption {
		logger.debug("update : " + getModelService());
		
		// Check if global status has change
		boolean isGlobalConditionValid = getConditionService().isConditionsValid(getWrapperService().getConditions(), null);
		StatusType globalStatus = StatusType.valueOf(getStatus());
		boolean rebuildGlobalStatus = (isGlobalConditionValid && globalStatus == StatusType.NOT_TODO)
								   || (!isGlobalConditionValid && globalStatus != StatusType.NOT_TODO);

		if (rebuildGlobalStatus) {
			setAlterable(null);
			clean(null);
			updateActivity(true, true, null);
			if(isGlobalConditionValid){
				updateTaskActionRef(getModelService());
			}
		}
	}

	private void updateTaskActionRef(AModelAssemblyService modelService) throws ClientException, ClientInterruption {
		for(IModelObjectService modelTaskActionObjectService : modelService.getChildrenDeep(ModelTaskActionService.class)){
			ModelTaskActionService modelTaskActionService = (ModelTaskActionService) modelTaskActionObjectService;
			if(modelTaskActionService.getWrapperService().isInputComputed()){
				modelTaskActionService.getStatusService().update();
			}
		}
	}

	@Override
	public void reactive(boolean recursively, List<String> instancesId, boolean clean) throws ClientException, ClientInterruption {
		logger.debug("reactiveService : (" + instancesId + ")" + getModelService());
		setAlterable(instancesId);
		updateActivity(recursively, true, instancesId);
	}

	@Override
	public void setActive(boolean recursive, boolean delete, List<String> instancesId)
			throws ClientException, ClientInterruption {
		getStatusBuilder().setActive(recursive, delete, instancesId);
	}

	@Override
	public void updateActivity(boolean recursive, boolean delete, List<String> instancesId)
			throws ClientException, ClientInterruption {
		logger.debug("updateActivity : " + " (" + instancesId + ")" + getModelService());
		getStatusBuilder().setActive(true, delete, instancesId);
		if (getWrapperService().getState() != null) {
			resetState(false, false, instancesId);
		}
		if (recursive) {
			for (IModelObjectService modelService : getModelService().getChildren()) {
				modelService.getStatusService().updateActivity(recursive, delete, instancesId);
			}
		}
		IModelObjectService parent = getModelService().getParent();
		if (parent != null) {
			parent.getStatusService().computeStatus(false);
		}
	}

	@Override
	public void computeStatus(boolean recursively) throws ClientException, ClientInterruption {
		logger.debug("computeStatus  : " + getModelService());
		StatusType currentStatus = getInitStatus();
		boolean forceTodo = false;
		if (currentStatus == StatusType.TODO) {
			for (IModelObjectService modelService : getModelService().getChildren()) {
				if (recursively) {
					modelService.getStatusService().computeStatus(recursively);
				}
				if (!forceTodo) {
					String status = modelService.getStatusService().getStatus();
					if (status != null && status != StatusType.NONE.value()
							&& modelService.getRunnableService().isRunnable()) {
						if (status.equals(StatusType.TODO.value())
								|| status.equals(StatusType.WAIT.value())) {
							forceTodo = true;
						} else {
							currentStatus = getStatusBuilder().checkStatusChange(
									currentStatus, StatusType.valueOf(status));
						}
					}
				}
			}
		}
		if (forceTodo) {
			currentStatus = StatusType.TODO;
		}
		if (getWrapperService().getState() != null) {
			updateState(currentStatus.value(), false, null, null);
		}
	}
	
	protected void computeChildrenStatus() throws ClientException, ClientInterruption {
		for (IModelObjectService modelService : getModelService().getChildren()) {
				modelService.getStatusService().computeStatus(true);
		}
	}

	@Override
	public void clean(List<String> instancesId) throws ClientException, ClientInterruption {
		logger.debug("clean (" + instancesId + ") : " + getModelService());
		for (IModelObjectService modelService : getModelService().getChildren()) {
			modelService.getStatusService().clean(instancesId);
		}
	}

	@Override
	public void archive(int passingId, int iterationId, List<String> instancesId)
			throws ClientException {
		logger.debug("archive (" + instancesId + ") : " + getModelService());
	}
	
	@Override
	public void updateDeepId(int passingId, int iterationId, List<String> instancesId) throws ClientException {
		getStatusBuilder().updateId(passingId, iterationId, instancesId);
		for (IModelObjectService modelService : getModelService().getChildren()) {
		    if (modelService.getStatusService() != null) {
		        modelService.getStatusService().updateDeepId(passingId, iterationId, instancesId);
		    }
		}
    	getModelProvider().addModelService(getModelService().getIdentifier(), getModelService());
	}

	@Override
	public void disable(boolean recursive, List<String> instancesId) throws ClientException, ClientInterruption {
		logger.debug("disable (" + instancesId + ") : " + getModelService());
		getStatusBuilder().setActive(false, false, instancesId);
		for (IModelObjectService modelService : getModelService().getChildren()) {
			modelService.getStatusService().disable(recursive, instancesId);
		}
	}
	
	@Override
	public void enable(boolean recursive, List<String> instancesId) throws ClientException, ClientInterruption {
		logger.debug("disable (" + instancesId + ") : " + getModelService());
		getStatusBuilder().setActive(true, false, instancesId);
		for (IModelObjectService modelService : getModelService().getChildren()) {
			modelService.getStatusService().enable(recursive, instancesId);
		}
	}

	@Override
	public void resetState(boolean recursively, boolean force, List<String> instancesId)
			throws ClientException, ClientInterruption {
		logger.debug("resetState (" + instancesId + ") : " + getModelService());
		if (getStatusBuilder().resetState(force, instancesId)) {
			getNotifications().notifyStatusChanged(getModelService());
		}
		// Reset parent if need
		IModelObjectService parentService = getModelService().getParent();
		if (parentService != null) {
			String parentStatus = parentService.getStatusService().getStatus();
			if (parentStatus != null 
				&& !parentService.getStatusService().getStatus().equals(StatusType.TODO.value())
				&& !parentService.getStatusService().getStatus().equals(StatusType.NOT_TODO.value())) {
				parentService.getStatusService().resetState(false, force, instancesId);
			}
			
			// Reset predecessor subphases of the present subphase
			if (getModelService() instanceof ModelSubPhaseService) {
				// if some child of parent (so followers of present service) are linked by predecessors link, 
				// their state must be reset (even if not recursively)
				boolean isPredecessorValid;
				if (parentService instanceof ModelOperationService) {
					if (!parentService.getChildren().isEmpty() && !recursively) {
						for (IModelObjectService modelService : parentService.getChildren()) {
							isPredecessorValid = modelService.getStatusService().arePredecessorsValid();
							if (!isPredecessorValid && modelService instanceof ModelSubPhaseService
									&& (modelService.getStatusService().getStatus().equals(StatusType.DONE.value())
									|| modelService.getStatusService().getStatus().equals(StatusType.TO_SIGN.value()))
									&& !modelService.getWrapperService().isArchived()) {
								modelService.getStatusService().resetState(false, force, instancesId);
							}
						}
					}
				} else if (parentService instanceof ModelSubPhaseGroupService) {
					IModelObjectService parentOperationService = parentService.getParent();
					if (!parentOperationService.getChildren().isEmpty() && !recursively) {
						// Reset all subphases of predecessor operations of present operation containing a reseted subphase
						for (IModelObjectService childrenSubPhaseOrSubPhaseGroupModelService : parentOperationService.getChildren()) {
							if (childrenSubPhaseOrSubPhaseGroupModelService instanceof ModelSubPhaseService) {
								isPredecessorValid = childrenSubPhaseOrSubPhaseGroupModelService.getStatusService().arePredecessorsValid();
								if ((!isPredecessorValid && (childrenSubPhaseOrSubPhaseGroupModelService.getStatusService().getStatus().equals(StatusType.DONE.value())
										|| childrenSubPhaseOrSubPhaseGroupModelService.getStatusService().getStatus().equals(StatusType.TO_SIGN.value())))
									&& !childrenSubPhaseOrSubPhaseGroupModelService.getWrapperService().isArchived()) {
									childrenSubPhaseOrSubPhaseGroupModelService.getStatusService().resetState(false, force, instancesId);
								}
							// Reset each subPhase for of subPhase Group
							} else if (childrenSubPhaseOrSubPhaseGroupModelService instanceof ModelSubPhaseGroupService) {
								for (IModelObjectService childrenSubPhaseModelService : childrenSubPhaseOrSubPhaseGroupModelService.getChildren()) {
									if (childrenSubPhaseModelService instanceof ModelSubPhaseService) {
										isPredecessorValid = childrenSubPhaseModelService.getStatusService().arePredecessorsValid();
										if ((!isPredecessorValid && (childrenSubPhaseModelService.getStatusService().getStatus().equals(StatusType.DONE.value())
												|| childrenSubPhaseModelService.getStatusService().getStatus().equals(StatusType.TO_SIGN.value()))
												&& !childrenSubPhaseModelService.getWrapperService().isArchived())) {
											childrenSubPhaseModelService.getStatusService().resetState(false, force, instancesId);
										}
									}
								}
							}
						}
					}
				}
			}
			
			// Reset predecessor operations of the present operation
			if (getModelService() instanceof ModelOperationService) {
				// if some child of parent (so followers of present service) are linked by predecessors link, 
				// their state must be reset (even if not recursively)
				boolean isPredecessorValid;
				if (!parentService.getChildren().isEmpty() && !recursively) {
					for (IModelObjectService modelService : parentService.getChildren()) {
						if (modelService instanceof ModelOperationService) {
							isPredecessorValid = modelService.getStatusService().arePredecessorsValid();
							if (!isPredecessorValid) {
								// Reset all subphases of predecessor operations of present operation containing a reseted subphase
								for (IModelObjectService childrenSubPhaseOrSubPhaseGroupModelService : modelService.getChildren()) {
									if (childrenSubPhaseOrSubPhaseGroupModelService instanceof ModelSubPhaseService) {
										if ((childrenSubPhaseOrSubPhaseGroupModelService.getStatusService().getStatus().equals(StatusType.DONE.value())
												|| childrenSubPhaseOrSubPhaseGroupModelService.getStatusService().getStatus().equals(StatusType.TO_SIGN.value()))
												&& !childrenSubPhaseOrSubPhaseGroupModelService.getWrapperService().isArchived()) {
											childrenSubPhaseOrSubPhaseGroupModelService.getStatusService().resetState(false, force, instancesId);
										}
									// Reset each subPhase of subPhase Group
									} else if (childrenSubPhaseOrSubPhaseGroupModelService instanceof ModelSubPhaseGroupService) {
										for (IModelObjectService childrenSubPhaseModelService : childrenSubPhaseOrSubPhaseGroupModelService.getChildren()) {
											if (childrenSubPhaseModelService instanceof ModelSubPhaseService) {
												if ((childrenSubPhaseModelService.getStatusService().getStatus().equals(StatusType.DONE.value())
														|| childrenSubPhaseModelService.getStatusService().getStatus().equals(StatusType.TO_SIGN.value())) 
														&& !childrenSubPhaseModelService.getWrapperService().isArchived()) {
													childrenSubPhaseModelService.getStatusService().resetState(false, force, instancesId);
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			
		}
		setServiceModified();
		if (recursively) {
			for (IModelObjectService modelService : getModelService().getChildren()) {
				modelService.getStatusService().resetState(recursively, force, instancesId);
			}
		}
	}

	@Override
	public void setAlterable(List<String> instancesId, boolean clean) throws ClientException, ClientInterruption {
		logger.debug("setAlterable (" + instancesId + ") : " + getModelService());

		IModelObjectService duplicableService = getParentDuplicable();
		IModelObjectService duplicableParentService = duplicableService.getParent();
		if (duplicableService != null && duplicableParentService != null) {
			getStatusBuilder().setAlterable(duplicableService, instancesId);
		}
		
	}
	
	@Override
	public void setAlterable(List<String> instancesId) throws ClientException, ClientInterruption {
		setAlterable(instancesId, true);
	}

	private IModelObjectService getParentDuplicable() throws ClientException {
		IModelObjectService duplicableService = null;
		if (isDuplicable()) {
			duplicableService = getModelService();
		} else {
			IModelObjectService parentService = getModelService().getParent();
			while (parentService != null) {
				if (parentService.getStatusService().isDuplicable()) {
					duplicableService = parentService;
					break;
				} else {
					parentService = parentService.getParent();
				}
			}
		}
		return duplicableService;
	}

	protected StatusType getInitStatus() {
		StatusType status = StatusType.NOT_TODO;
		if (getConditionService().isConditionsValid(getWrapperService().getConditions(), null)) {
			status = StatusType.TODO;
		}
		return status;
	}

	@Override
	public void updateComment(String comment, List<String> instancesId) throws ClientException {
		getStatusBuilder().setComment(comment, instancesId);
		getModelService().setModified();
	}

	@Override
	public boolean isInProgress() throws ClientException {
	    boolean isInProgress = false;
	    if (getStatus() != null && getModelService().getRunnableService().isRunnable()) {
	        isInProgress = getModelService().getRunnableService().isFinished();
	    }
    		
		for (IModelObjectService modelService : getModelService().getChildren()) {
			isInProgress |= modelService.getStatusService().isInProgress();
			if (isInProgress) {
				break;
			}
		}
		return isInProgress;
	}
	
	/**
	 * @return the conditionService
	 */
	public ModelConditionService getConditionService() {
		return conditionService;
	}

	/**
	 * @param conditionService the conditionService to set
	 */
	public void setConditionService(ModelConditionService conditionService) {
		this.conditionService = conditionService;
	}

	@Override
	public boolean arePredecessorsValid() {
		boolean isPredecessorsValid = true;
		
		IModelAssemblyWrapperService wrapper = getModelService().getWrapperService();
        List<String> predecessorsId = wrapper.getPredecessors();
        if (predecessorsId != null && !wrapper.isForcePredecessorsValid()) {
            for(String predecessorId : predecessorsId) {
                IModelObjectService modelService = getModelProvider().getModelService(predecessorId);
                if (    modelService.getWrapperService().isApplicable() 
                    && !modelService.getRunnableService().isFinished()) {
                    isPredecessorsValid = false;
                    break;
                }
            }
        }
		
		return isPredecessorsValid;
	}
}
