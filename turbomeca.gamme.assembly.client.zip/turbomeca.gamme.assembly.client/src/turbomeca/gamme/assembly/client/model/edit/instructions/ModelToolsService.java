package turbomeca.gamme.assembly.client.model.edit.instructions;

import turbomeca.gamme.assembly.client.model.edit.AModelAssemblyService;
import turbomeca.gamme.assembly.client.model.edit.hmi.updater.ModelHmiUpdaterService;
import turbomeca.gamme.assembly.client.model.edit.loader.ModelLoaderToolsService;
import turbomeca.gamme.assembly.client.model.edit.runnable.ModelRunnableStatusNoneService;
import turbomeca.gamme.assembly.client.model.edit.status.ModelStatusService;
import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperToolsService;
import turbomeca.gamme.assembly.services.model.data.Tools;

public class ModelToolsService extends AModelAssemblyService {

	private static final String TOOLS_SUFFIX_ID = "_tools";

	/**
	 * Constructor for task object
	 * 
	 * @param subPhaseService
	 *            parent service
	 * @param task
	 *            task object
	 */
	public ModelToolsService(ModelResourcesService resourceService, Tools tools) {
		super(resourceService.getDomain(), resourceService.getIdentifier() + TOOLS_SUFFIX_ID);
		setParent(resourceService);
		
		setWrapperService(new ModelWrapperToolsService(tools));
		setLoaderService(new ModelLoaderToolsService(this));
		setHmiUpdaterService(new ModelHmiUpdaterService());
		setStatusService(new ModelStatusService(this));
		setRunnableService(new ModelRunnableStatusNoneService(this));
	}

}
