package turbomeca.gamme.assembly.client.model.edit.notifications;

import java.util.Set;
import java.util.Vector;

import turbomeca.gamme.assembly.client.model.edit.AModelAssemblyService;
import turbomeca.gamme.assembly.client.model.edit.IModelAssemblyWrapperScheduleService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelMarkService;
import turbomeca.gamme.assembly.client.model.edit.runnable.ModelRunnableNoneService;
import turbomeca.gamme.assembly.client.model.edit.status.ModelStatusNoneService;
import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperElectronicNotificationService;
import turbomeca.gamme.assembly.services.model.data.ElectronicNotification;
import turbomeca.gamme.assembly.services.model.data.ElectronicNotificationRef;
import turbomeca.gamme.assembly.services.model.data.Mark;
import turbomeca.gamme.assembly.services.model.data.TaskAction;
import turbomeca.gamme.assembly.services.model.data.types.NotificationOriginType;
import turbomeca.gamme.assembly.services.model.data.types.NotificationType;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.constants.PropertyConstants;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public class ModelNotificationMarkService extends AModelNotificationService {

    /**
     * 
     * @param electronicNotification
     */
    public ModelNotificationMarkService(ModelNotificationsService modelNotificationService,
            ElectronicNotification electronicNotification) {
        super(modelNotificationService, electronicNotification);
    }
    
    /**
     * 
     * @param markService
     * @param newPnValue
     * @param newSnValue
     * @param newDerogValue
     */
    public ModelNotificationMarkService(ModelMarkService markService, ElectronicNotification electronicNotification) {
        super(markService.getDomain(), electronicNotification.getId());
        setRunnableService(new ModelRunnableNoneService());
        setStatusService(new ModelStatusNoneService(this));
        setWrapperService(new ModelWrapperElectronicNotificationService(electronicNotification));
    }
    
    /**
     * 
     * @param markService
     * @param newPnValue
     * @param newSnValue
     * @param newDerogValue
     */
    public ModelNotificationMarkService(ModelMarkService markService, String notificationId,
                                    String instanceId, String alternativeId, String newPnValue, String optionnalComment) {
        super(markService.getDomain(), notificationId);
        initService();
        
        // Get mark name
        String markName = buildNotificationDescription(markService, alternativeId);
        String message = null;
        if (instanceId == null) {
            message = String.format(
                    getConfiguration().getProperty(
                            PropertyConstants.PROPERTY_MESSAGE_NOTIFICATION_MARK_CHANGE),
                    markName, newPnValue);
        } else {
            message = String
                    .format(getConfiguration()
                            .getProperty(
                            		PropertyConstants.PROPERTY_MESSAGE_NOTIFICATION_MARK_CHANGE_PN),
                            markName, getSNContentIfNotNullElseGetInstanceId(instanceId), newPnValue);
        }
        
        createElectronicNotification(NotificationType.QUALITY, NotificationOriginType.MARK, message);
        getElectronicNotification().setAlternative(alternativeId);
        getElectronicNotification().setInstance(instanceId);
        getElectronicNotification().getRequest().setOptionnalComment(optionnalComment);
    }
    
    /**
     * 
     * @param markService
     * @param newPnValue
     * @param newSnValue
     * @param newDerogValue
     */
    public ModelNotificationMarkService(ModelMarkService markService, String notificationId,
                                    String instanceId, String alternativeId, Set<String> newPnValues, String optionnalComment) {
        super(markService.getDomain(), notificationId);
        initService();
        
        // Get mark name
        String markName = buildNotificationDescription(markService, alternativeId);
        String message = null;
        if (instanceId == null) {
            message = String.format(
                    getConfiguration().getProperty(
                            PropertyConstants.PROPERTY_MESSAGE_NOTIFICATION_MARK_CHANGE),
                    markName, newPnValues);
        } else {
            message = String
                    .format(getConfiguration()
                            .getProperty(
                            		PropertyConstants.PROPERTY_MESSAGE_NOTIFICATION_MARK_CHANGE_PN),
                            markName, getSNContentIfNotNullElseGetInstanceId(instanceId), newPnValues);
        }
        
        createElectronicNotification(NotificationType.QUALITY, NotificationOriginType.MARK, message);
        getElectronicNotification().setAlternative(alternativeId);
        getElectronicNotification().setInstance(instanceId);
        getElectronicNotification().getRequest().setOptionnalComment(optionnalComment);
    }

    @Override
    public void bindService(AModelAssemblyService modelService, String mustSynchronize) throws ClientException {
        super.bindService(modelService, mustSynchronize);
        
        ModelMarkService markService = (ModelMarkService) modelService;
        Mark mark = markService.getWrapperService().getMark();
        if (getElectronicNotification().getInstance() == null && getElectronicNotification().getAlternative() == null) {
            mark.removeAllElectronicNotificationRef();
        } else {
            Vector<ElectronicNotificationRef> electNotifRefList = new Vector<ElectronicNotificationRef>();
            for (ElectronicNotificationRef electNotifRef : mark.getElectronicNotificationRef()) {
                if (!isNotificationReference(electNotifRef)) {
                    electNotifRefList.add(electNotifRef);
                }
            }
            mark.setElectronicNotificationRef(electNotifRefList);
        }
        mark.addElectronicNotificationRef(createNotificationReference());
    }
    
    @Override 
    protected void notifyCancelElectronicNotification(IModelObjectService referenceService) throws ClientException {
        getNotifications().notifyServiceChanged(referenceService.getParent());
    }
    
    @Override
    public boolean isCleanable() {
    	switch (getElectronicNotification().getStatusNotification()) {
		case CANCELED:
			return true;
		default:
			return !getElectronicNotification().getRequest().getUserMark().getUser().getLogin()
            .equals(getConfiguration().getConfigUser().getUserLogin());
		}
    }

    @Override
    public boolean isBlockingSign() {
    	switch (getElectronicNotification().getStatusNotification()) {
		case CREATED:
			return true;
		case CANCELED:
			return false;
		case ACCEPTED:
		case ACCEPTED_NCR:
			return false;
		case REFUSED:
			return true;
		default:
			return false;
		}
    }
    
    /**
     * 
     * @param markService
     * @param alternativeId
     * @return
     */
    private String buildNotificationDescription(ModelMarkService markService, String alternativeId) {
        String markName = "[ ";
        Mark mark = markService.getWrapperService().getMark();
        if (mark.getCompound() != null) {
            markName += mark.getCompound() + " ";
        }
        if (mark.getDrawingMarker() != null) {
            markName += mark.getDrawingMarker() + " ";
        }
        if (mark.getAta() != null) {
            markName += mark.getAta() + " ";
        }
        markName += "]";
        if (alternativeId != null) {
            markName +=  getConfiguration().getProperty(
            		PropertyConstants.PROPERTY_MESSAGE_NOTIFICATION_MARK_ALTERNATIVE)
                    + " " + alternativeId;
        }
        return markName;
    }
    
    private String getSNContentIfNotNullElseGetInstanceId(String instanceId) {
    	String sn = "L" + instanceId;
    	IModelAssemblyWrapperScheduleService scheduleWrapper = (IModelAssemblyWrapperScheduleService) getModelProvider().getModelScheduleService().getWrapperService();
		TaskAction taskAction = scheduleWrapper.getInstantiation().getSN(Integer.parseInt(instanceId) - 1).getTaskAction();
		if(taskAction != null && taskAction.getInputAction() != null) {
			if (taskAction.getInputAction().getInputActionChoice() != null && taskAction.getInputAction().getInputActionChoice().getInputChoice() != null) {
				int nbValue = Integer.parseInt(taskAction.getInputAction().getInputValue().getValue());
				sn = taskAction.getInputAction().getInputActionChoice().getInputChoice().getStringValue(nbValue-1).getContent();
			} else if(taskAction.getInputAction().getInputValue() != null) {
				sn = taskAction.getInputAction().getInputValue().getValue();
			} 
		}
		return sn;
    }
}
