package turbomeca.gamme.assembly.client.model.edit.utils;

import java.math.BigDecimal;

import org.apache.log4j.Logger;
import org.nfunk.jep.JEP;

import turbomeca.gamme.assembly.client.ClientAssemblyException;
import turbomeca.gamme.assembly.client.model.edit.instructions.AModelTaskActionService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskActionService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskActionTableService;
import turbomeca.gamme.assembly.services.model.data.Formula;
import turbomeca.gamme.assembly.services.model.data.InputValue;
import turbomeca.gamme.assembly.services.model.data.TaskAction;
import turbomeca.gamme.assembly.services.model.data.TaskActionTable;
import turbomeca.gamme.assembly.services.model.data.Variable;
import turbomeca.gamme.ecran.client.model.provider.ModelXmlProvider;
import turbomeca.gamme.ecran.services.common.utils.jep.CustomJepFactory;

public class ModelFormulaService {

	/** logger for current class */
	private static Logger logger = Logger.getLogger(AModelTaskActionService.class);

	/** Formula CASTOR object */
	private Formula formula;

	/** Digit precision */
	private int precision;

	/**
	 * Constructor
	 * 
	 * @param formula
	 *            CASTOR object
	 */
	public ModelFormulaService(Formula formula, int precision) {
		this.formula = formula;
		this.precision = precision;
	}

	/**
	 * Compute formula with references
	 * 
	 * @return inputValues if all references are filled otherwise null
	 * @throws ClientEvalException
	 */
	public String compute() throws ClientAssemblyException {
		CustomJepFactory customJepFactory = new CustomJepFactory();
		JEP mathParser = customJepFactory.createCustomParser(false);
		mathParser.setImplicitMul(true);

		for (Variable variable : formula.getVariable()) {
			// Detect if variable is of type dataFromTable
			Object tableRef = variable.getTableRefId();
			
			// Table-linked variable
			if(tableRef != null) {
				if(!processTableLinkedVariable(variable, mathParser)) {
					return null;
				}
			}
			// Simple variable
			else if(!processSimpleVariable(variable, mathParser)) {
				return null;
			}
		}

		mathParser.parseExpression(formula.getExpression());

		// Format value if needed
		double valueComputed = BigDecimal.valueOf(mathParser.getValue()).setScale(
				precision, BigDecimal.ROUND_HALF_UP).doubleValue();
		return String.valueOf(valueComputed);
	}
	
	private boolean processTableLinkedVariable(Variable variable, JEP mathParser) {
		String name = variable.getName();
		Object refObject = variable.getRefId();
		Object tableRefObject = variable.getTableRefId();
		
		if(!variable.hasTestsRowIndex() || !variable.hasValuesRowIndex()) {
			logger.error("Table-linked variable has neither tests row nor values row declared!");
			return false;
		}
		
		// Correct table indexes as redactors uses "1" as a starting index, not "0"
		int testsRowIndex = variable.getTestsRowIndex() - 1;
		int valuesRowIndex = variable.getValuesRowIndex() - 1;
		
		// Check reference
		if(refObject == null || !(refObject instanceof TaskAction)) {
			logger.error("Variable " + name + " reference is not set or not a taskAction!");
			return false;
		}
		
		// Check table reference
		if(tableRefObject == null || !(tableRefObject instanceof TaskActionTable)) {
			logger.debug("Variable " + name + " reference is not set or not a taskActionTable!");
			return false;
		}
		
		// Read reference taskAction
		TaskAction refTaskAction = (TaskAction) refObject;
		ModelTaskActionService refTaskActionService = (ModelTaskActionService) ModelXmlProvider.getInstance().getModelService(refTaskAction.getId());
		
		// Compare reference value to the declared table tests row and read the valid column index
		TaskActionTable table = (TaskActionTable) tableRefObject;
		ModelTaskActionTableService service = (ModelTaskActionTableService) ModelXmlProvider.getInstance().getModelService(table.getId());
		
		int validColIndex = service.getColumnValidTest(testsRowIndex, refTaskActionService);
		
		if(validColIndex == -1) {
			logger.debug("The table-linked variable reference value is invalid for the given tests row: " + testsRowIndex);
			return false;
		}
		
		String value = service.getCellValue(valuesRowIndex, validColIndex);

		if(value == null) {
			logger.debug("Unable to read table-linked variable value from table[@id=" + table.getId() 
					+ ", cell[x=" + valuesRowIndex + ", y=" + validColIndex + "]");
			return false;
		}
		
		mathParser.addVariable(name, Double.parseDouble(value));
		return true;
	}

	private boolean processSimpleVariable(Variable variable, JEP mathParser) {
		String name = null;
		String value = null;

		name = variable.getName();
		Object taskActionObject = variable.getRefId();
		if (taskActionObject instanceof TaskAction) {
			TaskAction taskAction = (TaskAction) taskActionObject;
			InputValue inputValue = taskAction.getInputAction()
					.getInputValue();
			if (inputValue == null) {
				logger.info("Formula computation aborted : "
						+ taskAction.getId() + " has no value");
				return false;
			} else {
				value = inputValue.getValue();
			}
		}
		
		mathParser.addVariable(name, Double.parseDouble(value));
		return true;
	}

}
