package turbomeca.gamme.assembly.client.model.edit.factory;

import turbomeca.gamme.assembly.client.model.edit.AModelAssemblyService;
import turbomeca.gamme.assembly.client.model.edit.status.IModelStatusBuilderService;
import turbomeca.gamme.assembly.client.model.edit.status.ModelStatusBuilderService;

public class ModelStatusBuilderServiceFactory {

	public static IModelStatusBuilderService create(AModelAssemblyService modelService) {
		return new ModelStatusBuilderService(modelService);
	}
}
