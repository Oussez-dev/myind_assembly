package turbomeca.gamme.assembly.client.model.edit.provider;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelMarkService;
import turbomeca.gamme.assembly.services.model.data.TaskMark;

public class ModelMarkProvider {

    /** */
    private static ModelMarkProvider instance;
    
    /** */
    private HashMap<String, List<ModelMarkService>> marks;
    
    /** */
    private HashMap<String, List<TaskMark>> markReferences;
    
    /**
     * Singleton
     * @return the instance
     */
    public static ModelMarkProvider getInstance() {
        if (instance == null) {
            instance = new ModelMarkProvider();
        }
        return instance;
    }

    public void destroy() {
        instance = null;
        markReferences = null;
        marks = null;
    }
    
    private ModelMarkProvider() {
        setMarks(new HashMap<String, List<ModelMarkService>>());
        setMarkReferences(new HashMap<String, List<TaskMark>>());
    }
    
    /**
     * Add a mark service 
     * @param notificationService the notification to add
     */
    public void addMarkService(ModelMarkService markService) {
        String idUniq = markService.getWrapperService().getMark().getNameId();
        List<ModelMarkService> marks = getMarks().get(idUniq);
        if (marks == null) {
            getMarks().put(idUniq, new ArrayList<ModelMarkService>());
        }
        getMarks().get(idUniq).add(markService);
    }
    
    /**
     * 
     * @param modelMarkService
     * @return
     */
    public List<ModelMarkService> getMarks(ModelMarkService modelMarkService) {
        return getMarks(modelMarkService.getWrapperService().getMark().getNameId());
    }
    
    /**
     * Get all notification instances for an identifier 
     * @param id the notification identifier
     * @return the notifications list with same identifier
     */
    public List<ModelMarkService> getMarks(String id) {
        return getMarks().get(id);
    }
    
    
    /**
     * 
     * @param taskMark
     */
    public void addTaskMarkReference(TaskMark taskMark) {
        String idUniq = taskMark.getRefNameId();
        List<TaskMark> taskMarks = getMarkReferences().get(taskMark.getRefNameId());
        if (taskMarks == null) {
            getMarkReferences().put(idUniq, new ArrayList<TaskMark>());
        }
        getMarkReferences().get(taskMark.getRefNameId()).add(taskMark);
    }
    
    /**
     * 
     * @param modelMarkService
     * @return
     */
    public List<TaskMark> getMarkReferences(ModelMarkService modelMarkService) {
        return getMarkReferences().get(modelMarkService.getWrapperService().getMark().getNameId());
    }
    
    /**
     * @return the marks
     */
    public HashMap<String, List<ModelMarkService>> getMarks() {
        return marks;
    }

    /**
     * @param marks the marks to set
     */
    public void setMarks(HashMap<String, List<ModelMarkService>> marks) {
        this.marks = marks;
    }

    /**
     * @return the markReferences
     */
    public HashMap<String, List<TaskMark>> getMarkReferences() {
        return markReferences;
    }

    /**
     * @param markReferences the markReferences to set
     */
    public void setMarkReferences(HashMap<String, List<TaskMark>> markReferences) {
        this.markReferences = markReferences;
    }
}
