package turbomeca.gamme.assembly.client.model.edit.status;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskBenchSettingService;
import turbomeca.gamme.assembly.services.model.data.types.StatusType;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public class ModelStatusTaskBenchSettingService extends ModelStatusService {

	/** logger for current class */
	private static Logger logger = Logger
			.getLogger(ModelStatusTaskBenchSettingService.class);

	/**
	 * 
	 * @param modelService
	 */
	public ModelStatusTaskBenchSettingService(IModelObjectService modelService) {
		super(modelService);
	}

	@Override
	public void computeStatus(boolean recursively) throws ClientException, ClientInterruption {
		logger.debug("computeStatus : " + getModelService());
		
		ModelTaskBenchSettingService modelService = (ModelTaskBenchSettingService) getModelService();
		StatusType internalState = modelService.getInternalState();
		
        boolean isPredecessorsValid = true;
        ModelSubPhaseService subPhaseService = (ModelSubPhaseService) getModelService().getAncestor(ModelSubPhaseService.class);
        if (subPhaseService != null) {
        	/* For assembly, the subphase service is runnable only if
			   subphase is editable, qualifications are valid and all its predecessors are signed */
        	isPredecessorsValid = subPhaseService.getRunnableService().canRun();
        }
        
		if (isPredecessorsValid) {
			updateState(internalState.value(), false, null, null);
		}
	}
}
