package turbomeca.gamme.assembly.client.model.edit.hmi.updater;

import turbomeca.gamme.assembly.client.model.interfaces.IAssemblyModelHmiUpdaterService;
import turbomeca.gamme.assembly.services.constants.AssemblyXsltConstants;

public class ModelHmiUpdaterServiceOnMainView extends AModelAssemblyHmiUpdaterService implements IAssemblyModelHmiUpdaterService  {

    private String hmiParentId;
    private boolean tableMode;
    
    public ModelHmiUpdaterServiceOnMainView() {
        setHmiParentId("");
    }
    
    public ModelHmiUpdaterServiceOnMainView(String hmiParentId) {
        setHmiParentId(hmiParentId);
    }
    
	@Override
	public String getXsltTemplate() {
		return AssemblyXsltConstants.XSLT_UPDATE.value();
	}

	@Override
	public int getXsltTemplatePdfType() {
		return 0;
	}
	
	@Override
	public String getXsltTemplateSynthesis() {
		return null;
	}

	@Override
    public String getHmiParentId() {
        return hmiParentId;
    }

    @Override
    public boolean isModeTable() {
        return tableMode;
    }
    
    @Override
    public void setHmiParentId(String hmiParentId) {
        this.hmiParentId = hmiParentId;
    }
    
    @Override
    public void setModeTable(boolean tableMode) {
        this.tableMode = tableMode;
    }
}
