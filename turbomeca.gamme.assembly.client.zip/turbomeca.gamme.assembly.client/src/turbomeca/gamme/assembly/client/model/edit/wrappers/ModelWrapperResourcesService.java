package turbomeca.gamme.assembly.client.model.edit.wrappers;

import turbomeca.gamme.assembly.services.model.data.Resources;
import turbomeca.gamme.assembly.services.model.data.State;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public class ModelWrapperResourcesService extends AModelWrapperAssemblyService {

	/** */
	private Resources resources;

	/**
	 * Constructor for task object
	 * 
	 * @param subPhaseService
	 *            parent service
	 * @param task
	 *            task object
	 */
	public ModelWrapperResourcesService(Resources resources) {
	    setResources(resources);
	}


	@Override
	public Object getObject() {
		return resources;
	}

	/**
	 * @return the tools
	 */
	public Resources getResources() {
		return resources;
	}

	/**
	 * @param tools
	 *            the tools to set
	 */
	public void setResources(Resources resources) {
		this.resources = resources;
	}


	@Override
	public String getId() {
		return null;
	}


	@Override
	public void setId(String id) {
	}


	@Override
	public void addChild(IModelObjectService nextChild, IModelObjectService newChild)
			throws ClientException {
	}

	@Override
	public boolean isApplicable() {
		return true;
	}

	@Override
	public void setApplicable(boolean applicable) {
	}
	
	@Override
    public State getState() {
        return resources.getState();
    }
}
