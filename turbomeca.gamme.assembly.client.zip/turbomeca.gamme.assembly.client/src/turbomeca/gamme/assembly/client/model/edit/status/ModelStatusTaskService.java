package turbomeca.gamme.assembly.client.model.edit.status;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.services.model.data.types.StatusType;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;

public class ModelStatusTaskService extends ModelStatusService {

	/** logger for current class */
	private static Logger logger = Logger
			.getLogger(ModelStatusTaskService.class);

	/**
	 * 
	 * @param modelService
	 */
	public ModelStatusTaskService(IModelObjectService modelService) {
		super(modelService);
	}

	@Override
	public void computeStatus(boolean recursively) throws ClientException, ClientInterruption {
		logger.debug("computeStatus  : " + getModelService());
		if (getModelService().getChildren().size() > 0) {
			super.computeStatus(recursively);
		} else {
			/* When the task has no child (no taskAction, only taskPara for example), 
		 	 	its status must be updated to OK, if predecessor subPhases are valid */
	        boolean isPredecessorsValid = true;
	        ModelSubPhaseService subPhaseService = (ModelSubPhaseService) getModelService().getAncestor(ModelSubPhaseService.class);
	        if (subPhaseService != null) {
	        	/* For assembly, the subphase service is runnable only if
				   subphase is editable, qualifications are valid and all its predecessors are signed */
	        	isPredecessorsValid = subPhaseService.getRunnableService().canRun();
	        }
			if (isPredecessorsValid) {
				updateState(StatusType.OK.value(), false, null, null);
			}
		}
	}
}
