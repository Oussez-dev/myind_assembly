package turbomeca.gamme.assembly.client.model.edit.wrappers;

import turbomeca.gamme.assembly.services.model.data.ElectronicNotificationRef;

public interface IModelNotificationRefWrapper {
    
    /**
     * 
     * @return
     */
    public ElectronicNotificationRef[] getElectronicNotificationRef();

    /**
     * 
     */
    public void removeElectronicNotificationRef();
}
