package turbomeca.gamme.assembly.client.model.edit.wrappers;

import java.text.SimpleDateFormat;
import java.util.Date;

import turbomeca.gamme.assembly.services.model.data.DerogationMark;
import turbomeca.gamme.assembly.services.model.data.DerogationMarks;

public class ModelWrapperDerogationMarksService extends AModelWrapperAssemblyService {
	
	public static final String DEROGATION_ID ="derogationId";
	
	private static final String PREFIX_ID_DEROGATION_MARK	= "DerogMark";
	
	public static final String DATE_FORMAT_FILENAME = "ddMMyyyyHHmmss";

	/** */
	private DerogationMarks derogationMarks;

	/**
	 * Constructor for task object
	 * 
	 * @param subPhaseService
	 *            parent service
	 * @param task
	 *            task object
	 */
	public ModelWrapperDerogationMarksService(DerogationMarks derogationMarks) {
		setDerogationMarks(derogationMarks);
	}
	
	@Override
	public Object getObject() {
		return derogationMarks;
	}

	@Override
	public String getId() {
		return getDerogationMarks().getId();
	}

	@Override
	public void setId(String id) {
		getDerogationMarks().setId(id);
	}

	public void setDerogationMarks(DerogationMarks derogationMarks) {
		this.derogationMarks = derogationMarks;
	}

	public DerogationMarks getDerogationMarks() {
		return derogationMarks;
	}
	
	public DerogationMark getDerogationMark(String id) {
		DerogationMark returnDerogationMark = null;
		if(getDerogationMarks() !=null ){
			for(DerogationMark currentDerogation : getDerogationMarks().getDerogationMark()){
				if(currentDerogation.getId().equals(id)){
					returnDerogationMark = currentDerogation;
					break;
				}
			}
		}
		return returnDerogationMark;
	}
	
	/**
	 * @return
	 */
	public static String generateIdDerogMarks() {
		SimpleDateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT_FILENAME);
		String idGenerator = dateFormat.format(new Date().getTime());
		return PREFIX_ID_DEROGATION_MARK.concat(idGenerator);
	}
	
	public boolean isPnAlreadyExist(String pn) {
		boolean exist = false;
		if(getDerogationMarks() !=null ){
			for(DerogationMark currentDerogation : getDerogationMarks().getDerogationMark()){
				if(currentDerogation.getPN().equals(pn)){
					exist = true;
					break;
				}
			}
		}
		return exist;
	}

}
