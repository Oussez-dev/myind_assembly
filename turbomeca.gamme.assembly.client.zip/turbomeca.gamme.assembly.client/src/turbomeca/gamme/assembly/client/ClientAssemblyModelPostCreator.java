package turbomeca.gamme.assembly.client;

import java.util.UUID;

import org.apache.log4j.Logger;

import turbomeca.gamme.ecran.client.AClientInstancesProvider;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.model.IModelPostCreatorService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.services.common.constants.GlobalConstants;

public class ClientAssemblyModelPostCreator extends AClientInstancesProvider implements IModelPostCreatorService {

	private final static Logger logger = Logger.getLogger(ClientAssemblyModelPostCreator.class);
	
	@Deprecated
	@Override
	public boolean postCreate(IModelObjectService scheduleModelService) throws ClientException {
		return true;
	}

	/**
	 * @return unique id taskAction for TaskMark
	 */
	private String generatetaskActionTaskMark(String markId) {
		String uniqueId = UUID.randomUUID().toString();
		return markId + GlobalConstants.SEPARATOR_UNDERSCORE + uniqueId;
	}

}
