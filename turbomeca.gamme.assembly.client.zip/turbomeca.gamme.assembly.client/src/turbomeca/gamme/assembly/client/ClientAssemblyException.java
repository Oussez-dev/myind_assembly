package turbomeca.gamme.assembly.client;

import turbomeca.gamme.assembly.client.config.AssemblyPropertyConstants;
import turbomeca.gamme.ecran.client.ClientException;

public class ClientAssemblyException extends ClientException {

	/** */
	private static final long serialVersionUID = 1L;

	/** */
	public static final String EXCEPTION_RAS_DEFINITION_TASK = AssemblyPropertyConstants.PROPERTY_ERROR_DEFINITION_TASK;
	public static final String EXCEPTION_INPUT_RESOURCES_NOT_FINISHED = AssemblyPropertyConstants.PROPERTY_ERROR_INPUT_RESOURCES_NOT_FINISHED;
	public static final String EXCEPTION_SUB_PHASE_VALIDATION = "#TODO";
	public static final String EXCEPTION_CHANGE_MARK_VALUE_EMPTY = AssemblyPropertyConstants.PROPERTY_ERROR_CHANGE_MARK_VALUE_EMPTY;
	public static final String EXCEPTION_FAILED_TO_INSTANTIATED_DISASSEMBLY = AssemblyPropertyConstants.PROPERTY_ERROR_FAILED_TO_RETRIEVE_DISASSEMBLY_SCHEDULE;
	public static final String EXCEPTION_FAILED_TO_INSTANTIATED_ASSEMBLY = AssemblyPropertyConstants.PROPERTY_ERROR_FAILED_TO_RETRIEVE_ASSEMBLY_SCHEDULE;
	public static final String EXCEPTION_CHANGE_MARK_VALUE_IDENTICAL = AssemblyPropertyConstants.PROPERTY_ERROR_CHANGE_MARK_VALUE_IDENTICAL;

	/**
	 * Construction
	 * 
	 * @param exceptionType
	 *            exception type
	 */
	public ClientAssemblyException() {
		super();
	}

	public ClientAssemblyException(String key) {
		super(key);
	}
	
	public ClientAssemblyException(String key, String message) {
		super(key, message);
	}
}
