package turbomeca.gamme.assembly.client;

import turbomeca.gamme.assembly.client.utils.AssemblyUtils;
import turbomeca.gamme.assembly.services.schedule.merge.AssemblyModelMergeFactory;
import turbomeca.gamme.ecran.client.AClientControllersProvider;
import turbomeca.gamme.ecran.client.AClientMain;
import turbomeca.gamme.ecran.client.config.Configuration;
import turbomeca.gamme.ecran.client.context.AContextLoader;
import turbomeca.gamme.ecran.client.context.ContextLoaderMultiEdition;
import turbomeca.gamme.ecran.client.context.ContextLoaderReader;
import turbomeca.gamme.ecran.client.context.ContextLoaderSingleEdition;
import turbomeca.gamme.ecran.client.model.IModelPostCreatorService;
import turbomeca.gamme.ecran.client.model.IModelServiceBuilder;
import turbomeca.gamme.ecran.services.common.constants.OpenMode;
import turbomeca.gamme.ecran.services.runtime.bean.ContextEditing;
import turbomeca.gamme.ecran.services.schedule.service.merge.IModelMerge;

/**
 * Main class
 * 
 * @author Sopra Group
 */
public class ClientAssembly extends AClientMain {

	/** Default Id */
	private static final long serialVersionUID = -839073717115376009L;

	@Override
	protected AClientControllersProvider createClientInterfaces() {
		ClientAssemblyControllersProvider clientInterfaces = new ClientAssemblyControllersProvider();
		clientInterfaces.load();
		return clientInterfaces;
	}

	@Override
	protected IModelServiceBuilder createModelBuilder(Configuration configuration) {
		return new ClientAssemblyModelBuilder(configuration.getConfigRange().getRangeType());
	}

	@Override
    protected IModelPostCreatorService createPostCreator() {
		return new ClientAssemblyModelPostCreator();
    }
	
	@Override
	@Deprecated //Adapt with Merger DUF
	protected AContextLoader createContextLoader(Configuration configuration) throws ClientAssemblyException {
		AContextLoader contextLoader = null;
		switch (configuration.getConfigRange().getWritingMode()) {
		case OpenMode.OPEN_MODE_READ:
			contextLoader = new ContextLoaderReader();
			break;
		case OpenMode.OPEN_MODE_EDIT:
			contextLoader = new ContextLoaderSingleEdition();
			break;
		case OpenMode.OPEN_MODE_MULTI_EDIT:
            if(Boolean.valueOf(getConfiguration().getConfigRange().isExclusiveInstance())){
				IModelMerge merger = null;
				merger = AssemblyModelMergeFactory.create(configuration.getConfigRange().getRangeType());
				if (merger == null) {
					throw new ClientAssemblyException(ClientAssemblyException.EXCEPTION_UNKNOWN_SCHEDULE);
				}
				contextLoader = new ContextLoaderMultiEdition(merger);
			}
			else{
				contextLoader = new ContextLoaderSingleEdition();
				configuration.getConfigRange().setWritingMode(OpenMode.OPEN_MODE_EDIT);
			}
            break;
		default:
			throw new ClientAssemblyException(ClientAssemblyException.EXCEPTION_UNKNOWN_SCHEDULE);
		}
		return contextLoader;
	}

	@Override
	public ClientAssemblyControllersProvider getClientsHmiInterfaces() {
		return (ClientAssemblyControllersProvider) super.getClientsHmiInterfaces();
	}

	@Override
	protected ContextEditing configureStartContextEditing(Configuration configuration) {
	    if (AssemblyUtils.isAdmin(configuration)) {
            getConfiguration().getConfigUser().setAdmin(true);
        }
		return null;
	}

	@Override
	protected String getLogFileName() {
		return "assembly";
	}
}
