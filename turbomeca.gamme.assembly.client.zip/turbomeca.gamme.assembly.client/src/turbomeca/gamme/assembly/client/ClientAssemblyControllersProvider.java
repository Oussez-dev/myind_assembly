package turbomeca.gamme.assembly.client;

import turbomeca.gamme.assembly.client.module.edition.AssemblyEditionController;
import turbomeca.gamme.assembly.client.module.electronic.notification.ElectronicNotificationController;
import turbomeca.gamme.assembly.client.module.externaltools.ExternalToolsController;
import turbomeca.gamme.assembly.client.module.informations.InformationController;
import turbomeca.gamme.assembly.client.module.instruction.InstructionController;
import turbomeca.gamme.assembly.client.module.instruction.InstructionViewController;
import turbomeca.gamme.assembly.client.module.intervention.InterventionController;
import turbomeca.gamme.assembly.client.module.io.AssemblyIOController;
import turbomeca.gamme.assembly.client.module.navigation.NavigationController;
import turbomeca.gamme.assembly.client.module.sap.CommandControllerAssembly;
import turbomeca.gamme.assembly.client.module.sap.SapController;
import turbomeca.gamme.assembly.client.module.setting.bench.SettingBenchController;
import turbomeca.gamme.assembly.services.pdf.ConverterAssemblyXMLToPdf;
import turbomeca.gamme.ecran.client.AClientControllersProvider;
import turbomeca.gamme.ecran.client.module.io.IoController;
import turbomeca.gamme.ecran.client.module.lascom.LascomController;
import turbomeca.gamme.ecran.client.module.recorder.RecorderController;
import turbomeca.gamme.ecran.client.module.sap.ADefaultCommandController;
import turbomeca.gamme.ecran.client.module.voice.VoiceController;
import turbomeca.gamme.ecran.services.common.utils.pdf.ConverterXMLToPdfFactory;

/**
 * JavaScript interfaces manager
 * 
 * @author Sopra Group
 *
 */
public class ClientAssemblyControllersProvider extends AClientControllersProvider {

	/** Interface identifiers */

	public static final int INTERFACE_IO = 0;
	public static final int INTERFACE_NOTIFICATION = 1;
	public static final int INTERFACE_INTERVENTION = 2;
	public static final int INTERFACE_EDITION = 3;
	public static final int INTERFACE_SAP = 4;
	public static final int INTERFACE_INSTRUCTION = 5;
	public static final int INTERFACE_INFORMATION = 6;
	public static final int INTERFACE_TOOLS = 7;
	public static final int INTERFACE_SAP_COMMANDS = 8;
	public static final int INTERFACE_LASCOM = 9;
	public static final int INTERFACE_RECORD = 10;
	public static final int INTERFACE_INSTRUCTION_VIEW = 11;
	public static final int INTERFACE_NAVIGATION = 12;
	public static final int INTERFACE_SETTING_BENCH = 13;
	public static final int INTERFACE_VOICE = 14;
    
    /**
     * Constructor
     */
    public ClientAssemblyControllersProvider() {
        super();
    }
    
	public void load() {
	    IoController ioController = new AssemblyIOController(this);
		ioController.setConverterXmlToPdfFactory(new ConverterXMLToPdfFactory(ConverterAssemblyXMLToPdf.class));
        addController(INTERFACE_IO, ioController);
        addController(INTERFACE_NOTIFICATION, new ElectronicNotificationController(this));
        addController(INTERFACE_INTERVENTION, new InterventionController(this));
        addController(INTERFACE_EDITION, new AssemblyEditionController(this));
        addController(INTERFACE_SAP, new SapController(this));
        addController(INTERFACE_INSTRUCTION, new InstructionController(this));
        addController(INTERFACE_INFORMATION, new InformationController(this));
        addController(INTERFACE_TOOLS, new ExternalToolsController(this));
        addController(INTERFACE_SAP_COMMANDS, new CommandControllerAssembly(this));
        addController(INTERFACE_LASCOM, new LascomController(this));
        addController(INTERFACE_RECORD, new RecorderController(this));
        addController(INTERFACE_INSTRUCTION_VIEW, new InstructionViewController(this));
        addController(INTERFACE_NAVIGATION, new NavigationController(this));
        addController(INTERFACE_SETTING_BENCH, new SettingBenchController(this));
        addController(INTERFACE_VOICE, new VoiceController(this));
    }
    
	@Override
    public IoController getIoHmiInterface() {
    	return (IoController) getController(INTERFACE_IO);
    }
    
    public ElectronicNotificationController getElectronicNotificationHmiInterface() {
        return (ElectronicNotificationController) getController(INTERFACE_NOTIFICATION);
    }
    
    @Override
	public InstructionController getInstructionHmiInterface() {
        return (InstructionController) getController(INTERFACE_INSTRUCTION);
    }
    
    public SapController getSapController() {
    	return (SapController) getController(INTERFACE_SAP);
    }
    
    public InformationController getInformationHmiInterface() {
        return (InformationController) getController(INTERFACE_INFORMATION);
    }
    
    public InterventionController getInterventionHmiInterface() {
        return (InterventionController) getController(INTERFACE_INTERVENTION);
    }
    
    public ExternalToolsController getToolsHmiInterface() {
        return (ExternalToolsController) getController(INTERFACE_TOOLS);
    }
    
    public ADefaultCommandController getSapHmiInterface() {
        return (ADefaultCommandController) getController(INTERFACE_SAP_COMMANDS);
    }
    
    public AssemblyEditionController getEditionHmiInterface() {
        return (AssemblyEditionController) getController(INTERFACE_EDITION);
    }
    
    public LascomController getLascomInterface() {
        return (LascomController) getController(INTERFACE_LASCOM);
    }
    
    @Override
    public RecorderController getRecordHmiInterface() {
        return (RecorderController) getController(INTERFACE_RECORD);
    }
    
    public InstructionViewController getInstructionViewHmiInterface() {
    	return (InstructionViewController) getController(INTERFACE_INSTRUCTION_VIEW);
    }
    
    public NavigationController getNavigationHmiInterface() {
    	return (NavigationController) getController(INTERFACE_NAVIGATION);
    }
    
    public SettingBenchController getSettingBenchHmiInterface() {
    	return (SettingBenchController) getController(INTERFACE_SETTING_BENCH);
    }
        
    @Override
	public VoiceController getVoiceHmiInterface() {
    	return (VoiceController) getController(INTERFACE_VOICE);
    }
    
    
}
