package turbomeca.gamme.assembly.client.engine;

import turbomeca.gamme.ecran.client.engine.AModelServiceEngineConfig;

public class EngineConfigAssembly extends AModelServiceEngineConfig {

	@Override
	public String getNextDomain(String domain) {
		return null;
	}
}
