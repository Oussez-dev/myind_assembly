package turbomeca.gamme.assembly.client;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.services.pdf.ConverterAssemblyXMLToPdf;
import turbomeca.gamme.ecran.client.AClientPdfRecovery;
import turbomeca.gamme.ecran.services.common.utils.pdf.AConverterXMLToPdf;

public class ClientAssemblyPdfRecovery extends AClientPdfRecovery {

	private static Logger logger = Logger.getLogger(ClientAssemblyPdfRecovery.class);
	
	private static final long serialVersionUID = 8481389166904882418L;

	@Override
	public AConverterXMLToPdf createConverterXMLToPdf() {
		logger.info("Create converter");
		return new ConverterAssemblyXMLToPdf();
	}
}
