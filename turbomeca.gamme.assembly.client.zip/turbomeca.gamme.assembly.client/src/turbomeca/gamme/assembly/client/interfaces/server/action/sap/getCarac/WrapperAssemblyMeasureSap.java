package turbomeca.gamme.assembly.client.interfaces.server.action.sap.getCarac;

import turbomeca.gamme.assembly.services.model.data.CaracDef;
import turbomeca.gamme.assembly.services.model.data.MeasureSap;
import turbomeca.gamme.ecran.client.interfaces.server.sap.mapper.IWrapperMeasureSap;

public class WrapperAssemblyMeasureSap implements IWrapperMeasureSap {

	private MeasureSap measureSap;
	
	public  WrapperAssemblyMeasureSap (MeasureSap measure) {
		setMeasureSap(measure);
	}

	@Override
	public String getCaracDefPN(String pn) {
		String caracValue = null;
		for(CaracDef  carac :getMeasureSap().getCaracDef()){
    		if(carac.getPN().equals(pn)){
    			caracValue = carac.getName();
    		}
		}
		return caracValue;
	}

	@Override
	public String getSn() {
		return getMeasureSap().getSN().getTaskAction().getInputAction().getInputValue().getValue();
	}

	@Override
	public String getPn() {
		return getMeasureSap().getPN().getTaskAction().getInputAction().getInputValue().getValue();
	}

	/**
	 * @param measureSap the measureSap to set
	 */
	public void setMeasureSap(MeasureSap measureSap) {
		this.measureSap = measureSap;
	}

	/**
	 * @return the measureSap
	 */
	public MeasureSap getMeasureSap() {
		return measureSap;
	}
	
}
