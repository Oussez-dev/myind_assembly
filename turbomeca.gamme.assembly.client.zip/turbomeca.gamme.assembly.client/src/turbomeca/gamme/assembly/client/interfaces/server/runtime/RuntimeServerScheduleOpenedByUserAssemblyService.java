package turbomeca.gamme.assembly.client.interfaces.server.runtime;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.interfaces.server.runtime.action.ServerInterfaceScheduleOpenedByUserAssembly;
import turbomeca.gamme.ecran.client.interfaces.server.AServerInterfaceService;
import turbomeca.gamme.ecran.client.interfaces.server.runtime.action.ServerInterfaceScheduleOpenedByUser;

public class RuntimeServerScheduleOpenedByUserAssemblyService extends AServerInterfaceService {

	/** Logger */
	private static Logger logger = Logger.getLogger(RuntimeServerScheduleOpenedByUserAssemblyService.class);
	
	private static RuntimeServerScheduleOpenedByUserAssemblyService instance;
	
	public static RuntimeServerScheduleOpenedByUserAssemblyService getInstance() {
		if(instance == null) {
			instance = new RuntimeServerScheduleOpenedByUserAssemblyService();
		}
		
		return instance;
	}
	
	/**
	 * Returns if user opens the schedule for the first time using
	 * ScheduleOpenedByUserService webservice.
	 * 
	 * @return
	 */
	public boolean isScheduleFirstOpening() {
		
		ServerInterfaceScheduleOpenedByUser service = new ServerInterfaceScheduleOpenedByUserAssembly();
		boolean success = getRunner().run(service);
		
		if(success == false) {
			logger.error("Calling scheduleOpenedByUserAssembly WebService failed: we consider the schedule was not already opened by user !");
			return true;
		}
		
		return service.getFirstOpeningResult();
	}
}
