package turbomeca.gamme.assembly.client.interfaces.server.runtime.action;

import java.net.MalformedURLException;
import java.rmi.RemoteException;

import turbomeca.gamme.assembly.client.model.edit.schedule.AAssemblyScheduleService;
import turbomeca.gamme.ecran.client.interfaces.server.runtime.action.ServerInterfaceScheduleOpenedByUser;

public class ServerInterfaceScheduleOpenedByUserAssembly extends ServerInterfaceScheduleOpenedByUser {

	@Override
	public boolean execute() throws RemoteException, IllegalAccessException, MalformedURLException {
		
		boolean success = false;
		
		String userLogin = getContext().getContextUser().getLogin();
		String schedule = getContext().getContextRange().getRange();
		AAssemblyScheduleService scheduleService = (AAssemblyScheduleService) getModelProvider().getModelScheduleService();
		String scheduleVersion = scheduleService.getVersion(false);
		
		// Check schedule is opened for the first time and register the event if needed (careful, result boolean is inverted)
		Boolean result = getScheduleOpenedByUserService().registerScheduleIsOpenedByUser(userLogin, schedule, scheduleVersion);
		
		if(result == null) {
			success = false;
		} else {
			isFirstOpening = !result;
			success = true;
		}
		
		return success;
	}
}
