package turbomeca.gamme.assembly.client.interfaces.server.action.sap.getCarac;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;

import turbomeca.gamme.assembly.services.model.data.MeasureSap;
import turbomeca.gamme.ecran.client.interfaces.server.sap.action.ServerInterfaceGetCaract;
import turbomeca.gamme.ecran.client.interfaces.server.sap.mapper.IWrapperMeasureSap;
import turbomeca.gamme.ecran.services.common.exceptions.ServerInterfaceException;

public class ServerInterfaceAssemblyGetCaract extends ServerInterfaceGetCaract {
	
	/** */
	private DataCaracSap configCaracSap;
	
	public ServerInterfaceAssemblyGetCaract(List<MeasureSap> measureSap) {
	    super(buildWrapperMeasureSap(measureSap));
	    setConfigCaracSap(new DataCaracSap(measureSap));
	}
	
	@Override
	public boolean execute() throws RemoteException, IllegalAccessException, ServerInterfaceException {
		super.execute();
		configCaracSap.setResponse(getResponseCarac());
		return true;
	}

    /**
     * @param configCaracSap the configCaracSap to set
     */
    public void setConfigCaracSap(DataCaracSap configCaracSap) {
        this.configCaracSap = configCaracSap;
    }

    /**
     * @return the configCaracSap
     */
    public DataCaracSap getConfigCaracSap() {
        return configCaracSap;
    }
    
    private static List<IWrapperMeasureSap> buildWrapperMeasureSap(List<MeasureSap> measuresSap) {
    	List<IWrapperMeasureSap> wrapperSap = new ArrayList<IWrapperMeasureSap>();
    	for(MeasureSap currentSap : measuresSap ){
    		WrapperAssemblyMeasureSap wrapper = new WrapperAssemblyMeasureSap(currentSap);
    		wrapperSap.add(wrapper);
    	}
		return wrapperSap;
    }
}
