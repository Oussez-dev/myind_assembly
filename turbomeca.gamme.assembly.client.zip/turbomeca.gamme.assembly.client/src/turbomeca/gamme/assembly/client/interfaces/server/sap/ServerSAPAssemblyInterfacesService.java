package turbomeca.gamme.assembly.client.interfaces.server.sap;

import java.util.List;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.interfaces.server.action.sap.getCarac.DataCaracSap;
import turbomeca.gamme.assembly.client.interfaces.server.action.sap.getCarac.ServerInterfaceAssemblyGetCaract;
import turbomeca.gamme.assembly.services.model.data.MeasureSap;
import turbomeca.gamme.ecran.client.interfaces.server.sap.AServerSAPInterfacesService;
import turbomeca.gamme.ecran.client.interfaces.server.sap.action.ServerInterfaceGetContextBridge;
import turbomeca.gamme.ecran.client.interfaces.server.sap.mapper.DataResponseMappedMaterialsMarks;
import turbomeca.gamme.ecran.client.interfaces.server.sap.mapper.MapperBuilderSAP;
import turbomeca.gamme.ecran.server.ws.sap.client.interfaces.getContext.Z_WS_EXTRACT_UFIStub.ZTT_AFFAIRE_ERR;

public class ServerSAPAssemblyInterfacesService extends AServerSAPInterfacesService { 

	private static Logger logger = Logger.getLogger(ServerSAPAssemblyInterfacesService.class);

	/** Singleton instance */
	private static ServerSAPAssemblyInterfacesService instance;

	/**
	 * Singleton
	 * 
	 * @return instance
	 */
	public static ServerSAPAssemblyInterfacesService getInstance() {
		if (instance == null) {
			instance = new ServerSAPAssemblyInterfacesService();
		}
		return instance;
	}

	/***
	 * Override method link with assembly model
	 * @param measureSap
	 * @return
	 */
	public DataCaracSap getCaract(List<MeasureSap> measureSap) {
		DataCaracSap dataCaracSap = null;
		if (isInterfaceEnabled()) {
			ServerInterfaceAssemblyGetCaract getCaractInterface = new ServerInterfaceAssemblyGetCaract(measureSap);	
			getRunner().run(getCaractInterface);
			dataCaracSap = getCaractInterface.getConfigCaracSap();
		}
		return dataCaracSap;
	}

	/**
	 * 
	 * 
	 * @param affair
	 * @param material
	 * @param pn 
	 * @param subOfficialRangeName 
	 * @return null when web service response holds an error status
	 */
	public DataResponseMappedMaterialsMarks getContextFromBridge(String affair, String material, String pn, String subOfficialRangeName) {
		DataResponseMappedMaterialsMarks mappedResponseExtractUfi = null;
		if (isInterfaceEnabled()) {
			ServerInterfaceGetContextBridge getContextInterface = new ServerInterfaceGetContextBridge(affair, material);
			if (getRunner().run(getContextInterface) && !hasErrorsReturnedByBridgeSap(getContextInterface.getSapContext().getIT_AFFAIRE_ERR())) {
				mappedResponseExtractUfi = new DataResponseMappedMaterialsMarks();
				MapperBuilderSAP.convertResponseToConfigResultAtaPnSnDerog(getContextInterface.getSapContext(),
						mappedResponseExtractUfi, material, pn, subOfficialRangeName);
			}
		}
		return mappedResponseExtractUfi;
	}

	private boolean hasErrorsReturnedByBridgeSap (ZTT_AFFAIRE_ERR ztt_AFFAIRE_ERR) {
		boolean foundErrors = false;
		if(ztt_AFFAIRE_ERR != null && ztt_AFFAIRE_ERR.getItem() !=null && ztt_AFFAIRE_ERR.getItem().length >0 ) {
			for(turbomeca.gamme.ecran.server.ws.sap.client.interfaces.getContext.Z_WS_EXTRACT_UFIStub.ZTS_AFFAIRE_ERR currentErrors : ztt_AFFAIRE_ERR.getItem()) {
				if(currentErrors.getZTY_MESSAGE().getChar1().equals("E") || currentErrors.getZTY_MESSAGE().getChar1().equals("A")) {
					logger.error(" analyzeErrorFromWsSap - " + currentErrors.getZCD_MESSAGE().getNumeric3());
					foundErrors = true;
					break;
				}
			}
		}
		return foundErrors;
	}
}
