package turbomeca.gamme.assembly.client.interfaces.server.action.sap.getCarac;

import java.util.List;
import java.util.Map;

import turbomeca.gamme.assembly.services.model.data.MeasureSap;
import turbomeca.gamme.ecran.client.module.externaltools.config.ConfigurationMeasure;

public class DataCaracSap extends ConfigurationMeasure {
	
	private List<MeasureSap>  currentMeasure;
	
	private Map<String,String> response;
	
	public DataCaracSap(List<MeasureSap> measureSap) {
		super("Sap");
		setCurrentMeasure(measureSap);
	}
	
	public Map<String,String> getResponse() {
		return response;
	}
	
	public String getDataValue() {
		String data = null;
		if(getResponse()!=null){
			data=getResponse().get(0);
		}
		return data;
	}

	public void setResponse(Map<String, String> response) {
		this.response = response;
	}

	public List<MeasureSap> getCurrentMeasure() {
		return currentMeasure;
	}

	public void setCurrentMeasure(List<MeasureSap> currentMeasure) {
		this.currentMeasure = currentMeasure;
	}
}
