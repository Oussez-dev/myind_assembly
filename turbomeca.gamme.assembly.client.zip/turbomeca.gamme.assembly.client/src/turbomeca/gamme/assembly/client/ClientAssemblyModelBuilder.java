package turbomeca.gamme.assembly.client;

import turbomeca.gamme.assembly.client.context.AssemblyContext;
import turbomeca.gamme.assembly.client.model.edit.factory.ModelScheduleServiceFactory;
import turbomeca.gamme.assembly.client.model.edit.schedule.AAssemblyScheduleService;
import turbomeca.gamme.assembly.services.model.data.Instanciation;
import turbomeca.gamme.assembly.services.model.data.types.StatusType;
import turbomeca.gamme.ecran.client.AClientInstancesProvider;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.IModelServiceBuilder;
import turbomeca.gamme.ecran.services.common.bean.ContextConfig;
import turbomeca.gamme.ecran.services.common.constants.OpenMode;
import turbomeca.gamme.ecran.services.common.utils.misc.FormatUtils;
import turbomeca.gamme.ecran.services.runtime.bean.ContextApplicabilities;
import turbomeca.gamme.ecran.services.schedule.constants.Globals;

public class ClientAssemblyModelBuilder extends AClientInstancesProvider implements IModelServiceBuilder {

    /** Schedule model service */
    private AAssemblyScheduleService scheduleService;

    private static final String TOKEN_VERSION = "@version@"; 
    /**
     * Constructor
     * 
     * @param rangeType
     */
    public ClientAssemblyModelBuilder(int rangeType) {
        scheduleService = ModelScheduleServiceFactory.create(rangeType);
        getModelProvider().addModelService(scheduleService.getIdentifier(), scheduleService);
        getModelProvider().setObjectClass(getModelClass());
    }

    @Override
    public boolean build() throws ClientException, ClientInterruption {
        scheduleService.setSchedule(getModelProvider().getObject());
        scheduleService.getXmlSourceProvider().setXmlSource(getContext().getContextRange().getRange());
        
        // Build images and contexts for web service communications
        buildContext();
        
        // Load all instructions services
        scheduleService.getLoaderService().load(getModelProvider());
        
        // Re-initialize status in writing Mode
        if (getConfiguration().getConfigRange().getWritingMode() == OpenMode.OPEN_MODE_MULTI_EDIT
                && scheduleService.getStatusService().getStatus().equals(StatusType.DONE.value())) {
            scheduleService.getStatusService().updateActivity(false, false, null);
        }

        return true;
    }

    private void buildContext() {
        
        // Get schedule identification and save it to context
        String name = scheduleService.getOfficialRangeName() + "/"
                + scheduleService.getSubOfficialRangeName();
        String family = scheduleService.getWrapperService().getIdentification().getFamily();
        String variant = scheduleService.getWrapperService().getInstantiation().getVariant();
        String version = scheduleService.getVersion(getConfiguration().getConfigRange().getConfigIndex() == 0);
        String material = scheduleService.getWrapperService().getIdentification().getMaterial();
        String suffix = scheduleService.getWrapperService().getSuffix();
       
        // Patch waiting re-factoring with evaluation
        String pathImage = String.format(getContext().getContextConfig().getImagePath(), name, family.toLowerCase(), version.toLowerCase());
        String urlImage = String.format(getContext().getContextConfig().getImageUrl(), name, family.toLowerCase(), version.toLowerCase());
        
        // Build reversion schedule image path
        setReverseScheduleIdentification(material, family);
        
        // Build real image patch (with contextConfig override)
        getContext().setScheduleIdentification(name, material, family, variant, version, suffix);
        getContext().getContextRange().setContext(scheduleService.getName());
        getContext().getContextRange().setType(scheduleService.getWrapperService().getInstantiation().getContext());
        getContext().getContextRange().setOrder(scheduleService.getWrapperService().getInstantiation().getOrder());
        
        
        
        pathImage += "/" + material;
        urlImage += "/" + material;
        
        if (suffix != null && suffix != "") {
        	pathImage += "/" + suffix;
        	urlImage += "/" + suffix;
        }
        
        pathImage += "/" + Globals.GENERIC_FOLDER;
        urlImage += "/" + Globals.GENERIC_FOLDER;
        
        getContext().getContextConfig().setImageUrl(urlImage);
        getContext().getContextConfig().setImagePath(pathImage);
        getContext().getContextConfig().setExternalImageUrl(pathImage);

        // Build applicability context (used for external schedule instanciation)
        Instanciation instantiation = scheduleService.getWrapperService().getInstantiation();
        ContextApplicabilities contextApp = getContext().getContextApplicabilities();
        contextApp.setLanguage(instantiation.getLanguage());
        contextApp.setSite(getContext().getContextUser().getWorkingSite());
        contextApp.setMaterial(material);
        contextApp.setInstances(String.valueOf(instantiation.getInstances()));
        contextApp.setVersion(version);
        contextApp.setPartNumber(instantiation.getPn());
        contextApp.setModifications(FormatUtils.getStringValues(instantiation.getModifications().getModification(), " "));
        contextApp.setArticles(instantiation.getArticle());
        contextApp.setContext(instantiation.getContext());
        contextApp.setInterventionType(instantiation.getInterventionType());
        contextApp.setVariant(instantiation.getVariant());
        contextApp.setSite(instantiation.getSite());
        contextApp.setLevels(FormatUtils.getStringValues(instantiation.getLevel(), " "));
        contextApp.setMethod(instantiation.getMethod());
        contextApp.setEffectivity(instantiation.getEffectivity());
        contextApp.setOrder(instantiation.getOrder());
        contextApp.setAffair(instantiation.getAffair());
        contextApp.setIsolateModule(instantiation.getIsolatedModule());
        contextApp.setFictiveEngine(instantiation.getFictiveEngine());
        contextApp.setFamily(family);
    }
    
    
    /**
     * 
     * @param name
     * @param family
     * @param version
     * @param status
     */
    public void setReverseScheduleIdentification(String material, String family) {
        ContextConfig contextConfig = getContext().getContextConfig();
        
        String name = scheduleService.getReverseOfficialRangeName() + "/" + scheduleService.getReverseSubOfficialRangeName();
        String urlImage = String.format(contextConfig.getImageUrl(), name, family, TOKEN_VERSION);
        if (material != null) {
            urlImage += "/" + material;
        }

        String pathImage = String.format(getContext().getContextConfig().getImagePath(), 
                name, family.toLowerCase(), TOKEN_VERSION);
        pathImage += "/" + material;
        
        AssemblyContext contextCustom = new AssemblyContext();
        contextCustom.setReverseImageUrl(urlImage);
        contextCustom.setReverseImagePath(pathImage);        
        getContext().setContextCustom(contextCustom);
    }
    
    @Override
    public Class<?> getModelClass() {
        return scheduleService.getClassModel();
    }
}
