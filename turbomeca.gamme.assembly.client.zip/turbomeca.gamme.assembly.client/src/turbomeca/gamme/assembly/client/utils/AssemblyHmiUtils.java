package turbomeca.gamme.assembly.client.utils;

import java.awt.Component;
import java.io.File;

import javax.swing.JFileChooser;
import javax.swing.LookAndFeel;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public class AssemblyHmiUtils {
	
	public static File openDialogFile(String defaultPath, String defaultFileName, String title, Component container) throws Exception{
		
		JFileChooser chooser = new JFileChooser(defaultPath);
		File file = null;
		
		LookAndFeel look = UIManager.getLookAndFeel();
		
		UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		SwingUtilities.updateComponentTreeUI(chooser);
		chooser.setSelectedFile(new File(defaultFileName));
		chooser.setDialogTitle(title);
		int retrival=chooser.showSaveDialog(container);
		if (retrival == JFileChooser.APPROVE_OPTION) {
			file = chooser.getSelectedFile();
		}
		
		UIManager.setLookAndFeel(look);
		
		return file;
	}
	
}
