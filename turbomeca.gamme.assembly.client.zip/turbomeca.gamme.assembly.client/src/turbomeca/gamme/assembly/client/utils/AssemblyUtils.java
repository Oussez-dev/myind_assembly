package turbomeca.gamme.assembly.client.utils;

import java.util.Arrays;

import turbomeca.gamme.assembly.services.constants.Constants;
import turbomeca.gamme.assembly.services.utils.RoleConstants;
import turbomeca.gamme.ecran.client.config.Configuration;
import turbomeca.gamme.ecran.services.common.bean.ContextConfig;
import turbomeca.gamme.ecran.services.common.utils.misc.FormatUtils;

public class AssemblyUtils {

	public static boolean isAdmin(Configuration configuration) {
		String[] roles = configuration.getConfigUser().getUserRoles();
		
		return FormatUtils.contains(roles, String.valueOf(Constants.ROLE_CONTROLLER_ASSEMBLY))
		|| FormatUtils.contains(roles, String.valueOf(Constants.ROLE_CONTROLLER_DISASSEMBLY))
		|| (FormatUtils.contains(roles, String.valueOf(Constants.ROLE_REDACTOR)) && (configuration
				.getConfigRange().getConfigIndex() == 1));
	}
	
	public static boolean isAdminForCloseSchedule(Configuration configuration, ContextConfig contextConfig) {
		String[] roles = configuration.getConfigUser().getUserRoles();
		
		if(contextConfig.getRoleToCloseSchedule() != null) {
			if(!contextConfig.getRoleToCloseSchedule().equals("")) {
				String[] authorizedRole = RoleConstants.getCodeFromLibelle(contextConfig.getRoleToCloseSchedule().toUpperCase().replace(" ", "").split(","));
				for (String role : roles) {
					if(Arrays.asList(authorizedRole).contains(role)) {
						return true;
					}
				}
			}
			//Si la clé de conf est vide on autorise tous les profils
			else {
				return true;
			}
		}
		
		return false;
	}
	
	public static boolean isRedactorContext(Configuration configuration) {
		String[] roles = configuration.getConfigUser().getUserRoles();
		return (FormatUtils.contains(roles, String.valueOf(Constants.ROLE_REDACTOR)) && (configuration
				.getConfigRange().getConfigIndex() == 1));
	}
}
