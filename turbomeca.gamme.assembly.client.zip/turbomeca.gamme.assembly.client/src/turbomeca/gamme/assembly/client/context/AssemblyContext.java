package turbomeca.gamme.assembly.client.context;

import turbomeca.gamme.ecran.client.context.ContextCustom;

public class AssemblyContext extends ContextCustom {

    private static final String PROPERTY_REVERSE_IMAGE_URL = "reverseRangeImageUrl";
    
    private String reverseImageUrl;
    private String reverseImagePath;
    
    /**
     * @return the reverseImageUrl
     */
    public String getReverseImageUrl() {
        return reverseImageUrl;
    }
    /**
     * @param reverseImageUrl the reverseImageUrl to set
     */
    public void setReverseImageUrl(String reverseImageUrl) {
        this.reverseImageUrl = reverseImageUrl;
    }
    /**
     * @return the reverseImagePath
     */
    public String getReverseImagePath() {
        return reverseImagePath;
    }
    /**
     * @param reverseImagePath the reverseImagePath to set
     */
    public void setReverseImagePath(String reverseImagePath) {
        this.reverseImagePath = reverseImagePath;
        addPdfParameter(PROPERTY_REVERSE_IMAGE_URL, reverseImagePath);
    }
}
