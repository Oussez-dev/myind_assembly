package turbomeca.gamme.assembly.client.config;

public class AssemblyPropertyConstants {
	
	
	/** Property key message */
	public static final String PROPERTY_MARK_CHANGED = "mark.changed";
    
	/** Property key error */
	public static final String PROPERTY_ERROR_CHANGE_LEVEL_IN_PROGRESS = "error.levelChange.isInProgress";
	public static final String PROPERTY_ERROR_CHANGE_LEVEL_REFERENCES = "error.levelChange.references.not.valid";
	public static final String PROPERTY_INFO_SAME_LEVEL = "info.levelChange.same";
	public static final String PROPERTY_ERROR_CHANGE_LEVEL_PREDECESSORS = "error.levelChange.predecessor";
	public static final String PROPERTY_ERROR_CHANGE_LEVEL_MISSING_COMMENT = "error.levelChange.missingComment";
	public static final String PROPERTY_ERROR_INPUT_RESOURCES_NOT_FINISHED = "error.input.resources.not.finished";
	public static final String PROPERTY_ERROR_CHANGE_MARK_VALUE_EMPTY = "error.change.mark.empty.value";
	public static final String PROPERTY_ERROR_CHANGE_MARK_VALUE_IDENTICAL = "error.change.mark.identical.value";
	public static final String PROPERTY_ERROR_FAILED_TO_RETRIEVE_ASSEMBLY_SCHEDULE = "error.schedule.assembly.schedule";
	public static final String PROPERTY_ERROR_FAILED_TO_RETRIEVE_DISASSEMBLY_SCHEDULE = "error.schedule.disassembly.schedule";
	public static final String PROPERTY_INFO_PN_DEROGATION_REQUIRED = "info.sn.derogation.required";
	public static final String PROPERTY_INFO_DEROGATION_MARK_ALREADY_EXIST = "info.derogation.mark.already.exist";
	public static final String PROPERTY_INFO_NEW_PASSING_MISSING = "info.new.passing.missing";
	public static final String PROPERTY_ERROR_DEFINITION_TASK = "error.definition.task";
	
	/** Property modal title */
	public static final String PROPERTY_MODAL_TITLE_SELECT_LEVEL = "modal.title.select.level";
	public static final String PROPERTY_MODAL_TITLE_SELECT_MANUAL_INSTRUCTION_LEVEL = "modal.title.select.manual.instruction.level";
	public static final String PROPERTY_MODAL_TITLE_CHANGE_MARK = "modal.title.change.mark";
	public static final String PROPERTY_MODAL_TITLE_DEROGATION_MARK = "modal.title.derogation.mark";
    public static final String PROPERTY_MODAL_TITLE_SCHEDULE_COMPOUNDS = "modal.title.compounds";
    public static final String PROPERTY_MODAL_TITLE_DIRTY_VIEW = "modal.title.dirty.view";
    public static final String PROPERTY_MODAL_TITLE_OBSERVATIONS = "modal.title.observations";
	public static final String PROPERTY_MODAL_TITLE_SAP_SYNTHESIS = "modal.title.sap.synthesis";

	public static final String PROPERTY_RANGE_SAP_UPDATING = "range.sap.updating";
    public static final String PROPERTY_RANGE_SAP_UPDATED = "range.sap.updated";

	/** SAP messages */
    public static final String PROPERTY_ERROR_SAP_COMMUNICATION = "error.sap.communication";

	public static final String PROPERTY_INFO_STOP_PILOTING_TOOL = "info.stop.piloting.tool";


	
}
