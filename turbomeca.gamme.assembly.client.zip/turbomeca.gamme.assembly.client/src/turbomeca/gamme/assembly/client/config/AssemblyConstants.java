package turbomeca.gamme.assembly.client.config;

public class AssemblyConstants {
	
	public static final String EXTENSION_XML = ".xml";

	/** Default digit precision for user input */
	public static final int DEFAULT_DIGIT_PRECISION = 3;
	
	/** */
	public static final int REQUEST_TYPE_REWORK = 100;
	
	/** range type */
	public static final String ASSEMBLY = "assembly";
	public static final String ASSEMBLY_NEW = "assembly_new";
	public static final String ASSEMBLY_REPAIRED = "assembly_repaired";
	public static final String DISASSEMBLY = "disassembly";

}
