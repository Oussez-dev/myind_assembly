package turbomeca.gamme.assembly.client.config;

import turbomeca.gamme.assembly.services.constants.Constants;


public class AssemblyRoleConstants {

	public final static String ROLE_CONSULT_LABEL = "ROLE_CONSULT";
	public final static String ROLE_OPERATOR_ASSEMBLY_LABEL = "ROLE_OPERATOR_ASSEMBLY";
	public final static String ROLE_OPERATOR_DISASSEMBLY_LABEL = "ROLE_OPERATOR_DISASSEMBLY";
	public final static String ROLE_CONTROLLER_ASSEMBLY_LABEL = "ROLE_CONTROLLER_ASSEMBLY";
	public final static String ROLE_CONTROLLER_DISASSEMBLY_LABEL = "ROLE_CONTROLLER_DISASSEMBLY";
	public final static String ROLE_REDACTOR_LABEL = "ROLE_REDACTOR";
	public final static String ROLE_ADMIN_LABEL = "ROLE_ADMIN";
	public final static String ROLE_ADMIN_USER_LABEL = "ROLE_ADMIN_USER";
	public final static String ROLE_NOTIFICATION_QUALITY_LABEL = "ROLE_NOTIFICATION_QUALITY";
	public final static String ROLE_NOTIFICATION_METHOD_LABEL = "ROLE_NOTIFICATION_METHOD";
	public final static String ROLE_OPERATOR_ASSEMBLY_ST_LABEL = "ROLE_OPERATOR_ASSEMBLY_ST";
	public final static String ROLE_OPERATOR_DISASSEMBLY_ST_LABEL = "ROLE_OPERATOR_DISASSEMBLY_ST";
	
	public static String mapRoleFromKey(int key) {

		String role = null;
		switch (key) {
		case Constants.ROLE_CONSULT:
			role = "ROLE_CONSULT";
			break;
		case Constants.ROLE_OPERATOR_ASSEMBLY:
			role = "ROLE_OPERATOR_ASSEMBLY";
			break;
		case Constants.ROLE_OPERATOR_DISASSEMBLY:
			role = "ROLE_OPERATOR_DISASSEMBLY";
			break;
		case Constants.ROLE_CONTROLLER_ASSEMBLY:
			role = "ROLE_CONTROLLER_ASSEMBLY";
			break;
		case Constants.ROLE_CONTROLLER_DISASSEMBLY:
			role = "ROLE_CONTROLLER_DISASSEMBLY";
			break;
		case Constants.ROLE_REDACTOR:
			role = "ROLE_REDACTOR";
			break;
		case Constants.ROLE_ADMIN:
			role = "ROLE_ADMIN";
			break;
		case Constants.ROLE_ADMIN_USER:
			role = "ROLE_ADMIN_USER";
			break;
		case Constants.ROLE_NOTIFICATION_QUALITY:
			role = "ROLE_NOTIFICATION_QUALITY";
			break;
		case Constants.ROLE_NOTIFICATION_METHOD:
			role = "ROLE_NOTIFICATION_METHOD";
			break;
		case Constants.ROLE_OPERATOR_ASSEMBLY_ST:
			role = "ROLE_OPERATOR_ASSEMBLY_ST";
			break;
		case Constants.ROLE_OPERATOR_DISASSEMBLY_ST:
			role = "ROLE_OPERATOR_DISASSEMBLY_ST";
			break;
		}
		return role;
	}
}
