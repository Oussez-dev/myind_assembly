package turbomeca.gamme.assembly.client.module.sap.action.comparator;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.config.AssemblyConstants;
import turbomeca.gamme.assembly.client.model.edit.schedule.AAssemblyScheduleService;
import turbomeca.gamme.assembly.services.model.data.Identification;
import turbomeca.gamme.assembly.services.model.data.Instanciation;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.client.module.sap.ASapController;
import turbomeca.gamme.ecran.client.module.sap.SapAnalyse;
import turbomeca.gamme.ecran.client.module.sap.action.ASapComparatorAction;
import turbomeca.gamme.ecran.server.ws.sap.client.model.ASapContext;
import turbomeca.gamme.ecran.server.ws.sap.client.model.ExtractUfi.SapExtractUFIResponseContext;

public abstract class AActionScheduleComparator extends ASapComparatorAction {
	
	/** logger for current class */
	private static Logger logger = Logger.getLogger(AActionScheduleComparator.class);


	@Override
	protected List<SapAnalyse> compare(ASapController sapController) {
		List<SapAnalyse> result = new ArrayList<SapAnalyse>();

		AAssemblyScheduleService scheduleService = (AAssemblyScheduleService) getModelProvider()
				.getModelScheduleService();

		Instanciation instanciation = scheduleService.getWrapperService().getInstantiation();
		Identification identification = scheduleService.getWrapperService().getIdentification();
		

		if (isAssemblyRepaired() || isDisassembly()) {
			SapExtractUFIResponseContext sapContext = null;
			try {
				sapContext = sapController.getSapContextLoader().loadExtractUfi(instanciation.getAffair(), "", !sapController.isForceUpdate());
			} catch (Exception e) {
				logger.error("[SAP] Error during load extract ufi from sap " + e.getMessage());
			}

			if (sapContext != null) {
				result.addAll(compare(instanciation, identification, sapContext));
			}
		}
		return result;
	}

	protected abstract List<SapAnalyse> compare(Instanciation instanciation, Identification identification,
			ASapContext<?> sapContext);

	@Override
	public boolean canRun(IController controller) {
		return isSapSchedule(controller);
	}
	
	@Override
	protected boolean isSapSchedule(IController controller) {
		boolean result = false;
		AAssemblyScheduleService scheduleService = (AAssemblyScheduleService) getModelProvider()
				.getModelScheduleService();
		if (scheduleService.getWrapperService().getParameters().getIsSapSchedule() != null) {
			result = scheduleService.getWrapperService().getParameters().getIsSapSchedule().getIsSapSchedule();
		}
		logger.debug("[SAP] Schedule is configured for sap " + Boolean.toString(result));
		return result;
	}

	protected boolean isAssemblyNew() {
		AAssemblyScheduleService scheduleService = (AAssemblyScheduleService) getModelProvider().getModelScheduleService();
		return AssemblyConstants.ASSEMBLY_NEW.equals(scheduleService.getSubOfficialRangeName());
	}

	protected boolean isAssemblyRepaired() {
		AAssemblyScheduleService scheduleService = (AAssemblyScheduleService) getModelProvider().getModelScheduleService();
		return AssemblyConstants.ASSEMBLY_REPAIRED.equals(scheduleService.getSubOfficialRangeName());
	}

	protected boolean isDisassembly() {
		AAssemblyScheduleService scheduleService = (AAssemblyScheduleService) getModelProvider().getModelScheduleService();
		return AssemblyConstants.DISASSEMBLY.equals(scheduleService.getSubOfficialRangeName());
	}

}
