package turbomeca.gamme.assembly.client.module.electronic.notification.action;

import turbomeca.gamme.assembly.client.ClientAssemblyControllersProvider;
import turbomeca.gamme.assembly.client.model.edit.instructions.AModelTaskActionService;
import turbomeca.gamme.assembly.client.model.edit.notifications.AModelNotificationService;
import turbomeca.gamme.assembly.client.model.edit.notifications.ModelNotificationNcrService;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.constants.PropertyConstants;
import turbomeca.gamme.ecran.client.model.provider.ModelXmlProvider;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.client.module.io.IoController;
import turbomeca.gamme.ecran.services.common.constants.GlobalConstants;

public class ActionCreateElectronicNotificationNcr extends AActionCreateElectronicNotification {


	/** */
	private AModelTaskActionService taskActionService;

	/**
	 * 
	 * @param taskActionService
	 */
	public ActionCreateElectronicNotificationNcr(AModelTaskActionService taskActionService) {
		setTaskActionService(taskActionService);
	}

	@Override
	public boolean run(IController controller) throws ClientException {
		boolean succeed = false;
		AModelNotificationService notificationService = new ModelNotificationNcrService(getTaskActionService());
		boolean createOnServer = createNotification(notificationService, getTaskActionService());
		String mustSynchronize = null;
		if(!createOnServer){
			mustSynchronize = GlobalConstants.NOTIFICATION_STATUS_CREATED;
		}
		notificationService.bindService(getTaskActionService(), mustSynchronize);
		getLoggerHmi().info(PropertyConstants.PROPERTY_NOTIFICATION_CREATED);
		synchronizeOnServer(false);
		getModelProvider().setModelStatus(ModelXmlProvider.MODEL_STATUS_MODIFIED);
		((IoController) controller.getControllersProvider().getController(ClientAssemblyControllersProvider.INTERFACE_IO)).actionSaveOnServer();
		succeed = true;
		return succeed;
	}

	/**
	 * @param taskActionService the taskActionService to set
	 */
	public void setTaskActionService(AModelTaskActionService taskActionService) {
		this.taskActionService = taskActionService;
	}

	/**
	 * @return the taskActionService
	 */
	public AModelTaskActionService getTaskActionService() {
		return taskActionService;
	}

}