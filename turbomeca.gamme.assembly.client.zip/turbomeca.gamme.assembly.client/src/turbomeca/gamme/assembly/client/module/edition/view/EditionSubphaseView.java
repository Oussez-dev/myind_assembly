package turbomeca.gamme.assembly.client.module.edition.view;

import turbomeca.gamme.assembly.services.constants.AssemblyXsltConstants;



public class EditionSubphaseView extends AEditionView {

	/**
	 * @param listSubphaseIdQualified 
	 * 
	 */
	public EditionSubphaseView(String listSubphaseIdQualified) {
		super(AssemblyXsltConstants.XSLT_EDITION_SUBPHASES.value(), listSubphaseIdQualified);
	}

	@Override
	public void addSpecifiParameters() {

	}
}
