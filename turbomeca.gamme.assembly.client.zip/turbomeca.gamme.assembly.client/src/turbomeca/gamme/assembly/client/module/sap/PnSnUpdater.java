package turbomeca.gamme.assembly.client.module.sap;

import turbomeca.gamme.assembly.services.model.data.Mark;
import turbomeca.gamme.assembly.services.model.data.SN;
import turbomeca.gamme.assembly.services.model.data.SubPhase;
import turbomeca.gamme.ecran.client.ClientException;

public class PnSnUpdater extends APnSnUpdater {

	@Override
	protected boolean checkMaterial(String pn, SN[] sns) throws ClientException {
		return false;
	}

	@Override
	protected boolean checkMark(Mark mark, SubPhase subPhase) throws ClientException {
		return false;
	}
	
}
