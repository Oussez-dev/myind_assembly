package turbomeca.gamme.assembly.client.module.electronic.notification.view;

import org.apache.log4j.Logger;

import turbomeca.gamme.ecran.client.module.InterfaceView;

/**
 * Abstract class for HTML view
 * 
 * @author Sopra Group
 * 
 */
public class NotificationUpdaterView extends InterfaceView {

	/** logger for current class */
	private static Logger logger = Logger.getLogger(NotificationUpdaterView.class);

	private static final String JS_INTERFACE_SET_STATUS_NOTIFICATION = "setStatusNotification";
	private static final String JS_INTERFACE_SET_STATUS_VALIDATION = "setStatusValidation";
	
	/**
	 * Constructor
	 */
	public NotificationUpdaterView() {
		super();
	}

	public void setStatusNotification(String id, String status) {
        logger.debug("setStatusNotification : [ " + id + " - " + status + " ]");
        getJsInterface().callJs(JS_INTERFACE_SET_STATUS_NOTIFICATION,
                new Object[] { String.valueOf(id), status });
    }
	
	public void setStatusValidation(String id, String status) {
        logger.debug("setStatusValidation : [ " + id + " - " + status + " ]");
        getJsInterface().callJs(JS_INTERFACE_SET_STATUS_VALIDATION,
                new Object[] { String.valueOf(id), status });
    }
}