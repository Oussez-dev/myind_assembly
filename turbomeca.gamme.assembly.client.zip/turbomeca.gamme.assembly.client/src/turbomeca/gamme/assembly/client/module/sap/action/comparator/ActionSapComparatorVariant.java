package turbomeca.gamme.assembly.client.module.sap.action.comparator;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.services.model.data.Identification;
import turbomeca.gamme.assembly.services.model.data.Instanciation;
import turbomeca.gamme.ecran.client.module.sap.SapAnalyse;
import turbomeca.gamme.ecran.server.ws.sap.client.model.ASapContext;
import turbomeca.gamme.ecran.server.ws.sap.client.model.ExtractUfi.SapExtractUFIResponseContext;
import turbomeca.gamme.ecran.server.ws.sap.client.model.ExtractUfi.SapUfiAffaireEntete;
import turbomeca.gamme.ecran.services.common.constants.GlobalConstants;


public class ActionSapComparatorVariant extends AActionScheduleComparator {

	private static Logger logger = Logger.getLogger(ActionSapComparatorVariant.class);
	
	public static final String MAP_KEY = "variant.analyse.key";
	
	@Override
	protected List<SapAnalyse> compare(Instanciation instanciation, Identification identification,
			ASapContext<?> sapContext) {
		
		logger.info("[SAP] Analyse change variant from SAP");

		SapExtractUFIResponseContext sContext = (SapExtractUFIResponseContext) sapContext;
		List<SapAnalyse> result = new ArrayList<SapAnalyse>();
		
		String variant = instanciation.getVariant();
		
		SapUfiAffaireEntete entete = sContext.getEntetes().get(0);
		String valueSap = entete != null && entete.getSapStructure() != null ? entete.getSapStructure().getZCD_FVSOR().getChar10() : null;
		int lang = instanciation.getLanguage().compareTo("FR") == 0 ? 0 : 1;
 
		String[] values = getContext().getContextConfig().getContextSAP().getFamilyVariantSap().get(valueSap);
		String value = values[lang];
		
		String variantSap = value.split(GlobalConstants.SEPARATOR_SLASH)[1];
		
		logger.debug("[SAP] ActionSapComparatorVariant, current variant is " + variant + " and sap variant is " + variantSap );
		
		if (variant.compareTo(variantSap) != 0) {
			logger.info("[SAP] Analyse Variant, actual: " + variant + " sap: "+ variantSap);
			List<String> oldValue = new ArrayList<String>();
			oldValue.add(variant);
			
			List<String> newValue = new ArrayList<String>();
			newValue.add(variantSap);
			
			SapAnalyse sapAnalyse = SapAnalyse.updateValue(newValue, oldValue);
			result.add(sapAnalyse);
		}
 		
		return result;
	}
	
	@Override
	protected String getMapKey() {
		return MAP_KEY;
	}

}
