package turbomeca.gamme.assembly.client.module.externaltools.player.measure;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskActionMeasureService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskActionService;
import turbomeca.gamme.assembly.client.module.externaltools.ExternalToolsController;
import turbomeca.gamme.assembly.client.module.externaltools.ExternalToolsView;
import turbomeca.gamme.assembly.client.module.externaltools.provider.PlayerAcquistionProvider;
import turbomeca.gamme.assembly.services.model.data.types.StatusType;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.engine.ModelServiceEngine;
import turbomeca.gamme.ecran.client.hmi.ModalManager;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.services.devices.ExternalsToolsExceptions;

public class ThreadPlayerAcquisition extends Thread {

	/** logger for current class */
	private static Logger logger = Logger.getLogger(ThreadPlayerAcquisition.class);

	private IController controller;
	private String osNumber;
	private boolean forceModeAcquistion;
	private boolean toolsAcquistion;
	private ModelTaskActionMeasureService service;
	private ModelServiceEngine engine;
	private ModelTaskActionService taskAction;
	private APlayerAcquisition playerAcquisition;
	private ExternalToolsView extToolView;

	public ThreadPlayerAcquisition(
			ModelTaskActionMeasureService taskMeasureService,
			boolean forceModeAcquistion2, boolean toolsAcquistion2,
			String osNumber2, IController controller2, ModelServiceEngine modelServiceEngine2, 
			ModelTaskActionService taskAction2) {
		service = taskMeasureService;
		osNumber = osNumber2;
		forceModeAcquistion = forceModeAcquistion2;
		toolsAcquistion = toolsAcquistion2;
		controller = controller2;
		engine = modelServiceEngine2;
		taskAction = taskAction2;
	}
		
	@Override
	public final void run() {
		try {
			ThreadPlayerAcquisitionManager.getInstance().registerPlayer(this);
			doRun();
		}
		finally {
			ThreadPlayerAcquisitionManager.getInstance().unRegisterPlayer(this);
		}
	}

	protected void doRun() {
		logger.debug("ThreadPlayerAcquisition - start Thread");
		try {
			String idService = service.getIdentifier();					
			Object toolController = null;
			if(controller instanceof ExternalToolsController){
					toolController = controller;
			}
			if(toolController != null){
				extToolView = ((ExternalToolsController) toolController).getView();
			}
			for(APlayerAcquisition acquisition : PlayerAcquistionProvider.getAcquisition(service, forceModeAcquistion, toolsAcquistion, osNumber)) {			
				ServiceType serviceType = acquisition.getServiceType();
				if(extToolView != null){
					extToolView.changePlay(idService, true, serviceType.value());
					extToolView.focusElement(idService);
				}								
				playerAcquisition = acquisition;
		
				String value = acquisition.acquire();
							
				if(extToolView != null){
					extToolView.changePlay(idService, false, serviceType.value());
				}
				
				// On ne fait rien ici en cas d'erreur d'acquisition (notifiée à la MMI lors de l'appel à acquire())
				StatusType status = playerAcquisition.getState().getStatus();
				if (!StatusType.OK.equals(status)) continue;
				
				String formattedValue = value == null ? "" : taskAction.formatValuePrecision(value);
				String previousValue = taskAction.getValue();
				String previousValueNotNull = previousValue == null ? "" : previousValue;
				
				// On ne fait rien si la nouvelle valeur est égale à l'ancienne
				if (formattedValue.equals(previousValueNotNull)) continue;
				
				// Demande de confirmation si la valeur précédente n'était pas vide
				if (!previousValueNotNull.isEmpty() && toolController instanceof ExternalToolsController) {
					logger.debug("ThreadPlayerAcquisition - Previous value not empty");
					((ExternalToolsController) toolController).actionCreateConfirmationModalView(idService, taskAction.getValue(), formattedValue);					
					String userAnswer = ModalManager.getInstance().getUserAnswer();
					if (userAnswer.isEmpty()) continue; // Si l'utilisateur refuse le remplacement, on sort
				}
				taskAction.setValue(value, true);
				break;
			}
			service.getStatusService().updateState(null, false, null, null);
			if (!service.getRunnableService().isFinished()){
				if(extToolView != null){
					extToolView.changePlay(idService, false, playerAcquisition.getServiceType().value());
				}
				throw new ClientInterruption(ClientInterruption.INTERRUPTION_INSTRUCTION_FINISHED);
			}
			else {
				engine.next(service);
			}

		} catch (ExternalsToolsExceptions e1) {
			logger.error("ThreadPlayerAcquisition - finalize", e1);
		} catch (ClientException e1) {
			logger.error("ThreadPlayerAcquisition - finalize", e1);
		} catch (ClientInterruption e1) {
			logger.error("ThreadPlayerAcquisition - finalize", e1);
		}
		try {
			finalize();
		} catch (Throwable e) {
			logger.error("ThreadPlayerAcquisition - finalize", e);
		}
	}


	@SuppressWarnings("deprecation")
	public void stopThread() {
		try {
			ThreadPlayerAcquisitionManager.getInstance().unRegisterPlayer(this);
			logger.debug("ThreadPlayerAcquisition - Stop Thread");
			
			if(playerAcquisition instanceof PlayerAcquisitionTools) {
				((PlayerAcquisitionTools)playerAcquisition).stopAcquisition();
			}
			if(extToolView != null){
				extToolView.changePlay(service.getIdentifier(), false, playerAcquisition.getServiceType().value());
			}
			//threadComm.interrupt();
			this.stop();
		} catch (Throwable e) {
			e.printStackTrace();
		}
	}
}
