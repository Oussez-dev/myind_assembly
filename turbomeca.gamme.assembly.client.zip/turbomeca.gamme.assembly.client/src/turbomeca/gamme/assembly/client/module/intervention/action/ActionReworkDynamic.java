package turbomeca.gamme.assembly.client.module.intervention.action;


import java.util.UUID;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.model.edit.IModelAssemblyWrapperScheduleService;
import turbomeca.gamme.assembly.client.module.intervention.InterventionReworkDynamicManager;
import turbomeca.gamme.assembly.services.constants.AssemblyXsltConstants;
import turbomeca.gamme.assembly.services.model.data.Operations;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.constants.PropertyConstants;
import turbomeca.gamme.ecran.client.interfaces.server.runtime.RuntimeServerInterfaceService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.services.common.utils.transformer.ModelTransformation;
import turbomeca.gamme.ecran.services.common.utils.xml.ModelXmlDaoService;
import turbomeca.gamme.ecran.services.constants.XsltConstants;

public class ActionReworkDynamic extends AActionRework {

	/** logger for current class */
	private static Logger logger = Logger.getLogger(ActionReworkDynamic.class);

	/** */
	private InterventionReworkDynamicManager reworkManager;

	/**
	 * 
	 * @param reworkManager
	 * @param operationTitle
	 * @param subPhaseTitle
	 */
	public ActionReworkDynamic(InterventionReworkDynamicManager reworkManager) {
		setReworkManager(reworkManager);
	}

	@Override
	public boolean run(IController controller) throws ClientException, ClientInterruption {
		boolean success = true;
		try {
			// Disable notification
			controller.getNotificationsService().setDisableNotifications(true);
			boolean isAlive = RuntimeServerInterfaceService.getInstance().isAlive();
			if (isAlive) {

				// Increase passing identifier
				IModelObjectService modelScheduleService = getModelProvider().getModelScheduleService();
				IModelAssemblyWrapperScheduleService wrapper = (IModelAssemblyWrapperScheduleService) modelScheduleService.getWrapperService();
				int passingId = wrapper.getPassingId() + 1;

				// Apply XSLT transformation to build new identifiers and their references
				ModelTransformation transformer = null;
				try {
					transformer = new ModelTransformation(XsltConstants.XSLT_TRANSFORM_REWORK_DYNAMIC.value());
					transformer.addParameter(AssemblyXsltConstants.XSLT_PARAMETER_PASSING_ID.value(), passingId);
					if (getReworkManager().getReverseScheduleVersion() != null) { 
						transformer.addParameter(AssemblyXsltConstants.XSLT_PARAMETER_REVERSE_SCHEDULE_VERSION.value(), getReworkManager().getReverseScheduleVersion());
					}
					transformer.addParameter(XsltConstants.XSLT_PARAMETER_OPERATION_ID.value(), "op" + UUID.randomUUID().toString());
					transformer.addParameter(XsltConstants.XSLT_PARAMETER_OPERATION_TITLE.value(), getReworkManager().getOperationTitle());
					transformer.addParameter(AssemblyXsltConstants.XSLT_PARAMETER_SUBPHASE_REVERSE.value(), getReworkManager().getSubPhaseReverseId());
					transformer.addParameter(XsltConstants.XSLT_PARAMETER_SUBPHASE_CURRENT.value(), getReworkManager().getSubPhaseCurrentId());

					String fullXmlMerged = getReworkManager().buildXmlMergedWithEditedSubPhase();
					if (!transformer.transformStringToStream(fullXmlMerged)) {
						throw new ClientException();
					}
				} catch(Exception e) {
					logger.error(e);
					throw new ClientException();
				}


				// Load XSLT transformations
				ModelXmlDaoService modelXmlDaoService = new ModelXmlDaoService();
				modelXmlDaoService.setObjectClass(Operations.class);
				if (!modelXmlDaoService.setXmlModel(transformer.getResultStream())) {
					throw new ClientException();
				}

				addReworkOperations((Operations) modelXmlDaoService.getObject(), passingId);
				(new ActionUpdateScheduleTopStartOperation()).run(controller);
				controller.getNotificationsService().setModelReload();
			}
			else{
				getLoggerHmi().error(PropertyConstants.PROPERTY_ERROR_COMMUNICATION);
				success = false;
			}

		} finally {
			controller.getNotificationsService().setDisableNotifications(false);
		}
		return success;
	}

	/**
	 * @return the reworkManager
	 */
	public InterventionReworkDynamicManager getReworkManager() {
		return reworkManager;
	}

	/**
	 * @param reworkManager the reworkManager to set
	 */
	public void setReworkManager(InterventionReworkDynamicManager reworkManager) {
		this.reworkManager = reworkManager;
	}
}