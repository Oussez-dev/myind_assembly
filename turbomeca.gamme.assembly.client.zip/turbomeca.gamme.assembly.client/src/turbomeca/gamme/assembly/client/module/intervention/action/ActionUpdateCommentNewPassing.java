package turbomeca.gamme.assembly.client.module.intervention.action;

import turbomeca.gamme.assembly.client.ClientAssemblyControllersProvider;
import turbomeca.gamme.assembly.client.model.edit.IModelAssemblyWrapperScheduleService;
import turbomeca.gamme.assembly.client.model.edit.runnable.ModelRunnableScheduleService;
import turbomeca.gamme.assembly.client.module.edition.AssemblyEditionController;
import turbomeca.gamme.assembly.services.model.data.HistoricalPassing;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.interfaces.server.editing.EditingServerInterfaceService;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.client.module.action.AActionModify;

// FIXME: This can be moved to ecran...
public class ActionUpdateCommentNewPassing extends AActionModify{


	private final String comment;


	public ActionUpdateCommentNewPassing(String newComment) {
		this.comment = newComment;
	}

	@Override
	public boolean run(IController controller) throws ClientException,
	ClientInterruption {
		boolean success = true;
		AssemblyEditionController editionController =  (AssemblyEditionController) controller.getControllersProvider().
				getController(ClientAssemblyControllersProvider.INTERFACE_EDITION);
		EditingServerInterfaceService.getInstance().loadEditing();

		if(((ModelRunnableScheduleService) getModelProvider().getModelScheduleService().getRunnableService()).
				canRunForMultiEdition(editionController, getContext().getContextEditing().isOutOfDate())){

			IModelAssemblyWrapperScheduleService wrapper = (IModelAssemblyWrapperScheduleService) getModelProvider().getModelScheduleService().getWrapperService();
			wrapper.updateHistoricalPassing(((HistoricalPassing)wrapper.getHistoricalPassing()).getPassingCount(), getComment());
		}
		else{
			success = false;
		}
		return success;
	}

	public String getComment() {
		return comment;
	}


}
