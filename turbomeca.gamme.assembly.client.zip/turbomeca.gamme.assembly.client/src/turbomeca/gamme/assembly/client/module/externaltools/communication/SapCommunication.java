package turbomeca.gamme.assembly.client.module.externaltools.communication;

import java.util.Map;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.interfaces.server.action.sap.getCarac.DataCaracSap;
import turbomeca.gamme.assembly.client.interfaces.server.sap.ServerSAPAssemblyInterfacesService;

public abstract class SapCommunication {
	
	private static Logger logger = Logger.getLogger(SapCommunication.class);
	
	private ServerSAPAssemblyInterfacesService serverSap;
	
	private DataCaracSap configurationSap;
	
	public void init(DataCaracSap configCarac) {
		logger.debug("[PILOTING] : Init Configuration Measure SAP");
		serverSap =  ServerSAPAssemblyInterfacesService.getInstance();
		setConfigCarac(configCarac);
	}
	
	public abstract String getData();

	public abstract void execute() throws Exception;

	public abstract Map<String,String> getMapData();
	
	public abstract  void stop();
	
	public ServerSAPAssemblyInterfacesService getServerSap() {
		return serverSap;
	}

	public void setServerSap(ServerSAPAssemblyInterfacesService serverSap) {
		this.serverSap = serverSap;
	}

	public DataCaracSap getConfigCarac() {
		return configurationSap;
	}

	public void setConfigCarac(DataCaracSap configurationSap) {
		this.configurationSap = configurationSap;
	}

}