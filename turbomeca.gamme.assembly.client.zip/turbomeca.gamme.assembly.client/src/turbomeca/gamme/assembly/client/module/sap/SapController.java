package turbomeca.gamme.assembly.client.module.sap;

import turbomeca.gamme.assembly.client.ClientAssemblyControllersProvider;
import turbomeca.gamme.assembly.client.module.edition.AssemblyEditionController;
import turbomeca.gamme.assembly.client.module.sap.action.ActionUpdateSapData;
import turbomeca.gamme.assembly.client.module.sap.action.ActionUpdateSapPNData;
import turbomeca.gamme.assembly.client.module.sap.action.comparator.ActionSapComparatorLevel;
import turbomeca.gamme.assembly.client.module.sap.action.comparator.ActionSapComparatorTU;
import turbomeca.gamme.assembly.client.module.sap.action.comparator.ActionSapComparatorVariant;
import turbomeca.gamme.assembly.client.module.sap.action.executor.ActionSapExecutorLevel;
import turbomeca.gamme.ecran.client.IClientControllersProvider;
import turbomeca.gamme.ecran.client.module.sap.ASapController;

public class SapController extends ASapController {
	
	public SapController(IClientControllersProvider controllersProvider) {
		super(controllersProvider);
		addAction(new ActionSapComparatorTU());
		addAction(new ActionSapComparatorVariant());
//		addAction(new ActionSapExecutorEffectivity());
		addAction(new ActionSapComparatorLevel());
		addAction(new ActionSapExecutorLevel());
		
		addAction(new ActionUpdateSapPNData(getSapContextLoader()));
		addAction(new ActionUpdateSapData(getSapContextLoader()));
		
	}
	
	/**
	 * Only one way to get all subphase in edition and to be sure to can run controller's action
	 */
	@Override
	public boolean canRun() {
		AssemblyEditionController controller = ((ClientAssemblyControllersProvider)getControllersProvider()).getEditionHmiInterface();
		return controller.getFullEdition() != null && controller.getFullEdition().booleanValue();
	}

}
