package turbomeca.gamme.assembly.client.module.electronic.notification.view;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import turbomeca.gamme.assembly.client.model.edit.instructions.AModelTaskActionService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelOperationService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskActionService;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.constants.PropertyConstants;
import turbomeca.gamme.ecran.client.module.action.AActionView;
import turbomeca.gamme.ecran.services.common.utils.misc.FormatUtils;
import turbomeca.gamme.ecran.services.constants.XsltConstants;

public class CreateElectronicValidationView extends AActionView {

    private AModelTaskActionService taskActionService;

    public CreateElectronicValidationView(AModelTaskActionService taskActionnService) {
        super(XsltConstants.XSLT_CREATE_VALIDATION_ELECTRONIC_USER.value());
        setTaskActionService(taskActionnService);
    }

    @Override
    public boolean run() throws ClientException {
        getView().addParameter(XsltConstants.XSLT_PARAMETER_TASKACTION_ID.value(),
                getTaskActionService().getIdentifier());
        //Not user qualifications but taskAction and parents qualifications
        getView().addParameter(XsltConstants.XSLT_PARAMETER_USER_QUALIFICATIONS.value(),
        		getQualificationsFromTaskAction((ModelTaskActionService)getTaskActionService()));
        
        
        return getView().displayModal(
        		PropertyConstants.PROPERTY_MODAL_TITLE_ELECTRONIC_VALIDATION, false,
                getContext().getContextConfig().getUsers());
    }

    public AModelTaskActionService getTaskActionService() {
        return taskActionService;
    }

    public void setTaskActionService(AModelTaskActionService taskActionService) {
        this.taskActionService = taskActionService;
    }
    
    
    private String getQualificationsFromTaskAction(ModelTaskActionService taskActionService) {
    	String qualifications = "";
    	Set<String> intersectionQualifications = new HashSet<String>();
    	ModelSubPhaseService subPhaseService = (ModelSubPhaseService) taskActionService.getAncestor(ModelSubPhaseService.class);
    	if(subPhaseService != null) {
    		
    	if(subPhaseService.getQualifications()!= null && subPhaseService.getQualifications().size() > 0) {
        		intersectionQualifications.addAll(subPhaseService.getQualifications());
    		} else {
    			ModelOperationService operationService = (ModelOperationService) subPhaseService.getAncestor(ModelOperationService.class);
    	    	if(operationService != null && operationService.getQualifications()!= null && operationService.getQualifications().size() > 0){
    	    		intersectionQualifications.addAll(operationService.getQualifications());
    	    	}
    		}
    	}
    	
    	if(intersectionQualifications.size() >0 ){
    		List<String> list = new ArrayList<String>(intersectionQualifications);
    		qualifications = FormatUtils.getStringValues(list);
    	}
    	return qualifications;    	
    }
    
}
