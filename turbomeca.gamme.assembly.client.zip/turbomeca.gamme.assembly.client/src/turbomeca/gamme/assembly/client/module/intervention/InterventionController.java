package turbomeca.gamme.assembly.client.module.intervention;

import java.text.ParseException;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.ClientAssemblyControllersProvider;
import turbomeca.gamme.assembly.client.model.edit.runnable.ModelRunnableScheduleService;
import turbomeca.gamme.assembly.client.model.edit.schedule.AAssemblyScheduleService;
import turbomeca.gamme.assembly.client.module.edition.AssemblyEditionController;
import turbomeca.gamme.assembly.client.module.intervention.action.ActionChangeMark;
import turbomeca.gamme.assembly.client.module.intervention.action.ActionCreateDerogationMark;
import turbomeca.gamme.assembly.client.module.intervention.action.ActionDeleteDerogationMark;
import turbomeca.gamme.assembly.client.module.intervention.action.ActionDirty;
import turbomeca.gamme.assembly.client.module.intervention.action.ActionReworkDefined;
import turbomeca.gamme.assembly.client.module.intervention.action.ActionReworkDynamic;
import turbomeca.gamme.assembly.client.module.intervention.action.ActionReworkDynamicEditionAddTask;
import turbomeca.gamme.assembly.client.module.intervention.action.ActionReworkDynamicEditionAddTaskAction;
import turbomeca.gamme.assembly.client.module.intervention.action.ActionReworkDynamicEditionAddTaskPara;
import turbomeca.gamme.assembly.client.module.intervention.action.ActionReworkDynamicEditionSetOperationTitle;
import turbomeca.gamme.assembly.client.module.intervention.action.ActionReworkDynamicEditionSetSubPhaseTitle;
import turbomeca.gamme.assembly.client.module.intervention.action.ActionReworkDynamicEditionSetTaskPara;
import turbomeca.gamme.assembly.client.module.intervention.action.ActionSynchronizePredefinedTuning;
import turbomeca.gamme.assembly.client.module.intervention.action.ActionSynchronizeRework;
import turbomeca.gamme.assembly.client.module.intervention.action.ActionUpdateCommentNewPassing;
import turbomeca.gamme.assembly.client.module.intervention.action.ActionUpdateScheduleTopStartOperation;
import turbomeca.gamme.assembly.client.module.intervention.action.ActionValidateChangeLevel;
import turbomeca.gamme.assembly.client.module.intervention.action.ActionValidateLevelInstructions;
import turbomeca.gamme.assembly.client.module.intervention.view.ChangeMarkView;
import turbomeca.gamme.assembly.client.module.intervention.view.DerogationMarksView;
import turbomeca.gamme.assembly.client.module.intervention.view.DirtyView;
import turbomeca.gamme.assembly.client.module.intervention.view.NewPassingView;
import turbomeca.gamme.assembly.client.module.intervention.view.ReworkDynamicViewLevelSelection;
import turbomeca.gamme.assembly.client.module.intervention.view.ReworkDynamicViewSubPhaseEdition;
import turbomeca.gamme.assembly.client.module.intervention.view.ReworkDynamicViewSubPhaseSelection;
import turbomeca.gamme.assembly.client.module.intervention.view.ReworkPreDefinedView;
import turbomeca.gamme.assembly.client.module.intervention.view.SelectionInstructionLevelView;
import turbomeca.gamme.assembly.client.module.intervention.view.SelectionLevelView;
import turbomeca.gamme.assembly.client.module.intervention.view.TuningScheduleView;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.IClientControllersProvider;
import turbomeca.gamme.ecran.client.constants.PropertyConstants;
import turbomeca.gamme.ecran.client.interfaces.server.editing.EditingServerInterfaceService;
import turbomeca.gamme.ecran.client.interfaces.server.runtime.RuntimeServerInterfaceService;
import turbomeca.gamme.ecran.client.model.provider.ModelXmlProvider;
import turbomeca.gamme.ecran.client.module.intervention.DefaultInterventionController;
import turbomeca.gamme.ecran.client.module.intervention.action.ActionEditTuning;
import turbomeca.gamme.ecran.client.module.intervention.action.ActionNewTuning;
import turbomeca.gamme.ecran.client.module.intervention.action.ActionPredefinedTuning;
import turbomeca.gamme.ecran.client.module.io.IoController;
import turbomeca.gamme.ecran.services.common.utils.misc.FormatUtils;

public class InterventionController extends DefaultInterventionController {

	/** logger for current class */
	private static Logger logger = Logger.getLogger(InterventionController.class);

	private InterventionReworkDynamicManager reworkActionManager;

	public InterventionController(IClientControllersProvider provider) {
		super(provider);
		setReworkActionManager(new InterventionReworkDynamicManager());
	}
	
	@Override
	public boolean init() throws ClientException, ClientInterruption {
		new ActionUpdateScheduleTopStartOperation().run(this);
		return super.init();
	}


	/**********************************************
	 *  Level change interfaces
	 **********************************************/

	public void actionDisplayLevelSelection() {
		logger.info("actionDisplayLevelSelection");
		execute(new SelectionLevelView(getControllersProvider()));
	}

	public void actionValidateChangeLevel(String level) {
		logger.info("actionValidateChangeLevel : " + level);
		boolean success = execute(new ActionValidateChangeLevel(level));
		if(success){
			((IoController) getControllersProvider().getController(ClientAssemblyControllersProvider.INTERFACE_IO)).actionSaveOnServer();
		}
	}

	public void actionDisplayManualLevelInstruction() {
		logger.info("actionDisplayManualLevelInstruction");
		execute(new SelectionInstructionLevelView());
	}

	public void actionValidateLevelInstructions(String identifiers, String comment) {
		logger.info("actionValidateLevelInstructions : identifiers=" + identifiers + " - comment=" + comment);
		if (execute(new ActionValidateLevelInstructions(identifiers, comment))) {
			((IoController) getControllersProvider().getController(ClientAssemblyControllersProvider.INTERFACE_IO)).actionSaveOnServer();
		}
	}


	/**********************************************
	 *  Change mark interfaces
	 **********************************************/

	public void actionDisplayChangeMark(String markId, String instanceId, String alternativeId) {
		logger.info("actionDisplayChangeMark : [ id=" + markId + " - instance=" + instanceId + " - " + alternativeId + " ]");
		execute(new ChangeMarkView(markId, instanceId, alternativeId));
	}

	public boolean actionValidateChangeMark(String markId, String instanceId, String alternativeId,
			boolean newPn, String PN, 
			boolean newSn, String SN, 
			boolean newDerog, String derogation, String subPhaseId, String optionnalComment) {
		logger.info("actionValidateChangeMark : [ id=" + markId + " - instance=" + instanceId + " - alternative=" + alternativeId + " ]");
		return execute(new ActionChangeMark(markId, instanceId, alternativeId, newPn, PN, newSn,  SN, newDerog, derogation, subPhaseId, optionnalComment));
	}


	/**********************************************
	 *  Dirty view interfaces
	 **********************************************/

	public boolean actionDisplayDirtyView(String identifier) {
		logger.info("actionDisplayDirtyView : " + identifier);
		return execute(new DirtyView(identifier));
	}

	public boolean actionValidateDirtyView(String subPhaseId, String[] items) {
		logger.info("actionValidateDirtyView : " + subPhaseId);
		return execute(new ActionDirty(subPhaseId, items));
	}

	/**********************************************
	 *  Rework interfaces
	 * @throws ParseException 
	 **********************************************/

	public boolean actionDisplayTuningPredefined() throws ParseException {
		logger.info("actionDisplayTuningPredefined");
		AAssemblyScheduleService scheduleService = (AAssemblyScheduleService) getModelProvider().getModelScheduleService();
		boolean isAlive = RuntimeServerInterfaceService.getInstance().isAlive();
		if (isAlive) {
			AssemblyEditionController editionController =  (AssemblyEditionController) getControllersProvider().
					getController(ClientAssemblyControllersProvider.INTERFACE_EDITION);
			EditingServerInterfaceService.getInstance().loadEditing();

			if(((ModelRunnableScheduleService)scheduleService.getRunnableService()).
					canRunForMultiEdition(editionController,getContext().getContextEditing().isOutOfDate())){
				if (scheduleService.getWrapperService().getRework() != null) {
					return execute(new ReworkPreDefinedView());
				}
			}
			else{
				return false;
			}
		}
		else{
			getLoggerHmi().error(PropertyConstants.PROPERTY_ERROR_COMMUNICATION);
			return false;
		}
		return false;
	}

	public boolean actionValidateTuningDynamicLevelSelection(String level) {
		logger.info("actionValidateTuningDynamicLevelSelection : " + level);
		boolean isAlive = RuntimeServerInterfaceService.getInstance().isAlive();
		if (isAlive) {
			getReworkActionManager().setLevel(level);
			return actionDisplaySubPhaseSelection();
		}
		else{
			getLoggerHmi().error(PropertyConstants.PROPERTY_ERROR_COMMUNICATION);
			return false;
		}
	}

	public boolean actionDisplaySubPhaseSelection() {
		logger.info("actionDisplaySubPhaseSelection");
		boolean isAlive = RuntimeServerInterfaceService.getInstance().isAlive();
		if (isAlive) {
			return execute(new ReworkDynamicViewSubPhaseSelection(getReworkActionManager()));
		}
		else{
			getLoggerHmi().error(PropertyConstants.PROPERTY_ERROR_COMMUNICATION);
			return false;
		}
	}

	public boolean actionValidateReworkDynamicSubPhaseSelection(String reverseSubPhaseId, String currentSubPhaseId) {
		logger.info("actionValidateReworkDynamicSubPhaseSelection : [ reverse=" + reverseSubPhaseId + " - current=" + currentSubPhaseId + " ]");
		boolean isAlive = RuntimeServerInterfaceService.getInstance().isAlive();
		if (isAlive) {
			getReworkActionManager().setSubPhaseReverseId(reverseSubPhaseId);
			getReworkActionManager().setSubPhaseCurrentId(currentSubPhaseId);
			return execute(new ReworkDynamicViewSubPhaseEdition(getReworkActionManager()));
		}
		else{
			getLoggerHmi().error(PropertyConstants.PROPERTY_ERROR_COMMUNICATION);
			return false;
		}
	}

	public boolean actionReloadReworkDynamicSubPhaseSelection() {
		logger.info("actionReloadReworkDynamicSubPhaseSelection");
		boolean isAlive = RuntimeServerInterfaceService.getInstance().isAlive();
		if (isAlive) {
			return execute(new ReworkDynamicViewSubPhaseEdition(getReworkActionManager()));
		}
		else{
			getLoggerHmi().error(PropertyConstants.PROPERTY_ERROR_COMMUNICATION);
			return false;
		}
	}

	public boolean actionEditedReworkSetOperationTitle(String title) {
		return execute(new ActionReworkDynamicEditionSetOperationTitle(getReworkActionManager(), title));
	}

	public boolean actionEditedReworkSetSubPhaseTitle(String title) {
		return execute(new ActionReworkDynamicEditionSetSubPhaseTitle(getReworkActionManager(), title));
	}

	public boolean actionEditedReworkAddTask() {
		return execute(new ActionReworkDynamicEditionAddTask(getReworkActionManager()));
	}

	public boolean actionEditedReworkAddTaskPara(String taskId) {
		return execute(new ActionReworkDynamicEditionAddTaskPara(getReworkActionManager(), taskId));
	}

	public boolean actionEditedReworkSetTaskPara(String taskId, String taskParaId, String value) {
		return execute(new ActionReworkDynamicEditionSetTaskPara(getReworkActionManager(), taskId, taskParaId, value));
	}

	public boolean actionEditedReworkAddTaskAction(String taskId) {
		return execute(new ActionReworkDynamicEditionAddTaskAction(getReworkActionManager(), taskId));
	}

	public boolean actionValidateReworkDynamic(boolean hasSubPhase) {
		logger.info("actionValidateReworkDynamic");
		if (!hasSubPhase) {
			getReworkActionManager().resetSubPhaseEdited();
		}
		boolean success = execute(new ActionReworkDynamic(getReworkActionManager()));
		if(success){
			success = execute(new ActionSynchronizeRework());
		}
		return success;
	}

	/**
	 * @return the reworkActionBuilder
	 */
	public InterventionReworkDynamicManager getReworkActionManager() {
		return reworkActionManager;
	}

	/**
	 * @param reworkActionBuilder the reworkActionBuilder to set
	 */
	public void setReworkActionManager(InterventionReworkDynamicManager reworkActionManager) {
		this.reworkActionManager = reworkActionManager;
	}

	/**********************************************
	 *  Display  Derogation Marks interfaces
	 **********************************************/

	/** Method who display modal or create or edit an derogation mark 
	 * @param reworkActionBuilder the reworkActionBuilder to set
	 */
	public boolean actionDisplayDerogationMarks() {
		logger.info("actionDisplayDerogationMArks");
		return execute(new DerogationMarksView(getControllersProvider()));
	}

	/** Method who display modal or create or edit an derogation mark 
	 * @param reworkActionBuilder the reworkActionBuilder to set
	 */
	public boolean actionCreateDerogationMark (String servicesId, String pn, String sn, String derog) {
		boolean success = execute(new ActionCreateDerogationMark(servicesId, pn, sn, derog));
		if(success){
			((IoController) getControllersProvider().getController(ClientAssemblyControllersProvider.INTERFACE_IO)).actionSaveOnServer();
		}
		return success;
	}

	/** Method who display modal or create or edit an derogation mark 
	 * @param reworkActionBuilder the reworkActionBuilder to set
	 */
	public boolean actionDeleteDerogationMark (String idDerogation) {
		boolean success = execute(new ActionDeleteDerogationMark(idDerogation));
		if(success){
			((IoController) getControllersProvider().getController(ClientAssemblyControllersProvider.INTERFACE_IO)).actionSaveOnServer();
		}
		return success;
	}

	/**********************************************
	 *  New passing interfaces
	 **********************************************/
	
	/**
	 * Override the DefaultController actionDisplayNewPassing to manage the out of date
	 */
	@Override
	public void actionDisplayNewPassing() {
		logger.info("actionDisplayNewPassing");
		execute(new NewPassingView(getControllersProvider()));
	}
	
	public void actionDisplayTuningSchedule() {
		logger.info("actionDisplayTuningSchedule");
		execute(new TuningScheduleView(getControllersProvider()));
	}
	
	public boolean actionUpdateCommentNewPassing(String comment) {
		logger.info("actionUpdateCommentNewPassing : " + comment);
		boolean success = execute(new ActionUpdateCommentNewPassing(comment));
		if(success){
			((IoController) getControllersProvider().getController(ClientAssemblyControllersProvider.INTERFACE_IO)).actionSaveOnServer();
		}
		return success;
	}
	
//	@Override
	public void actionNewTuning(String instances, String identifiers, String unselectIdentifiers, String comment) {
		logger.info("actionNewTuning instances=" + instances);
		logger.info("actionNewTuning identifiers=" + identifiers + " with comments :" + comment);
		logger.info("actionNewTuning unselectIdentifiers=" + unselectIdentifiers + " with comments :" + comment);
		boolean success = execute(new ActionNewTuning(instances, identifiers, unselectIdentifiers, comment));

//		boolean success = execute(new ActionNewPassingWithComment(identifiers, unselectIdentifiers, comment));
		if (success) {
			int ioControllerId = getControllersProvider().getControllerId(IoController.class);
			((IoController) getControllersProvider().getController(ioControllerId)).actionSaveOnServer();
			logger.info("call actionRefresh");
			((IoController) getControllersProvider().getController(ioControllerId)).actionRefresh();
			getModelProvider().setModelStatus( ModelXmlProvider.MODEL_STATUS_MODIFIED);
			try {
				getModelProvider().getModelScheduleService().getStatusService().computeStatus(true);
			} catch (ClientException e) {
				handleClientException(e);
			} catch ( ClientInterruption e) {
				handleException(e);
			}
			((IoController) getControllersProvider().getController(ioControllerId)).actionSaveOnServer();
		}
	}

	
//	@Override
	public void actionEditTuning(String instances, String identifiers, String unselectSubPhaseChildIdentifiers, String unselectIdentifiers, String comment) {
		logger.info("actionEditTuning instances=" + instances);
		logger.info("actionEditTuning identifiers=" + identifiers + " with comments :" + comment);
		logger.info("actionEditTuning unselectIdentifiers=" + unselectSubPhaseChildIdentifiers + " with comments :" + comment);
		boolean success = execute(new ActionEditTuning(instances, identifiers, unselectSubPhaseChildIdentifiers, unselectIdentifiers, comment));
		if (success) {
			int ioControllerId = getControllersProvider().getControllerId(IoController.class);
			((IoController) getControllersProvider().getController(ioControllerId)).actionSaveOnServer();
			logger.info("call actionRefresh");
			((IoController) getControllersProvider().getController(ioControllerId)).actionRefresh();
			getModelProvider().setModelStatus( ModelXmlProvider.MODEL_STATUS_MODIFIED);
			((IoController) getControllersProvider().getController(ioControllerId)).actionSaveOnServer();
		}
	}
	
	public boolean actionValidateTuningPredefined(String instances, String operationsId) {
		logger.info("actionValidateTuningPredefined instances=" + instances);
		logger.info("actionValidateTuningPredefined operationsId= " + operationsId);
		int ioControllerId = getControllersProvider().getControllerId(IoController.class);
		boolean success = execute(new ActionPredefinedTuning(instances, operationsId, ""));
		if (success) {
			((IoController) getControllersProvider().getController(ioControllerId)).actionSaveOnServer();
			logger.info("call actionRefresh");
			((IoController) getControllersProvider().getController(ioControllerId)).actionRefresh();
			getModelProvider().setModelStatus( ModelXmlProvider.MODEL_STATUS_MODIFIED);
			((IoController) getControllersProvider().getController(ioControllerId)).actionSaveOnServer();
			success &= execute(new ActionSynchronizePredefinedTuning());
		}
		return success;
	}

	public boolean actionDisplayTuningDynamic() throws ParseException {
		logger.info("actionDisplayTuningDynamic");
		boolean isAlive = RuntimeServerInterfaceService.getInstance().isAlive();
		if (isAlive) {
			getReworkActionManager().init();
			AAssemblyScheduleService scheduleService = (AAssemblyScheduleService) getModelProvider().getModelScheduleService();
			if (scheduleService.hasLevelDefined()) {
				return execute(new ReworkDynamicViewLevelSelection(getReworkActionManager()));
			} else {
				return execute(new ReworkDynamicViewSubPhaseSelection(getReworkActionManager()));
			}
		}
		else{
			getLoggerHmi().error(PropertyConstants.PROPERTY_ERROR_COMMUNICATION);
			return false;
		}
	}
}
