package turbomeca.gamme.assembly.client.module.intervention.view;

import turbomeca.gamme.assembly.client.ClientAssemblyControllersProvider;
import turbomeca.gamme.assembly.client.config.AssemblyPropertyConstants;
import turbomeca.gamme.assembly.client.model.edit.runnable.ModelRunnableScheduleService;
import turbomeca.gamme.assembly.client.module.edition.AssemblyEditionController;
import turbomeca.gamme.assembly.services.constants.AssemblyXsltConstants;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.IClientControllersProvider;
import turbomeca.gamme.ecran.client.interfaces.server.editing.EditingServerInterfaceService;
import turbomeca.gamme.ecran.client.module.action.AActionView;

public class DerogationMarksView  extends AActionView  {

	private IClientControllersProvider controllerProvider;

	public DerogationMarksView(IClientControllersProvider iClientControllersProvider) {
		super(AssemblyXsltConstants.XSLT_INTERVENTION_DEROGATION_MARK.value());
		setControllerProvider(iClientControllersProvider);
	}

	@Override
	public boolean run() throws ClientException {
		boolean success = true;
		AssemblyEditionController editionController =  (AssemblyEditionController) getControllerProvider().
				getController(ClientAssemblyControllersProvider.INTERFACE_EDITION);
		EditingServerInterfaceService.getInstance().loadEditing();

		if(((ModelRunnableScheduleService) getModelProvider().getModelScheduleService().getRunnableService()).
				canRunForMultiEdition(editionController, getContext().getContextEditing().isOutOfDate())){
			getView().bindService(getModelProvider().getModelScheduleService());
			success =  getView().displayModal(AssemblyPropertyConstants.PROPERTY_MODAL_TITLE_DEROGATION_MARK, true);
		}
		else{
			success = false;
		}
		return success;
	}

	public IClientControllersProvider getControllerProvider() {
		return controllerProvider;
	}

	public void setControllerProvider(IClientControllersProvider controllerProvider) {
		this.controllerProvider = controllerProvider;
	}

}
