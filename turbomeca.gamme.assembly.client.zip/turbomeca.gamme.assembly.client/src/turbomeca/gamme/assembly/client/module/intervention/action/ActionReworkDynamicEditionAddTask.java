package turbomeca.gamme.assembly.client.module.intervention.action;

import turbomeca.gamme.assembly.client.module.intervention.InterventionReworkDynamicManager;
import turbomeca.gamme.assembly.client.module.intervention.view.ReworkDynamicViewSubPhaseEdition;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.module.IController;

public class ActionReworkDynamicEditionAddTask extends AActionReworkDynamic {

    /**
     * 
     * @param reworkManager
     */
    public ActionReworkDynamicEditionAddTask(InterventionReworkDynamicManager reworkManager) {
        super(reworkManager);
    }

    @Override
    public boolean run(IController controller) throws ClientException {
        getReworkManager().addNewTask();
        return new ReworkDynamicViewSubPhaseEdition(getReworkManager()).run();
    }
}