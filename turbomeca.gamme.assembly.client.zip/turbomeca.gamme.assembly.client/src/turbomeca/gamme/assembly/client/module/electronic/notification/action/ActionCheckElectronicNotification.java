package turbomeca.gamme.assembly.client.module.electronic.notification.action;

import java.util.List;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.model.edit.notifications.AModelNotificationService;
import turbomeca.gamme.assembly.client.model.edit.provider.ModelNotificationProvider;
import turbomeca.gamme.assembly.services.model.data.ElectronicNotification;
import turbomeca.gamme.assembly.services.model.data.Response;
import turbomeca.gamme.assembly.services.model.data.User;
import turbomeca.gamme.assembly.services.model.data.UserMark;
import turbomeca.gamme.assembly.services.model.data.types.StatusNotificationType;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.constants.PropertyConstants;
import turbomeca.gamme.ecran.client.interfaces.server.notification.NotificationServerInterfaceService;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.services.notification.bean.NotificationBean;

public class ActionCheckElectronicNotification extends AActionCreateElectronicNotification {

	/** logger for current class */
	private static Logger logger = Logger.getLogger(ActionCheckElectronicNotification.class);

	@Override
	public boolean run(IController controller) throws ClientException, ClientInterruption {
		// FIXME : almost same code as DUF --> Need to be moved in Ecran
		List<NotificationBean> notificationsBean = NotificationServerInterfaceService.getInstance().loadNotifications();
		boolean needSynchronisation = false; 
		
		if (notificationsBean != null) {
				// Manage notifications
				for(NotificationBean electNotif : notificationsBean) {
					List<AModelNotificationService> notifications = ModelNotificationProvider
							.getInstance().getNotifications(electNotif.getUfiId());
					
					if (notifications != null) {
						for(AModelNotificationService notification : notifications) {
							ElectronicNotification  elec = (ElectronicNotification) notification.getWrapperService().getObject();
							logger.debug("Electronic notification id " + elec.getId() + " active ? " + elec.isActive() + " updated ? " + elec.isUpdated());
							if (elec.isActive() && (!elec.hasUpdated() || (elec.hasUpdated() && !elec.isUpdated()))) {
								Response response = new Response();
								response.setComment(electNotif.getResponseComment());
								response.setNcr(electNotif.getNcrNumber());
								UserMark userMark = new UserMark();
								userMark.setDateTime(electNotif.getResponseDate());
								User user = new User();
								user.setLogin(electNotif.getResponseLogin());
								user.setName(electNotif.getResponseUser());
								userMark.setUser(user);
								response.setUserMark(userMark);
								notification.update(StatusNotificationType.valueOf(electNotif.getStatus()), response);
								needSynchronisation = true;
							}
							else {
								logger.debug("No update for unactive notification" + notification);
							}
						}
						
					} else {
						logger.error("Internal error : notification send by server is not found on client");
					}
				}
				if(needSynchronisation) {
					synchronizeOnServer(false);
				}
				
				getLoggerHmi().info(PropertyConstants.PROPERTY_NOTIFICATION_CHECK_DONE);
		}
		return true;
	}
}