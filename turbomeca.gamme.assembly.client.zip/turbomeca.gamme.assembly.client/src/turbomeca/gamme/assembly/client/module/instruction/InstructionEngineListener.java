package turbomeca.gamme.assembly.client.module.instruction;

import java.util.ArrayList;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.ClientAssemblyControllersProvider;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelOperationService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelResourcesService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseGroupService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskActionMeasureService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskPilotingService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskService;
import turbomeca.gamme.assembly.client.model.edit.schedule.AAssemblyScheduleService;
import turbomeca.gamme.assembly.client.module.electronic.notification.ElectronicNotificationController;
import turbomeca.gamme.assembly.client.module.externaltools.ExternalToolsController;
import turbomeca.gamme.assembly.client.module.externaltools.player.InstructionPlayerFactory;
import turbomeca.gamme.assembly.client.module.externaltools.player.measure.PlayerTaskMeasure;
import turbomeca.gamme.assembly.services.model.data.types.StatusType;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.config.Configuration;
import turbomeca.gamme.ecran.client.constants.PropertyConstants;
import turbomeca.gamme.ecran.client.context.ContextRequest;
import turbomeca.gamme.ecran.client.engine.IModelServiceEngineListener;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelScheduleService;
import turbomeca.gamme.ecran.client.module.externaltools.player.IPlayerInstruction;
import turbomeca.gamme.ecran.client.module.instruction.view.IInstructionView;

public class InstructionEngineListener implements IModelServiceEngineListener {

	/** logger for current class */
	private static Logger logger = Logger.getLogger(InstructionEngineListener.class);

	/** Instruction page view */
	private InstructionController controller;

	/**
	 * Constructor
	 * 
	 * @param view
	 *            instruction page view
	 */
	public InstructionEngineListener(InstructionController instructionController) {
		setController(instructionController);
	}

	@Override
	public void next(IModelObjectService previousService, IModelObjectService newService, boolean focusNext)
			throws ClientException, ClientInterruption {
		logger.debug("next : " + newService);
		controller.getNotificationsService().applyNotifications();
		controller.getNotificationsService().setDisableNotifications(false);

		IPlayerInstruction player = InstructionPlayerFactory.createPlayer(newService, false, false);
		if (player != null) {
			boolean canFocus = newService.getHmiUpdaterService().canFocus(previousService, newService);
			if (    getController().getContext().getContextRequest().getRequestType() == ContextRequest.CONTINUE
					|| canFocus) {
				getView().focusTaskActionService(newService);
				if(!previousService.equals(newService)) {

					try {
						// if player run without problem, so engine go to the nextService 
						if (player.autoRun() && player.run(getController()) && player.isModify()) {
							getController().getEngine().next(newService, focusNext);
						}
					} finally {
						if (player.isModify() && player.autoRun()) {
							getView().blurTaskActionService(newService);
						}
					}
				}
			}
			if(!previousService.equals(newService) && canFocus) {
				if(newService instanceof ModelTaskActionMeasureService ||  newService.getParent() instanceof ModelTaskActionMeasureService ) {
					ModelTaskActionMeasureService modelTaskAction = (ModelTaskActionMeasureService) newService.getAncestor(ModelTaskActionMeasureService.class);
					if(modelTaskAction.getMeasureTool() !=null && modelTaskAction.getMeasureRdd() ==null && modelTaskAction.getMeasureSap() == null) {
						logger.debug("previous : " + previousService);
						if(previousService instanceof ModelTaskService){
							int indexLastChildrenTask = previousService.getChildren().size() -1;
							previousService = previousService.getChildren().get(indexLastChildrenTask);
						}
						if(previousService instanceof ModelTaskActionMeasureService 
								||  previousService.getParent() instanceof ModelTaskActionMeasureService){
							ModelTaskActionMeasureService previousModelTaskAction = (ModelTaskActionMeasureService) previousService.getAncestor(ModelTaskActionMeasureService.class);
							String newType = modelTaskAction.getMeasureTool().getType();
							String previousType = null;
							if(previousModelTaskAction.getMeasureTool() != null){
								previousType = previousModelTaskAction.getMeasureTool().getType();							
							}
							logger.debug("previous type tool : "+ previousType);
							logger.debug("actual type tool : "+ newType);

							if(previousType != null && !previousType.isEmpty() && newType != null && previousType.equals(newType) 
									&& modelTaskAction.getMeasureTool().getTaskAction().getInputAction().getInputValue() != null){
								PlayerTaskMeasure playerMeasure = (PlayerTaskMeasure) player;
								playerMeasure.setForceModeAcquistion(true);
								playerMeasure.setToolsAcquistion(true);
								ExternalToolsController externalToolCon = (ExternalToolsController) getController().getControllersProvider().getController(ClientAssemblyControllersProvider.INTERFACE_TOOLS);
								playerMeasure.run(externalToolCon);
							}
						}
					}
				}
			}
		}
	}

	@Override
	public void objectFinished(IModelObjectService objectService) throws ClientException,
	ClientInterruption {
		logger.debug("objectFinished : " + objectService); 
		if (objectService instanceof ModelSubPhaseService) {
			subPhaseFinished((ModelSubPhaseService) objectService);
		} else if (objectService instanceof ModelTaskService ||
				objectService instanceof ModelTaskPilotingService) {
			objectService.getStatusService().computeStatus(false);
		} else if (objectService instanceof ModelOperationService) {
			objectService.getStatusService().updateState(StatusType.DONE.value(), true, null, null);
			operationFinished((ModelOperationService) objectService);
		} else if (   objectService instanceof ModelResourcesService
				|| objectService instanceof ModelOperationService
				|| objectService instanceof ModelSubPhaseGroupService) {
			objectService.getStatusService().updateState(StatusType.DONE.value(), true, null, null);
		} else {
			logger.info("Object finished, but nothing to do : " + objectService);
		}
	}


	/**
	 * Call-back when an sub-phase service is finished
	 * 
	 * @param subPhaseService
	 *            sub-phase service finished
	 * @throws ClientException
	 * @throws ClientInterruption
	 */
	private void subPhaseFinished(ModelSubPhaseService subPhaseService) throws ClientException,
	ClientInterruption {
		if(subPhaseService.hasNoneSignature()) {
			return;
		}
		if(subPhaseService.isSetupSubPhase()){
			ElectronicNotificationController electNotifController = (ElectronicNotificationController) getController().getControllersProvider().getController(ClientAssemblyControllersProvider.INTERFACE_NOTIFICATION);
			electNotifController.actionCreateElectronicNotificationUser(subPhaseService.getIdentifier(),Configuration.getInstance().getProperty(PropertyConstants.PROPERTY_MESSAGE_NOTIFICATION_SUBPHASE_SETUP));

		}
		if (!subPhaseService.getRunnableService().needValidation()) {
			//				subPhaseService.getStatusService().updateState(StatusType.DONE.value(), true, null, null);
			getController().actionValidateSubPhase(subPhaseService.getIdentifier(), null);
		} else {
			subPhaseService.getStatusService().updateState(StatusType.TO_SIGN.value(), true, null, null);
		}
	}

	private void operationFinished(ModelOperationService currentOperationService) {
		AAssemblyScheduleService scheduleService = (AAssemblyScheduleService) getController().getScheduleService();
		ModelOperationService lastOperationService = scheduleService.getLastOperationClosed();
		if (lastOperationService != null) {
			lastOperationService.getWrapperService().setLastOperationClosed(false);
		}
		currentOperationService.getWrapperService().setLastOperationClosed(true);
	}

	@Override
	public void domainFinished(String domain) {
		logger.debug("domainFinished");
	}

	@Override
	public void scheduleFinished() throws ClientException, ClientInterruption {
		logger.debug("scheduleFinished");
		IModelScheduleService scheduleService = getController().getScheduleService();

		StatusType scheduleStatus = StatusType.valueOf(scheduleService.getStatusService().getStatus());
		boolean canValidate = scheduleService.getRunnableService().canValidate();
		if ((scheduleStatus == StatusType.TODO || scheduleStatus == StatusType.TO_SIGN ) && canValidate) {
			getController().actionDisplayValidation(scheduleService);
		} else {
			scheduleService.getStatusService().updateState(StatusType.TO_SIGN.value(), true, null, null);
			getController().getLoggerHmi().error(PropertyConstants.PROPERTY_ERROR_TO_SIGN_VALIDATION_ALL_SUBPHASE);
		}
	}

	@Override
	public void noAction() {
		getController().getLoggerHmi().info(PropertyConstants.PROPERTY_NO_MORE_ACTION);
	}

	/**
	 * @return the controller
	 */
	public InstructionController getController() {
		return controller;
	}

	/**
	 * @return the view
	 */
	public IInstructionView getView() {
		return controller.getView();
	}

	/**
	 * @param controller the controller to set
	 */
	public void setController(InstructionController controller) {
		this.controller = controller;
	}

	@Override
	public String getNextDomain(String domain) {
		return null;
	}

	@Override
	public void domainFinishedForInstances(String domain,
			ArrayList<String> arrayList) {
		logger.debug("domainFinishedForInstances");
	}
}
