package turbomeca.gamme.assembly.client.module.externaltools.action;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.ClientAssemblyException;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskActionMeasureService;
import turbomeca.gamme.assembly.client.module.externaltools.ExternalToolsController;
import turbomeca.gamme.assembly.client.module.externaltools.player.InstructionPlayerFactory;
import turbomeca.gamme.assembly.services.model.data.InputValue;
import turbomeca.gamme.assembly.services.model.data.MeasureRdd;
import turbomeca.gamme.assembly.services.model.data.MeasureSap;
import turbomeca.gamme.assembly.services.model.data.TaskActionMeasure;
import turbomeca.gamme.assembly.services.model.data.types.StatusType;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.client.module.externaltools.player.IPlayerInstruction;
import turbomeca.gamme.ecran.services.devices.ExternalsToolsExceptions;

public class ActionRunMeasureTool extends AActionRunPlayer {

	private String serviceId;
	private static Logger logger = Logger.getLogger(ActionRunMeasureTool.class);

	public ActionRunMeasureTool(String serviceId) {
		setServiceId(serviceId);
	}

	@Override
	public boolean run(IController controller) throws ClientException, ClientInterruption {
		boolean succes = true;
		
		logger.debug("[PILOTING] : ActionRunMeasureTool - run");
		
		ModelTaskActionMeasureService taskMeasureService = ((ModelTaskActionMeasureService) getModelProvider()
				.getModelService(getServiceId()));

		if(!isSubPhaseFinished(taskMeasureService)) {
			if (!isResourcesFinished(taskMeasureService)) {
				throw new ClientAssemblyException(
						ClientAssemblyException.EXCEPTION_INPUT_RESOURCES_NOT_FINISHED);
			}
	
			if (!canRunPlayer(taskMeasureService)) {
				throw new ClientException(
						ExternalsToolsExceptions.MESSAGE_DISABBLE_ACTION_ACQUISITION, "ExternalsToolsExceptions");
			}
	
			TaskActionMeasure taskMeasure = (TaskActionMeasure) taskMeasureService
					.getWrapperService().getObject();
			InputValue toolEnter = taskMeasure.getMeasureTool().getTaskAction()
					.getInputAction().getInputValue();
	
			if (toolEnter == null || toolEnter.getValue().isEmpty()) {
				throw new ClientException(
						ExternalsToolsExceptions.TOOLS_INPUT_MISSING, "ExternalsToolsExceptions");
			}
			IPlayerInstruction playerInstruction = InstructionPlayerFactory.createPlayer(taskMeasureService, true, true);
			((ExternalToolsController) controller).setPlayerInProgress(playerInstruction);
			succes = playerInstruction.run(controller);
		}
		return succes;
	}


	/**
	 * Function who verify that player can be run
	 * 
	 * @param taskMeasureService
	 * @return
	 */
	public boolean canRunPlayer(ModelTaskActionMeasureService taskMeasureService) {
		
		boolean runPlayer = true;
		MeasureSap measureSap = taskMeasureService.getMeasureSap();
		MeasureRdd measureRdd = taskMeasureService.getMeasureRdd();

		// Test on Measure Sap
		if (measureSap != null) {
			if (measureSap.getState().getStatus()!=StatusType.KO) {
				runPlayer = false;
			}
		}
		
		// Test on Measure Tools
		if (runPlayer) {
			if (measureRdd != null) {
				if (measureRdd.getState().getStatus()!=StatusType.KO) {
					runPlayer = false;
				}
			}
		}
		
		return runPlayer;
	}

	public String getServiceId() {
		return serviceId;
	}

	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}

}
