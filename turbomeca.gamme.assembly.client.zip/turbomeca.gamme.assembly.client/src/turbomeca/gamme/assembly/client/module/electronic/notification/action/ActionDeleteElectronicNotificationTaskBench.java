package turbomeca.gamme.assembly.client.module.electronic.notification.action;

import java.util.List;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.client.model.edit.notifications.AModelNotificationService;
import turbomeca.gamme.assembly.client.model.edit.notifications.ModelNotificationsService;
import turbomeca.gamme.assembly.client.model.edit.provider.ModelNotificationProvider;
import turbomeca.gamme.assembly.services.model.data.ElectronicNotification;
import turbomeca.gamme.assembly.services.model.data.ElectronicNotifications;
import turbomeca.gamme.assembly.services.model.data.types.NotificationOriginType;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.interfaces.server.runtime.RuntimeFullEditionService;
import turbomeca.gamme.ecran.client.module.IController;

public class ActionDeleteElectronicNotificationTaskBench extends AActionCreateElectronicNotification {
	
	/** */
    private String subPhaseId;

	/**
	 * 
	 * @param taskActionService
	 */
	public ActionDeleteElectronicNotificationTaskBench(String subPhaseId) {
		setSubPhaseId(subPhaseId);
	}

	@Override
	public boolean run(IController controller) throws ClientException {
    	boolean successSynchronizeOnServer = true;
    	
		ModelSubPhaseService modelServiceSubPhase = (ModelSubPhaseService) getModelProvider().getModelService(getSubPhaseId());
		
		ModelNotificationsService notificationService = modelServiceSubPhase.getNotificationsService();
		
		if (notificationService != null) {
			ElectronicNotifications electronicNotifications = filterSettingBenchNotifications(notificationService.getWrapperService().getElectronicNotifications());

			ElectronicNotification[] electronicNotifs = electronicNotifications.getElectronicNotification();

			for(ElectronicNotification electronicNotification : electronicNotifs) {
				electronicNotifications.removeElectronicNotification(electronicNotification);
				electronicNotification.setActive(false);

				List<AModelNotificationService> notifications = ModelNotificationProvider.getInstance().getNotifications(electronicNotification.getId());

				if (notifications != null) {
					for(AModelNotificationService notification : notifications) {
						notification.getWrapperService().setActive(false);

						//the method bellow allows to delete from the database this alea
						ModelNotificationProvider.getInstance().addNotificationServiceToErase(notification);
						notification.getElectronicNotification().setActive(false);
						controller.getNotificationsService().notifyServiceChanged(notification.getParent());
						controller.getNotificationsService().notifyElectronicNotificationChanged(modelServiceSubPhase);
					}
				}
			}
			successSynchronizeOnServer = synchronizeOnServer(true);
			controller.getNotificationsService().notifyServiceChanged(modelServiceSubPhase);
		}
		
		return successSynchronizeOnServer;
	}
	
	protected RuntimeFullEditionService getRuntimeFullEditionService() {
		return RuntimeFullEditionService.getInstance();
	}

	/**
     * @return the subPhaseId
     */
    public String getSubPhaseId() {
        return subPhaseId;
    }

    /**
     * @param subPhaseId the subPhaseId to set
     */
    public void setSubPhaseId(String subPhaseId) {
        this.subPhaseId = subPhaseId;
    }
    
    /**
     * 
     * @param electronicNotifications
     * 	 object containing the notifications to treat
     * 	
     * @return another object containing only notifications emitted by a setting bench task
     */
    private static final ElectronicNotifications filterSettingBenchNotifications(ElectronicNotifications  electronicNotifications) {
    	ElectronicNotifications result = new ElectronicNotifications();
    	
    	if (electronicNotifications != null) {
			for(ElectronicNotification electronicNotification : electronicNotifications.getElectronicNotification()) {
				if(electronicNotification.getOrigin().equals(NotificationOriginType.TASK_BENCH)){
					result.addElectronicNotification(electronicNotification);
				}
			}
    	}
    	
		return result;
    }
}