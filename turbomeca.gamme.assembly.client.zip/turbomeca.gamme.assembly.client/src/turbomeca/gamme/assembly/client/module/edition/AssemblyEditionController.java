package turbomeca.gamme.assembly.client.module.edition;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelOperationService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseGroupService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.client.module.edition.action.ActionRefreshAndUpdateReferences;
import turbomeca.gamme.assembly.client.module.edition.action.ActionUpdateEditingObjects;
import turbomeca.gamme.ecran.client.IClientControllersProvider;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.module.edition.EditionController;
import turbomeca.gamme.ecran.services.common.constants.GlobalConstants;
import turbomeca.gamme.ecran.services.constants.XsltConstants;

/**
 * Class manages the selection of edited operations
 * 
 * @author Sopra Group
 */
public class AssemblyEditionController extends EditionController {

	
	public AssemblyEditionController(IClientControllersProvider provider) {
		super(provider, XsltConstants.XSLT_EDITION_SUBPHASES.value());
	}
	
	@Override
	public boolean init() {
		return initSubPhaseLevelEdition();
	}
	
	/**
	 * Reloads model from server
	 */
	public void actionRefresh() {
		execute(new ActionRefreshAndUpdateReferences());
		//execute(new Action)
	}

	/**
	 * Saves current range and update editing operations on server
	 * 
	 * @param operationsList
	 *            edited operations
	 */
	@Override
	public boolean updateOperationsEdited(String objectsList) {
		return execute(new ActionUpdateEditingObjects(objectsList));
	}

	@Override
	public boolean updateAllSubPhaseInEdition(boolean checkRights) {
		return execute(new ActionUpdateEditingObjects(getSubphaseWithUserQualification(checkRights)));
	}
	
	/**
	 * Get subPhases which have not or have the qualification of the user
	 * @param checkQualification : check user qualification or not
	 * @return
	 */
	private String getSubphaseWithUserQualification(boolean checkQualification) {
		StringBuilder editableSubphases = new StringBuilder();
		boolean firstSubphase = false;
		for (IModelObjectService operation : getModelProvider().getModelScheduleService().getChildrenDeep(ModelOperationService.class)) {
			ModelOperationService operationservice = (ModelOperationService) operation;
			boolean userOperationQualified = operationservice.isUserQualified(operationservice.getQualifications(), getConfiguration().getConfigUser().getUserQualificationsList());
			for(IModelObjectService subphase: operation.getChildrenDeep(ModelSubPhaseService.class))
			{
				ModelSubPhaseService subphaseService = (ModelSubPhaseService) subphase;
				if (subphase.getWrapperService().isApplicable()
						&& !subphaseService.isArchived()
						&& !subphaseService.isAlternative()) {
					boolean userSubphaseQualified = subphaseService.isUserQualified(subphaseService.getQualifications(),
							getConfiguration().getConfigUser().getUserQualificationsList());
					firstSubphase = addEditableSubphase(checkQualification, userSubphaseQualified, userOperationQualified, editableSubphases, subphase.getIdentifier(), firstSubphase);
					
					// If sub-phase has alternatives, then we need to take them in edition too
					if (subphaseService.hasAlternatives()) {
						for(IModelObjectService alternativeSubphase: subphaseService.getAlternatives()) {
							ModelSubPhaseService alternativeSubphaseService = (ModelSubPhaseService) subphase;
							boolean userAltSubphaseQualified = alternativeSubphaseService.isUserQualified(subphaseService.getQualifications(),
									getConfiguration().getConfigUser().getUserQualificationsList());
							firstSubphase = addEditableSubphase(checkQualification, userAltSubphaseQualified, userOperationQualified, editableSubphases, alternativeSubphase.getIdentifier(), firstSubphase);
						}
					}
					
				}
			}
			// Special treatment for subphases groups
			for(IModelObjectService subphaseGroup: operation.getChildrenDeep(ModelSubPhaseGroupService.class))
			{
				ModelSubPhaseGroupService subphaseGroupService = (ModelSubPhaseGroupService) subphaseGroup;
				if (subphaseGroup.getWrapperService().isApplicable()) {
					boolean userSubphaseGroupQualified = subphaseGroupService.isUserQualified(subphaseGroupService.getQualifications(),
							getConfiguration().getConfigUser().getUserQualificationsList());
					firstSubphase = addEditableSubphase(checkQualification, userSubphaseGroupQualified, userOperationQualified, editableSubphases, subphaseGroup.getIdentifier(), firstSubphase);
				}
			}
		}
		return editableSubphases.toString();
	}
	
	private boolean addEditableSubphase(boolean checkQualification, boolean userSubphaseQualified, boolean userOperationQualified,
			StringBuilder editableSubphases, String identifier,
			boolean firstSubphase) {
		if(checkQualification){
			if(userOperationQualified && userSubphaseQualified){
				if (firstSubphase) {
					editableSubphases.append(GlobalConstants.SEPARATOR_DOT_COMA);
				}
				editableSubphases.append(identifier);
				firstSubphase = true;
			}
		}
		else{
			if (firstSubphase) {
				editableSubphases.append(GlobalConstants.SEPARATOR_DOT_COMA);
			}
			editableSubphases.append(identifier);
			firstSubphase = true;
		}
		return firstSubphase;
	}
	
}
