package turbomeca.gamme.assembly.client.module.externaltools;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskActionMeasureService;
import turbomeca.gamme.assembly.client.module.electronic.notification.view.CreateConfirmationModalView;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskPilotingService;
import turbomeca.gamme.assembly.client.module.externaltools.action.ActionRunIsConnectedTool;
import turbomeca.gamme.assembly.client.module.externaltools.action.ActionRunMeasureRDD;
import turbomeca.gamme.assembly.client.module.externaltools.action.ActionRunMeasureTool;
import turbomeca.gamme.assembly.client.module.externaltools.action.ActionRunPilotingTool;
import turbomeca.gamme.assembly.client.module.externaltools.action.ActionSetInputTool;
import turbomeca.gamme.assembly.client.module.externaltools.action.ActionStopMeasureTool;
import turbomeca.gamme.assembly.client.module.externaltools.action.ActionStopPilotingTool;
import turbomeca.gamme.assembly.client.module.externaltools.action.ActionUpdateAutoMode;
import turbomeca.gamme.assembly.client.module.instruction.action.ActionSetInput;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.IClientControllersProvider;
import turbomeca.gamme.ecran.client.hmi.ModalManager;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.module.AController;
import turbomeca.gamme.ecran.client.module.externaltools.action.ActionInitExternalTools;
import turbomeca.gamme.ecran.client.module.externaltools.player.IPlayerInstruction;
import turbomeca.gamme.ecran.services.model.tool.TaskPilotingConstants;


/**
 * 
 * @author Sopra Group
 */
public class ExternalToolsController extends AController {

	/** logger for current class */
	private static Logger logger = Logger.getLogger(ExternalToolsController.class);

	/** */
	private ExternalToolsEngineListener engineListener;

	private IPlayerInstruction playerInProgress;
	
	private ExternalToolsView view;
	
	/**
	 * Constructor
	 */
	public ExternalToolsController(IClientControllersProvider provider) {
		super(provider);
		view = new ExternalToolsView();
	}

	@Override
	public boolean init() throws ClientException {
		setEngineListener(new ExternalToolsEngineListener(this));
		getEngine().addListener(getEngineListener());
		return execute(new ActionInitExternalTools());
	}

	@Override
	public boolean destroy() {
		getEngine().removeListener(getEngineListener());
		setEngineListener(null);
		return true;
	}

	/**
	 * 
	 * @return
	 */
	public boolean actionSetInputTool(String toolId , String taskActionId, String toolPn) {
		logger.info("actionSetInputTool : " + toolId + " - "+taskActionId +" - "+ toolPn);
		boolean hasExecute =  execute(new ActionSetInputTool(taskActionId, toolPn));
		if(toolPn != null && !toolPn.isEmpty() && hasExecute){
			IModelObjectService newService = getModelProvider().getModelService(toolId);
			if(newService instanceof ModelTaskActionMeasureService){
				ModelTaskActionMeasureService toolService = (ModelTaskActionMeasureService) newService;
				//if the ModelActionMeasure contain only a Measuretool, it execute automatically the actionrunmeasuretool 
				if(toolService.getMeasureRdd() == null && toolService.getMeasureSap() == null && toolService.getMeasureTool() != null)
					hasExecute = actionRunMeasureTool(toolId);
			} else if(newService instanceof ModelTaskPilotingService && TaskPilotingConstants.TOOL_TYPE_SCREW_DRIVER.equals(
					((ModelTaskPilotingService)newService).getTool())){
				hasExecute = actionRunIsConnectedTool(toolPn, toolId);
			}
		}
		return hasExecute;
	}
	
	private boolean actionRunIsConnectedTool(String toolName, String serviceId) {
		logger.info("setInputToolAndUpdateAutoMode : "+toolName);
		return execute(new ActionRunIsConnectedTool(serviceId));
	}

	public boolean actionUpdateAutoMode(String taskPilotingId, boolean autoMode) {
		logger.info("setInputToolAndUpdateAutoMode : "+taskPilotingId +" - "+ autoMode);
		return execute(new ActionUpdateAutoMode(taskPilotingId, autoMode));
	}

	public boolean actionSetInputTaskActionPilotingResult(String taskActionId, String value) {
		logger.info("actionSetInputTaskActionPilotingResult : " +taskActionId +" - "+ value);
		return execute(new ActionSetInput(taskActionId, value));
	}
	
	/**
	 * 
	 * @return
	 */
	public boolean actionRunMeasureRdd(String serviceId) {
		logger.info("actionRunMeasureRdd : " + serviceId);
		return execute(new ActionRunMeasureRDD(serviceId));
	}

	/**
	 * 
	 * @return
	 */
	public boolean actionRunMeasureTool(String serviceId) {
		logger.info("actionRunMeasureTool : " + serviceId);
		return execute(new ActionRunMeasureTool(serviceId));
	}
	
	/**
	 * 
	 * @return
	 */
	public boolean actionStopMeasureTool(String serviceId) {
		logger.info("actionStopMeasureTool : " + serviceId);
		return execute(new ActionStopMeasureTool(serviceId));
	}
	/**
	 * 
	 * @param newValue 
	 * @param taskActionValue 
	 * @return
	 */
	public boolean actionCreateConfirmationModalView(String serviceId, String taskActionValue, String newValue) {
		logger.info("actionCreateConfirmationModalView : " + serviceId);
		return execute(new CreateConfirmationModalView(serviceId, taskActionValue, newValue));
	}
	
	/**
	 * 
	 * @return
	 */
	public void actionRecordUserSelection(String confirmation) {
		ModalManager.getInstance().setUserAnswer(confirmation);
	}


	/**
	 * 
	 * @return
	 */
	public boolean actionRunPilotingTool(String serviceId) {
		logger.info("actionRunPilotingTool : " + serviceId);
		return execute(new ActionRunPilotingTool(serviceId));
	}

	/**
	 * 
	 * @return
	 */
	public boolean actionStopPilotingTool(String serviceId) {
		logger.info("actionStopPilotingTool : " + serviceId);
		return execute(new ActionStopPilotingTool(serviceId));
	}

	/**
	 * @return the engineListener
	 */
	public ExternalToolsEngineListener getEngineListener() {
		return engineListener;
	}

	/**
	 * @param engineListener the engineListener to set
	 */
	public void setEngineListener(ExternalToolsEngineListener engineListener) {
		this.engineListener = engineListener;
	}

	public IPlayerInstruction getPlayerInProgress() {
		return playerInProgress;
	}

	public void setPlayerInProgress(IPlayerInstruction playerInProgress) {
		this.playerInProgress = playerInProgress;
	}

	/**
	 * @return the view
	 */
	public ExternalToolsView getView() {
		return view;
	}

	/**
	 * @param view the view to set
	 */
	public void setView(ExternalToolsView view) {
		this.view = view;
	}
}
