package turbomeca.gamme.assembly.client.module.intervention.view;

import turbomeca.gamme.assembly.client.ClientAssemblyControllersProvider;
import turbomeca.gamme.assembly.client.model.edit.runnable.ModelRunnableScheduleService;
import turbomeca.gamme.assembly.client.module.edition.AssemblyEditionController;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.IClientControllersProvider;
import turbomeca.gamme.ecran.client.constants.PropertyConstants;
import turbomeca.gamme.ecran.client.interfaces.server.editing.EditingServerInterfaceService;
import turbomeca.gamme.ecran.client.module.action.AActionView;
import turbomeca.gamme.ecran.client.tuning.utils.TuningConstants;
import turbomeca.gamme.ecran.services.constants.XsltConstants;


/***
 * This class is almost similar to
 * turbomeca.gamme.ecran.client.module.intervention.view.NewPassingView but it
 * also check that the schedule is not out of date.
 * <p>
 * An out of date schedule means a sub phase not taken in edition by current
 * user has been updated by another user. <br>
 * FIXME: this case is not specified in SFD. I suppose it's to force to
 * synchronize the schedule (in order to be sure to retrieve the correct passing
 * number as another user may have performed a new passing). Such behavior
 * should be set at ecran level and this class removed to use ecran ones instead
 * 
 * @author ahermo
 *
 */
public class TuningScheduleView extends AActionView {

	private IClientControllersProvider controllerProvider;

	public TuningScheduleView(IClientControllersProvider iClientControllersProvider) {
		super(XsltConstants.XSLT_INTERVENTION_TUNING_SCHEDULE.value());
		setControllerProvider(iClientControllersProvider);
	}

	@Override
	public boolean run() throws ClientException {
		boolean success = true;
		AssemblyEditionController editionController =  (AssemblyEditionController) getControllerProvider().
				getController(ClientAssemblyControllersProvider.INTERFACE_EDITION);
		EditingServerInterfaceService.getInstance().loadEditing();

		if(((ModelRunnableScheduleService) getModelProvider().getModelScheduleService().getRunnableService()).
				canRunForMultiEdition(editionController, getContext().getContextEditing().isOutOfDate())){
			getView().bindService(getModelProvider().getModelScheduleService());
			String listSubPhaseId = new String();
			if(getContext().getContextEditing().getObjectEdited() != null){
				for(String subphaseId : getContext().getContextEditing().getObjectEdited()){
					listSubPhaseId = listSubPhaseId.concat(subphaseId + 
							TuningConstants.SPACE + TuningConstants.SELECTED_SUBPHASES_SEPARATOR + TuningConstants.SPACE);
				}
			}
			getView().addParameter(XsltConstants.XSLT_PARAMETER_LIST_SUBPHASE_ID.value(), listSubPhaseId);
			success = getView().displayModal(PropertyConstants.PROPERTY_MODAL_TUNING_STATIC, true);
		}
		else{
			success = false;
		}
		return success;

	}

	public IClientControllersProvider getControllerProvider() {
		return controllerProvider;
	}

	public void setControllerProvider(IClientControllersProvider controllerProvider) {
		this.controllerProvider = controllerProvider;
	}
}
