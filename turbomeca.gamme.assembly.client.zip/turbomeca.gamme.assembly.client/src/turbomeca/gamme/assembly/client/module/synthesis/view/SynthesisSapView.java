package turbomeca.gamme.assembly.client.module.synthesis.view;

import turbomeca.gamme.assembly.client.config.AssemblyPropertyConstants;
import turbomeca.gamme.assembly.services.constants.AssemblyXsltConstants;
import turbomeca.gamme.assembly.services.model.data.types.StatusType;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.model.interfaces.IModelScheduleService;
import turbomeca.gamme.ecran.client.module.action.AActionView;
import turbomeca.gamme.ecran.client.utils.Utils;
import turbomeca.gamme.ecran.services.constants.XsltConstants;


public class SynthesisSapView extends AActionView {

    private IModelScheduleService scheduleService;
    
	public SynthesisSapView(IModelScheduleService scheduleService) {
		super(AssemblyXsltConstants.XSLT_SAP_SYNTHESIS.value());
		this.scheduleService = scheduleService;
	}

	@Override
	public boolean run() throws ClientException {
		getView().reset();
		getView().bindService(getScheduleService());
		getView().addEditingContextParameters();
		getView().addParameter(XsltConstants.XSLT_PARAMETER_VALIDABLE.value(), 
                Boolean.valueOf(getScheduleService().getStatusService().getStatus().equals(StatusType.SAP_TO_SIGN.value())));
		getView().addParameter(AssemblyXsltConstants.XSLT_PARAMETER_MULTI_INSTANCES.value(), false);
		getView().addParameter(AssemblyXsltConstants.XSLT_PARAMETER_INSTANCES.value(), Utils
                .getStringValues(getConfiguration().getConfigRange().getItems()));
		return getView().displayModal(AssemblyPropertyConstants.PROPERTY_MODAL_TITLE_SAP_SYNTHESIS, true);
	}

    /**
     * @return the scheduleService
     */
    private IModelScheduleService getScheduleService() {
        return scheduleService;
    }
}
