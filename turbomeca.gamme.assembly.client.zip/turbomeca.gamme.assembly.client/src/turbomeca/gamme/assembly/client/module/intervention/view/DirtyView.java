package turbomeca.gamme.assembly.client.module.intervention.view;

import turbomeca.gamme.assembly.client.config.AssemblyPropertyConstants;
import turbomeca.gamme.assembly.services.constants.AssemblyXsltConstants;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.module.action.AActionServiceView;
import turbomeca.gamme.ecran.services.constants.XsltConstants;

public class DirtyView extends AActionServiceView {
	
	public DirtyView(String subPhaseId) {
		super(subPhaseId, AssemblyXsltConstants.XSLT_INTERVENTION_DIRTY_VIEW.value());
	}

	public boolean run() throws ClientException {
		getView().bindService(getModelService());
		getView().addParameter(XsltConstants.XSLT_PARAMETER_SUBPHASE_ID.value(), getServiceId());
		return getView().displayModal(AssemblyPropertyConstants.PROPERTY_MODAL_TITLE_DIRTY_VIEW, true);
	}
}
