package turbomeca.gamme.assembly.client.module.externaltools;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import turbomeca.gamme.assembly.client.interfaces.server.action.sap.getCarac.DataCaracSap;
import turbomeca.gamme.assembly.client.interfaces.server.sap.ServerSAPAssemblyInterfacesService;
import turbomeca.gamme.assembly.client.model.edit.instructions.AModelTaskActionService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelResourcesService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskActionMeasureService;
import turbomeca.gamme.assembly.services.model.data.MeasureSap;
import turbomeca.gamme.assembly.services.model.data.types.StatusType;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.constants.PropertyConstants;
import turbomeca.gamme.ecran.client.engine.AModelServiceDefaultEngineListener;
import turbomeca.gamme.ecran.client.hmi.HmiLogger;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;


/**
 * 
 * @author Sopra Group
 */
public class ExternalToolsEngineListener extends AModelServiceDefaultEngineListener {

	/** */
	private ExternalToolsController controller;
	
	/**
	 * Constructor
	 */
	public ExternalToolsEngineListener(ExternalToolsController controller) {
		super();
		setController(controller);
	}

	/**
	 * @return the HMI logger
	 */
	protected HmiLogger getLoggerHmi() {
	    return getController().getLoggerHmi();
	}
	

	@Override
	public void objectFinished(IModelObjectService objectService)
			throws ClientException, ClientInterruption {

		if (objectService instanceof ModelResourcesService) {
			HashMap<String, List<ModelTaskActionMeasureService>> mapTaskAction = new HashMap<String, List<ModelTaskActionMeasureService>>();
			List<MeasureSap> listSap = new ArrayList<MeasureSap>();
			List<ModelTaskActionMeasureService> listTaskActionMeasureSap = new ArrayList<ModelTaskActionMeasureService>();
			
			ModelSubPhaseService subPhaseService = (ModelSubPhaseService) objectService
					.getAncestor(ModelSubPhaseService.class);
			List<IModelObjectService> listTaskActionMeasure = subPhaseService
					.getChildrenDeep(ModelTaskActionMeasureService.class);

			for (IModelObjectService listObjectService : listTaskActionMeasure) {
				ModelTaskActionMeasureService taskMeasureService = (ModelTaskActionMeasureService) listObjectService;
				if (!taskMeasureService.getRunnableService().isFinished()) {
					if(taskMeasureService.getMeasureSap()!=null){
						String key = taskMeasureService.buildKeyForMeasureSAP();
						if (key != null) {
							if (!mapTaskAction.containsKey(key)) {
								List<ModelTaskActionMeasureService> listTaskActionMeasureService = new ArrayList<ModelTaskActionMeasureService>();
								listTaskActionMeasureService.add(taskMeasureService);
								mapTaskAction.put(key, listTaskActionMeasureService);
							} else {
								mapTaskAction.get(key).add(taskMeasureService);
							}
							listSap.add(taskMeasureService.getMeasureSap());
							
							listTaskActionMeasureSap.add(taskMeasureService);
						} else {
							taskMeasureService.setStateMeasureSap(StatusType.KO);
							getLoggerHmi().error(PropertyConstants.PROPERTY_ERROR_TOOLS_BAD_CONFIGURATION_MEASURE_SAP_FROM_MARKS);
						}
					}
				}
					
			}

			// Call Web Service Sap if measure Sap Found
			if (listSap.size() > 0 && ServerSAPAssemblyInterfacesService.getInstance().isInterfaceEnabled()) {
				DataCaracSap config = ServerSAPAssemblyInterfacesService.getInstance().getCaract(listSap);
				if (config != null && config.getResponse() != null) {
					Map<String, String> mapResponse = config.getResponse();
					for (Entry<String, List<ModelTaskActionMeasureService>> entry : mapTaskAction.entrySet()) {
						String keyMap = entry.getKey();
						List<ModelTaskActionMeasureService> taskActionMeasureServiceToUpdate = entry.getValue();
						if (mapResponse.containsKey(keyMap)) {
							for (ModelTaskActionMeasureService taskActionMeasure : taskActionMeasureServiceToUpdate) {
								AModelTaskActionService taskAction = (AModelTaskActionService) getController().getModelProvider()
										.getModelService(taskActionMeasure.getTaskActionId());
								taskAction.setValue(mapResponse.get(keyMap), true);
								taskActionMeasure.setStateMeasureSap(StatusType.OK);
							}
						} else {
							for (ModelTaskActionMeasureService taskActionMeasure : taskActionMeasureServiceToUpdate) {
								taskActionMeasure.setStateMeasureSap(StatusType.KO);
							}
						}
					}
				} else {
					// Change Statut list Sap
					for (ModelTaskActionMeasureService currentMeasure : listTaskActionMeasureSap) {
						currentMeasure.setStateMeasureSap(StatusType.KO);
					}
					getLoggerHmi().error(PropertyConstants.PROPERTY_ERROR_COMMUNICATION);
				}
			} else {
				getLoggerHmi().info(PropertyConstants.PROPERTY_MESSAGE_TOOLS_NO_CHANGED_FOUND);
			}
		}
	}

    /**
     * @return the controller
     */
    public ExternalToolsController getController() {
        return controller;
    }

    /**
     * @param controller the controller to set
     */
    public void setController(ExternalToolsController controller) {
        this.controller = controller;
    }
}
