package turbomeca.gamme.assembly.client.module.intervention.action;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelMarkService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.client.model.edit.notifications.AModelNotificationService;
import turbomeca.gamme.assembly.client.model.edit.notifications.ModelNotificationMarkService;
import turbomeca.gamme.assembly.client.model.edit.utils.ModelUtils;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.edit.instructions.IModelSubPhaseService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.services.common.constants.GlobalConstants;

/**
 * Processes a change mark action when the mark is updated with multiple PN
 * values.
 * 
 * It creates a change mark with multiple pn values notification for the
 * specified mark and to all the marks that references it.
 * 
 * Warning: this action will not set pn values in the mark.
 * 
 * @author ademartin
 *
 */
public class ActionChangeMarkMultiplePnValues extends ActionChangeMark {

	private static final Logger logger = Logger.getLogger(ActionChangeMarkMultiplePnValues.class);
	
	Set<String> pnValues;
	
	public ActionChangeMarkMultiplePnValues(String serviceId, String instanceId, String alternativeId, String subPhaseId, String extraComment, Set<String> pnValues) {
		super(serviceId, instanceId, alternativeId, false, null, false, null, false, null, subPhaseId, extraComment);
		this.pnValues = pnValues;
	}

	@Override
	public boolean run(IController controller) throws ClientException,
			ClientInterruption {
		
		logger.debug("run - actionChangeMarkMultiplePnValues[subPhaseId= " + getSubPhaseId() + ", markId= " + getMarkServiceId() + 
				", instanceId=" + getInstanceId() + ", alternativeId=" + getAlternativeId() + ", pnValues=" + pnValues + "]");
		
		boolean succeed = false;
		List<IModelObjectService> listServiceToUpdate = new ArrayList<IModelObjectService>();
		controller.getNotificationsService().setDisableNotifications(true);
		
		try {
			ModelMarkService markService = (ModelMarkService) getModelProvider().getModelService(getMarkServiceId());
	    	String notificationId = UUID.randomUUID().toString();
	    	
	    	ModelSubPhaseService modelServiceSubPhase = (ModelSubPhaseService) getModelProvider().getModelService(getSubPhaseId());
	    	ModelNotificationMarkService notificationService =  new ModelNotificationMarkService(markService, notificationId, 
					getInstanceId(), getAlternativeId(), pnValues, getOptionnalComment());
	    	
	    	boolean createOnServer = createNotification(notificationService, modelServiceSubPhase);
			String mustSynchronize = null;
			
	        if(!createOnServer) {
	        	mustSynchronize = GlobalConstants.NOTIFICATION_STATUS_CREATED;
	        }
	        
	        for (ModelMarkService markReferenceService : markService.getMarkReferences()) {
				if (markReferenceService.impactedByInstance(getInstanceId())) {

					IModelSubPhaseService subPhaseService = ModelUtils.getSubPhaseParent(markReferenceService);
					if (subPhaseService.getRunnableService().isRunnable()) {
						AModelNotificationService notificationServiceLinked = 
								new ModelNotificationMarkService(markReferenceService, notificationId, 
										getInstanceId(), getAlternativeId(), pnValues, getOptionnalComment());

						subPhaseService.getStatusService().setAlterable(null);
						listServiceToUpdate.add(subPhaseService);

						notificationServiceLinked.bindService(markReferenceService, mustSynchronize);
					}
				}

				// Update delete notifications on server 
				synchronizeOnServer(false);
	        }
	    }
		finally {
			controller.getNotificationsService().setDisableNotifications(false);
//			if (succeed) {
//				for (IModelObjectService modelService : listServiceToUpdate) {
//					controller.getNotificationsService().notifyServiceChanged(modelService);
//				}
//			}
		}
		return succeed;
	}
}
