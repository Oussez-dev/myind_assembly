package turbomeca.gamme.assembly.client.module.intervention.view;

import turbomeca.gamme.assembly.client.module.intervention.InterventionReworkDynamicManager;
import turbomeca.gamme.assembly.services.model.data.SubPhase;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.constants.PropertyConstants;
import turbomeca.gamme.ecran.services.common.utils.xml.ModelXmlDaoService;
import turbomeca.gamme.ecran.services.constants.XsltConstants;

public class ReworkDynamicViewSubPhaseEdition extends AReworkDynamicView {
	
    /** */
    private ModelXmlDaoService daoService;
    
	public ReworkDynamicViewSubPhaseEdition(InterventionReworkDynamicManager reworkManager) {
		super(XsltConstants.XSLT_INTERVENTION_REWORK_DYNAMIC_SUBPHASE_EDITION.value(), reworkManager);
		setDaoService(new ModelXmlDaoService());
        getDaoService().setObjectClass(SubPhase.class);
	}
	
	@Override
	public boolean run() throws ClientException {
	    getReworkManager().buildXmlMerged();
	    getView().bindSource(daoService.getXmlSource(getReworkManager().getSubPhaseEdited()));
		return getView().displayModal(PropertyConstants.PROPERTY_MODAL_TITLE_REWORK_DYNAMIC_SUBPHASE_EDITION, true);
	}

    /**
     * @return the daoService
     */
    public ModelXmlDaoService getDaoService() {
        return daoService;
    }

    /**
     * @param daoService the daoService to set
     */
    public void setDaoService(ModelXmlDaoService daoService) {
        this.daoService = daoService;
    }
}
