package turbomeca.gamme.assembly.client.module.instruction.action;

import turbomeca.gamme.assembly.client.ClientAssemblyException;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelMarkService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelResourcesService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskActionService;
import turbomeca.gamme.assembly.client.model.edit.utils.ModelUtils;
import turbomeca.gamme.assembly.services.model.data.Resources;
import turbomeca.gamme.assembly.services.model.data.types.StatusType;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.edit.instructions.IModelTaskActionService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.module.IController;

public abstract class AActionInput extends turbomeca.gamme.ecran.client.module.instruction.action.AActionInput {


	protected AActionInput(String taskActionId) {
		super(taskActionId);
	}
	
	protected AActionInput(String taskActionId, String value) {
		super(taskActionId, value);

	}

	@Override
	protected void checkRun(IModelTaskActionService taskActionService) throws ClientException, ClientInterruption {
	    // Check resources validation is done (if taskAction don't belong to resources) 
	    if (!ModelUtils.isResourcesAction(taskActionService)) {
    	    ModelSubPhaseService subPhaseService = (ModelSubPhaseService)ModelUtils.getSubPhaseParent(taskActionService);
	    	ModelResourcesService resourcesService = subPhaseService.getResourcesService();
    	    if (resourcesService != null && !resourcesService.getRunnableService().isFinished()) {
    	        checkResources(resourcesService);
    	        if (!resourcesService.getRunnableService().isFinished()) {
    	            taskActionService.resetValue(true);
                    throw new ClientAssemblyException(ClientAssemblyException.EXCEPTION_INPUT_RESOURCES_NOT_FINISHED);
    	        }
    	    }
	    }
	    super.checkRun(taskActionService);
	}
	
	/**
	 * 
	 * @param resourcesService
	 */
	protected void checkResources(ModelResourcesService resourcesService) {
	    ModelSubPhaseService subPhaseService = (ModelSubPhaseService) resourcesService.getAncestor(ModelSubPhaseService.class);
	    boolean isAssembly = subPhaseService.isAssemblySubPhase();
	    Resources resources = (Resources) resourcesService.getWrapperService().getObject();
	    if (resources.getIngredients() == null && resources.getTools() == null) {
	        if (!isAssembly || resources.getMarks() == null) {
	            resourcesService.getWrapperService().getState().setStatus(StatusType.DONE);
	        }
	    }
    }


	protected void applyReferenceValue(IController controller, IModelObjectService modelObjectService,
			ModelTaskActionService taskActionService) throws ClientException,
			ClientInterruption {
		taskActionService.setValue(getValue());
		applyValueToReference(controller, modelObjectService, taskActionService);
	}
	
	protected void applyValueToReference(IController controller, IModelObjectService modelObjectService, ModelTaskActionService taskActionService) throws ClientException, ClientInterruption {
	    if (modelObjectService instanceof ModelMarkService) {
            ((ModelMarkService) modelObjectService).applyValueToReference(controller, taskActionService);
        }
	}
	
	protected void forceResetRessource(ModelTaskActionService taskActionService) throws ClientException, ClientInterruption {
		ModelResourcesService ressources = (ModelResourcesService) taskActionService.getAncestor(ModelResourcesService.class);
		if(ressources !=null) {
			ressources.getStatusService().resetState(false, true, null);
		}
	}
	
}
