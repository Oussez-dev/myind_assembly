package turbomeca.gamme.assembly.client.module.synchronize;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.model.edit.IModelAssemblyWrapperScheduleService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelOperationService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.client.model.edit.notifications.AModelNotificationService;
import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperElectronicNotificationService;
import turbomeca.gamme.assembly.services.model.data.ElectronicNotification;
import turbomeca.gamme.assembly.services.model.data.Geode;
import turbomeca.gamme.assembly.services.model.data.ObjectToSynchronize;
import turbomeca.gamme.assembly.services.model.data.ObjectsToSynchronize;
import turbomeca.gamme.ecran.client.model.interfaces.IModelScheduleService;
import turbomeca.gamme.ecran.client.model.provider.ModelXmlProvider;
import turbomeca.gamme.ecran.client.synchronize.ASynchronizeObjectService;
import turbomeca.gamme.ecran.services.common.constants.GlobalConstants;
import turbomeca.gamme.ecran.services.notification.bean.BufferNotification;

public class AssemblySynchronizeObjectService extends ASynchronizeObjectService {

	private static Logger logger = Logger.getLogger(AssemblySynchronizeObjectService.class);

	@Override
	public List<BufferNotification> getListNotification(IModelScheduleService modelScheduleService) {
		//get id notification to synchronize
		HashMap<String, String> listIdToSynchronize = new HashMap<String, String>();
		ModelXmlProvider modelXmlProvider = ModelXmlProvider.getInstance();
		IModelAssemblyWrapperScheduleService wrapper = (IModelAssemblyWrapperScheduleService) modelXmlProvider.getModelScheduleService().getWrapperService();
		ObjectsToSynchronize objectsToSynchronize = wrapper.getObjectsToSynchronize();
		if(objectsToSynchronize != null) {
			for(ObjectToSynchronize objectToSynchronize : objectsToSynchronize.getObjectToSynchronize()) {
				if(objectToSynchronize.getObjectType() != null && objectToSynchronize.getObjectType().equals(GlobalConstants.ELECTRONIC_NOTIFICATION)) {
					String synchronize = objectToSynchronize.getSynchronize();
					String id = objectToSynchronize.getRefId();
					if(id != null && !id.isEmpty() && synchronize != null && !synchronize.isEmpty()) {
						listIdToSynchronize.put(id, synchronize);
					}
				}
			}
		}
		List<BufferNotification> listNotification = new ArrayList<BufferNotification>();
		//get modelService to synchronize
		for(String id : listIdToSynchronize.keySet()){
			AModelNotificationService modelNotifService = (AModelNotificationService) modelXmlProvider.getModelService(id);
			if(modelNotifService != null) {
				listNotification.add(createBufferNotificationWithModelService(modelNotifService, modelScheduleService, listIdToSynchronize.get(id)));
			}
			else{
				if(listIdToSynchronize.get(id).equals(GlobalConstants.NOTIFICATION_STATUS_CANCELED))
				{
					listNotification.add(createBufferNotificationWithModelService(id, listIdToSynchronize.get(id)));
				}
			}
		}
		return listNotification;
	}

	private BufferNotification createBufferNotificationWithModelService(String id, String synchronize) {
		BufferNotification bufferNotification = new BufferNotification();
		bufferNotification.setId(id);
		bufferNotification.setSynchronize(synchronize);
		logger.debug("Synchronize : update notification "+id + " on " + synchronize + " on file server");
		return bufferNotification;
	}

	private BufferNotification createBufferNotificationWithModelService(AModelNotificationService modelNotificationService, IModelScheduleService modelScheduleService, String synchronize) {
		BufferNotification bufferNotification = new BufferNotification();
		IModelAssemblyWrapperScheduleService wrapperSchedule = (IModelAssemblyWrapperScheduleService) modelScheduleService.getWrapperService();
		ModelWrapperElectronicNotificationService wrapperNotificationService = (ModelWrapperElectronicNotificationService) modelNotificationService.getWrapperService();
		ElectronicNotification elecNotif = (ElectronicNotification) wrapperNotificationService.getObject();
		String notifId = wrapperNotificationService.getId();
		bufferNotification.setId(notifId);
		bufferNotification.setSynchronize(synchronize);
		String notifRequestComment = elecNotif.getRequest().getComment();
		bufferNotification.setCommentInput(notifRequestComment);
		String optionnalComment = elecNotif.getRequest().getOptionnalComment();
		bufferNotification.setOptionnalRequestComment(optionnalComment);
		String notifStatus = elecNotif.getStatusNotification().toString();
		bufferNotification.setStatus(notifStatus);
		String notifType = elecNotif.getType().toString();
		bufferNotification.setType(notifType);
		ModelSubPhaseService subphaseService = (ModelSubPhaseService) modelNotificationService.getAncestor(ModelSubPhaseService.class);
		if(subphaseService != null){
			String notifSubPhaseId = subphaseService.getWrapperService().getSubPhase().getDisplayId();
			bufferNotification.setSubPhaseId(notifSubPhaseId);
		}
		ModelOperationService operationService = (ModelOperationService) modelNotificationService.getAncestor(ModelOperationService.class);
		if(operationService != null){
			String notifOperationId = operationService.getWrapperService().getOperation().getDisplayId();
			bufferNotification.setOperationId(notifOperationId);
		}
		String notifOrder = wrapperSchedule.getInstantiation().getOrder();
		bufferNotification.setOrder(notifOrder);
		Geode currentGeode = wrapperSchedule.getIdentification().getGeode(0);
		String notifGeode = currentGeode.getReference() + " - "+ currentGeode.getVersion();
		bufferNotification.setGeodeRefV(notifGeode);
		logger.debug("Synchronize : update notification "+notifId + " on " + synchronize + " on file server");
		return bufferNotification;
	}

	@Override
	public void removeFlagSynchronize(IModelScheduleService modelScheduleService) {
		//		for(IModelObjectService modelObjectNotificationService : modelScheduleService.getChildrenImplementDeep(AModelNotificationService.class)){
		//			AModelNotificationService modelNotifService = (AModelNotificationService) modelObjectNotificationService;
		//			if(modelNotifService != null && modelNotifService.getElectronicNotification() != null 
		//					&& modelNotifService.getElectronicNotification().getSynchronize() != null) {
		//				boolean removeNotif = modelNotifService.getElectronicNotification().getSynchronize().equals(StatusNotificationType.CANCELED.toString());
		//				modelNotifService.removeSynchronize();
		//				if(removeNotif) {
		//					try {
		//						if(modelNotifService.getElectronicNotification() != null && modelNotifService.getElectronicNotification().getRefId() != null){
		//							ModelTaskActionService modelTaskActionServiceReferenced = (ModelTaskActionService) ModelUtils.getModelServiceReferenced(ModelXmlProvider.getInstance(), modelNotifService.getElectronicNotification().getRefId());
		//							ActionDispatcherManager.getInstance().run(new ActionDeleteElectronicNotificationNcr(modelTaskActionServiceReferenced, false));
		//						}
		//					} catch (ClientException e) {
		//						logger.error("Error during remove children notification",e);
		//					}
		//					catch (ClientInterruption e) {
		//						logger.error("Error during remove children notification",e);
		//					}
		//				}
		//			}
		//		}
	}
}
