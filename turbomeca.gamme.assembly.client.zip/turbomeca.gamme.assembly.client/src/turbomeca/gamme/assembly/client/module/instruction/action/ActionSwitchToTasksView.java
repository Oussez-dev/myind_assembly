package turbomeca.gamme.assembly.client.module.instruction.action;

import java.util.List;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.module.instruction.view.TasksView;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.constants.PropertyConstants;
import turbomeca.gamme.ecran.client.model.edit.instructions.IModelOperationService;
import turbomeca.gamme.ecran.client.model.edit.instructions.IModelSubPhaseService;
import turbomeca.gamme.ecran.client.model.edit.instructions.IModelTaskService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.client.module.instruction.action.ActionContinue;
import turbomeca.gamme.ecran.client.module.instruction.view.IInstructionView;

/***
 * This Action perform the switch from the main view to the TasksView
 * 
 * 
 * @author ahermo
 *
 */
public class ActionSwitchToTasksView extends  AActionSwitchView {

	private static Logger logger = Logger.getLogger(ActionSwitchToTasksView.class);
	private final String operationId;

	public ActionSwitchToTasksView(String operationId) {
		this.operationId = operationId;
	}
	
	 @Override
	public boolean run(IController controller) throws ClientException, ClientInterruption {
		boolean resultOk = super.run(controller);
		if(resultOk) {
			IModelObjectService serviceToFocus = getModelProvider().getModelService(operationId);
			controller.execute(new ActionContinue(serviceToFocus));
		}
		 return false;	
	}
	 
	@Override
	protected IInstructionView getViewToSwitchTo() throws ClientException {
		IModelObjectService taskService = getTaskServiceToDisplay();
		if(taskService == null ) {
			throw new ClientException(ClientException.EXCEPTION_SERVICE_NOT_FOUND , "No TaskService found for " + operationId);
		}
		return new TasksView(taskService.getIdentifier());
	}

	private IModelObjectService getTaskServiceToDisplay() {
		IModelObjectService objectService = getModelProvider().getModelService(operationId);
		if(objectService != null && objectService instanceof IModelOperationService) {
        	IModelOperationService operationService = (IModelOperationService) objectService;
        	List<IModelObjectService> subPhasesServices = operationService.getChildrenDeep(IModelSubPhaseService.class);
        	if(!subPhasesServices.isEmpty()) {
        		IModelSubPhaseService subPhaseService = (IModelSubPhaseService) subPhasesServices.get(0);
        		List<IModelObjectService> tasksServices = subPhaseService.getChildrenDeep(IModelTaskService.class);
        		
        		if(!tasksServices.isEmpty()) {
        			return tasksServices.get(0);
        		} else {
        			getLoggerHmi().error(PropertyConstants.PROPERTY_TASKS_VIEW_NO_TASKS);
        			logger.error("No tasks in operation[@id=" + operationId + "]");
        		}
        	} else {
        		logger.error("No sub-phases in operation[@id=" + operationId + "]");
        		getLoggerHmi().error(PropertyConstants.PROPERTY_TASKS_VIEW_NO_TASKS);
        	}
        }
		return null;
	}
}
