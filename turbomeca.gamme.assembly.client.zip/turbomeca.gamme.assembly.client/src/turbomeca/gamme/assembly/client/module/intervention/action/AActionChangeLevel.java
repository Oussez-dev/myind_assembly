package turbomeca.gamme.assembly.client.module.intervention.action;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.config.AssemblyPropertyConstants;
import turbomeca.gamme.assembly.client.model.edit.IModelAssemblyWrapperScheduleService;
import turbomeca.gamme.assembly.client.model.edit.schedule.AAssemblyScheduleService;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelStatusService;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.client.module.action.AActionModify;
import turbomeca.gamme.ecran.services.common.constants.GlobalConstants;
import turbomeca.gamme.ecran.services.common.utils.string.StringUtil;

public abstract class AActionChangeLevel extends AActionModify {

	/** logger for current class */
	private static Logger logger = Logger.getLogger(AActionChangeLevel.class);

	protected static final String LEVEL_VALUE_OTHER = "other";
	
	protected List<String> currentLevel = null;
	protected String comment = null;
	protected Map<String, Boolean> subPhaseModified = new HashMap<String, Boolean>();
	
	/**
	 * 
	 * @param level
	 */
	public AActionChangeLevel(String level) {
		super();
		if (level != null && !level.isEmpty()) {
			setCurrentLevel(new ArrayList<String>(Arrays.asList(level.split(GlobalConstants.SEPARATOR_DOT_COMA))));
		}
	}
	
	/**
	 * 
	 * @param level
	 * @param comment
	 */
	public AActionChangeLevel(String level, String comment) {
		super();
		if (level != null && !level.isEmpty()) {
			setCurrentLevel(new ArrayList<String>(Arrays.asList(level.split(GlobalConstants.SEPARATOR_DOT_COMA))));
		}
		setComment(comment);

	}
	
	@Override
	public boolean run(IController controller) throws ClientException, ClientInterruption {
		
		IModelObjectService scheduleService = getModelProvider().getModelScheduleService();
		IModelAssemblyWrapperScheduleService scheduleWrapper = (IModelAssemblyWrapperScheduleService)scheduleService.getWrapperService();
		
		if(getCurrentLevel() == null){
			return false;
		}
		
		if (!getCurrentLevel().contains(LEVEL_VALUE_OTHER) && StringUtil.compareList(getCurrentLevel(), Arrays.asList(scheduleWrapper.getInstantiation().getLevel()))) {
			getLoggerHmi().info(AssemblyPropertyConstants.PROPERTY_INFO_SAME_LEVEL);
			return false;
		}
		
		/**
		 * The checkConditions, also fill the subPhaseModified attribute used to applyModifications
		 */
		if(!checkConditions(scheduleService)) {
			return false;
		} else {
			applyModifications(scheduleService, controller);
			(new ActionUpdateScheduleTopStartOperation()).run(controller);
			
		}
		return true;
	}
	

	/**
	 * @param scheduleService
	 * @return
	 * @throws ClientException
	 */
	protected abstract boolean checkConditions(IModelObjectService scheduleService) throws ClientException;
	
	/**
	 * @param scheduleService
	 * @throws ClientException
	 */
	protected void applyModifications(IModelObjectService scheduleService, IController controller) throws ClientException {
		controller.getNotificationsService().setDisableDynamicNotifications(true);
		controller.getNotificationsService().setModelReload();
		
		// Model instructions Modifications
		Set<String> subPhaseToModify = getSubPhaseModified().keySet();
		Iterator<String> itSubPhaseModifiy = subPhaseToModify.iterator();
		while (itSubPhaseModifiy.hasNext()) {
			String idServiceModified = itSubPhaseModifiy.next();
			IModelObjectService serviceModified = getModelProvider().getModelService(idServiceModified);
			serviceModified.getWrapperService().setApplicable(getSubPhaseModified().get(idServiceModified).booleanValue());
			if(!getSubPhaseModified().get(idServiceModified).booleanValue()){
				IModelStatusService subphaseStatusService = serviceModified.getStatusService();
				try {
					subphaseStatusService.clean(null);
					subphaseStatusService.resetState(true, true, null);
				} catch (ClientInterruption e) {
					logger.error(e);
				}
			}
		}
		changeLevel();
		scheduleService.setModified();
	}
	
	/**
	 * @param newLevel
	 * @param comment
	 */
	public void changeLevel() {
		AAssemblyScheduleService scheduleService = (AAssemblyScheduleService) getModelProvider().getModelScheduleService();
		IModelAssemblyWrapperScheduleService scheduleWrapper = scheduleService.getWrapperService();
		
		// Save old levels in levelHistory
		scheduleService.saveLevelHistory(scheduleWrapper.getInstantiation().getLevel(), getComment());
		// Remove old levels
		scheduleWrapper.getInstantiation().removeAllLevel();
		// Add new levels
		for (String level : getCurrentLevel()) {
			scheduleWrapper.getInstantiation().addLevel(level);
		}
	}
	
	public Map<String, Boolean> getSubPhaseModified() {
		return subPhaseModified;
	}

	public void setSubPhaseModified(Map<String, Boolean> subPhaseModified) {
		this.subPhaseModified = subPhaseModified;
	}

	public List<String> getCurrentLevel() {
		return currentLevel;
	}

	public void setCurrentLevel(List<String> currentLevel) {
		this.currentLevel = currentLevel;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}
}
