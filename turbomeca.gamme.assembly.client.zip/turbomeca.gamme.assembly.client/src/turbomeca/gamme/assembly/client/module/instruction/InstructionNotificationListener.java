package turbomeca.gamme.assembly.client.module.instruction;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.model.edit.instructions.AModelTaskActionService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskActionMeasureService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskActionService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskPilotingService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelToolService;
import turbomeca.gamme.assembly.client.model.edit.schedule.AAssemblyScheduleService;
import turbomeca.gamme.assembly.client.module.instruction.view.InstructionView;
import turbomeca.gamme.assembly.services.model.data.TaskAction;
import turbomeca.gamme.assembly.services.model.data.TaskActionMeasure;
import turbomeca.gamme.assembly.services.model.data.TaskPiloting;
import turbomeca.gamme.assembly.services.model.data.types.StatusType;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.engine.ModelServiceEngine;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.module.instruction.ADefaultInstructionNotificationListener;
import turbomeca.gamme.ecran.client.module.instruction.IInstructionNotificationListener;
import turbomeca.gamme.ecran.client.module.instruction.view.IInstructionView;

public class InstructionNotificationListener extends ADefaultInstructionNotificationListener implements IInstructionNotificationListener {

	/** logger for current class */
	private static Logger logger = Logger.getLogger(InstructionNotificationListener.class);

	/**
	 * Constructor
	 * 
	 * @param view
	 *            instruction page view
	 */
	public InstructionNotificationListener(IInstructionView view) {
		super(view);
	}
	
	@Override
    protected InstructionView getInstructionView() {
        return (InstructionView) super.getInstructionView();
    }

	@Override
	public void modelReload() {
		getInstructionView().refresh();
	}

	@Override
	public void modelChanged() {
		logger.debug("Hmi Update - apply model changes ... ");
	}

	@Override
	public void editionChanged() {
		getInstructionView().refresh();
		ModelServiceEngine.getInstance().getEngineContext().setCurrentService(null);
	}

	@Override
	public void valueChanged(IModelObjectService service) throws ClientException {
		logger.debug("valueChanged : " + service);
		if (service instanceof ModelTaskActionService) {
			AModelTaskActionService taskActionService = (AModelTaskActionService) service;
			if (taskActionService.getTextValue() == null) {
				getInstructionView().resetInput(service, 0, true);
			} else {
				getInstructionView().setInput(service, 0, taskActionService.getValue(), taskActionService.isValid());
			}
			
			if(service.getParent() instanceof ModelToolService){
				 getInstructionView().setEnable(taskActionService, taskActionService.getWrapperService().isForceEditable());
			}
		} else if (service instanceof ModelTaskActionMeasureService) {
		    for(IModelObjectService child : service.getChildren()) {
		        valueChanged(child);
		    }
		} else if (service instanceof ModelTaskPilotingService) {
			getInstructionView().refreshService(service.getAncestor(ModelTaskService.class));
		}
	}

	@Override
	public void statusChanged(IModelObjectService service) throws ClientException {
		logger.debug("statusChanged : " + service);
		
		if (service instanceof AAssemblyScheduleService) {
			if (service.getRunnableService().isFinished()) {
				if (!service.getRunnableService().canValidate()) {
					getInstructionView().refreshService(service);
				}
			} else {
				getInstructionView().refreshService(service);
			}
		} else if (service instanceof ModelTaskActionMeasureService) {
			taskMeasureStatusChanged((ModelTaskActionMeasureService) service);
		}  else if (service instanceof ModelTaskActionService) {
			   TaskAction taskAction = (TaskAction) service.getWrapperService().getObject();
			    getInstructionView().setEnable(service, !taskAction.hasForceEditable() || taskAction.isForceEditable());
			    AModelTaskActionService taskActionService = (AModelTaskActionService) service;
			    if (taskActionService.isSapTaskAction()) {
	                getInstructionView().updateSapStatus(service, taskActionService.getSapStatus(0));
	            }
        } else if (service instanceof ModelTaskPilotingService) {
        	TaskPiloting taskPilonting = (TaskPiloting) service.getWrapperService().getObject();
		    getInstructionView().setStatus(service, taskPilonting.getState().getStatus().value());
        } else {
			// Update HMI status
			getInstructionView().setStatus(service, service.getStatusService().getStatus());
			// Activate/Disactivate service
			activateService(service);
		}
	}
	
	
	private void taskMeasureStatusChanged(ModelTaskActionMeasureService taskMeasureService) {
		StatusType statusSap = null;
		StatusType statusRdd = null;
		StatusType statusTool = null;
		
		boolean rddDisable = false;
		boolean toolDisable = false;
		
		TaskActionMeasure taskMeasure = (TaskActionMeasure) taskMeasureService.getWrapperService().getObject();
	    if (taskMeasure.getMeasureSap() != null) {
	    	statusSap = taskMeasure.getMeasureSap().getState().getStatus();
	    	if (statusSap != StatusType.KO) {
            	rddDisable = true;
            	toolDisable = true;
            }
        }
	    
        if (taskMeasure.getMeasureRdd() != null) {
        	statusRdd = taskMeasure.getMeasureRdd().getState().getStatus();
        	
        	if (statusRdd == StatusType.OK || (statusSap !=null && statusSap==StatusType.KO && statusRdd != StatusType.KO)) {
            	toolDisable = true;
            } else if(taskMeasure.getMeasureTool() !=null && (statusSap ==null || statusSap !=null && statusSap==StatusType.KO) && statusRdd == StatusType.KO) {
            	rddDisable = true;
            	toolDisable = false;
            }
        }
       
        if (taskMeasure.getMeasureTool() != null) {
        	statusTool = taskMeasure.getMeasureTool().getState().getStatus();
	        if (statusTool == StatusType.OK ) {
	        	rddDisable = true;
	        }
        }
        
        getInstructionView().updateTaskMeasureActions(taskMeasureService, rddDisable, toolDisable);
        getInstructionView().updateTaskMeasureStatus(taskMeasureService, statusSap, statusRdd, statusTool);
	}
	

	@Override
	public void serviceActivation(IModelObjectService modelObjectService) throws ClientException {
	    logger.debug("serviceActivation : " + modelObjectService);
		getInstructionView().activeService(modelObjectService);
	}

	@Override
	public void serviceChanged(IModelObjectService service) throws ClientException {
	    logger.debug("serviceChanged : " + service);
		getInstructionView().refreshService(service);
	}

	@Override
	public void contextChanged(IModelObjectService service, String context) throws ClientException {
		getInstructionView().refreshService(service);
	}

	@Override
	public void writingModeChange(boolean readMode) {
		getInstructionView().switchReadOnlyMode(readMode);
		getInstructionView().refresh();
	}

}
