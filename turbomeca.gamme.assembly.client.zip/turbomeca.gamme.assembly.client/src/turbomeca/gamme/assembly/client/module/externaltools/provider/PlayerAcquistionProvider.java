package turbomeca.gamme.assembly.client.module.externaltools.provider;

import java.util.ArrayList;
import java.util.List;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskActionMeasureService;
import turbomeca.gamme.assembly.client.module.externaltools.config.ConfigurationTaskPiloting;
import turbomeca.gamme.assembly.client.module.externaltools.player.measure.APlayerAcquisition;
import turbomeca.gamme.assembly.client.module.externaltools.player.measure.PlayerAcquisitionRdd;
import turbomeca.gamme.assembly.client.module.externaltools.player.measure.PlayerAcquisitionSap;
import turbomeca.gamme.assembly.client.module.externaltools.player.measure.PlayerAcquisitionTools;
import turbomeca.gamme.assembly.client.module.externaltools.player.piloting.PlayerAcquisitionTaskPiloting;
import turbomeca.gamme.assembly.services.model.data.State;
import turbomeca.gamme.assembly.services.model.data.TaskActionMeasure;
import turbomeca.gamme.assembly.services.model.data.TaskPiloting;
import turbomeca.gamme.assembly.services.model.data.types.StatusType;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.module.externaltools.config.ConfigurationRDD;
import turbomeca.gamme.ecran.client.module.externaltools.config.ConfigurationTools;
import turbomeca.gamme.ecran.services.devices.ExternalsToolsExceptions;

public class PlayerAcquistionProvider {
	
	public static List<APlayerAcquisition> getAcquisition(IModelObjectService service, boolean modeForce, boolean isToolsMeasure, String os) throws ExternalsToolsExceptions {
		
		List<APlayerAcquisition> listAcquisition = new ArrayList<APlayerAcquisition>();
		if(service instanceof ModelTaskActionMeasureService){
		TaskActionMeasure taskMesure = (TaskActionMeasure)service.getWrapperService().getObject();
			if(modeForce==false){
				if (taskMesure.getMeasureSap() != null && taskMesure.getMeasureSap().getState().getStatus()==StatusType.TODO) {
					listAcquisition.add(new PlayerAcquisitionSap(taskMesure.getMeasureSap()));
				}
				if (taskMesure.getMeasureRdd() != null) {
					ConfigurationRDD configuration = new ConfigurationRDD(taskMesure.getMeasureRdd().getCaracteristic(), os);
					State state = taskMesure.getMeasureRdd().getState();
					listAcquisition.add(new PlayerAcquisitionRdd(configuration,state));
				}
			}else{
				if(isToolsMeasure){
					if (taskMesure.getMeasureTool() != null) {
						State state = taskMesure.getMeasureTool().getState();
						String toolType = taskMesure.getMeasureTool().getType();
						String toolName= taskMesure.getMeasureTool().getTaskAction().getInputAction().getInputValue().getValue();
						ConfigurationTools configuration = new ConfigurationTools(toolName, toolType);
						listAcquisition.add(new PlayerAcquisitionTools(configuration,state));
					}
				}else{
					if (taskMesure.getMeasureRdd()!= null) {
						ConfigurationRDD configuration = new ConfigurationRDD(taskMesure.getMeasureRdd().getCaracteristic(), os);
						State state = taskMesure.getMeasureRdd().getState();
						listAcquisition.add(new PlayerAcquisitionRdd(configuration,state));
					}
				}
			}
		} else {
			TaskPiloting taskPiloting = (TaskPiloting) service
					.getWrapperService().getObject();
			ConfigurationTaskPiloting config = new ConfigurationTaskPiloting(
					taskPiloting);
			State state = taskPiloting.getState();
			listAcquisition.add(new PlayerAcquisitionTaskPiloting(config, state));
		}
		return listAcquisition;
	}
}
	
