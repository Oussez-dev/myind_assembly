package turbomeca.gamme.assembly.client.module.externaltools.provider;

import turbomeca.gamme.assembly.client.module.externaltools.communication.ServletCommunication;
import turbomeca.gamme.ecran.client.AClientInstancesProvider;
import turbomeca.gamme.ecran.client.module.externaltools.communication.EthernetCommunication;
import turbomeca.gamme.ecran.client.module.externaltools.communication.SerialCommunication;
import turbomeca.gamme.ecran.client.module.externaltools.config.ConfigurationTools;
import turbomeca.gamme.ecran.services.devices.ExternalsToolsExceptions;
import turbomeca.gamme.ecran.services.devices.IDevices;
import turbomeca.gamme.ecran.services.devices.config.IConfigurationMeasure;

public class PlayerAcquisitionToolsProvider extends AClientInstancesProvider {
	
	public static IDevices getCommunicationWay(IConfigurationMeasure conf) throws ExternalsToolsExceptions  {
		if(conf instanceof ConfigurationTools){
			ConfigurationTools confTools  = (ConfigurationTools)conf;
		if (confTools.getConfigurationPort().getNamePort().equals("Serial")){
				SerialCommunication serial = new SerialCommunication();
				serial.init(conf);
				return serial;
		} else if (confTools.getConfigurationPort().getNamePort().equals("Ethernet")){
				EthernetCommunication eth = new EthernetCommunication();
				eth.init(conf);
				return eth;
		}
		}else{
			ServletCommunication servlet= new ServletCommunication();
			servlet.init(conf);
			return servlet;	
		}
		return null;
	}
}
