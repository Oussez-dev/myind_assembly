package turbomeca.gamme.assembly.client.module.sap.action;

import turbomeca.gamme.assembly.client.model.edit.schedule.AAssemblyScheduleService;
import turbomeca.gamme.assembly.client.module.instruction.action.ActionValidateSchedule;
import turbomeca.gamme.assembly.services.model.data.types.StatusType;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.edit.instructions.IModelOperationService;
import turbomeca.gamme.ecran.client.model.edit.instructions.IModelSubPhaseService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelScheduleService;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.client.module.sap.action.AActionExecuteCommand;
import turbomeca.gamme.ecran.services.command.bean.CommandBean;
import turbomeca.gamme.ecran.services.command.constants.CommandConstants;

/**
 * This action manages schedule update with SAP context
 * @author Sopra Group
 */
public class ActionExecuteCommandAssembly extends AActionExecuteCommand {

	public ActionExecuteCommandAssembly(CommandBean sapCommand) {
		super(sapCommand);
	}

	@Override
	protected void initSapParameters() {
		super.initSapParameters();
		getListSapParameters().put(CommandConstants.PARAMETER_LAST_OPERATION_CLOSED, getLastOperationClosedId());
		
	}
	
	@Override
	protected boolean canCloseObject(IModelObjectService object) throws ClientException {
		boolean canClose = false;
		if (object instanceof IModelSubPhaseService) {
			canClose = StatusType.TO_SIGN.value().equals(object.getStatusService().getStatus());
		}
		return canClose;
	}

	@Override
	protected void closeSchedule(IController controller, IModelScheduleService scheduleService) throws ClientException, ClientInterruption {
		ActionValidateSchedule validateSchedule = new ActionValidateSchedule(null);
		validateSchedule.run(controller);
	}
	
	private String getLastOperationClosedId() {
		String operationId = "";
		IModelOperationService modelOperationService = ((AAssemblyScheduleService)
				getModelProvider().getModelScheduleService()).getLastOperationClosed();
		if (modelOperationService != null) {
			operationId = modelOperationService.getIdentifier();
		}
		return operationId;
	}
}
