package turbomeca.gamme.assembly.client.module.intervention.action;

import java.util.HashMap;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelMarkService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelMarksService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelResourcesService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.client.module.action.AActionModify;
import turbomeca.gamme.ecran.services.common.constants.GlobalConstants;

public class ActionDirty extends AActionModify {

	private String subPhaseId;
	private String[] items;

	public ActionDirty(String subPhaseId, String[] items) {
		setSubPhaseId(subPhaseId);
		setItems(items);
	}

	@Override
	public boolean run(IController controller) throws ClientException, ClientInterruption {
		HashMap<String, String> itemsDirted = new HashMap<String, String>();
		for(String item : items) {
			String[] itemSplit = item.split(GlobalConstants.SEPARATOR_DOT_COMA);
			if (itemSplit.length > 0) {
				String comment = null;
				if (itemSplit.length == 2) {
					comment = itemSplit[1];
				}
				itemsDirted.put(itemSplit[0], comment);
			}
		}

		ModelMarksService marksService = (ModelMarksService) getModelProvider().getModelService(ModelResourcesService.RESOURCES_PREFIX_ID + getSubPhaseId() + ModelMarksService.MARKS_SUFFIX_ID);
		if (marksService != null) {
			for(IModelObjectService markObjectService : marksService.getChildren()) {
				ModelMarkService markService = (ModelMarkService) markObjectService;
				boolean isDirty = itemsDirted.containsKey(markService.getIdentifier());
				String comment = itemsDirted.get(markService.getIdentifier());

				// Update dirty status of its marks links
				for(ModelMarkService markReferenceLink : markService.getMarkReferences()) {
					ModelSubPhaseService subPhaseService = (ModelSubPhaseService) markReferenceLink.getAncestor(ModelSubPhaseService.class);
					if(!subPhaseService.isArchived()){
						((ModelMarkService) markReferenceLink).setDirty(isDirty, comment); 
						controller.getNotificationsService().notifyServiceChanged(subPhaseService);
					}
				}
			}
		}
		return true;
	}

	/**
	 * @return the subPhaseId
	 */
	public String getSubPhaseId() {
		return subPhaseId;
	}

	/**
	 * @param subPhaseId the subPhaseId to set
	 */
	public void setSubPhaseId(String subPhaseId) {
		this.subPhaseId = subPhaseId;
	}

	/**
	 * @return the items
	 */
	public String[] getItems() {
		return items;
	}

	/**
	 * @param items the items to set
	 */
	public void setItems(String[] items) {
		this.items = items;
	}
}
