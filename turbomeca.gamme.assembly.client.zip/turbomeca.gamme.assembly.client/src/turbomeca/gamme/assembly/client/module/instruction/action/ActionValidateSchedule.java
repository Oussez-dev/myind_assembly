package turbomeca.gamme.assembly.client.module.instruction.action;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.ClientAssemblyException;
import turbomeca.gamme.assembly.client.interfaces.server.sap.ServerSAPAssemblyInterfacesService;
import turbomeca.gamme.assembly.client.model.edit.IModelAssemblyWrapperScheduleService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskActionMeasureService;
import turbomeca.gamme.assembly.client.model.edit.schedule.AAssemblyScheduleService;
import turbomeca.gamme.assembly.client.model.edit.wrappers.IModelInstanceIdWrapper;
import turbomeca.gamme.assembly.client.module.instruction.InstructionController;
import turbomeca.gamme.assembly.services.model.data.InputValue;
import turbomeca.gamme.assembly.services.model.data.SN;
import turbomeca.gamme.assembly.services.model.data.TaskAction;
import turbomeca.gamme.assembly.services.model.data.TaskActionMeasure;
import turbomeca.gamme.assembly.services.model.data.Value;
import turbomeca.gamme.assembly.services.model.data.types.StatusType;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.constants.PropertyConstants;
import turbomeca.gamme.ecran.client.interfaces.server.sap.mapper.DataRequestUpdateSapCarac;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelWrapperService;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.client.module.action.AActionModify;

public class ActionValidateSchedule extends AActionModify {

    /** logger for current class */
    private static Logger logger = Logger.getLogger(InstructionController.class);
    
    /** */
	private String comment;

	/**
	 * 
	 * @param comment
	 */
	public ActionValidateSchedule(String comment) {
		setComment(comment);
	}

	@Override
	public boolean run(IController controller) throws ClientException, ClientInterruption {
		IModelObjectService scheduleServiceObject = controller.getModelProvider().getModelScheduleService();
		if (scheduleServiceObject instanceof AAssemblyScheduleService) {
			AAssemblyScheduleService scheduleService = (AAssemblyScheduleService) scheduleServiceObject;
			if (scheduleServiceObject.getRunnableService().canValidate()) {
				scheduleService.getStatusService().updateState(StatusType.DONE.value(), true, getComment(), null);
				getLoggerHmi().info(PropertyConstants.PROPERTY_SCHEDULE_FINISHED);
				sendSapCaraUpdate(scheduleService);
			} else {
				scheduleService.getStatusService().updateState(StatusType.TO_SIGN.value(), true, getComment(), null);
				getLoggerHmi().info(PropertyConstants.PROPERTY_SCHEDULE_TO_VALIDATE);
			}
			
			getContext().forceHmiOpenReadMode(true);
			controller.getNotificationsService().notifyWritingModeChange(true);
			getModelProvider().setStatusChanged(true);
			return true;
		} else {
			throw new ClientAssemblyException(ClientAssemblyException.EXCEPTION_SERVICE_NOT_FOUND);
		}
	}

	/**
	 * 
	 * @param scheduleService
	 */
	private void sendSapCaraUpdate(AAssemblyScheduleService scheduleService) {
		
		if (ServerSAPAssemblyInterfacesService.getInstance().isInterfaceEnabled()) {
		    IModelAssemblyWrapperScheduleService scheduleWrapper = (IModelAssemblyWrapperScheduleService) getModelProvider().getModelScheduleService().getWrapperService();
		    
		    List<DataRequestUpdateSapCarac> configUpdateSapCaracList = new ArrayList<DataRequestUpdateSapCarac>();
		    String pn = scheduleWrapper.getInstantiation().getPn();
		    
		    Integer instanceId = null;
		    if (scheduleWrapper.getInstantiation().getSN().length > 1) {
		        instanceId = 1;
		    }
		    
		    for(SN snInput : scheduleWrapper.getInstantiation().getSN()) {
		        String sn = snInput.getTaskAction().getInputAction().getInputValue().getValue();
	    	    addSapUpdateCarac(scheduleService, configUpdateSapCaracList, pn, sn, instanceId);
	    	    if (instanceId != null) {
	    	        instanceId++;
	    	    }
		    }
	
		    if (!configUpdateSapCaracList.isEmpty()) {
	            if (!ServerSAPAssemblyInterfacesService.getInstance().updateCharac(configUpdateSapCaracList)) {
	                getLoggerHmi().errorMsg("Error during SAP update");
	            }
	        }
		}
    }
	
	/**
	 * 
	 * @param modelService
	 * @param configUpdateSapCaracList
	 */
	private void addSapUpdateCarac( IModelObjectService modelService, 
	                                List<DataRequestUpdateSapCarac> configUpdateSapCaracList,
	                                String pn, String sn, Integer instanceId) {
	    if (modelService instanceof ModelTaskActionMeasureService) {
	        ModelTaskActionMeasureService taskActionMeasureService = (ModelTaskActionMeasureService) modelService;
    	    TaskActionMeasure taskActionMeasure = (TaskActionMeasure) taskActionMeasureService.getWrapperService().getObject();
    	    if (         taskActionMeasure.isSendSap()
    	            &&   taskActionMeasure.getCaracNameSap() != null
    	            &&  (      taskActionMeasure.getMeasureSap() == null
    	                    || taskActionMeasure.getMeasureSap().getState().getStatus() != StatusType.OK)) {
    	            
	            TaskAction taskAction = taskActionMeasure.getTaskAction();
	            logger.debug("Add TaskAction for SAP Notification update : " + taskAction.getId() 
	                    + " for instance " + instanceId + " (sn=" + sn + ")");
	            
	            InputValue inputValue = taskAction.getInputAction().getInputValue();
                if (inputValue != null) {
                    
                    String unit = "";
                    Value value = taskActionMeasure.getTaskAction().getValue();
                    if (value != null && value.getUnit() != null) {
                        unit = value.getUnit();
                    }
                    
    	            DataRequestUpdateSapCarac configUpdateSapCarac = new DataRequestUpdateSapCarac();
    	            configUpdateSapCarac.setPn(pn);
    	            configUpdateSapCarac.setSn(sn);
    	            configUpdateSapCarac.setCaracName(taskActionMeasure.getCaracNameSap());
    	            configUpdateSapCarac.setValue(inputValue.getValue());
    	            configUpdateSapCarac.setUnit(unit);
    	            configUpdateSapCaracList.add(configUpdateSapCarac);
                }
    	    }
        } else {
	        for (IModelObjectService childService : modelService.getChildren()) {
	            IModelWrapperService wrapperService = childService.getWrapperService();
	            if (       instanceId == null 
	                 || !(childService.getWrapperService() instanceof IModelInstanceIdWrapper)
	                 || (    wrapperService instanceof IModelInstanceIdWrapper 
	                      && (    !((IModelInstanceIdWrapper) wrapperService).hasInstanceId()
	                           ||  ((IModelInstanceIdWrapper) wrapperService).getInstanceId() == instanceId))) {
	                addSapUpdateCarac(childService, configUpdateSapCaracList, pn, sn, instanceId);
	            }
	        }
        }
	}

    /**
	 * @param comment
	 *            the comment to set
	 */
	public void setComment(String comment) {
		this.comment = comment;
	}

	/**
	 * @return the comment
	 */
	public String getComment() {
		return comment;
	}
}
