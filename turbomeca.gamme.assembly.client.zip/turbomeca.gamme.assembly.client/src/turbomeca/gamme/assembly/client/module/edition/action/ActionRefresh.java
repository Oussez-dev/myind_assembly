package turbomeca.gamme.assembly.client.module.edition.action;

import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.context.ContextLoaderProvider;
import turbomeca.gamme.ecran.client.model.interfaces.IModelScheduleService;
import turbomeca.gamme.ecran.client.module.IController;

public class ActionRefresh extends turbomeca.gamme.ecran.client.module.edition.action.ActionRefresh {

	public ActionRefresh() {
		super();
	}

	@Override
	public boolean run(IController controller) throws ClientException, ClientInterruption {
		boolean succeed = false;
		if (ContextLoaderProvider.getInstance().reload()) {
		    IModelScheduleService schedule = getModelProvider().getModelScheduleService();
			schedule.setSchedule(getModelProvider().getObject());
			schedule.getXmlSourceProvider().setXmlSource(getContext().getContextRange().getRange());
			schedule.getLoaderService().load(getModelProvider());
			controller.getNotificationsService().setModelReload();
			succeed = true;
		}
		return succeed;
	}
}
