package turbomeca.gamme.assembly.client.module.intervention;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.UUID;

import turbomeca.gamme.assembly.client.ClientAssemblyException;
import turbomeca.gamme.assembly.client.model.edit.schedule.AAssemblyScheduleService;
import turbomeca.gamme.assembly.client.model.edit.schedule.AssemblyScheduleService;
import turbomeca.gamme.assembly.services.model.data.Para;
import turbomeca.gamme.assembly.services.model.data.State;
import turbomeca.gamme.assembly.services.model.data.SubPhase;
import turbomeca.gamme.assembly.services.model.data.Task;
import turbomeca.gamme.assembly.services.model.data.TaskChoice;
import turbomeca.gamme.assembly.services.model.data.Tasks;
import turbomeca.gamme.assembly.services.model.data.TasksItem;
import turbomeca.gamme.assembly.services.model.data.Title;
import turbomeca.gamme.assembly.services.model.data.types.StatusType;
import turbomeca.gamme.assembly.services.schedule.creation.utils.AssemblyGlobalServices;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.constants.PropertyConstants;
import turbomeca.gamme.ecran.client.interfaces.server.runtime.RuntimeServerInterfaceService;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.client.module.action.AAction;
import turbomeca.gamme.ecran.services.common.utils.date.DateUtils;
import turbomeca.gamme.ecran.services.common.utils.xml.ModelXmlDaoService;

public class InterventionReworkDynamicManager extends AAction {

    private static final String FILE_HEADER_XML = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
    private static final String LINE_BREAK = "\r\n";
    private static final String BALISE_XML_REWORK_OPENING = "<rework>";
    private static final String BALISE_XML_REWORK_CLOSING = "</rework>";
    private static final String BALISE_XML_FUll_ROOT_OPENING = "<root>";
    private static final String BALISE_XML_FULL_ROOT_CLOSING = "</root>";
    private static final String TAG_EMPTY_DISASSEMBLY = "<disassembly><operations/></disassembly>";
    private static final String TAG_EMPTY_ASSEMBLY = "<assembly><operations/></assembly>";

    /** XML flow of current schedule with reverse flow */
    private String xmlScheduleFlowMerge;
    /** Version of reverse schedule */
    private String reverseScheduleVersion;
    /** String level selection */
    private String level;
    /** SubPhase identifier selected of reverse schedule */
    private String subPhaseReverseId;
    /** SubPhase identifier selected of current schedule */
    private String subPhaseCurrentId;
    /** SubPhase edited by user */
    private SubPhase subPhaseEdited;
    /** Operation title */
    private String operationTitle;

    /**
     * @throws ClientException
     * 
     */
    public InterventionReworkDynamicManager() {
        super();
        xmlScheduleFlowMerge = null;
    }

    public void init() throws ParseException {
    	String title = getConfiguration().getProperty(PropertyConstants.PROPERTY_REWORK_OPERATION_TITLE);
    	String dateFormat = getConfiguration().getProperty(PropertyConstants.PROPERTY_DATE_FORMAT);
        setOperationTitle(String.format(title, 
        								(new SimpleDateFormat(dateFormat)).format(DateUtils.getCurrentDate())));
        initSubPhaseEdited();
    }

    public void resetSubPhaseEdited() {
        setSubPhaseEdited(new SubPhase());
    } 
       
    private void initSubPhaseEdited() {
        resetSubPhaseEdited();
        Title titleSubPhase = new Title();
        titleSubPhase.addPara(new Para());
        getSubPhaseEdited().setTitle(titleSubPhase);
        getSubPhaseEdited().setId("subPh" + UUID.randomUUID().toString());
        getSubPhaseEdited().setPassing(1);
        
        State state = new State();
        state.setStatus(StatusType.TODO);
        getSubPhaseEdited().setState(state);

        Task task = new Task();
        task.setId(UUID.randomUUID().toString());

        state = new State();
        state.setStatus(StatusType.TODO);
        task.setState(state);

        TasksItem tasksItem = new TasksItem();
        tasksItem.setTask(task);
        task.setTaskChoice(new TaskChoice());
        getSubPhaseEdited().setTasks(new Tasks());
        addNewTask();
    }

    @Override
    public boolean run(IController controller) throws ClientException, ClientInterruption {
        // Dirty, only for getting model provider
        throw new ClientException();
    }

    public String buildXmlMerged() throws ClientException {
        if (getXmlScheduleFlowMerge() == null) {
            String xmlFlowReverse = loadIfNeededXmlReverse();
            String xmlCurrentSchedule = getModelProvider().getXmlSource();
            xmlCurrentSchedule = xmlCurrentSchedule.substring(xmlCurrentSchedule
                    .indexOf(FILE_HEADER_XML) + FILE_HEADER_XML.length() + 1);
            StringBuffer xmlMerged = new StringBuffer();
            xmlMerged.append(FILE_HEADER_XML);
            xmlMerged.append(LINE_BREAK);
            xmlMerged.append(BALISE_XML_REWORK_OPENING);
            xmlMerged.append(LINE_BREAK);
            xmlMerged.append(xmlFlowReverse);
            xmlMerged.append(LINE_BREAK);
            xmlMerged.append(xmlCurrentSchedule);
            xmlMerged.append(LINE_BREAK);
            xmlMerged.append(BALISE_XML_REWORK_CLOSING);
            setXmlScheduleFlowMerge(xmlMerged.toString());
        }

        return getXmlScheduleFlowMerge();
    }

    public String buildXmlMergedWithEditedSubPhase() {
        // Initialize DAO service
        ModelXmlDaoService daoService = new ModelXmlDaoService();
        daoService.setObjectClass(SubPhase.class);

        // Remove header line from rework flow
        String xmlMergedWithEditedSubPhase = getXmlScheduleFlowMerge().substring(
                getXmlScheduleFlowMerge().indexOf(FILE_HEADER_XML) + FILE_HEADER_XML.length() + 1);

        // Remove header line from edited subPhase
        String xmlFlowEditedSubPhase = daoService.getXmlSource(getSubPhaseEdited());
        xmlFlowEditedSubPhase = xmlFlowEditedSubPhase.substring(xmlFlowEditedSubPhase.indexOf(FILE_HEADER_XML) + FILE_HEADER_XML.length() + 1);
        
        
        // Build new XML with operations schedule and the new sub phase edited
        StringBuffer xmlMerged = new StringBuffer();
        xmlMerged.append(FILE_HEADER_XML);
        xmlMerged.append(LINE_BREAK);
        xmlMerged.append(BALISE_XML_FUll_ROOT_OPENING);
        xmlMerged.append(LINE_BREAK);
        xmlMerged.append(xmlMergedWithEditedSubPhase);
        xmlMerged.append(LINE_BREAK);
        xmlMerged.append(xmlFlowEditedSubPhase);
        xmlMerged.append(LINE_BREAK);
        xmlMerged.append(BALISE_XML_FULL_ROOT_CLOSING);

        return xmlMerged.toString();

    }

    private String loadIfNeededXmlReverse() throws ClientAssemblyException {
        String xmlFlowReverse = null;
        AAssemblyScheduleService scheduleService = (AAssemblyScheduleService) getModelProvider()
                .getModelScheduleService();

        String emptyContent = TAG_EMPTY_ASSEMBLY;
        int reverseSchedule = AssemblyGlobalServices.SCHEDULE_IDENTIFIER_ASSEMBLY_TYPE;
        if (scheduleService instanceof AssemblyScheduleService) {
            reverseSchedule = AssemblyGlobalServices.SCHEDULE_IDENTIFIER_DISASSEMBLY_TYPE;
            emptyContent = TAG_EMPTY_DISASSEMBLY;
        }

        if (xmlFlowReverse == null) {
        	String currentLevel = getContext().getContextApplicabilities().getLevels();
        	getContext().getContextApplicabilities().setLevels(getLevel());
            turbomeca.gamme.ecran.services.common.bean.ContextRange contextReverse = RuntimeServerInterfaceService.getInstance().getExternalContextData(reverseSchedule);
            getContext().getContextApplicabilities().setLevels(currentLevel);
            if (contextReverse != null) {
                setReverseScheduleVersion(contextReverse.getHistory());
                xmlFlowReverse = contextReverse.getRange();
                if (xmlFlowReverse != null) {
                	xmlFlowReverse = xmlFlowReverse.substring(xmlFlowReverse.indexOf(FILE_HEADER_XML)
                        + FILE_HEADER_XML.length() + 1);
                }
            }
        }
        if (xmlFlowReverse == null) {
        	xmlFlowReverse = emptyContent;
        }
        return xmlFlowReverse;
    }

    public void addNewTask() {
        State state = new State();
        state.setStatus(StatusType.TODO);

        Task task = new Task();
        task.setId(UUID.randomUUID().toString());
        task.setState(state);

        TasksItem tasksItem = new TasksItem();
        tasksItem.setTask(task);

        task.setTaskChoice(new TaskChoice());
        Tasks tasks = getSubPhaseEdited().getTasks();
        if (tasks == null) {
        	tasks = new Tasks();
        }
        tasks.addTasksItem(tasksItem);
    }

    /**
     * @return the level
     */
    public String getLevel() {
        return level;
    }

    /**
     * @param level
     *            the level to set
     */
    public void setLevel(String level) {
        this.level = level;
    }

    /**
     * @return the subPhaseReverseId
     */
    public String getSubPhaseReverseId() {
        return subPhaseReverseId;
    }

    /**
     * @param subPhaseReverseId
     *            the subPhaseReverseId to set
     */
    public void setSubPhaseReverseId(String subPhaseReverseId) {
        this.subPhaseReverseId = subPhaseReverseId;
    }

    /**
     * @return the subPhaseCurrentId
     */
    public String getSubPhaseCurrentId() {
        return subPhaseCurrentId;
    }

    /**
     * @param subPhaseCurrentId
     *            the subPhaseCurrentId to set
     */
    public void setSubPhaseCurrentId(String subPhaseCurrentId) {
        this.subPhaseCurrentId = subPhaseCurrentId;
    }

    /**
     * @return the xmlScheduleFlowMerge
     */
    public String getXmlScheduleFlowMerge() {
        return xmlScheduleFlowMerge;
    }

    /**
     * @param xmlScheduleFlowMerge
     *            the xmlScheduleFlowMerge to set
     */
    public void setXmlScheduleFlowMerge(String xmlScheduleFlowMerge) {
        this.xmlScheduleFlowMerge = xmlScheduleFlowMerge;
    }

    /**
     * @return the subPhaseEdited
     */
    public SubPhase getSubPhaseEdited() {
        return subPhaseEdited;
    }

    /**
     * @param subPhaseEdited
     *            the subPhaseEdited to set
     */
    public void setSubPhaseEdited(SubPhase subPhaseEdited) {
        this.subPhaseEdited = subPhaseEdited;
    }

    /**
     * @return the operationTitle
     */
    public String getOperationTitle() {
        String title = "";
        if (operationTitle != null) {
            title = operationTitle;
        }
        return title;
    }

    /**
     * @param operationTitle
     *            the operationTitle to set
     */
    public void setOperationTitle(String operationTitle) {
        this.operationTitle = operationTitle;
    }

    /**
     * @return the xmlReverseScheduleVersion
     */
    public String getReverseScheduleVersion() {
        return reverseScheduleVersion;
    }

    /**
     * @param xmlReverseScheduleVersion the xmlReverseScheduleVersion to set
     */
    public void setReverseScheduleVersion(String reverseScheduleVersion) {
        this.reverseScheduleVersion = reverseScheduleVersion;
    }
}