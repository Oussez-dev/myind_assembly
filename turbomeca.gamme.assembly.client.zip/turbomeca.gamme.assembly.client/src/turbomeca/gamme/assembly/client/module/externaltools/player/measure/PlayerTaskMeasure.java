package turbomeca.gamme.assembly.client.module.externaltools.player.measure;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.model.edit.IModelAssemblyWrapperScheduleService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskActionMeasureService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskActionService;
import turbomeca.gamme.assembly.services.model.data.TaskActionMeasure;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.module.externaltools.player.APlayerInstruction;

public class PlayerTaskMeasure extends APlayerInstruction {

	/** logger for current class */
	private static Logger logger = Logger.getLogger(PlayerTaskMeasure.class);
	
	private ThreadPlayerAcquisition threadPlayer = null;

	public PlayerTaskMeasure (IModelObjectService service, boolean forceMode, boolean toolsAcquisition){
		super();
		setModelService(service);
		setForceModeAcquistion(forceMode);
		setToolsAcquistion(toolsAcquisition);
	}

	@Override
	public boolean play() throws ClientException, ClientInterruption {
		logger.info("[PILOTING] : Play Measure : " + getModelService().getIdentifier());
		ModelTaskActionMeasureService taskMeasureService = (ModelTaskActionMeasureService) getModelService();
		TaskActionMeasure taskMeasure = (TaskActionMeasure)taskMeasureService.getWrapperService().getObject();
		ModelTaskActionService taskAction = (ModelTaskActionService) getModelProvider().getModelService(taskMeasure.getTaskAction().getId());
		IModelAssemblyWrapperScheduleService wrapper = (IModelAssemblyWrapperScheduleService) getModelProvider().getModelScheduleService().getWrapperService();
		String osNumber = wrapper.getInstantiation().getOrder();
		
		threadPlayer = new ThreadPlayerAcquisition(taskMeasureService, isForceModeAcquistion(), 
				isToolsAcquistion(), osNumber, getController(), getEngine(), taskAction);
		threadPlayer.start();
		return true;
	}

	@Override
	public boolean stop(IModelObjectService service) throws ClientException, ClientInterruption {
		logger.info("[PILOTING] : Stop Measure : " + getModelService().getIdentifier());
		threadPlayer.stopThread();
		return true;
	}
}
