package turbomeca.gamme.assembly.client.module.intervention.view;

import turbomeca.gamme.assembly.client.ClientAssemblyException;
import turbomeca.gamme.assembly.client.config.AssemblyPropertyConstants;
import turbomeca.gamme.assembly.client.model.edit.utils.ModelUtils;
import turbomeca.gamme.assembly.services.constants.AssemblyXsltConstants;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.model.edit.instructions.IModelSubPhaseService;
import turbomeca.gamme.ecran.client.module.action.AActionServiceView;
import turbomeca.gamme.ecran.services.constants.XsltConstants;

public class ChangeMarkView extends AActionServiceView {

	/** */
	private String instance;
	private String alternative;

	public ChangeMarkView(String serviceId, String instance, String alternative) {
		super(serviceId, AssemblyXsltConstants.XSLT_INTERVENTION_CHANGE_MARK.value());
		setInstance(instance);
		setAlternative(alternative);
	}

	@Override
	public boolean run() throws ClientException {
		boolean success = true;
		IModelSubPhaseService subPhaseService = ModelUtils.getSubPhaseParent(getModelService());
		if(!subPhaseService.getRunnableService().isFinished()){
			if (subPhaseService.getWrapperService().isArchived()) {
				throw new ClientAssemblyException(ClientAssemblyException.EXCEPTION_ACTION_FORBIDEN_SUB_PHASE_ARCHIVED);
			}

			getView().addParameter(AssemblyXsltConstants.XSLT_PARAMETER_MARK_ID.value(), getServiceId());
			if (getInstance() != null) {
				getView().addParameter(AssemblyXsltConstants.XSLT_PARAMETER_INSTANCE_ID.value(), getInstance());
			}
			if (getAlternative() != null) {
				getView().addParameter(AssemblyXsltConstants.XSLT_PARAMETER_ALTERNATIVE_ID.value(), getAlternative());
			}
			getView().bindService(subPhaseService);
			getView().addParameter(XsltConstants.XSLT_PARAMETER_SUBPHASE_ID.value(), subPhaseService.getIdentifier());
			success =  getView().displayModal(AssemblyPropertyConstants.PROPERTY_MODAL_TITLE_CHANGE_MARK, true);
		}
		return success;
	}

	/**
	 * @return the instance
	 */
	 public String getInstance() {
		 return instance;
	 }

	 /**
	  * @param instance the instance to set
	  */
	 public void setInstance(String instance) {
		 this.instance = instance;
	 }

	 /**
	  * @return the alternative
	  */
	 public String getAlternative() {
		 return alternative;
	 }

	 /**
	  * @param alternative the alternative to set
	  */
	 public void setAlternative(String alternative) {
		 this.alternative = alternative;
	 }
}
