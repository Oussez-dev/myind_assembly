package turbomeca.gamme.assembly.client.module.electronic.notification.action;

import turbomeca.gamme.assembly.client.ClientAssemblyControllersProvider;
import turbomeca.gamme.assembly.client.model.edit.runnable.ModelRunnableScheduleService;
import turbomeca.gamme.assembly.client.module.edition.AssemblyEditionController;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.interfaces.server.editing.EditingServerInterfaceService;
import turbomeca.gamme.ecran.client.module.IController;

public class ActionDeleteElectronicPostIt extends AActionElectronicPostIt {

	@Override
	public boolean run(IController controller) throws ClientException {
		boolean success = true;
		AssemblyEditionController editionController =  (AssemblyEditionController) controller.getControllersProvider().
				getController(ClientAssemblyControllersProvider.INTERFACE_EDITION);
		EditingServerInterfaceService.getInstance().loadEditing();

		if(((ModelRunnableScheduleService) getModelProvider().getModelScheduleService().getRunnableService()).
				canRunForMultiEdition(editionController, getContext().getContextEditing().isOutOfDate())){
			getScheduleWrapper().setElectronicPostIt(null);
		}
		else{
			success = false;
		}
		return success;
	}
}
