package turbomeca.gamme.assembly.client.module.electronic.notification.view;

import turbomeca.gamme.assembly.client.model.edit.IModelAssemblyWrapperScheduleService;
import turbomeca.gamme.ecran.client.constants.PropertyConstants;
import turbomeca.gamme.ecran.client.module.action.AActionView;
import turbomeca.gamme.ecran.services.constants.XsltConstants;

public class ElectronicPostItView extends AActionView {

    public ElectronicPostItView() {
        super(XsltConstants.XSLT_NOTIFICATION_POST_IT.value());
    }

    @Override
    public boolean run() {
        IModelAssemblyWrapperScheduleService wrapperSchedule = (IModelAssemblyWrapperScheduleService) getModelProvider().getModelScheduleService().getWrapperService();
        String currentValue = "";
        if (wrapperSchedule.getElectronicPostIt() != null) {
            currentValue = wrapperSchedule.getElectronicPostIt().getComment();
        }
        getView().addParameter(XsltConstants.XSLT_PARAMETER_POSTIT_COMMENT.value(), currentValue);
        return getView().displayModal(PropertyConstants.PROPERTY_MODAL_TITLE_POST_IT, true);
    }
}
