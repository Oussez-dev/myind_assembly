package turbomeca.gamme.assembly.client.module.instruction.action;

import turbomeca.gamme.assembly.client.ClientAssemblyException;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskActionService;
import turbomeca.gamme.assembly.services.model.data.Test;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.dispatcher.ActionDispatcherManager;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.client.module.instruction.action.ActionContinue;
import turbomeca.gamme.ecran.client.module.instruction.view.ErrorConfirmationView;

public class ActionSetInputWithTest extends ActionSetInput {

	private Test[] test;
	
	public ActionSetInputWithTest(String taskActionId, String value, Test[] test, boolean desableInvalidMessage) {
		super(taskActionId, value);
		this.test = test;
	}


	/**
	 * change the input value if and return true if the value is valid otherwhise return false.
	 * you can disable the invalid message modal
	 */
	@Override
	public boolean internalRun(IController controller,
			ModelTaskActionService taskActionService) throws ClientException,
			ClientInterruption {
		String value = getValue();

		if (value == null || value.isEmpty() || value.equals(Boolean.FALSE.toString())) {
			taskActionService.resetValue(true);
			forceResetRessource(taskActionService);
		} else {
			boolean isValueValid = true;
			try {
				isValueValid = taskActionService.checkValue(getValue(), test);
			} catch (ClientInterruption e) {
				taskActionService.setValue(null);
				throw new ClientAssemblyException(
						ClientAssemblyException.EXCEPTION_SEQUENCE);
			}

			if (!isValueValid
					&& getContext().getContextConfig().getNotifyBadInput()) {
				new ErrorConfirmationView(taskActionService, value).run();
			} else {
				taskActionService.getParent();
				taskActionService.setValue(value);
				taskActionService.setValid(isValueValid);
				if (!ActionDispatcherManager.getInstance().run()) {
					new ActionContinue(taskActionService).run(controller);
				}
			}
			return isValueValid;
		}
		return true;
	}
}
