package turbomeca.gamme.assembly.client.module.intervention.action;

import java.util.UUID;

import turbomeca.gamme.assembly.client.module.intervention.InterventionReworkDynamicManager;
import turbomeca.gamme.assembly.client.module.intervention.view.ReworkDynamicViewSubPhaseEdition;
import turbomeca.gamme.assembly.services.model.data.Para;
import turbomeca.gamme.assembly.services.model.data.Task;
import turbomeca.gamme.assembly.services.model.data.TaskChoiceItem;
import turbomeca.gamme.assembly.services.model.data.TaskPara;
import turbomeca.gamme.assembly.services.model.data.TaskParaTypeItem;
import turbomeca.gamme.assembly.services.model.data.TasksItem;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.module.IController;

public class ActionReworkDynamicEditionAddTaskPara extends AActionReworkDynamic {

    /** */
    private String taskId;
    
    public ActionReworkDynamicEditionAddTaskPara(InterventionReworkDynamicManager reworkManager, String taskId) {
        super(reworkManager);
        setTaskId(taskId);
    }

    @Override
    public boolean run(IController controller) throws ClientException {
        for(TasksItem tasksItem : getReworkManager().getSubPhaseEdited().getTasks().getTasksItem()) {
            Task task = tasksItem.getTask();
            if (task.getId().equals(getTaskId())) {
                TaskPara taskPara = new TaskPara();
                TaskParaTypeItem taskParaItem = new TaskParaTypeItem();
                taskParaItem.setPara(new Para());
                taskPara.addTaskParaTypeItem(taskParaItem);
                taskPara.setId(UUID.randomUUID().toString());
                
                TaskChoiceItem taskChoiceItem = new TaskChoiceItem();
                taskChoiceItem.setTaskPara(taskPara);
                task.getTaskChoice().addTaskChoiceItem(taskChoiceItem);
            }
        }
        return new ReworkDynamicViewSubPhaseEdition(getReworkManager()).run();
    }

    /**
     * @return the taskId
     */
    public String getTaskId() {
        return taskId;
    }

    /**
     * @param taskId the taskId to set
     */
    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }
}