package turbomeca.gamme.assembly.client.module.informations.view;

import turbomeca.gamme.assembly.client.config.AssemblyPropertyConstants;
import turbomeca.gamme.ecran.client.module.action.AActionView;

public class InformationObservationsView extends AActionView {

    public InformationObservationsView() {
        super("");
    }
    
    public InformationObservationsView(String xsltSynthesisFile) {
        super(xsltSynthesisFile);
    }
    
    @Override
    public boolean run() {
        getView().bindService(getModelProvider().getModelScheduleService());
        return getView().displayModal(AssemblyPropertyConstants.PROPERTY_MODAL_TITLE_OBSERVATIONS, true);
    }
}
