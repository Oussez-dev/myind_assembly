package turbomeca.gamme.assembly.client.module.externaltools.player.piloting;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="pilotingResult")
public class ModelTaskPilotingValue {
	private String value;
	private String message;
	private float torqueMin;
	private float torqueMax;
	private float finalTorque;
	
	public ModelTaskPilotingValue() {

	}

	public ModelTaskPilotingValue(String value, String message) {
		this.value = value;
		this.message = message;
	}

	public ModelTaskPilotingValue (float torqueMin, float finalTorque, float torqueExpected) {
		this.finalTorque = torqueExpected;
		this.torqueMax = finalTorque;
		this.torqueMin = torqueMin;
	}

	public String getMessage() {
		return message;
	}
	
	@XmlElement
	public void setMessage(String message) {
		this.message = message;
	}

	public String getValue() {
		return value;
	}
	
	@XmlElement
	public void setValue(String value) {
		this.value = value;
	}

	public float getTorqueMin() {
		return torqueMin;
	}
	
	@XmlElement
	public void setTorqueMin(float torqueMin) {
		this.torqueMin = torqueMin;
	}

	public float getTorqueMax() {
		return torqueMax;
	}
	
	@XmlElement
	public void setTorqueMax(float torqueMax) {
		this.torqueMax = torqueMax;
	}

	public float getTorqueExpected() {
		return finalTorque;
	}
	
	@XmlElement
	public void setTorqueExpected(float torqueExpected) {
		this.finalTorque = torqueExpected;
	}

}
