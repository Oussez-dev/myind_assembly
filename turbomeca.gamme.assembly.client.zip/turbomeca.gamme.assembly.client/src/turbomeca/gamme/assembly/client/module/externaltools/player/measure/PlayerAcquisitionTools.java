package turbomeca.gamme.assembly.client.module.externaltools.player.measure;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.module.externaltools.provider.PlayerAcquisitionToolsProvider;
import turbomeca.gamme.assembly.services.model.data.State;
import turbomeca.gamme.ecran.client.constants.PropertyConstants;
import turbomeca.gamme.ecran.client.module.externaltools.config.ConfigurationTools;
import turbomeca.gamme.ecran.services.devices.ExternalsToolsExceptions;
import turbomeca.gamme.ecran.services.devices.IDevices;

public class PlayerAcquisitionTools extends APlayerAcquisition {

	private static Logger logger = Logger.getLogger(PlayerAcquisitionTools.class);

	private IDevices communicator = null;

	public PlayerAcquisitionTools (ConfigurationTools configuration, State state){
		super(ServiceType.TOOL);
		setConfigurationMeasure(configuration);
		setState(state);

		int errorId;
		try {
			logger.debug("[PILOTING] : PlayerAcquisitionTools - prepare communication way");

			errorId = ((ConfigurationTools)getConfigurationMeasure()).loadConfiguration();
			if( errorId == 0){
				communicator= PlayerAcquisitionToolsProvider.getCommunicationWay(getConfigurationMeasure());
				logger.debug("[PILOTING] : PlayerAcquisitionTools - acquireAcquistion - end preparation of communication way");
			}else if (errorId == 1) {
				getLoggerHmi().error(PropertyConstants.PROPERTY_ERROR_TOOLS_UNEXPECTED_TYPE);
			}else {
				getLoggerHmi().error(PropertyConstants.PROPERTY_ERROR_TOOLS_BUILD_CONFIGURATION);
			}

		} catch (ExternalsToolsExceptions e) {
			logger.error("[PILOTING] : PlayerAcquisitionTools - constructor", e);
		} catch (Exception e) {
			logger.error("[PILOTING] : PlayerAcquisitionTools - constructor", e);
		}
	}

	@Override
	public String acquireAcquistion() throws ExternalsToolsExceptions, InterruptedException {
		String value=null;
		if(communicator != null){
			communicator.listen();
			logger.debug("[PILOTING] : PlayerAcquisitionTools - acquireAcquistion - end execute action");
			value = communicator.getData();
			logger.debug("[PILOTING] : PlayerAcquisitionTools - acquireAcquistion - value = " + value);
		}
		return value;
	}

	public void stopAcquisition(){
		try {
			if(communicator != null){
				communicator.stop();
			}
		} catch (Exception e) {
			logger.error("[PILOTING] : PlayerAcquisitionTools - stop", e);
		}
	}
}
