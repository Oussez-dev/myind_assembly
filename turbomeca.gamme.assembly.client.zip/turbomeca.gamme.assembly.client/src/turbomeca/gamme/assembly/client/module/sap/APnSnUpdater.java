package turbomeca.gamme.assembly.client.module.sap;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.ClientAssemblyControllersProvider;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseGroupService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.client.module.edition.AssemblyEditionController;
import turbomeca.gamme.assembly.services.model.data.Derogation;
import turbomeca.gamme.assembly.services.model.data.InputAction;
import turbomeca.gamme.assembly.services.model.data.InputActionChoice;
import turbomeca.gamme.assembly.services.model.data.InputChoice;
import turbomeca.gamme.assembly.services.model.data.InputField;
import turbomeca.gamme.assembly.services.model.data.InputValue;
import turbomeca.gamme.assembly.services.model.data.Instanciation;
import turbomeca.gamme.assembly.services.model.data.Mark;
import turbomeca.gamme.assembly.services.model.data.PN;
import turbomeca.gamme.assembly.services.model.data.SN;
import turbomeca.gamme.assembly.services.model.data.StringValue;
import turbomeca.gamme.assembly.services.model.data.SubPhase;
import turbomeca.gamme.assembly.services.model.data.TaskAction;
import turbomeca.gamme.assembly.services.model.data.User;
import turbomeca.gamme.assembly.services.model.data.UserMark;
import turbomeca.gamme.assembly.services.model.data.types.InputType;
import turbomeca.gamme.ecran.client.AClientInstancesProvider;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.interfaces.server.sap.mapper.DataResponseSnDerog;
import turbomeca.gamme.ecran.client.model.AModelObjectService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.services.common.constants.GlobalConstants;

/**
 * Abstract class for marks PN/SN and header material SN update process.
 * 
 * @author ademartin
 *
 */
public abstract class APnSnUpdater extends AClientInstancesProvider{

	/** Logger for current class */
	private static Logger logger = Logger.getLogger(APnSnUpdater.class);
	
	/** Used to declare SAP response is ready to process (is not empty, and has data to process) */
	private boolean sapSynchronized;
	
	/** Used to declare SAP response given is valid */
	private boolean sapResponseValid;
	
	private IController controller;
	
	public boolean update(Instanciation instanciation)  throws Exception {
		boolean scheduleUpdated = false;
        if(!instanciation.isSynchronizedWithSap() && sapSynchronized) {
        	scheduleUpdated |= checkMaterial(instanciation.getPn(), instanciation.getSN());
        }
        // updatePnSnSubPhases MUST be called even if SAP is not connected to force the PN to be at read only
        // TODO : updatePnSnSubPhases() return always true ...
        scheduleUpdated |= updatePnSnSubPhases();
        
        return scheduleUpdated;
	}
	
	/**
	 * Method to check and update header material.
	 * 
	 * @param pn
	 * @param sns
	 * @throws ClientException 
	 */
	protected abstract boolean checkMaterial(String pn, SN[] sns) throws ClientException;
	
	/**
	 * Method that searches each sub-phase edited by user and starts its own
	 * checking process.
	 * 
	 * @return
	 * @throws ClientInterruption 
	 * @throws ClientException 
	 */
	private boolean updatePnSnSubPhases() throws Exception {
		boolean updated = false;
		for(String currentSubPhase : getContext().getContextEditing().getObjectEdited()) {
			IModelObjectService subPhaseObjectService = getModelProvider().getModelService(currentSubPhase);
			if(subPhaseObjectService != null) {
				if (subPhaseObjectService instanceof ModelSubPhaseService) {
					updated |= checkSubPhase((ModelSubPhaseService) subPhaseObjectService);
                } else if (subPhaseObjectService instanceof ModelSubPhaseGroupService) {
                    for (IModelObjectService subPhaseInstanceObjectService : subPhaseObjectService.getChildren()) {
                        if (subPhaseInstanceObjectService instanceof ModelSubPhaseService) {
                        	updated |= checkSubPhase((ModelSubPhaseService) subPhaseInstanceObjectService);
                        }
                    }
                }
			} else {
				logger.debug("no object service found for current id "+ currentSubPhase);
			}
		}
		 return updated;
	}
	
	/**
	 * Method that starts the update of all marks containing in the given
	 * sub-phase if it was not already updated by SAP.
	 * 
	 * If not already updated by SAP, it sets its related "synchronizedWithSap"
	 * attribute to true at the end of the process.
	 * 
	 * @param subPhaseService
	 * @throws ClientException
	 * @throws ClientInterruption
	 */
	public boolean checkSubPhase(ModelSubPhaseService subPhaseService) throws ClientException, ClientInterruption {
		boolean updated = false;
        logger.debug("checkSubPhase : " + subPhaseService.getIdentifier());
        SubPhase subPhase = subPhaseService.getWrapperService().getSubPhase();
        if((!subPhase.hasSynchronizedWithSap() || !subPhase.isSynchronizedWithSap())) {
        	if (subPhase.getResources() != null && subPhase.getResources().getMarks() != null) {
                logger.debug("checkSubPhase : analyse resources of subPhase " + subPhaseService.getIdentifier());
                Enumeration<? extends Mark> enumMark = subPhase.getResources().getMarks().enumerateMark();
                while (enumMark.hasMoreElements()) {
                    Mark mark = enumMark.nextElement();
                    if (mark.getSN() != null) {
                        logger.debug("checkSubPhase : Analyze mark " + mark.getId());
    	                // Update references
                        if (checkMark(mark, subPhase)) {
    	                    // Update references
                        	updated = true;
    	                    for (IModelObjectService children : getModelProvider().getModelService(mark.getId()).getChildren()) {
    	                        children.getStatusService().setServiceModified();
    	                    }
                        }
                    } else {
                        logger.debug("postCreate : mark " + mark.getId()+ " has no SN record");
                        disableInputMark(mark);
                    }
                }
            }
        	if(sapResponseValid) {
        		subPhase.setSynchronizedWithSap(true);
        	}
        } else {
        	logger.debug("SubPhase "+subPhase.getId()+ "is already synchronised with Sap");
        }
        return updated;
    }
	
	/**
	 * Method to check and update the given mark.
	 * @param mark the mark to check and update
	 * @param subPhase the mark parent sub-phase
	 * @return
	 * @throws ClientException 
	 */
	protected abstract boolean checkMark(Mark mark, SubPhase subPhase) throws ClientException;
	
	protected void addSnToEditionContext(SN[] sns) throws ClientException {
    	List<String> snIdToSynchronize = new ArrayList<String>(sns.length);
    	for( SN sn : sns ) {
    		snIdToSynchronize.add(sn.getTaskAction().getId());
    	}
    	// Notify objects are in edition
    	((AssemblyEditionController) getController().getControllersProvider()
				.getController(ClientAssemblyControllersProvider.INTERFACE_EDITION))
						.forceObjectEdition(snIdToSynchronize);
    }
	
	/**
	 * Method to disable the PN fields of a mark.
	 * @param mark
	 * @throws ClientException 
	 */
	protected void disableInputMark(Mark mark) throws ClientException {
		Enumeration<? extends PN> enumPn = mark.enumeratePN();
		while (enumPn.hasMoreElements()) {
			buildNoPn(enumPn.nextElement().getTaskAction());
		}
	}
	
	/**
	 * Returns if given taskAction value is different than the given one.
	 * 
	 * @param taskAction
	 * @param value
	 * @return
	 */
	private boolean isValueDifferent(TaskAction taskAction, String value) {
    	boolean valueDifferent = true;
    	if (taskAction != null && taskAction.getInputAction() != null && taskAction.getInputAction().getInputValue() != null) {
    		valueDifferent = value.equals(taskAction.getInputAction().getInputValue().getValue());
    	}
    	return valueDifferent;
    }
	
	/**
	 * Must be used to set the associated boolean at subclass initialization
	 * @param isSapSynchronized
	 */
	protected void setSapSynchronized(boolean isSapSynchronized) {
		this.sapSynchronized = isSapSynchronized;
	}
	
	public boolean getSapSynchronized() {
		return this.sapSynchronized;
	}
	
	/**
	 * Must be used to set the associated boolean at subclass initialization
	 * 
	 * @param sapResponseValid
	 */
	protected void setSapResponseValid(boolean sapResponseValid) {
		this.sapResponseValid = sapResponseValid;
	}
	
	/**
	 * Method for update task action when more than 1 pn come from SAP
	 * @param responsePnSnDerog
	 * @param pns
	 * @param taskActionPn
	 * @param sns
	 * @param derogations
	 * @return
	 * @throws ClientException
	 */
	protected boolean buildMultiplePn(Map<String, List<DataResponseSnDerog>> responsePnSnDerog,
			List<String> pns, TaskAction taskActionPn, SN[] sns, Derogation[] derogations) throws ClientException {
		boolean hasUpdated = false;
		
		if (taskActionPn != null && !isTaskActionAlreadySeized(taskActionPn)) {
			// Update PN choice
			InputChoice inputChoice = new InputChoice();
			for (String pn : pns) {
				StringValue stringValue = new StringValue();
				stringValue.setContent(pn);
				inputChoice.addStringValue(stringValue);
			}
			updateWithCurrentValues(inputChoice, taskActionPn);
			taskActionPn.getInputAction().getInputActionChoice().setInputChoice(inputChoice);
			if (!pns.isEmpty()) {
				InputValue inputValue = new InputValue();
				inputValue.setValue("1");
				taskActionPn.getInputAction().setInputValue(inputValue);
			}
			hasUpdated = true;
		}

		// Update SN and derogation choice
		InputChoice inputChoiceDerog = new InputChoice();
		for (SN sn : sns) {
			if(isSnAlreadySeized(sn)) {
				logger.warn("Unable to update current Mark SN object with the corresponding value set from getSnFromOs response=" + responsePnSnDerog + " as it was already seized");
				continue;
			}
			
			InputChoice inputChoiceSn = new InputChoice();
			if (sn.getTaskAction() != null) {
				for (String pnApplicable : pns) {
					buildInputChoice(responsePnSnDerog.get(pnApplicable), inputChoiceSn, inputChoiceDerog);
				}
				
				updateWithCurrentValues(inputChoiceSn, sn.getTaskAction());
				// Change SN inputField if inputChoice if SN has at least one value
				if (inputChoiceSn.getStringValueCount() > 0) {
					sn.getTaskAction().getInputAction().getInputActionChoice().setInputField(null);
					sn.getTaskAction().getInputAction().getInputActionChoice().setInputChoice(inputChoiceSn);
				}
				hasUpdated = true;
			}
		}
		for (Derogation derog : derogations) {
			if (derog.getTaskAction() != null) {
				// Change derogation inputField to inputChoice if derogation has at least one value
				if (inputChoiceDerog.getStringValueCount() > 0) {
					derog.getTaskAction().getInputAction().getInputActionChoice().setInputField(null);
					derog.getTaskAction().getInputAction().getInputActionChoice().setInputChoice(inputChoiceDerog);
					hasUpdated = true;
				}
			}
		}
		
		if (hasUpdated) {
			((AModelObjectService) getModelProvider().getModelScheduleService()).setModified();
		}
		
		return hasUpdated;
	}
	
	/**
	 * Method for update task action when only 1 pn come from SAP
	 * @param responsePnSnDerog
	 * @param uniqPn
	 * @param taskActionPn
	 * @param sns
	 * @return
	 * @throws ClientException
	 */
	protected boolean buildUniquePn(Map<String, List<DataResponseSnDerog>> responsePnSnDerog,
			String uniqPn, TaskAction taskActionPn, SN[] sns) throws ClientException {

		boolean hasUpdated = false;
		// If we are in task action and task action field is empty
		if (taskActionPn != null && !isTaskActionAlreadySeized(taskActionPn)) {
			InputChoice inputChoice = taskActionPn.getInputAction().getInputActionChoice().getInputChoice();
			InputValue inputValue = new InputValue();
			inputValue.setValue(String.valueOf(getPositionValue(inputChoice, uniqPn)));
			inputValue.setUserMark(buildUserMarkSap());
			taskActionPn.getInputAction().setInputValue(inputValue);
			taskActionPn.setEditable(inputChoice.getStringValue().length > 1); // We are editable if choice > 1
			hasUpdated = true;
		}

		List<DataResponseSnDerog> listConfig = responsePnSnDerog.get(uniqPn);
		for (SN sn : sns) {
			if(isSnAlreadySeized(sn)) {
				logger.warn("Unable to update current Mark SN object with the corresponding value set from getSnFromOs response=" + listConfig + " as it was already seized");
				continue;
			}
			
			if (listConfig.size() == 1) {
				hasUpdated |= buildInputField(listConfig.get(0), sn.getTaskAction(), null);
			} else {
				InputChoice inputChoiceSn = new InputChoice();
				InputChoice inputChoiceDerog = new InputChoice();
				// Build choice
				if (sn.getTaskAction() != null) {
					hasUpdated |= buildInputChoice(listConfig, inputChoiceSn, inputChoiceDerog);
					// Change inputField if inputChoice for SN has at least one value
					InputAction inputActionSn = sn.getTaskAction().getInputAction();
					if (inputChoiceSn.getStringValueCount() > 0) {
						inputActionSn.getInputActionChoice().setInputField(null);
						inputActionSn.getInputActionChoice().setInputChoice(inputChoiceSn);
					}
					updateWithCurrentValues(inputChoiceSn, sn.getTaskAction());
				}
			}
		}
		
		if (hasUpdated) {
			((AModelObjectService) getModelProvider().getModelScheduleService()).setModified();
		}
		if(taskActionPn != null && isTaskActionAlreadySeized(taskActionPn)) {
    		// User has already set this PN or a single PN is already defined for this taskAction
			InputChoice inputChoice = taskActionPn.getInputAction().getInputActionChoice().getInputChoice();
        	taskActionPn.setEditable(inputChoice != null && inputChoice.getStringValue().length > 1);
    	}
		
		return hasUpdated;
	}
	
	private int getPositionValue(InputChoice inputChoice, String value) {
		int position = -1;
		StringValue[] values = inputChoice.getStringValue();
		for (int i = 0; values != null && i < values.length; i++) {
			if (values[i].getContent().compareTo(value) == 0) {
				position = i+1;
				break;
			}
		}
		return position;
	}
	
	/**
	 * Method to disable a taskAction as if it has no PN value at all.
	 * 
	 * @param taskActionPn
	 * @return
	 * @throws ClientException 
	 */
	protected boolean buildNoPn(TaskAction taskActionPn) throws ClientException {
        boolean hasUpdated = false;
        if (taskActionPn != null && !isTaskActionAlreadySeized(taskActionPn)) {
            InputAction inputAction = taskActionPn.getInputAction();
            InputActionChoice inputActionChoice = inputAction.getInputActionChoice();
            
            if (inputActionChoice.getInputField() != null) {
                if (inputAction.getInputValue() != null && inputAction.getInputValue().getValue() != null) {
                    inputAction.setDefaultValue(inputAction.getInputValue().getValue());
                }
            } else if (inputActionChoice.getInputChoice() != null 
                    && inputActionChoice.getInputChoice().getStringValueCount() == 1){
                String uniqueValue = inputActionChoice.getInputChoice().getStringValue(0).getContent();
                
                InputField inputField = new InputField();
                inputField.setType(InputType.STRING);
                
                InputValue inputValue = new InputValue();
                inputValue.setValue(uniqueValue);
                
                UserMark userMarkSap = new UserMark();
                userMarkSap.setDateTime(Calendar.getInstance().getTime());
                User userSap = new User();
                userSap.setLogin(GlobalConstants.SAP_LOGIN);
                userSap.setName(GlobalConstants.SAP_LOGIN);
                userMarkSap.setUser(userSap);
                inputValue.setUserMark(userMarkSap);

            	hasUpdated |= isValueDifferent(taskActionPn, uniqueValue);
                inputAction.setInputValue(inputValue);
                inputAction.setDefaultValue(inputAction.getInputValue().getValue());
                
                inputAction.getInputActionChoice().setInputChoice(null);
                inputAction.getInputActionChoice().setInputField(inputField);
            }
        }
        
        if (hasUpdated) {
			((AModelObjectService) getModelProvider().getModelScheduleService()).setModified();
		}
        if(taskActionPn != null && isTaskActionAlreadySeized(taskActionPn)) {
    		// User has already set this PN or a single PN is already defined for this taskAction
        	taskActionPn.setEditable(false);
    	}
        
        return hasUpdated;
    }
	
	/**
	 * Method to build a userMark object referencing SAP as user.
	 * 
	 * @return
	 */
	protected UserMark buildUserMarkSap() {
		UserMark userMarkSap = new UserMark();
		userMarkSap.setDateTime(Calendar.getInstance().getTime());
		User userSap = new User();
		userSap.setLogin(GlobalConstants.SAP_LOGIN);
		userSap.setName(GlobalConstants.SAP_LOGIN);
		userMarkSap.setUser(userSap);
		return userMarkSap;
	}
	
	protected boolean buildInputChoice(List<DataResponseSnDerog> listConfig,
			InputChoice inputChoiceSn, InputChoice inputChoiceDerog) {
		boolean hasUpdated = false;
		for (DataResponseSnDerog configSn : listConfig) {
			if (configSn.getSn() != null && !configSn.getSn().isEmpty()) {
				StringValue stringValue = new StringValue();
				stringValue.setContent(configSn.getSn());
				inputChoiceSn.addStringValue(stringValue);
			}
		}

		// Allow manual value
		inputChoiceSn.setManual(true);
		inputChoiceDerog.setManual(true);
		return hasUpdated;
	}
	
	private boolean buildInputField(DataResponseSnDerog configSn, TaskAction taskActionSn, TaskAction taskActionDerog) {
    	boolean hasUpdated = false;
        if (configSn != null) {
            if (taskActionSn != null && configSn.getSn() != null) {
                hasUpdated = isValueDifferent(taskActionSn, configSn.getSn());
                InputValue inputValue = new InputValue();
                inputValue.setValue(configSn.getSn());
                taskActionSn.getInputAction().setDefaultValue(configSn.getSn());
                taskActionSn.getInputAction().setInputValue(inputValue);
            }
        }
        
        return hasUpdated;
    }
	
	private void updateWithCurrentValues(InputChoice inputChoiceToUpdate, TaskAction taskSource) {
		
    	if (taskSource == null 
    			|| taskSource.getInputAction() == null 
    			|| taskSource.getInputAction().getInputValue() == null 
    			|| taskSource.getInputAction().getInputValue().getValue() == null 
    			|| taskSource.getInputAction().getInputActionChoice() == null 
    			|| taskSource.getInputAction().getInputActionChoice().getInputChoice() == null) {
    		return;
    	}
    	
    	String sapValue = inputChoiceToUpdate.getStringValue()[0].getContent();
    	
    	// we find value(s) present in task action
    	List<String> currentValues = new ArrayList<String>();
    	if (taskSource.getInputAction().getInputActionChoice() != null) {
    		StringValue[] tmpValues = taskSource.getInputAction().getInputActionChoice().getInputChoice().getStringValue();
    		if (tmpValues != null && tmpValues.length > 0) {
    			for (StringValue sv : tmpValues) {
    				currentValues.add(sv.getContent());
    			}
    		}
    	} else if (taskSource.getInputAction().getInputValue() != null) { 
    		String value = taskSource.getInputAction().getInputValue().getValue();
    		if (value != null) {
    			currentValues.add(value);
    		}
    	}
    	
    	List<String> tmpStringValues = convertStringValueToString(inputChoiceToUpdate.getStringValue());
    	List<String> valueToAdds = new ArrayList<String>(tmpStringValues);
    	
    	for (String currentValue : currentValues) {
    		if (!tmpStringValues.contains(currentValue)) {
    			valueToAdds.add(currentValue);
    		}
    	}
    	
    	for (String valueToAdd : valueToAdds) {
    		StringValue newValue = new StringValue();
    		newValue.setContent(valueToAdd);
    		inputChoiceToUpdate.addStringValue(newValue);
    	}
    	
    	// Force first value from sap
    	if (sapValue != null) {
    		StringValue newValue = new StringValue();
    		newValue.setContent(sapValue);
    		inputChoiceToUpdate.addStringValue(newValue);
    	}
	}
	
	private List<String> convertStringValueToString(StringValue[] stringValues) {
		List<String> result = new ArrayList<String>();
		for (StringValue sv : stringValues) {
			result.add(sv.getContent());
		}
		return result;
	}
	
	/**
	 * Returns if given SN object has already a data seized in it.
	 * @param sn the SN object to check
	 * @return true if a data is already seized, false otherwise
	 */
	protected boolean isSnAlreadySeized(SN sn) {
		if(sn.getTaskAction() == null ) {
			return false;
		}
		return isTaskActionAlreadySeized(sn.getTaskAction());
	}
	
	/**
	 * Returns if given PN object has already a data seized in it.
	 * @param sn the PN object to check
	 * @return true if a data is already seized, false otherwise
	 */
	protected boolean isPnAlreadySeized(PN pn) {
    	if(pn.getTaskAction() == null) {
			return false;
		}
    	return isTaskActionAlreadySeized(pn.getTaskAction());
	}
	/**
	 * Check if the provided taskAction holds a value
	 * 
	 * @param taskAction
	 * @return
	 */
	protected boolean isTaskActionAlreadySeized(TaskAction taskAction) {
		InputAction inputAction = taskAction.getInputAction();
		if( inputAction == null) {
			return false;
		}
		
		InputValue inputValue = inputAction.getInputValue();
		if( inputValue == null) {
			return false;
		}
		
		return !inputValue.getValue().isEmpty();
	}

	protected IController getController() {
		return controller;
	}

	protected void setController(IController controller) {
		this.controller = controller;
	}
}
