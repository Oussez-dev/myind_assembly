package turbomeca.gamme.assembly.client.module.informations.view;

import turbomeca.gamme.assembly.services.constants.AssemblyXsltConstants;
import turbomeca.gamme.ecran.client.module.informations.view.InformationSummaryView;

public class InformationSummaryViewAssembly extends InformationSummaryView{

	public InformationSummaryViewAssembly() {
		super(AssemblyXsltConstants.XSLT_INFORMATION_SUMMARY.value());
	}
}
