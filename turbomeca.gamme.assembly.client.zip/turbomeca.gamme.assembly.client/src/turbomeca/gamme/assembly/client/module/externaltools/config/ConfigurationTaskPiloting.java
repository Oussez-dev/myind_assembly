package turbomeca.gamme.assembly.client.module.externaltools.config;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.EmptyStackException;
import java.util.TimeZone;


import turbomeca.gamme.assembly.services.model.data.InputValue;
import turbomeca.gamme.assembly.services.model.data.TaskPiloting;
import turbomeca.gamme.ecran.client.context.Context;
import turbomeca.gamme.ecran.client.module.externaltools.config.ConfigurationMeasure;
import turbomeca.gamme.ecran.client.module.externaltools.config.ConfigurationServlet;

public class ConfigurationTaskPiloting extends ConfigurationMeasure {
	
	private static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmm");
	
	private ConfigurationServlet configurationServlet;

	public ConfigurationTaskPiloting (TaskPiloting taskPiloting) {
		super("TaskPiloting");
		loadConfiguration(taskPiloting);
	}
	
	public void loadConfiguration(TaskPiloting taskPiloting) {
		 	Context  context = getContext();
		 	String user = context.getContextUser().getLogin();
		 	Calendar cal = Calendar.getInstance();
			
			dateFormat.setTimeZone(TimeZone.getDefault());
			String dateString = dateFormat.format(cal.getTime());
			String vin = user + '-' + dateString;
			InputValue inputToolname = taskPiloting.getTaskAction().getInputAction().getInputValue();
			String toolName ="";
			if(inputToolname != null && !inputToolname.getValue().isEmpty())
				toolName = taskPiloting.getTaskAction().getInputAction().getInputValue().getValue();
			else {
				throw new EmptyStackException();
			}
		 	String numProgramme;
		 	int nombreVis = 0;
		 	nombreVis = taskPiloting.getQuantity();		 		
	 		numProgramme =taskPiloting.getProgramNum();	
		 	
		 	ConfigurationServlet config = new ConfigurationServlet(nombreVis, numProgramme, vin, user, toolName, context.getContextConfig().getContextTool());
		 	setConfigurationServlet(config);
	}
 
	public ConfigurationServlet getConfigurationServlet() {
			return configurationServlet;
	}

	public void setConfigurationServlet(ConfigurationServlet configurationServlet) {
			this.configurationServlet = configurationServlet;
		}
}
