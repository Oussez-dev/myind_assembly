package turbomeca.gamme.assembly.client.module.instruction.action;

import turbomeca.gamme.assembly.client.ClientAssemblyException;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.edit.instructions.IModelTaskActionService;
import turbomeca.gamme.ecran.client.module.IController;

public class ActionUpdateComment extends AActionInput {

	private String comment;
	
	public ActionUpdateComment(String taskActionId, String comment) {
		super(taskActionId);
		setComment(comment);
	}

	@Override
	public boolean run(IController controller) throws ClientException, ClientInterruption {
		IModelTaskActionService taskActionService = getTaskActionService();
		if (taskActionService.getStatusService().isAlterable()) {
			taskActionService.updateComment(getComment());
		}
		else {
			throw new ClientAssemblyException(ClientAssemblyException.EXCEPTION_INSTRUCTION_PARENT_FINISHED);
		}
		return true;
	}

	/**
	 * @param comment the comment to set
	 */
	public void setComment(String comment) {
		this.comment = comment;
	}

	/**
	 * @return the comment
	 */
	public String getComment() {
		return comment;
	}
}
