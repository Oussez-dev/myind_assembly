package turbomeca.gamme.assembly.client.module.intervention.action;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import turbomeca.gamme.assembly.client.config.AssemblyPropertyConstants;
import turbomeca.gamme.assembly.client.model.edit.AModelAssemblyService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseGroupService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelWrapperService;
import turbomeca.gamme.ecran.services.common.constants.GlobalConstants;

public class ActionValidateLevelInstructions extends AActionChangeLevel {
	
	private List<String> services;
	String comment = null;
	
	/**
	 * 
	 * @param services
	 * @param instancesId
	 */
	public ActionValidateLevelInstructions(String services, String comment) {
		super(LEVEL_VALUE_OTHER, comment);
		this.services = null;
		if (services != null && !services.isEmpty()) {
			this.services = new ArrayList<String>(Arrays.asList(services.split(GlobalConstants.SEPARATOR_DOT_COMA)));
		}
		setComment(comment);
	}
	
	/* (non-Javadoc)
	 * @see turbomeca.gamme.assembly.client.module.intervention.action.AActionChangeLevel#checkConditions(turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService)
	 */
	protected boolean checkConditions(IModelObjectService scheduleService) throws ClientException {
		if (getComment() == null || getComment().isEmpty()) {
			getLoggerHmi().error(AssemblyPropertyConstants.PROPERTY_ERROR_CHANGE_LEVEL_MISSING_COMMENT);
			return false;
		}
		
        // Check references validity
		List<IModelObjectService> operationsService = scheduleService.getChildren();
		for (IModelObjectService operationService : operationsService) {
			for (IModelObjectService childService : operationService.getChildren()) {
			    if (childService instanceof ModelSubPhaseService) {
			        if (!checkSubPhase((ModelSubPhaseService) childService)) {
			            return false;
			        }
			    } else if (childService instanceof ModelSubPhaseGroupService) {
			        for (IModelObjectService childGroupService : childService.getChildren()) {
			            if (!checkSubPhase((ModelSubPhaseService) childGroupService)) {
	                        return false;
	                    }
			        }
			    }
			}
		}
		
		return true;
	}
	
	private boolean checkSubPhase(ModelSubPhaseService subPhaseService) throws ClientException {
	    IModelWrapperService wrapper = subPhaseService.getWrapperService();
        if (!wrapper.isArchived() && !wrapper.isAlternative()) {
            if (isSelected(subPhaseService)) {
                List<IModelObjectService> listReferences = new ArrayList<IModelObjectService>();
                boolean hasValidReferences = ((AModelAssemblyService)subPhaseService).checkReferencesByLevel(listReferences, getCurrentLevel());
                boolean hasValidPredecessors = ((AModelAssemblyService)subPhaseService).hasApplicablePredecessors(getCurrentLevel());
                if (!hasValidReferences) {
                    getLoggerHmi().error(AssemblyPropertyConstants.PROPERTY_ERROR_CHANGE_LEVEL_REFERENCES);
                    return false;
                } else if (!hasValidPredecessors) {
                    getLoggerHmi().error(AssemblyPropertyConstants.PROPERTY_ERROR_CHANGE_LEVEL_PREDECESSORS);
                    return false;
                } else {
                    getSubPhaseModified().put(subPhaseService.getIdentifier(), Boolean.TRUE);
                }
            } else {
                getSubPhaseModified().put(subPhaseService.getIdentifier(), Boolean.FALSE);
            }
        }
        return true;
	}
	
	/**
	 * @param sousPhaseService
	 * @return
	 */
	private boolean isSelected(IModelObjectService sousPhaseService) {
		if (getServices() != null && !getServices().isEmpty()) {
			if (getServices().contains(sousPhaseService.getIdentifier())) {
				return true;
			}
		} 
		return false;
	}
	
	/**
	 * @return the identifiers
	 */
	public List<String> getServices() {
		return services;
	}
	
}
