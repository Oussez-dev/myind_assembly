package turbomeca.gamme.assembly.client.module.intervention.action;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.model.edit.IModelAssemblyWrapperScheduleService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelOperationService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseGroupService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.services.model.data.Operation;
import turbomeca.gamme.assembly.services.model.data.Operations;
import turbomeca.gamme.assembly.services.model.data.SubPhase;
import turbomeca.gamme.assembly.services.model.data.SubPhaseGroup;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.context.ContextRequest;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.module.action.AActionModify;

public abstract class AActionRework extends AActionModify {

    /** logger for current class */
    private static Logger logger = Logger.getLogger(AActionRework.class);
    
    /** Internal status for rework treatments */
    private static final int REWORK_SEARCHING = 0;
    private static final int REWORK_FOUND = 1;
    private static final int REWORK_FINISHED = 2;
    
    /**
     * 
     * @param reworkOperations
     * @throws ClientException
     * @throws ClientInterruption 
     */
    public void addReworkOperations(Operations reworkOperations, int passing) throws ClientException, ClientInterruption {
        
        // Increase passing identifier
        IModelObjectService modelScheduleService = getModelProvider().getModelScheduleService();
        IModelAssemblyWrapperScheduleService wrapper = (IModelAssemblyWrapperScheduleService) modelScheduleService.getWrapperService();
        
        // Add new operations service after the operation with rework activation flag
        int index = 1;
        int reworkStatus = REWORK_SEARCHING;
        Vector<Operation> operationsSchedule = new Vector<Operation>();
        List<IModelObjectService> operationsScheduleService = new ArrayList<IModelObjectService>();
        for(IModelObjectService modelService : modelScheduleService.getChildren()) {
            if (modelService instanceof ModelOperationService) {
                ModelOperationService operationService = (ModelOperationService) modelService;
                switch(reworkStatus) {
                    case REWORK_SEARCHING:
                        operationsSchedule.add(operationService.getWrapperService().getOperation());
                        operationsScheduleService.add(operationService);
                        if (operationService.getWrapperService().getOperation().isReworkActivation()) {
                            reworkStatus = REWORK_FOUND;
                        }
                        index++;
                        break;
                    case REWORK_FOUND:
                        if (!operationService.getWrapperService().getOperation().isRework()) {
                            addReworkOperations(modelScheduleService, operationsScheduleService, operationsSchedule, reworkOperations, index);
                            index += reworkOperations.getOperationCount();
                            reworkStatus = REWORK_FINISHED;
                        }
                        operationService.getWrapperService().getOperation().setDisplayId(String.valueOf(index * 10));
                        operationsSchedule.add(operationService.getWrapperService().getOperation());
                        operationsScheduleService.add(operationService);
                        index++;
                        break;
                    case REWORK_FINISHED:
                        operationService.getWrapperService().getOperation().setDisplayId(String.valueOf(index * 10));
                        operationsSchedule.add(operationService.getWrapperService().getOperation());
                        operationsScheduleService.add(operationService);
                        index++;
                        break;
                }
            } else {
                operationsScheduleService.add(modelService);
            }
        }
        // If no rework flag has been found, add rework operations at the end
        if (reworkStatus != REWORK_FINISHED) {
            addReworkOperations(modelScheduleService, operationsScheduleService, operationsSchedule, reworkOperations, index);
        }
        
        // Update new operations list
        wrapper.setOperations(operationsSchedule);
        modelScheduleService.getChildren().clear();
        modelScheduleService.getChildren().addAll(operationsScheduleService);
        
        // Set schedule modified and notify model must be reloaded
        modelScheduleService.setModified();
        wrapper.setPassingId(passing);
		wrapper.updateHistoricalPassing(passing, null);
        displayArborescence(modelScheduleService, "");
    }

    /**
     * Build operation service for new rework operation and add them to the new operation list
     *  
     * @param scheduleService the schedule service
     * @param operationsSchedule the operations vector
     * @param operationsRework the operations for rework
     * @param index operation index
     * 
     * @throws ClientException
     * @throws ClientInterruption 
     */
    private void addReworkOperations(   IModelObjectService scheduleService,
                                        List<IModelObjectService> scheduleOperationsService,
                                        Vector<Operation> operationsSchedule, 
                                        Operations operationsRework, 
                                        int index) throws ClientException, ClientInterruption {
        getContext().getContextRequest().setRequestType(ContextRequest.ACTIVITY_UPDATE);
        for(Operation operation : operationsRework.getOperation()) {
            operation.setDisplayId(String.valueOf(index * 10));
            operationsSchedule.add(operation);
            ModelOperationService operationService = new ModelOperationService(scheduleService, operation);
            operationService.getLoaderService().load(getModelProvider());
            operationService.getStatusService().clean(null);
            operationService.getLoaderService().link();
            updateSubPhaseDisplayId(operationService);
            getModelProvider().addModelService(operationService.getIdentifier(), operationService);
            scheduleOperationsService.add(operationService);
            index++;
        }
    }
    
    private void updateSubPhaseDisplayId(ModelOperationService operationService) {
        int displayId = 1;
        for(IModelObjectService childService : operationService.getChildren()) {
            if (childService instanceof ModelSubPhaseService) {
                ((SubPhase) childService.getWrapperService().getObject()).setDisplayId(String.valueOf(displayId));
                displayId++;
            } else if (childService instanceof ModelSubPhaseGroupService) {
                ((SubPhaseGroup) childService.getWrapperService().getObject()).setDisplayId(String.valueOf(displayId));
                for(IModelObjectService childSubPhaseService : childService.getChildren()) {
                    if (childSubPhaseService instanceof ModelSubPhaseService) {
                        ((SubPhase) childSubPhaseService.getWrapperService().getObject()).setDisplayId(String.valueOf(displayId));
                    }
                }
                displayId++;
            }
        }
    }
}