package turbomeca.gamme.assembly.client.module.electronic.notification.action;

import turbomeca.gamme.assembly.client.ClientAssemblyControllersProvider;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.client.model.edit.notifications.AModelNotificationService;
import turbomeca.gamme.assembly.client.model.edit.notifications.ModelNotificationTaskBenchService;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.constants.PropertyConstants;
import turbomeca.gamme.ecran.client.model.provider.ModelXmlProvider;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.client.module.io.IoController;
import turbomeca.gamme.ecran.services.common.constants.GlobalConstants;

public class ActionCreateElectronicNotificationTaskBench extends AActionCreateElectronicNotification {

    /** */
    private String subPhaseId;
    
    /**
     * 
     * @param taskActionService
     */
    public ActionCreateElectronicNotificationTaskBench(String subPhaseId) {
        setSubPhaseId(subPhaseId);
    }

    @Override
    public boolean run(IController controller) throws ClientException {
        boolean succeed = false;
        ModelSubPhaseService modelServiceSubPhase = (ModelSubPhaseService) getModelProvider().getModelService(getSubPhaseId());
        AModelNotificationService notificationService = new ModelNotificationTaskBenchService(modelServiceSubPhase);
        
        boolean createOnServer = createNotification(notificationService, modelServiceSubPhase);
        String mustSynchronize = null;
        if(!createOnServer){
        	mustSynchronize = GlobalConstants.NOTIFICATION_STATUS_CREATED;
        }
       	notificationService.bindService(modelServiceSubPhase, mustSynchronize);
        getLoggerHmi().info(PropertyConstants.PROPERTY_NOTIFICATION_CREATED);
        
        getModelProvider().setModelStatus(ModelXmlProvider.MODEL_STATUS_MODIFIED);
        ((IoController) controller.getControllersProvider().getController(ClientAssemblyControllersProvider.INTERFACE_IO)).actionSaveOnServer();
        succeed = true;
        return succeed;
    }

    /**
     * @return the subPhaseId
     */
    public String getSubPhaseId() {
        return subPhaseId;
    }

    /**
     * @param subPhaseId the subPhaseId to set
     */
    public void setSubPhaseId(String subPhaseId) {
        this.subPhaseId = subPhaseId;
    }
}