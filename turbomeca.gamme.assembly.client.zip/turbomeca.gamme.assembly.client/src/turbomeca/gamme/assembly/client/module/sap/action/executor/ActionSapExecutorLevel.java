package turbomeca.gamme.assembly.client.module.sap.action.executor;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.module.intervention.action.ActionValidateChangeLevel;
import turbomeca.gamme.assembly.client.module.sap.action.comparator.ActionSapComparatorLevel;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.client.module.sap.SapAnalyse;
import turbomeca.gamme.ecran.client.module.sap.action.ASapExecutorAction;
import turbomeca.gamme.ecran.services.common.constants.GlobalConstants;
import turbomeca.gamme.ecran.services.common.utils.string.StringUtil;

public class ActionSapExecutorLevel extends ASapExecutorAction {
	

	
	/** logger for current class */
	private static Logger logger = Logger.getLogger(ActionSapExecutorLevel.class);

	@Override
	protected void execute(SapAnalyse analyses, IController controller) {
		logger.info("[SAP] Schedule level change, update levels with :");
		controller.execute(new ActionValidateChangeLevel(StringUtil.joinValues(analyses.getNewValue(), GlobalConstants.SEPARATOR_DOT_COMA)));
	}

	@Override
	protected String getMapKey() {
		return ActionSapComparatorLevel.MAP_KEY;
	}
	
	@Override
	public boolean canRun(IController controller) {
		return true;
	}


}
