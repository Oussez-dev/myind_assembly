package turbomeca.gamme.assembly.client.module.intervention.action;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.ClientAssemblyException;
import turbomeca.gamme.assembly.client.model.edit.schedule.AAssemblyScheduleService;
import turbomeca.gamme.assembly.services.model.data.Assembly;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.model.provider.ModelXmlProvider;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.client.module.intervention.action.AActionApplicabilityChangeUpdate;
import turbomeca.gamme.ecran.services.common.utils.transformer.ModelTransformation;


/**
 * This class is in charge of updating whole schedule according to a new
 * intervention type.
 * 
 * Technically, this is performed through an XSL transformation application
 * which updates the applicability attributes of filtered objects
 * 
 * @author ademartin
 *
 **/
public class ActionApplicabilityChangeUpdate extends AActionApplicabilityChangeUpdate  {

	/** Logger for current class */
	private static Logger logger = Logger.getLogger(ActionApplicabilityChangeUpdate.class);

	@Override
	protected void performTransformation(ModelTransformation transformer, IController controller) throws ClientException {
		AAssemblyScheduleService scheduleModelService = (AAssemblyScheduleService) getModelProvider().getModelScheduleService();

		try {
			// Performs the transformation
			if (transformer.transformStringToStream(scheduleModelService.getXmlSource())) {
				// Update schedule model with transform result
				ModelXmlProvider.getInstance().setObjectClass(Assembly.class);
				if (! ModelXmlProvider.getInstance().setXmlModel(transformer.getResultStream())) {
					throw new ClientAssemblyException();
				}
				scheduleModelService.getWrapperService().setObject(ModelXmlProvider.getInstance().getObject());
				scheduleModelService.getChildren().clear();
				scheduleModelService.getLoaderService().load(controller.getModelProvider());
//				((ModelStatusScheduleService)scheduleModelService.getStatusService()).computeSubphasesStatus();
				scheduleModelService.setModified();

			} else {
				throw new ClientAssemblyException(ClientAssemblyException.EXCEPTION_INTERNAL);
			}
		} catch (Exception e) {
			logger.error("change context error", e);
			throw new ClientAssemblyException(ClientAssemblyException.EXCEPTION_INTERNAL);
		}
	}
	
	@Override
	protected String getInstancePn() {
		AAssemblyScheduleService scheduleModelService = (AAssemblyScheduleService) getModelProvider().getModelScheduleService();
		return scheduleModelService.getWrapperService().getInstantiation().getPn();
	}

	@Override
	protected String getInstanceReturnCause() {
		return null;
	}

	@Override
	protected String getInstanceInterventionType() {
		AAssemblyScheduleService scheduleModelService = (AAssemblyScheduleService) getModelProvider().getModelScheduleService();
		return scheduleModelService.getWrapperService().getInstantiation().getInterventionType();
	}
}
