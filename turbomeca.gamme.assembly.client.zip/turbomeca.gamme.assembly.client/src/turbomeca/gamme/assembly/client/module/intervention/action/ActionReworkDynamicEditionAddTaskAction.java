package turbomeca.gamme.assembly.client.module.intervention.action;

import java.util.UUID;

import turbomeca.gamme.assembly.client.module.intervention.InterventionReworkDynamicManager;
import turbomeca.gamme.assembly.client.module.intervention.view.ReworkDynamicViewSubPhaseEdition;
import turbomeca.gamme.assembly.services.model.data.InputAction;
import turbomeca.gamme.assembly.services.model.data.InputActionChoice;
import turbomeca.gamme.assembly.services.model.data.InputField;
import turbomeca.gamme.assembly.services.model.data.Task;
import turbomeca.gamme.assembly.services.model.data.TaskAction;
import turbomeca.gamme.assembly.services.model.data.TaskChoiceItem;
import turbomeca.gamme.assembly.services.model.data.TasksItem;
import turbomeca.gamme.assembly.services.model.data.types.InputType;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.module.IController;

public class ActionReworkDynamicEditionAddTaskAction extends AActionReworkDynamic {

    private String taskId;
    
    public ActionReworkDynamicEditionAddTaskAction(InterventionReworkDynamicManager reworkManager, String taskId) {
        super(reworkManager);
        setTaskId(taskId);
    }

    @Override
    public boolean run(IController controller) throws ClientException {
        for(TasksItem tasksItem : getReworkManager().getSubPhaseEdited().getTasks().getTasksItem()) {
            Task task = tasksItem.getTask();
            if (task.getId().equals(getTaskId())) {
                InputField inputField = new InputField();
                inputField.setType(InputType.STRING);
                
                InputActionChoice inputActionChoice = new InputActionChoice();
                inputActionChoice.setInputField(inputField);
                
                InputAction inputAction = new InputAction();
                inputAction.setInputActionChoice(inputActionChoice);
                
                TaskAction taskAction = new TaskAction();
                taskAction.setId(UUID.randomUUID().toString());
                taskAction.setInputAction(inputAction);
                
                TaskChoiceItem taskChoiceItem = new TaskChoiceItem();
                taskChoiceItem.setTaskAction(taskAction);
                
                task.getTaskChoice().addTaskChoiceItem(taskChoiceItem);
            }
        }
        return new ReworkDynamicViewSubPhaseEdition(getReworkManager()).run();
    }

    /**
     * @return the taskId
     */
    public String getTaskId() {
        return taskId;
    }

    /**
     * @param taskId the taskId to set
     */
    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }
}