package turbomeca.gamme.assembly.client.module.externaltools.communication;

import java.io.IOException;
import java.net.ConnectException;
import java.net.SocketTimeoutException;
import java.util.List;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.URIException;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.util.URIUtil;
import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.module.externaltools.config.ConfigurationTaskPiloting;
import turbomeca.gamme.ecran.client.module.externaltools.config.ConfigurationServlet;
import turbomeca.gamme.ecran.services.devices.ExternalsToolsExceptions;
import turbomeca.gamme.ecran.services.devices.IDevices;
import turbomeca.gamme.ecran.services.devices.config.IConfigurationMeasure;

public class ServletCommunication implements IDevices {
	private static Logger logger = Logger.getLogger(ServletCommunication.class);

	private static final int SOCKET_TIMEOUT = 15 * 60 * 1000; // 15 mins
	private static final int CONNECTION_TIMEOUT = 60 * 1000; // 1 mins
	
	
	private HttpClient httpClient = null;
	private GetMethod getMethod = null;
	private String dataString = null;
	private ConfigurationServlet configuration;
	
	@Override
	public void init(IConfigurationMeasure configurationMeasure) {
		ConfigurationTaskPiloting conf = (ConfigurationTaskPiloting)configurationMeasure;
		setConfiguration(conf.getConfigurationServlet());
		
		httpClient = new HttpClient(); 
		httpClient.getHttpConnectionManager().getParams().setConnectionTimeout(CONNECTION_TIMEOUT);  
        httpClient.getHttpConnectionManager().getParams().setSoTimeout(SOCKET_TIMEOUT);  
	}

	@Override
	public String getData(){
		return dataString;
	}

	@Override
	public void listen() throws ExternalsToolsExceptions, InterruptedException  {
		logger.debug("[PILOTING] : ServletCommunication - Listen");
		getMethod= new GetMethod(getConfiguration().getUrlStartServlet());
		executeRequest();
	}

	/***
	 * 
	 * 
	 * 
	 * @throws ExternalsToolsExceptions 
	 * @throws IOException 
	 * @throws HttpException 
	 * @throws InterruptedException if the thread has been interrupted. This
	 *                              exception is raised manually as the library used
	 *                              for managing the connection is not an
	 *                              InterruptibleChannel (refer to Thread.interrupt
	 *                              javadoc)
	 */
	public void executeRequest() throws ExternalsToolsExceptions, InterruptedException {
		buildQueryString(getMethod);
		logger.debug("[Piloting] : ServletCommunication - Executing query");
		int httpStatus = -1;
		try {
			httpStatus = httpClient.executeMethod(getMethod);
			logger.debug("[PILOTING] : ServletCommunication - HTTP Status : " + httpStatus);
			
			if (Thread.currentThread().isInterrupted()) {
				throw new InterruptedException(
						"ServletCommunication Thread has been interrupted while executing a request");
			}
			if (httpStatus == HttpStatus.SC_INTERNAL_SERVER_ERROR) {
				logger.error("[PILOTING] : ServletCommunication ERROR : " + getMethod.getResponseBodyAsString());
				throw new ExternalsToolsExceptions(ExternalsToolsExceptions.ERROR_PILOTING_TOOLS_INTERNAL_ERROR);
			} else if (httpStatus == HttpStatus.SC_SERVICE_UNAVAILABLE) {
				logger.error("[PILOTING] : ServletCommunication ERROR : " + getMethod.getResponseBodyAsString());
				throw new ExternalsToolsExceptions(ExternalsToolsExceptions.ERROR_PILOTING_TOOLS_UNAVAILABLE);
			} else if (httpStatus != HttpStatus.SC_OK) {
				throw new ExternalsToolsExceptions(ExternalsToolsExceptions.ERROR_PILOTING_TOOLS_BAD_RESPONSE);
			}
			dataString = getMethod.getResponseBodyAsString();
		} catch (HttpException e) {
			if (!Thread.currentThread().isInterrupted()) 
				throw new ExternalsToolsExceptions(ExternalsToolsExceptions.ERROR_PILOTING_TOOLS);
			else
				logger.error("[PILOTING] : Error from tools piloting", e);
		} catch (ConnectException e) {
			throw new ExternalsToolsExceptions(ExternalsToolsExceptions.NO_RESPONSE_TOOLS_PILOTING, "", e);
		} catch (SocketTimeoutException e) {
			throw new ExternalsToolsExceptions(ExternalsToolsExceptions.NO_RESPONSE_TOOLS_PILOTING_TIMEOUT, "", e);
		} catch (IOException e) {
			throw new ExternalsToolsExceptions(ExternalsToolsExceptions.ERROR_PILOTING_TOOLS, "", e);
		}
	}

	@Override
	public List<String> getListData() {
		return null;
	}

	@Override
	public void stop() throws HttpException, IOException, ExternalsToolsExceptions, InterruptedException  {
		logger.debug("[PILOTING] : ServletCommunication - Stop");
		getMethod= new GetMethod(getConfiguration().getUrlStopServlet());
		executeRequest();
	}
	
	public void buildQueryString(GetMethod method) throws ExternalsToolsExceptions{
		try {
			logger.debug("[PILOTING] : ServletCommunication - Building query ...");
			//Print Configuration
			configuration.printConfiguration();
			String queryString = getMethod.getQueryString();
			String libParamHandler = "handler=";
			String libParamAction = "action=";
			int posValueHandler = queryString.indexOf(libParamHandler)+libParamHandler.length();
			int posLibAction = queryString.indexOf(libParamAction);
			int posValueAction = posLibAction+libParamAction.length();
			String action = queryString.substring(posValueAction);
			String handler = queryString.substring(posValueHandler, posLibAction-1);
			NameValuePair paramAction = new NameValuePair("action", URIUtil.encodeQuery(action));
			NameValuePair paramHandler = new NameValuePair("handler",URIUtil.encodeQuery(handler));
	        NameValuePair paramToolName= new NameValuePair("toolname",URIUtil.encodeQuery(configuration.getToolname()));
	        NameValuePair paramProgName= new NameValuePair("pset",URIUtil.encodeQuery(configuration.getNumProg()));
	        NameValuePair paramNbVis = new NameValuePair("batchsize",URIUtil.encodeQuery(String.valueOf(configuration.getNbVis())));
	        NameValuePair paramVin= new NameValuePair("vin",URIUtil.encodeQuery(configuration.getVin()));
	        String userLogin = configuration.getUser();
	        int userLoginLength = userLogin.length();
	        String userId = userLogin.substring(userLoginLength - 4, userLoginLength);
	        NameValuePair paramUser= new NameValuePair("user",URIUtil.encodeQuery(userId));
	        getMethod.setQueryString(new NameValuePair[]{paramHandler,paramAction, paramToolName, paramProgName, paramNbVis, paramVin, paramUser});
	        logger.debug("[PILOTING] : ServletCommunication - Build query :"+ getMethod.getQueryString());
		} catch (URIException e) {
			logger.error("ServletCommunication - buildQueryString ",e);
			throw new ExternalsToolsExceptions(ExternalsToolsExceptions.ERROR_BUILD_REQUEST_PILOTING_TOOLS);
		}
		
	}

	public void release() {
	if (getMethod != null) {
		getMethod.releaseConnection();
		}
	}
	
	
	public ConfigurationServlet getConfiguration() {
		return configuration;
	}

	public void setConfiguration(ConfigurationServlet configuration) {
		this.configuration = configuration;
	}

}
