package turbomeca.gamme.assembly.client.module.intervention.view;

import turbomeca.gamme.assembly.client.module.intervention.InterventionReworkDynamicManager;
import turbomeca.gamme.assembly.services.constants.AssemblyXsltConstants;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.constants.PropertyConstants;
import turbomeca.gamme.ecran.services.constants.XsltConstants;

public class ReworkDynamicViewSubPhaseSelection extends AReworkDynamicView {
	
	public ReworkDynamicViewSubPhaseSelection(InterventionReworkDynamicManager reworkManager) {
		super(AssemblyXsltConstants.XSLT_INTERVENTION_REWORK_DYNAMIC_MANUAL_SELECTION.value(), reworkManager);
	}
	
	@Override
	public boolean run() throws ClientException {
	    getReworkManager().buildXmlMerged();
	    getView().bindSource(getReworkManager().getXmlScheduleFlowMerge());
	    if (getReworkManager().getLevel() != null) {
	        getView().addParameter(AssemblyXsltConstants.XSLT_PARAMETER_LEVEL.value(), getReworkManager().getLevel());
	    }
	    getView().addParameter(XsltConstants.XSLT_PARAMETER_OPERATION_TITLE.value(), getReworkManager().getOperationTitle());
		return getView().displayModal(PropertyConstants.PROPERTY_MODAL_TITLE_REWORK_DYNAMIC_MANUAL_SELECTION, true);
	}
}
