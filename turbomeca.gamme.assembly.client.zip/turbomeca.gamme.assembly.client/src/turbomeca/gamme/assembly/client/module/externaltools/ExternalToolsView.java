package turbomeca.gamme.assembly.client.module.externaltools;

import turbomeca.gamme.ecran.client.module.InterfaceView;

public class ExternalToolsView extends InterfaceView {
	
	private static final String JS_INTERFACE_CALL_UPDATE_PLAY_ICON = "updatePlayIcon";
	private static final String JS_INTERFACE_STOP_BLOCK_UI = "stopBlockUI";
	private static final String JS_INTERFACE_START_BLOCK_UI = "startBlockUI";
	private static final String JS_INTERFACE_CLOSE_MODAL = "closeModal";
	
	public void changePlay(String toolId, boolean isRunning, String playerType) {
		logger.debug("changePlay : [ " + toolId + " - " + isRunning + " - " + playerType + " ]");
		getJsInterface().callJs(JS_INTERFACE_CALL_UPDATE_PLAY_ICON, new Object[] { toolId, isRunning, playerType });
	}
	
	public void stopBlockUI() {
		getJsInterface().callJs(JS_INTERFACE_STOP_BLOCK_UI, null);
	}
	
	public void startBlockUi(String appletId, String toolId) {
		getJsInterface().callJs(JS_INTERFACE_START_BLOCK_UI, new Object[] { appletId, toolId });
	}
	
	public void closeModal() {
		getJsInterface().callJs(JS_INTERFACE_CLOSE_MODAL, null);		
	}
}
