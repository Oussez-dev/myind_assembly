package turbomeca.gamme.assembly.client.module.electronic.notification.action;

import turbomeca.gamme.assembly.client.model.edit.IModelAssemblyWrapperScheduleService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelOperationService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskActionService;
import turbomeca.gamme.assembly.services.constants.Constants;
import turbomeca.gamme.assembly.services.model.data.TaskAction;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.constants.PropertyConstants;
import turbomeca.gamme.ecran.client.dispatcher.ActionDispatcherManager;
import turbomeca.gamme.ecran.client.interfaces.server.notification.NotificationServerInterfaceService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.client.module.action.AActionModify;

/**
 * This Action is raised when user select a peer for validating its taskAction
 * 
 * 
 * @author ahermo
 *
 */
public class ActionCreateElectronicValidation extends AActionModify {
	
	/**
	 * 
	 * Task action id who must double validate
	 * */
    private String taskActionId;
    
    /**
     * User Name who can validate
     */
    private String userLogin;
    
    /**
     * User Name who can validate
     */
    private String userName;
    
    /**
     * 
     * @param taskActionService
     */
    public ActionCreateElectronicValidation(String taskActionId, String userLogin, String userName) {
        setTaskActionId(taskActionId);
        setUserLogin(userLogin);
        setUserName(userName);
    }

    @Override
    public boolean run(IController controller) throws ClientException, ClientInterruption {
    	boolean isCreated;
    	String subPhaseNumber = null;
    	String operationNumber = null;
    	
    	
    	IModelAssemblyWrapperScheduleService serviceSchedule = (IModelAssemblyWrapperScheduleService)getModelProvider().getModelScheduleService().getWrapperService();
       
    	ModelTaskActionService modelServiceTaskAction = (ModelTaskActionService) getModelProvider().getModelService(getTaskActionId());
		
    	String order = serviceSchedule.getInstantiation().getOrder();
		String scheduleName = getContext().getContextUser().getRangeName();
		
		ModelSubPhaseService subPhaseService = (ModelSubPhaseService) modelServiceTaskAction.getAncestor(ModelSubPhaseService.class);
		
		if( subPhaseService !=null ){
			subPhaseNumber = subPhaseService.getWrapperService().getSubPhase().getDisplayId();
			ModelOperationService operationService = (ModelOperationService) subPhaseService.getAncestor(ModelOperationService.class);
    		if( operationService !=null ){
    			operationNumber = operationService.getWrapperService().getOperation().getDisplayId();		
    		}
    	}
    	
    	String comment = buildCommentDoubleValidation(modelServiceTaskAction);
    	IModelObjectService parentService = modelServiceTaskAction.getParent();
    	
    	if (parentService.getRunnableService().isFinished()) {
    	    parentService.getStatusService().resetState(false, true, null);
    	}
        
    	isCreated = NotificationServerInterfaceService.getInstance().createElectronicValidation(scheduleName, getRangeType(getConfiguration().getConfigRange().getRangeType()), order, operationNumber, subPhaseNumber, getTaskActionId(), getUserLogin(), getUserName(), comment);
        
    	if(isCreated){
        	getLoggerHmi().info(PropertyConstants.PROPERTY_MESSAGE_CREATE_VALIDATION);
        	controller.getNotificationsService().notifyElectronicNotificationChanged(modelServiceTaskAction);
        	controller.getNotificationsService().notifyServiceChanged(modelServiceTaskAction);
    	} else{
        	getLoggerHmi().error(PropertyConstants.PROPERTY_ERROR_CREATE_VALIDATION);
        }
        
        if (!getActionDispatcherManager().run()) {
            controller.getEngine().current(true);
        }
        return isCreated;
    }

    private ActionDispatcherManager getActionDispatcherManager() {
        return ActionDispatcherManager.getInstance();
    }
    
	private String buildCommentDoubleValidation(ModelTaskActionService modelServiceTaskAction) {
		String commentFormat = getConfiguration().getProperty(PropertyConstants.PROPERTY_COMMENT_CREATE_VALIDATION);
		String value = modelServiceTaskAction.getWrapperService().getValue();
		String unit = "NA";
		String name = "NA";
		TaskAction task = (TaskAction) modelServiceTaskAction.getWrapperService().getObject();
		if (task.getValue() != null) {
			if (task.getValue().getUnit() != null) {
				unit = task.getValue().getUnit();
			}
			if (task.getValue().getName() != null) {
				name = task.getValue().getName();
			}
		}
		return String.format(commentFormat, name, unit, value);
	}
	
	
	private String getRangeType(int rangeType) {
		if( rangeType == Constants.SCHEDULE_TYPE_ASSEMBLY) {
			return Constants.ASSEMBLY;
		}
		if( rangeType == Constants.SCHEDULE_TYPE_DISASSEMBLY) {
			return Constants.DISASSEMBLY;
		}
		return taskActionId;
	}
	
    
	@Override
	public boolean isUserAction() {
		return true;
	}
	
	public String getTaskActionId() {
		return taskActionId;
	}

	public String getUserLogin() {
		return userLogin;
	}

	public String getUserName() {
		return userName;
	}

	public void setTaskActionId(String taskActionId) {
		this.taskActionId = taskActionId;
	}

	public void setUserLogin(String userLogin) {
		this.userLogin = userLogin;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

}
