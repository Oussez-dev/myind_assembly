package turbomeca.gamme.assembly.client.module.intervention.view;

import turbomeca.gamme.assembly.client.module.intervention.InterventionReworkDynamicManager;
import turbomeca.gamme.assembly.services.constants.AssemblyXsltConstants;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.constants.PropertyConstants;

public class ReworkDynamicViewLevelSelection extends AReworkDynamicView {
	
	public ReworkDynamicViewLevelSelection(InterventionReworkDynamicManager reworkManager) {
		super(AssemblyXsltConstants.XSLT_INTERVENTION_REWORK_DYNAMIC_LEVEL_SELECTION.value(), reworkManager);
	}
	
	@Override
	public boolean run() throws ClientException {
	    getReworkManager().buildXmlMerged();
	    getView().bindService(getModelProvider().getModelScheduleService());
		return getView().displayModal(PropertyConstants.PROPERTY_MODAL_TITLE_REWORK_DYNAMIC_LEVEL_SELECTION, true);
	}
}
