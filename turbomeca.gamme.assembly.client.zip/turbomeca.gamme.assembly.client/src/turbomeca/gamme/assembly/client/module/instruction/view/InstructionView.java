package turbomeca.gamme.assembly.client.module.instruction.view;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.model.edit.IModelAssemblyWrapperService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelIngredientsService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelMarksService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskActionMeasureService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskPilotingService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelToolsService;
import turbomeca.gamme.assembly.services.constants.AssemblyXsltConstants;
import turbomeca.gamme.assembly.services.model.data.TaskActionMeasure;
import turbomeca.gamme.assembly.services.model.data.types.StatusType;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelScheduleService;
import turbomeca.gamme.ecran.client.module.ViewConverter;
import turbomeca.gamme.ecran.client.module.instruction.view.AInstructionView;
import turbomeca.gamme.ecran.services.constants.XsltConstants;

public class InstructionView extends AInstructionView {
	
	private static final String JS_INTERFACE_UPDATE_SAP_STATUS = "setSapStatus";

	/** logger for current class */
	private static Logger logger = Logger.getLogger(InstructionView.class);

    /**
     * Constructor
     * 
     * @param scheduleService
     */
    public InstructionView(IModelScheduleService scheduleService) {
    	super(scheduleService);
    }
    
    /**
     * Constructor
     * 
     * @param scheduleService
     */
    public InstructionView(String xsltTemplate) {
    	super(xsltTemplate);
    }

    /**
     * 
     * @param taskActionService
     * @throws ClientException
     */
    @Override
    public void focusTaskActionService(IModelObjectService service) throws ClientException {
        IModelObjectService parentService = service.getParent();
        if (parentService instanceof ModelToolsService
                || parentService instanceof ModelMarksService
                || parentService instanceof ModelIngredientsService) {
            getView().showElement(parentService.getIdentifier());
        }

        if (service instanceof ModelTaskActionMeasureService) {
            getView().focusInput(((ModelTaskActionMeasureService) service).getTaskActionId(),
                    ((ModelTaskActionMeasureService) service).getTaskActionId(), 0);
        } else if (service instanceof ModelTaskPilotingService) {
            ModelTaskPilotingService taskPiloting = (ModelTaskPilotingService) service;
            getView().focusInput(taskPiloting.getWrapperService().getId(),
                    taskPiloting.getTaskActionId(), 0);
        } else {
            getView().focusInput(service.getHmiUpdaterService().getHmiParentId(),
                    service.getIdentifier(), 0);
        }
    }

    
    /**
     * 
     * @param taskActionService
     * @throws ClientException
     */
    @Override
    public void blurTaskActionService(IModelObjectService service) throws ClientException {
        if (service instanceof ModelTaskPilotingService) {
            getView().blurInput(((ModelTaskPilotingService) service).getTaskActionId(),
                    ((ModelTaskPilotingService) service).getTaskActionId(), 0);
        } else if (service instanceof ModelTaskActionMeasureService) {
            getView().blurInput(((ModelTaskActionMeasureService) service).getTaskActionId(),
                    ((ModelTaskActionMeasureService) service).getTaskActionId(), 0);
        } else {
            getView().blurInput(service.getHmiUpdaterService().getHmiParentId(),
                    service.getIdentifier(), 0);
        }
    }


    /**
     * Path For delivery update Actions TaskMeasure
     * 
     * @param modelService
     * @param rddActive
     * @param toolsActive
     */
    public void updateTaskMeasureActions(IModelObjectService modelService, boolean rddActive,
            boolean toolsActive) {

        TaskActionMeasure taskMeasure = (TaskActionMeasure) modelService.getWrapperService().getObject();
        String idTaskMeasure = taskMeasure.getId();

        if (taskMeasure.getMeasureRdd() != null) {
            getView().setDisableImageButon("play_measureRdd_" + idTaskMeasure, rddActive);
        }
        if (taskMeasure.getMeasureTool() != null) {
            getView().setDisableImageButon("play_measureTool_" + idTaskMeasure, toolsActive);
            getView().setDisable("measureToolsBlock_" + idTaskMeasure, toolsActive);
        }
    }

    /**
     * Path For delivery update Status taskMeasure
     * 
     * @param modelService
     * @param rddActive
     * @param toolsActive
     */
    public void updateTaskMeasureStatus(IModelObjectService modelService, StatusType stateSap,
            StatusType stateRdd, StatusType stateTools) {
        TaskActionMeasure taskMeasure = (TaskActionMeasure) modelService.getWrapperService()
                .getObject();
        String id = taskMeasure.getId();

        if (taskMeasure.getMeasureSap() != null) {
            setStatusManual(id + "_0", stateSap.value(), modelService.getWrapperService().getObjectTagName());
        }

        if (taskMeasure.getMeasureRdd() != null) {
            setStatusManual(id + "_1", stateRdd.value(),  modelService.getWrapperService().getObjectTagName());
        }

        if (taskMeasure.getMeasureTool() != null) {
            setStatusManual(id + "_2", stateTools.value(), modelService.getWrapperService().getObjectTagName());
        }
    }

    /** Patch for delivery */
    public void setStatusManual(String id, String status, String objectType) {
        getView().setStatus(id, status, objectType);
    }
    
    
    /**
     * 
     * @param view
     */
    @Override
    public void addInstructionViewCustomParameters(ViewConverter view, IModelObjectService modelService) {
    	IModelScheduleService schedule = getModelProvider().getModelScheduleService();
        getViewConverter().addParameter(XsltConstants.XSLT_PARAMETER_INSTANCES.value(), ((IModelAssemblyWrapperService) schedule.getWrapperService()).getInstantiation().getInstances());
        getViewConverter().addParameter(XsltConstants.XSLT_PARAMETER_GEODE_URL_DEFAULT.value(), getContext().getContextConfig().getExternalWebLinkEncloser());
        ModelSubPhaseService subphaseService = (ModelSubPhaseService) modelService.getAncestor(ModelSubPhaseService.class);
        if(subphaseService != null){
            getViewConverter().addParameter(XsltConstants.XSLT_PARAMETER_SUBPHASE_ID.value(), subphaseService.getIdentifier());
        }
        else{
        	 getViewConverter().addParameter(XsltConstants.XSLT_PARAMETER_SUBPHASE_ID.value(), "");
        }
    }

	@Override
	protected String getXsltUpdateFile() {
		return AssemblyXsltConstants.XSLT_UPDATE.value();
	}
	
    public void updateSapStatus(IModelObjectService service, StatusType sapStatus) {
        logger.debug("updateSapStatus : [id=" + service.getIdentifier() + " - status=" + sapStatus.value() + "]");
        getView().getJsInterface().callJs(JS_INTERFACE_UPDATE_SAP_STATUS,
                new Object[] { service.getIdentifier(), sapStatus.value() });
    }
}
