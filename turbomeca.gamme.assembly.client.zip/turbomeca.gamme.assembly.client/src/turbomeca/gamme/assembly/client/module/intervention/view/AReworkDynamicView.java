package turbomeca.gamme.assembly.client.module.intervention.view;

import turbomeca.gamme.assembly.client.module.intervention.InterventionReworkDynamicManager;
import turbomeca.gamme.ecran.client.module.action.AActionView;

public abstract class AReworkDynamicView extends AActionView {

    /** */
    private InterventionReworkDynamicManager reworkManager;
    
    /**
     * 
     * @param newDerog 
     * @param newSn 
     * @param newPn 
     * @param services
     * @param instancesId
     */
    public AReworkDynamicView(String xslFile, InterventionReworkDynamicManager reworkManager) {
        super(xslFile);
        setReworkManager(reworkManager);
    }

    /**
     * @return the reworkManager
     */
    public InterventionReworkDynamicManager getReworkManager() {
        return reworkManager;
    }

    /**
     * @param reworkManager the reworkManager to set
     */
    public void setReworkManager(InterventionReworkDynamicManager reworkManager) {
        this.reworkManager = reworkManager;
    }
}