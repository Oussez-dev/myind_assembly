package turbomeca.gamme.assembly.client.module.intervention.action;

import java.util.ArrayList;
import java.util.Collections;

import turbomeca.gamme.assembly.client.ClientAssemblyControllersProvider;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelOperationService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.client.module.edition.AssemblyEditionController;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelScheduleService;
import turbomeca.gamme.ecran.client.model.provider.ModelXmlProvider;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.services.common.utils.misc.FormatUtils;

public class ActionSynchronizePredefinedTuning extends AActionRework{

	private ArrayList<String> listOperationRework;
	private ArrayList<String> listSubphaseRework;

	public ActionSynchronizePredefinedTuning() {
		ArrayList<String> listIdOperationRework = new ArrayList<String>();
		ArrayList<String> listIdSubphaseRework = new ArrayList<String>();

		IModelScheduleService modelScheduleService = getModelProvider().getModelScheduleService();
		for(IModelObjectService operationService : modelScheduleService.getChildrenDeep(ModelOperationService.class)){
			ModelOperationService modelOperationService = (ModelOperationService) operationService;
			if(modelOperationService.isRework()){
				listIdOperationRework.add(modelOperationService.getIdentifier());
				for(IModelObjectService subphaseService : operationService.getChildrenDeep(ModelSubPhaseService.class)){
					listIdSubphaseRework.add(subphaseService.getIdentifier());
				}
			}
		}
		//reverse the list for the synchronization 
		Collections.reverse(listIdOperationRework);
		setListOperationRework(listIdOperationRework);
		setListSubphaseRework(listIdSubphaseRework);
	}

	@Override
	public boolean run(IController controller) throws ClientException,
	ClientInterruption {
		if(getContext().getContextEditing() != null){
			getModelProvider().setModelStatus(ModelXmlProvider.MODEL_STATUS_VALID);
			AssemblyEditionController editionController = (AssemblyEditionController)controller.getControllersProvider().getController(ClientAssemblyControllersProvider.INTERFACE_EDITION);
			String[] newListObjectEdited = addOperationReworkOnObjectEdited(getContext().getContextEditing().getObjectEdited(), getListOperationRework());
			editionController.updateOperationsEdited(FormatUtils.getStringValues(newListObjectEdited));
			getModelProvider().setModelStatus(ModelXmlProvider.MODEL_STATUS_MODIFIED);
			String[] ListObjetEditedWithoutOperation = removeOperationReworkOnObjectEdited(getContext().getContextEditing().getObjectEdited());
			editionController.updateOperationsEdited(FormatUtils.getStringValues(ListObjetEditedWithoutOperation));

		}
		return true;
	}

	/**
	 * remove the if of the rework operation from the list of edited object
	 * @param objectEdited
	 * @return
	 */
	private String[] removeOperationReworkOnObjectEdited(String[] objectEdited) {
		ArrayList<String> arraylistObjectEdited = new ArrayList<String>(); 
		Collections.addAll(arraylistObjectEdited, objectEdited);
		ArrayList<String> listIdToRemove = new ArrayList<String>();
		for(String id : arraylistObjectEdited){
			if(getListOperationRework().contains(id)){
				listIdToRemove.add(id);
			}
		}
		for(String idToRemove : listIdToRemove){
			arraylistObjectEdited.remove(idToRemove);
		}
		arraylistObjectEdited.addAll(getListSubphaseRework());
		return arraylistObjectEdited.toArray(new String[arraylistObjectEdited.size()]);
	}

	/**
	 * Add id of rework operation and remove the id of rework subPhase from the list of edited object
	 * So the rework subPhase will not be synchronized and only their operation.
	 * @param objectEdited
	 * @param listOperationReworkid
	 * @return
	 */
	private String[] addOperationReworkOnObjectEdited(String[] objectEdited, ArrayList<String> listOperationReworkid) {
		ArrayList<String> arraylistObjectEdited = new ArrayList<String>(); 
		Collections.addAll(arraylistObjectEdited, objectEdited);
		arraylistObjectEdited.addAll(listOperationReworkid);
		return arraylistObjectEdited.toArray(new String[arraylistObjectEdited.size()]);
	}

	public ArrayList<String> getListOperationRework() {
		return listOperationRework;
	}

	public void setListOperationRework(ArrayList<String> listOperationRework) {
		this.listOperationRework = listOperationRework;
	}

	public ArrayList<String> getListSubphaseRework() {
		return listSubphaseRework;
	}

	public void setListSubphaseRework(ArrayList<String> listSubphaseRework) {
		this.listSubphaseRework = listSubphaseRework;
	}

}
