package turbomeca.gamme.assembly.client.module.instruction.action;

import java.io.File;
import java.io.StringReader;
import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.stream.StreamSource;

import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.model.edit.schedule.AAssemblyScheduleService;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.constants.PropertyConstants;
import turbomeca.gamme.ecran.client.interfaces.server.ServerInterfaceRunner;
import turbomeca.gamme.ecran.client.interfaces.server.bdcl.ServerInterfaceBDCLGetData;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.client.module.instruction.action.ActionCheckValidateSchedule;
import turbomeca.gamme.ecran.server.ws.bdcl.client.interfaces.DataAcquisitionCode;
import turbomeca.gamme.ecran.server.ws.bdcl.client.interfaces.DataAcquisitionResultBean;
import turbomeca.gamme.ecran.server.ws.bdcl.client.interfaces.DataAcquisitionResultListBean;
import turbomeca.gamme.ecran.server.ws.bdcl.client.interfaces.dataAcquisition.WSBDCLStub.WS_BDCL_DataAcquisitionResponse;

public class ActionCheckValidateScheduleAssembly extends ActionCheckValidateSchedule{

	private static Logger logger = Logger.getLogger(ActionCheckValidateScheduleAssembly.class);
	
	private ServerInterfaceRunner runner;
	
	public ActionCheckValidateScheduleAssembly() {
		runner = new ServerInterfaceRunner();
	}
	
	@Override
	public boolean run(IController controller) throws ClientException, ClientInterruption {
		
		// Create the four param for the request (schedule's id, schedule's file name without extension, 
		// schedule's xml stream, instantiated schedule path)
		
		File serverDirFile = new File(getContext().getContextConfig().getDirectoryServerPath());
		File scheduleFile = new File(serverDirFile, getContext().getContextUser().getRangeName());

		String filePath = scheduleFile.getParent();
		String fileName = FilenameUtils.getBaseName(scheduleFile.getAbsolutePath());
		String id = buildScheduleId();
		// SHE doesn't need the schedule xml anymore
		String xmlStream = null;
		
		logger.info("Initializing ServerInterfaceBDCL with fileName=" + fileName + ", scheduleId=" + id + ", xmlStream=" + xmlStream
				+ "and filePath=" + filePath);
		
		// Creating the interface with BDCL with required fields describes in the wsdl
		ServerInterfaceBDCLGetData getDataBdclInterface = new ServerInterfaceBDCLGetData(fileName, id, xmlStream, filePath);
		
		WS_BDCL_DataAcquisitionResponse response = null;
		DataAcquisitionResultListBean dataAcqList = null;
		String xmlResp = null;
		
		// Run the interface to request BDCL
		if(getRunner().run(getDataBdclInterface)) {
			
			response = getDataBdclInterface.getResponse();
			
			xmlResp = response.getWS_BDCL_DataAcquisitionResult();
			
			logger.info("Response from BDCL : " + xmlResp);
			
			try {
				JAXBContext jaxbContext = JAXBContext.newInstance(DataAcquisitionResultListBean.class);
				Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
				StringReader reader = new StringReader(xmlResp);
				dataAcqList = (DataAcquisitionResultListBean) jaxbUnmarshaller.unmarshal(reader);
			} catch (JAXBException e) {
				logger.error("Can't Parse BDCL Response - ", e);
				throw new ClientException(PropertyConstants.PROPERTY_ERROR_RESPONSE_FORMAT);
			}
			
			// StreamSource instead of String in order to allow the xsl processor (Saxon) to handle as a map the content of resultData 
			// (which is formatted in xml)
			StringReader sr = new StringReader(xmlResp);
			StreamSource ss = new StreamSource(sr);
			setResult(ss);
		}

		if (response != null) {
			boolean isCheck = true;
			// If there is at least one ERR code the control is fail
			for(DataAcquisitionResultBean dt : dataAcqList.getResult()) {
				if(dt.getCode().equals(DataAcquisitionCode.ERR)) {
					isCheck = false;
					break;
				}
			}
			
			return isCheck;
		} else {
			setResult(buildDefaultErrorResult());
			throw new ClientException(PropertyConstants.PROPERTY_ERROR_SERVICE_COMMUNICATION);
		}
	}

	/**
	 * @return A default error message when BDCL's response is null. This message is formatted like BDCL response
	 * in order to be display in the dedicated modal window.
	 */
	private StreamSource buildDefaultErrorResult() {
			DataAcquisitionResultListBean defErrBeanList = new DataAcquisitionResultListBean();
			DataAcquisitionResultBean defErr = new DataAcquisitionResultBean();
			defErr.setCode(DataAcquisitionCode.ERR);
			defErr.setMessage(getConfiguration().getProperty(PropertyConstants.PROPERTY_ERROR_SERVICE_COMMUNICATION));
			defErrBeanList.getResult().add(defErr);
			JAXBContext jaxbContext;
			String errString = null;
			
			try {
				jaxbContext = JAXBContext.newInstance(DataAcquisitionResultListBean.class);
				Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
				jaxbMarshaller.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.TRUE);
				StringWriter sw = new StringWriter();
				jaxbMarshaller.marshal(defErrBeanList, sw);
				errString = sw.toString();
			} catch (JAXBException e) {
				logger.error("Can't Parse default Response - ", e);
			}
			StringReader sr = new StringReader(errString);
			return new StreamSource(sr);
	}

	private String buildScheduleId() {
		// Geode version
		String version = ((AAssemblyScheduleService) getModelProvider().getModelScheduleService()).getGeodeVersion();
		// Geode reference
		String geodeRef = ((AAssemblyScheduleService) getModelProvider().getModelScheduleService()).getGeodeReference();
		return geodeRef.concat("#").concat(version);
	}

	public ServerInterfaceRunner getRunner() {
		return runner;
	}

	public void setRunner(ServerInterfaceRunner runner) {
		this.runner = runner;
	}
}
