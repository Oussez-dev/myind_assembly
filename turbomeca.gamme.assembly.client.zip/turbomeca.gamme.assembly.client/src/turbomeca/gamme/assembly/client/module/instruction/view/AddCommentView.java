package turbomeca.gamme.assembly.client.module.instruction.view;

import turbomeca.gamme.assembly.services.constants.AssemblyXsltConstants;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.constants.PropertyConstants;
import turbomeca.gamme.ecran.client.module.action.AActionView;
import turbomeca.gamme.ecran.services.constants.XsltConstants;

public class AddCommentView extends AActionView {
	
	private String objectId;
    private int groupId;
    private String comment;

    public AddCommentView(String objectId, int groupId, String comment) {
    	super(AssemblyXsltConstants.XSLT_INSTRUCTION_ADD_COMMENT_NON_APPLICABLE_SUBPHASE.value());
        setObjectId(objectId);
        setGroupId(groupId);
        setComment(comment);
    }

    @Override
    public boolean run() throws ClientException {
        getView().addParameter(XsltConstants.XSLT_PARAMETER_OBJECT_ID.value(),
                getObjectId());
        getView().addParameter(XsltConstants.XSLT_PARAMETER_GROUP_ID.value(),
                String.valueOf(getGroupId()));
        if (getComment() != null) {
            getView().addParameter(XsltConstants.XSLT_PARAMETER_VALUE.value(), getComment());
        }
        return getView().displayModal(PropertyConstants.PROPERTY_MODAL_TITLE_COMMENTARY, true);
    }

    public int getGroupId() {
        return groupId;
    }

    public void setGroupId(int groupId) {
        this.groupId = groupId;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

	public String getObjectId() {
		return objectId;
	}

	public void setObjectId(String objectId) {
		this.objectId = objectId;
	}


}