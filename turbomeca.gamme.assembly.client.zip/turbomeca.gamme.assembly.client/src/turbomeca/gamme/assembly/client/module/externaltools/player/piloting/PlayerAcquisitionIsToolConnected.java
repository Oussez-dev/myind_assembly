package turbomeca.gamme.assembly.client.module.externaltools.player.piloting;

import java.io.IOException;
import java.net.ConnectException;
import java.net.SocketTimeoutException;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.module.externaltools.player.measure.APlayerAcquisition;
import turbomeca.gamme.assembly.client.module.externaltools.player.measure.ServiceType;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.services.devices.ExternalsToolsExceptions;

public class PlayerAcquisitionIsToolConnected extends APlayerAcquisition {
	private static final int SOCKET_TIMEOUT = 15 * 60 * 1000; // 15 mins
	private static final int CONNECTION_TIMEOUT = 60 * 1000; // 1 mins
	
	private static Logger logger = Logger.getLogger(PlayerAcquisitionIsToolConnected.class);
	
	private String url;

	private String toolSn;

	private HttpClient httpClient;
	private GetMethod getMethod;
	
	public PlayerAcquisitionIsToolConnected (String url, String toolSn){
		//TODO JGU added tool connected
		super(ServiceType.TOOL_CONNECTED);
		this.toolSn = toolSn;
		this.url = url;
		
		httpClient = new HttpClient(); 
		httpClient.getHttpConnectionManager().getParams().setConnectionTimeout(CONNECTION_TIMEOUT);  
        httpClient.getHttpConnectionManager().getParams().setSoTimeout(SOCKET_TIMEOUT);  
	}
	
	@Override
	public String acquireAcquistion() throws ExternalsToolsExceptions, InterruptedException  {
		logger.debug("[PILOTING] : PlayerAcquisitionTools - acquireAcquistion");
		String dataString = null;
		int httpStatus = -1;
		try{
			getMethod = new GetMethod(url);
			getMethod.setQueryString(new NameValuePair[]{new NameValuePair("toolName", toolSn)});
			logger.debug("[PILOTING] : Request sent :"+ getMethod.getQueryString());
			httpStatus = httpClient.executeMethod(getMethod);

			if (Thread.currentThread().isInterrupted()) {
				throw new InterruptedException(
						"ServletCommunication Thread has been interrupted while executing a request");
			}
			if (httpStatus == HttpStatus.SC_INTERNAL_SERVER_ERROR) {
				throw new ExternalsToolsExceptions(ExternalsToolsExceptions.ERROR_PILOTING_TOOLS_INTERNAL_ERROR);
			} else if (httpStatus == HttpStatus.SC_SERVICE_UNAVAILABLE) {
				logger.error("[PILOTING] : " + getMethod.getResponseBodyAsString());
				throw new ExternalsToolsExceptions(ExternalsToolsExceptions.ERROR_PILOTING_TOOLS_UNAVAILABLE);
			} else if (httpStatus != HttpStatus.SC_OK) {
				throw new ExternalsToolsExceptions(ExternalsToolsExceptions.ERROR_PILOTING_TOOLS_BAD_RESPONSE);
			}
			dataString = getMethod.getResponseBodyAsString();
		} catch (HttpException e) {
			if (!Thread.currentThread().isInterrupted()) 
				throw new ExternalsToolsExceptions(ExternalsToolsExceptions.ERROR_PILOTING_TOOLS);
			else
				logger.error("[PILOTING] : Error from tools piloting", e);
		} catch (ConnectException e) {
			throw new ExternalsToolsExceptions(ExternalsToolsExceptions.NO_RESPONSE_TOOLS_PILOTING, "", e);
		} catch (SocketTimeoutException e) {
			throw new ExternalsToolsExceptions(ExternalsToolsExceptions.NO_RESPONSE_TOOLS_PILOTING_TIMEOUT, "", e);
		} catch (IOException e) {
			throw new ExternalsToolsExceptions(ExternalsToolsExceptions.ERROR_PILOTING_TOOLS, "", e);
		} finally{
			if (getMethod != null) {
				getMethod.releaseConnection();
			}
		}
		return dataString;
	}
	
	@Override
	public String acquire() throws ExternalsToolsExceptions, ClientInterruption {
		String value = null;
		try {
			value = acquireAcquistion();
		} catch (InterruptedException e) {
			logger.error("[PILOTING] : Interuption of acquisition", e);
			Thread.currentThread().interrupt();
		} 
		return value;
	}
}
