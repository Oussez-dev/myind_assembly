package turbomeca.gamme.assembly.client.module.externaltools.action;

import turbomeca.gamme.assembly.client.ClientAssemblyException;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskActionMeasureService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskPilotingService;
import turbomeca.gamme.assembly.client.module.externaltools.ExternalToolsController;
import turbomeca.gamme.assembly.client.module.externaltools.player.InstructionPlayerFactory;
import turbomeca.gamme.assembly.services.model.data.InputValue;
import turbomeca.gamme.assembly.services.model.data.TaskPiloting;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.client.module.externaltools.player.IPlayerInstruction;
import turbomeca.gamme.ecran.services.devices.ExternalsToolsExceptions;

public class ActionRunPilotingTool extends AActionRunPlayer {

	private String serviceId;
	
	public ActionRunPilotingTool(String serviceId){
		setServiceId(serviceId);
	}
	
	@Override
	public boolean run(IController controller) throws ClientException, ClientInterruption {
		boolean success = true;
		ModelTaskPilotingService taskPilotingService = ((ModelTaskPilotingService) getModelProvider().getModelService(getServiceId()));
		
		if(!isSubPhaseFinished(taskPilotingService)) {
			if(!isResourcesFinished(taskPilotingService)) {
				throw new ClientAssemblyException(ClientAssemblyException.EXCEPTION_INPUT_RESOURCES_NOT_FINISHED);
			}
			
	        TaskPiloting  taskPiloting = (TaskPiloting)taskPilotingService.getWrapperService().getObject();
	        InputValue toolEnter = taskPiloting.getTaskAction().getInputAction().getInputValue();
	        
	        if(toolEnter == null || toolEnter.getValue().isEmpty()) {
	        	throw new ClientException(ExternalsToolsExceptions.TOOLS_INPUT_MISSING);
	        }
	        
	    	IPlayerInstruction  playerInstruction = InstructionPlayerFactory.createPlayer(taskPilotingService,false,false);
	    	((ExternalToolsController) controller).setPlayerInProgress(playerInstruction);
	    	success = playerInstruction.run(controller);
		}
		return success;    	
	}

	
	public String getServiceId() {
		return serviceId;
	}

	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}

	@Override
	protected boolean canRunPlayer(
			ModelTaskActionMeasureService taskActionMeasure) {
		return true;
	}
}
