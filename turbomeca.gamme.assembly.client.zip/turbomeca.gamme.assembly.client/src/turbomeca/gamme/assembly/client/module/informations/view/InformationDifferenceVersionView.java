package turbomeca.gamme.assembly.client.module.informations.view;

import turbomeca.gamme.assembly.services.constants.AssemblyXsltConstants;
import turbomeca.gamme.ecran.client.constants.PropertyConstants;
import turbomeca.gamme.ecran.client.module.action.AActionView;

public class InformationDifferenceVersionView extends AActionView {

	/** Must be set if differences modal must show a "read term" version of itself */
	private boolean isShownAtOpening;
	
	public InformationDifferenceVersionView(boolean isShownAtOpening) {
		super(AssemblyXsltConstants.XSLT_INFORMATION_DIFFERENCES.value());
		this.isShownAtOpening = isShownAtOpening;
	}
	
	@Override
	public boolean run() {
		getView().bindService(getModelProvider().getModelScheduleService());
		
		if(isShownAtOpening) {
			// Modification modal is opened as "read term" version, must disable top-right corner close button
			// and set XSL parameter to toggle its design
			getView().addParameter(AssemblyXsltConstants.XSLT_PARAMETER_IS_SHOWN_AT_OPENING.value(), "true");
			return getView().displayModal(PropertyConstants.PROPERTY_MODAL_TITLE_SCHEDULE_DIFFERENCES, false);
		}
		
		return getView().displayModal(PropertyConstants.PROPERTY_MODAL_TITLE_SCHEDULE_DIFFERENCES, true);
	}
}
