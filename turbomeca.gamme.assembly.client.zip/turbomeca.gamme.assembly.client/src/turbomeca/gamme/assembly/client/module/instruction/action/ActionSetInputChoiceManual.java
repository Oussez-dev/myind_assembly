package turbomeca.gamme.assembly.client.module.instruction.action;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelMarkService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskActionService;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.module.IController;

public class ActionSetInputChoiceManual extends ActionSetInput {

	/**
	 * 
	 * @param taskActionId
	 * @param value
	 */
	public ActionSetInputChoiceManual(String taskActionId, String value) {
		super(taskActionId, value);
	}
	
	protected void applyReferenceValue(IModelObjectService modelObjectService,
			ModelTaskActionService taskActionService) throws ClientException,
			ClientInterruption {
		applyReferenceValue(null, modelObjectService, taskActionService);
	}
	
	protected void applyReferenceValue(IController controller, IModelObjectService modelObjectService,
			ModelTaskActionService taskActionService) throws ClientException,
			ClientInterruption {
		taskActionService.addChoiceValue(getValue(), true);
		if (modelObjectService instanceof ModelMarkService) {
	            ((ModelMarkService) modelObjectService).applyValueToReference(null, taskActionService, getValue());
	    }
	}
}
