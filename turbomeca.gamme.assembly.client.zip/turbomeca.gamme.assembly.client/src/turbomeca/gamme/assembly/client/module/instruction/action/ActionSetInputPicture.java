package turbomeca.gamme.assembly.client.module.instruction.action;

import java.io.File;
import java.util.Date;

import turbomeca.gamme.assembly.client.module.instruction.InstructionController;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.client.module.instruction.action.ActionSetInput;
import turbomeca.gamme.ecran.client.module.io.action.ActionUploadDocument;

public class ActionSetInputPicture extends ActionSetInput {

	public ActionSetInputPicture(String taskActionId, String value) {
		super(taskActionId, value);
	}

	@Override
	public boolean run(IController controller) throws ClientException, ClientInterruption {
		String valueRaw = getValue();
		if (valueRaw != null) {
			setValue(new Date().getTime()+"-"+ new File(valueRaw).getName());
			new ActionUploadDocument(valueRaw, getValue()).run(controller);
			((InstructionController)controller).setValuePictureFromCheck(getValue());
		}
		else { 
		    setValue(null);
		    controller.getNotificationsService().notifyServiceChanged(getTaskActionService());
		}
		return super.run(controller);
	}
}
