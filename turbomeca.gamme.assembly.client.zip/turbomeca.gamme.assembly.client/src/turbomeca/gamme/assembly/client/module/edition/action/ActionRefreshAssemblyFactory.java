package turbomeca.gamme.assembly.client.module.edition.action;

public class ActionRefreshAssemblyFactory extends turbomeca.gamme.ecran.client.module.edition.action.ActionRefreshFactory {

	@Override
	public ActionRefresh create() {
		return new ActionRefresh();
	}
}
