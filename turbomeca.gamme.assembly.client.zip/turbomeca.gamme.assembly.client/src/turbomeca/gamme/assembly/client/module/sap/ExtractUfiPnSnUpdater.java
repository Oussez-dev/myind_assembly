package turbomeca.gamme.assembly.client.module.sap;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.module.intervention.action.ActionChangeMark;
import turbomeca.gamme.assembly.client.module.intervention.action.ActionChangeMarkMultiplePnValues;
import turbomeca.gamme.assembly.services.model.data.Derogation;
import turbomeca.gamme.assembly.services.model.data.InputAction;
import turbomeca.gamme.assembly.services.model.data.InputActionChoice;
import turbomeca.gamme.assembly.services.model.data.InputChoice;
import turbomeca.gamme.assembly.services.model.data.InputValue;
import turbomeca.gamme.assembly.services.model.data.Mark;
import turbomeca.gamme.assembly.services.model.data.PN;
import turbomeca.gamme.assembly.services.model.data.SN;
import turbomeca.gamme.assembly.services.model.data.StringValue;
import turbomeca.gamme.assembly.services.model.data.SubPhase;
import turbomeca.gamme.assembly.services.model.data.TaskAction;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.interfaces.server.sap.mapper.DataResponseMappedMaterialsMarks;
import turbomeca.gamme.ecran.client.interfaces.server.sap.mapper.DataResponseMarkPnSnDerog;
import turbomeca.gamme.ecran.client.interfaces.server.sap.mapper.DataResponseSnDerog;
import turbomeca.gamme.ecran.client.model.AModelObjectService;
import turbomeca.gamme.ecran.client.module.IController;

/**
 * Class to update marks PN/SN and header material SN using an extractUfi SAP
 * web-service mapped response.
 * 
 * @author ademartin
 *
 */
public class ExtractUfiPnSnUpdater extends APnSnUpdater {

	/** Logger for current class */
	private static Logger logger = Logger.getLogger(ExtractUfiPnSnUpdater.class);
	
	/** The extractUfi response (intended to be already mapped) */
	private DataResponseMappedMaterialsMarks response;
	
	// TODO switch this message to a key
	private final static String EXTRACT_UFI_SAP_DEROG = "EXTRACT_UFI SAP derogation";
	
	/**
	 * Constructor for PN/SN updater that uses an extractUfi mapped response
	 * 
	 * @param controller
	 * @param response
	 *            the mapped extractUfi response to use
	 */
	public ExtractUfiPnSnUpdater(IController controller, DataResponseMappedMaterialsMarks response) {
		setController(controller);
		
		boolean isSapSynchronized = response != null && response.getAtaPnSnDerogMarks() != null && !response.getAtaPnSnDerogMarks().isEmpty();
		setSapSynchronized(isSapSynchronized);
		
		// Check data to process is given, consider the response as invalid if not
		// FIXME Kept for historical use, maybe the response data needs some specific controls ?
		if(response == null) {
			setSapResponseValid(false);
			this.response = new DataResponseMappedMaterialsMarks();
		} else {
			setSapResponseValid(true);
			this.response = response;
		}
	}
	
	@Override
	protected boolean checkMaterial(String pn, SN[] sns) throws ClientException {
		List<DataResponseSnDerog> listConfig = response.getPnSnMaterial().get(pn);
		boolean hasUpdated = false;
		
		if (listConfig != null) {

			if (listConfig.size() > 1) {
				logger.error("Unable to update header material SN[] as SAP returned more than one SN value!");
				return hasUpdated;
			}

			for(SN sn : sns) {
				if(isSnAlreadySeized(sn)) {
					logger.warn("An header material has already a manual seizure, abort its updating process...");
					return hasUpdated;
				}
			}
			
			// We got only one sn from sap and current sn field is empty
			hasUpdated = buildUniquePn(response.getPnSnMaterial(), pn, null, sns);
			if (hasUpdated) {
				addSnToEditionContext(sns);
			}
		} else {
			logger.warn("PN material not found in SAP data received");
		}
		
		return hasUpdated;
	}

	/**
	 * This method is used to check and update a mark using extractUfi data.
	 * 
	 * It first reads its ATA, its quantity and get the associated data from the
	 * extractUfi map.
	 * 
	 * Then it calls the method in charge of checking these SAP data and update
	 * the PN[] and SN[] objects.
	 * 
	 * @param mark
	 *            the mark to update
	 * @return true if updating process succeeds, false otherwise
	 * @throws ClientException 
	 */
	@Override
	protected boolean checkMark(Mark mark, SubPhase subPhase) throws ClientException {
		if (getContext().getContextConfig().getUpdateMarkByPnActive()) {
			return checkMarkByAta(mark, subPhase);
		} else {
			return checkMarkByPn(mark, subPhase);
		}
	}
	
	protected boolean checkMarkByAta(Mark mark, SubPhase subPhase) throws ClientException {
		boolean hasUpdated = false;

		String ata = mark.getAta();
		int quantity;

		if(mark.getQuantity() == null || mark.getQuantity().length == 0 || 
				mark.getQuantity(0).getContent() == null || mark.getQuantity(0).getContent().isEmpty()) {
			// Default quantity if it is not explicitly set
			logger.debug("Current mark[@ATA=" + ata + "] object has no quantity set: set it to 1 by default");
			quantity = 1;
		} else {
			// Consider the first quantity element text as the mark quantity (XSD model is wrong?)
			quantity = Integer.parseInt(mark.getQuantity(0).getContent());
		}

		// Read extractUfi data for this mark ATA
		List<DataResponseMarkPnSnDerog> ataMap = response.getAtaPnSnDerogMarks().get(ata);

		// No mark data from SAP, disable it
		if(ataMap == null) {
			logger.warn("No SAP data for current mark[@ATA=" + ata + "]");
			disableInputMark(mark);
			return false;
		}

		// Update PN[] and SN[] objects for current mark
		hasUpdated = updateMarkPnSnFromExtractUfi(mark, subPhase, ataMap, quantity, ata);

		return hasUpdated;
	}
	
	/**
	 * To use when applet.config.sap.mro.update.pnsn.by.pn = "true"
	 * @param mark
	 * @param subPhase
	 * @return
	 * @throws ClientException
	 */
	protected boolean checkMarkByPn(Mark mark, SubPhase subPhase) throws ClientException {
		boolean hasUpdated = false;
		for (int i = 0; i < mark.getPNCount(); i++) {
            PN pn = mark.getPN(i);
            SN[] sn = mark.getSN();
            Derogation[] derog = mark.getDerogation();

            // Build list of applicable PN
            Map<String, List<DataResponseSnDerog>> responsePnSnDerog = getApplicablePns(pn);
            // There are multiple PN applicable
            if (responsePnSnDerog.size() > 1 ) {
               hasUpdated = buildMultiplePn(responsePnSnDerog, new ArrayList<String>(responsePnSnDerog.keySet()), pn.getTaskAction(), sn, derog);
            }
            // There is only PN applicable
            else if (responsePnSnDerog.size() == 1) {
            	 hasUpdated = buildUniquePn(responsePnSnDerog, responsePnSnDerog.keySet().iterator().next(), pn.getTaskAction(), sn);
            }
            // There is no PN applicable
            else {
            	 hasUpdated = buildNoPn(pn.getTaskAction());
            }
        }
		return hasUpdated;
	}
	
	private Map<String, List<DataResponseSnDerog>> getApplicablePns(PN pn) {
		Map<String, List<DataResponseSnDerog>> currentPns = new HashMap<String, List<DataResponseSnDerog>>();
		TaskAction taskAction = pn.getTaskAction();
		if (taskAction != null) {
			// Build list of applicable PN
			InputAction inputAction = taskAction.getInputAction();
			InputActionChoice inputActionChoice = inputAction.getInputActionChoice();
			if (inputActionChoice.getInputChoice() != null) {
				InputChoice inputChoice = inputActionChoice.getInputChoice();
				for (StringValue stringValue : inputChoice.getStringValue()) {
					List<DataResponseSnDerog> listConfig = response.getPnSnMarks().get(stringValue.getContent());
					if (listConfig != null && !listConfig.isEmpty()) {
						currentPns.put(stringValue.getContent(), listConfig);
					}
				}
			} else if (inputActionChoice.getInputField() != null) {
				InputValue inputValue = taskAction.getInputAction().getInputValue();
				if (inputValue != null) {
					List<DataResponseSnDerog> listConfig = response.getPnSnMarks().get(inputValue.getValue());
					if (listConfig != null && !listConfig.isEmpty()) {
						currentPns.put(inputValue.getValue(), listConfig);
					}
				}
			}
		}
		return currentPns;
	}

	
	/**
	 * This method is used to set PN and SN from extractUfi data in a given
	 * mark.
	 * 
	 * It uses mark/PN[] size to count the number of mark instance.
	 * 
	 * It reads all PN(s) data received, stores them into a set then calls a
	 * method to update each mark PN[] object using this set, regardless of the
	 * instance they correspond to (no ordering from SAP data read).
	 * 
	 * Then, it reads all SN(s) data received, stores them into a set then calls
	 * a method to update each mark SN[] object using this set, regardless of
	 * the instance and quantity they correspond to (no ordering from SAP data
	 * read).
	 * 
	 * @param mark
	 *            the mark to update
	 * @param dataResponseMarkPnSnDerog
	 *            the data linked to the mark by the ATA to use for the update
	 *            process
	 * @param quantity
	 *            the quantity of the given mark to update SN[] objects (there
	 *            is as much SN[] objects as mark quantity for each mark
	 *            instance)
	 * @return true if updating process succeeds, false otherwise
	 * @throws ClientException 
	 */
    private boolean updateMarkPnSnFromExtractUfi(Mark mark, SubPhase subPhase,
			List<DataResponseMarkPnSnDerog> dataResponseMarkPnSnDerog, int quantity, String ata) throws ClientException {
	
    	// Read mark instance number generated
    	int instances  = mark.getPNCount();
		
    	// No PN[] object to update, nothing to do
    	if(instances == 0) {
    		logger.error("Mark[@ATA=" + ata + "] has no PN[] object to update!");
    		return false;
    	}
    	
    	// Store all PN(s) that must be set in PN[i] object, deleting duplications
    	Set<String> extractUfiPnSet = new HashSet<String>();
    	
    	for(int j = 0; j < dataResponseMarkPnSnDerog.size(); j++) {
    		extractUfiPnSet.add(dataResponseMarkPnSnDerog.get(j).getPn());
    	}
    	
    	// Store all SN(s) that must be set in SN[] objects, deleting duplications
    	Set<String> extractUfiSnSet = new HashSet<String>();
    	
    	for(int j = 0; j < dataResponseMarkPnSnDerog.size(); j++) {
    		extractUfiSnSet.add(dataResponseMarkPnSnDerog.get(j).getSn());
    	}
    	
    	// Loop for each mark instance
		for(int i = 0; i < instances; i++) {
			
			logger.debug("Updating Mark[@ATA=" + ata + "] PN[instance=" + i + "] object with the corresponding "
	    				+ "value set from extractUfi PN(s)=" + extractUfiPnSet + "...");
			
	    	// Start updating mark instance associated PN[] object
	    	PN pn = mark.getPN(i);
	    	
	    	if( isPnAlreadySeized(pn) ) {
	    		logger.warn("Unable to update current Mark[@ATA=" + ata + "] PN[" + i + "] object with the corresponding "
	    				+ "value set from extractUfi PN(s)=" + extractUfiPnSet + " as it was already seized");
	    	} else if(!updateMarkPnValueFromExtractUfi(mark, subPhase, pn, extractUfiPnSet)) {
	    		logger.error("Unable to update current Mark[@ATA=" + ata + "] PN[instance=" + i + "] object with the corresponding "
	    				+ "value set from extractUfi PN(s)=" + extractUfiPnSet + "!");
	    		continue;
	    	}
	    	
		    // Loop on each mark SN[] objects that corresponds to current mark instance i to update it using the SN(s) set
	    	for(int j = 0; j < quantity; j++) {
		    	
		    	// Check there is the instance/quantity SN[] object to update in the mark. If not, log an error
		    	int k = (i * quantity) + j;
		    	
		    	logger.debug("Updating Mark[@ATA=" + ata + "] SN[" + k + "] object with the corresponding "
		    				+ "value set from extractUfi SN(s)=" + extractUfiSnSet + "...");
		    	
		    	if(mark.getSN() == null || mark.getSN().length <= k) {
		    		logger.error("Expecting a SN[" + k + "] object to update in current Mark[@ATA=" + ata + "] but it does not exist!");
		    		continue;
		    	}

		    	// Update current SN[] object using its corresponding SN(s) set
		    	SN sn = mark.getSN(k);
		    	
		    	if(isSnAlreadySeized(sn)) {
		    		logger.warn("Unable to update current Mark[@ATA=" + ata + "] SN[" + k + "] object with the corresponding "
		    				+ "value set from extractUfi SN(s)=" + extractUfiSnSet + " as it was already seized");
		    	} else if(!updateMarkSnValueFromExtractUfi(sn, extractUfiSnSet)) {
		    		logger.error("Unable to update current Mark[@ATA=" + ata + "] SN[" + k + "] object with the corresponding "
		    				+ "value set from extractUfi SN(s)=" + extractUfiSnSet + "!");
		    		continue;
		    	}
	    	}
		}
		
		return true;
	}
    


	/**
	 * Method to update a given SN object using a set of SN(s).
	 * 
	 * <ul>
	 * <li>If set is of size 1, it updates the inputValue object into the
	 * specified SN object. This inputValue is set with the unique SN value
	 * using a built SAP userMark.</li>
	 * <li>If set is of size > 1, it creates an inputChoice object into the
	 * specified SN object.</li>
	 * </ul>
	 * 
	 * @param sn
	 *            the SN object to update
	 * @param extractUfiSnSet
	 *            the SN(s) values to set in the SN object
	 * @return true if process succeeds, false otherwise
	 * @throws ClientException 
	 */
	private boolean updateMarkSnValueFromExtractUfi(SN sn, Set<String> extractUfiSnSet) throws ClientException {
		InputAction inputAction = sn.getTaskAction().getInputAction();
		boolean hasUpdated = false;
		
		if(extractUfiSnSet == null || extractUfiSnSet.size() == 0) {
			logger.error("Unable to update SN[] object as SAP data set is empty!");
			return false;
		} else if(extractUfiSnSet.size() == 1) {
			Iterator<String> iter = extractUfiSnSet.iterator();
			String extractUfiSn = iter.next();
			
			InputValue inputValue = null;
			
			if(inputAction.getInputValue() == null) {
				InputValue newInputValue = new InputValue();
				inputAction.setInputValue(newInputValue);
			}
			
			inputValue = inputAction.getInputValue();
			inputValue.setValue(extractUfiSn);
			inputValue.setUserMark(buildUserMarkSap());
			hasUpdated = true;
		} else {
			Iterator<String> iter = extractUfiSnSet.iterator();
			
			// Reset input value to replace it by an inputChoice
			inputAction.setInputValue(null);
			InputChoice inputChoiceSn = new InputChoice();
			
			while(iter.hasNext()) {
				String extractUfiSn = iter.next();
				
				StringValue stringValue = new StringValue();
                stringValue.setContent(extractUfiSn);
                inputChoiceSn.addStringValue(stringValue);
			}
			
			InputActionChoice inputActionChoice = new InputActionChoice();
			inputActionChoice.setInputChoice(inputChoiceSn);
			inputAction.setInputActionChoice(inputActionChoice);
			hasUpdated = true;
		}
		
		if (hasUpdated) {
			((AModelObjectService) getModelProvider().getModelScheduleService()).setModified();
		}
		
		return true;
	}

    
    /**
	 * Method to update a given PN object using a set of PN(s).
	 * 
	 * If the PN(s) we want match the redactor draft, it updates the PN object
	 * and set the PN(s) we want:
	 * 
	 * <ul>
	 * <li>If the set is of size 1 (unique PN), it sets it as an input value</li>
	 * <li>If the set is of size > 1 (multiple PN(s)), it sets it as an
	 * inputChoice</li>
	 * </ul>
	 * 
	 * If not => SHE answer
	 * 
	 * @param pn
	 *            the PN object to update
	 * @param extractUfiPnSet
	 *            the PN(s) values to set in the PN object
	 * @return true if process succeeds, false otherwise
     * @throws ClientException 
	 */
    private boolean updateMarkPnValueFromExtractUfi(Mark mark, SubPhase subPhase, PN pn, Set<String> extractUfiPnSet) throws ClientException {

    	InputAction inputAction = pn.getTaskAction().getInputAction();
    	boolean hasUpdated = false;
    	
    	// Case: no PN(s) values to set
    	if(extractUfiPnSet == null || extractUfiPnSet.size() == 0) {
			logger.error("Unable to update PN[] object as SAP data set is empty!");
			return false;
		} 
    	// Case: only one PN value to set
    	else if(extractUfiPnSet.size() == 1) {
			
			Iterator<String> iter = extractUfiPnSet.iterator();
			String extractUfiPn = iter.next();
			
			// The redactor has not specified any PN or has already specified one different PN: must call the change mark action
			if(inputAction == null || (inputAction.getInputActionChoice().getInputField() != null 
					&& !extractUfiPn.equals(inputAction.getInputValue().getValue()))) {
		    	logger.warn("PN[] has no input or already defines a different PN value: must run action change mark...");
		    	getController().execute(new ActionChangeMark(mark.getId(), 
						Integer.toString(pn.getTaskAction().getInstance()), 
						Integer.toString(pn.getTaskAction().getAlternative()), 
						true, extractUfiPn, false, null, true, EXTRACT_UFI_SAP_DEROG, subPhase.getId(), null, true));
				return true;
	    	} 
			// The redactor has specified one same PN, lock it
			else if((inputAction.getInputActionChoice().getInputField() != null 
					&& extractUfiPn.equals(inputAction.getInputValue().getValue()))) {
	    		disableInputMark(mark);
	    	}
			// The redactor has specified a list of PN(s) represented by an inputChoice
			else if(inputAction.getInputActionChoice().getInputChoice() != null) {
				
	    		// Check the PN value to set is contained in the inputChoice
	    		InputChoice inputChoice = inputAction.getInputActionChoice().getInputChoice();
	    		
	    		int pnPosition = inputChoicePnPosition(inputChoice, extractUfiPn);
	    		
	    		if(pnPosition != -1) {
	    			// Found the value to set in the inputChoice
	    			InputValue extractUfiInput = buildSapMarkInputValueFromInputChoicePosition(pnPosition);
	    			inputAction.setInputValue(extractUfiInput);
	    			hasUpdated = true;
	    		} else {
	    			// The value to set was not found: must call the change mark action
	    			logger.warn("Mark PN inputChoice does not contain extractUfi PN=" + extractUfiPn + ": must run action change mark...");
	    			getController().execute(new ActionChangeMark(mark.getId(), 
	    					Integer.toString(pn.getTaskAction().getInstance()), 
	    					Integer.toString(pn.getTaskAction().getAlternative()), 
	    					true, extractUfiPn,
	    			false, null, true, EXTRACT_UFI_SAP_DEROG, subPhase.getId(), null, true));
	    			return true;
	    		}
	    	}
		}
    	// Case: many PN(s) values to set
    	else {
    		// The redactor has not specified any PN, we set an inputChoice containing all the PN(s) that must be set
    		if(inputAction == null) {
    			InputAction newInputAction = new InputAction();
    			InputActionChoice newInputActionChoice = new InputActionChoice();
    			InputChoice newInputChoice = new InputChoice();

    			for(String pnToAdd : extractUfiPnSet) {
    				StringValue newStringValue = new StringValue();
    				newStringValue.setContent(pnToAdd);
    				newInputChoice.addStringValue(newStringValue);
    			}
    			newInputActionChoice.setInputChoice(newInputChoice);
    			newInputAction.setInputActionChoice(newInputActionChoice);
    			
    			pn.getTaskAction().setInputAction(newInputAction);
    			hasUpdated = true;
    		} 
    		// The redactor has already specified one PN
    		else if(inputAction.getInputActionChoice().getInputField() != null) {
    			// Check the specified PN is contained in the incoming SAP list
    			String value = inputAction.getInputValue().getValue();
    			boolean isContained = false;
    			
    			for(String pnToAdd : extractUfiPnSet) {
    				if(pnToAdd.equals(value)) {
    					isContained = true;
    					break;
    				}
    			}
    			// Redactor value is contained in incoming SAP list
    			if(isContained) {
    				pn.getTaskAction().setEditable(false);
    				logger.warn("Redactor specified one PN=" + value + ", which is contained in incoming SAP data list=" + extractUfiPnSet + " -> we kept it");
    				hasUpdated = true;
    			} 
    			// Redactor value not contained: we set the incoming SAP list with a change mark notification
    			else {
    				InputAction newInputAction = new InputAction();
        			InputActionChoice newInputActionChoice = new InputActionChoice();
        			InputChoice newInputChoice = new InputChoice();

        			for(String pnToAdd : extractUfiPnSet) {
        				StringValue newStringValue = new StringValue();
        				newStringValue.setContent(pnToAdd);
        				newInputChoice.addStringValue(newStringValue);
        			}
        			newInputActionChoice.setInputChoice(newInputChoice);
        			newInputAction.setInputActionChoice(newInputActionChoice);
        			
        			pn.getTaskAction().setInputAction(newInputAction);
        			getController().execute(new ActionChangeMarkMultiplePnValues(mark.getId(), 
        					Integer.toString(pn.getTaskAction().getInstance()), 
        					Integer.toString(pn.getTaskAction().getAlternative()), 
        					subPhase.getId(), null, extractUfiPnSet));
        			return true;
    			}
    		} // The redactor has specified a list of PN(s) represented by an inputChoice
			else if(inputAction.getInputActionChoice().getInputChoice() != null) {
				
	    		InputChoice inputChoice = inputAction.getInputActionChoice().getInputChoice();
	    		
	    		// Check the PN(s) values to set are contained in the inputChoice
	    		Iterator<String> iter = extractUfiPnSet.iterator();
	    		
	    		boolean isContained = true;
	    		List<Integer> subListIndex = new ArrayList<Integer>();
	    		
	    		while(iter.hasNext()) {
	    			String extractUfiPn = iter.next();
	    			int pnPosition = inputChoicePnPosition(inputChoice, extractUfiPn);
	    			
	    			if(pnPosition == -1) {
	    				isContained = false;
	    			} else {
	    				subListIndex.add(pnPosition);
	    			}
	    		}
	    		
	    		if(!isContained) {
	    			logger.warn("SAP PN(s) received are not contained in redactor list: set the incoming SAP list and delete the old one...");
	    			InputAction newInputAction = new InputAction();
        			InputActionChoice newInputActionChoice = new InputActionChoice();
        			InputChoice newInputChoice = new InputChoice();

        			for(String pnToAdd : extractUfiPnSet) {
        				StringValue newStringValue = new StringValue();
        				newStringValue.setContent(pnToAdd);
        				newInputChoice.addStringValue(newStringValue);
        			}
        			newInputActionChoice.setInputChoice(newInputChoice);
        			newInputAction.setInputActionChoice(newInputActionChoice);
        			
        			pn.getTaskAction().setInputAction(newInputAction);
        			getController().execute(new ActionChangeMarkMultiplePnValues(mark.getId(), 
        					Integer.toString(pn.getTaskAction().getInstance()), 
        					Integer.toString(pn.getTaskAction().getAlternative()), 
        					subPhase.getId(), null, extractUfiPnSet));
        			return true;
	    		}
	    		
	    		// Reduce inputChoice values to the ones we want to set
	    		List<StringValue> keptValues = new ArrayList<StringValue>();
	    		
	    		for(Integer subListItem : subListIndex) {
	    			// Careful, adjusting the position returned by inputChoicePnPosition() is needed
	    			keptValues.add(inputChoice.getStringValue(subListItem - 1));
	    		}
	    		
	    		inputChoice.removeAllStringValue();
	    		
	    		for(StringValue keptValue : keptValues) {
	    			inputChoice.addStringValue(keptValue);
	    		}
	    		hasUpdated = true;
			}
    	}
    	
    	if (hasUpdated) {
    		((AModelObjectService) getModelProvider().getModelScheduleService()).setModified();
    	}
    	
    	return true;
    }
    
    /**
	 * Convenient method to build and return an inputValue to reference a mark
	 * inputChoice element using a position parameter.
	 * 
	 * The inputValue returned is then ready to be inserted in a mark
	 * inputAction to specify, for instance, which PN is used if a list of PN is
	 * defined as an inputChoice in it.
	 * 
	 * Please note that the position parameter is used directly and must start
	 * from 1 instead of usual 0.
	 * 
	 * @param position
	 *            the inputChoice element position to use to build the
	 *            inputValue
	 * @return the inputValue build
	 */
    private InputValue buildSapMarkInputValueFromInputChoicePosition(int position) {
    	InputValue inputValue = new InputValue();
    	inputValue.setValue(Integer.toString(position));
    	inputValue.setUserMark(buildUserMarkSap());
    	return inputValue;
    }
    
    
	/**
	 * Returns current StringValue position in InputChoice that has the
	 * specified PN as content.
	 * 
	 * @param inputChoice
	 *            the inputChoice from where to read StringValues
	 * @param pn
	 *            the PN value to search
	 * @return the StringValue position that defines the specified PN, or -1 if
	 *         not contained. Please note that the position starts from 1
	 *         instead of usual 0
	 */
    private int inputChoicePnPosition(InputChoice inputChoice, String pn) {

    	int i = 1;
    	for(StringValue pnItem : inputChoice.getStringValue()) {
			if(pnItem.getContent().equals(pn)) {
				return i;
			}
			i++;
		}
    	return -1;
    }
}
