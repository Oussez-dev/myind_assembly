package turbomeca.gamme.assembly.client.module.externaltools.action;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.ClientAssemblyException;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskActionMeasureService;
import turbomeca.gamme.assembly.client.module.externaltools.player.InstructionPlayerFactory;
import turbomeca.gamme.assembly.services.model.data.MeasureRdd;
import turbomeca.gamme.assembly.services.model.data.MeasureSap;
import turbomeca.gamme.assembly.services.model.data.MeasureTool;
import turbomeca.gamme.assembly.services.model.data.types.StatusType;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.client.module.externaltools.player.IPlayerInstruction;
import turbomeca.gamme.ecran.services.devices.ExternalsToolsExceptions;

public class ActionRunMeasureRDD extends AActionRunPlayer{

	private static Logger logger = Logger.getLogger(ActionRunMeasureRDD.class);

	
	private String serviceId;
	
	public ActionRunMeasureRDD(String serviceId){
		setServiceId(serviceId);
	}
	
	@Override
	public boolean run(IController controller) throws ClientException, ClientInterruption {
		logger.debug("[PILOTING] : service Identifier - "+getServiceId());
		ModelTaskActionMeasureService taskMeasureService = ((ModelTaskActionMeasureService) getModelProvider().getModelService(getServiceId()));
		boolean state = true;
		
		if(!isSubPhaseFinished(taskMeasureService)) {
			if(!isResourcesFinished(taskMeasureService)){
				throw new ClientAssemblyException(ClientAssemblyException.EXCEPTION_INPUT_RESOURCES_NOT_FINISHED);
			}
			
			if(!canRunPlayer(taskMeasureService)){
				throw new ClientException(ExternalsToolsExceptions.MESSAGE_DISABBLE_ACTION_ACQUISITION, "ExternalToolsException");
			}
			
			IPlayerInstruction  playerInstruction = InstructionPlayerFactory.createPlayer(taskMeasureService,true,false);
			state = playerInstruction.run(controller);
		}
		return state;
	}

	/**
	 * Function who verify that player can be run 
	 * @param taskMeasureService
	 * @return
	 */
	public boolean canRunPlayer(ModelTaskActionMeasureService taskMeasureService) {
		boolean runPlayer= true;
		MeasureSap measureSap = taskMeasureService.getMeasureSap(); 
		MeasureTool measureTool = taskMeasureService.getMeasureTool(); 
		MeasureRdd measureRdd = taskMeasureService.getMeasureRdd(); 
		
		//Test on Measure Sap
		if(measureSap!=null){
			if(measureSap.getState().getStatus()!=StatusType.KO) {
				runPlayer=false;
			}
		}
		//Test on Measure Tools
		if(measureTool!=null){
			if(measureRdd.getState().getStatus()==StatusType.KO) {
				runPlayer=false;
			}
		}
		return runPlayer;		
	}
	public String getServiceId() {
		return serviceId;
	}

	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}

}
