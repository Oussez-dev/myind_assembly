package turbomeca.gamme.assembly.client.module.sap.action;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.config.AssemblyConstants;
import turbomeca.gamme.assembly.client.interfaces.server.sap.ServerSAPAssemblyInterfacesService;
import turbomeca.gamme.assembly.client.model.edit.schedule.AAssemblyScheduleService;
import turbomeca.gamme.assembly.client.module.sap.APnSnUpdater;
import turbomeca.gamme.assembly.client.module.sap.ExtractUfiPnSnUpdater;
import turbomeca.gamme.assembly.client.module.sap.GetSnFromOsPnSnUpdater;
import turbomeca.gamme.assembly.client.module.sap.PnSnUpdater;
import turbomeca.gamme.assembly.services.model.data.Identification;
import turbomeca.gamme.assembly.services.model.data.Instanciation;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.constants.PropertyConstants;
import turbomeca.gamme.ecran.client.interfaces.server.sap.mapper.DataResponseMappedMaterialsMarks;
import turbomeca.gamme.ecran.client.interfaces.server.sap.mapper.DataResponsePnSnDerog;
import turbomeca.gamme.ecran.client.interfaces.server.sap.mapper.MapperBuilderSAP;
import turbomeca.gamme.ecran.client.model.AModelObjectService;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.client.module.action.AActionModify;
import turbomeca.gamme.ecran.server.ws.sap.client.interfaces.ISapContextLoader;
import turbomeca.gamme.ecran.server.ws.sap.client.model.ExtractUfi.SapExtractUFIResponseContext;

public class ActionUpdateSapPNData extends AActionModify {

	/** logger for current class */
	private static Logger logger = Logger.getLogger(ActionUpdateSapPNData.class);

	private ISapContextLoader sapLoader;

	public ActionUpdateSapPNData(ISapContextLoader sapLoader) {
		this.sapLoader = sapLoader;
	}

	@Override
	public boolean run(IController controller) throws ClientException, ClientInterruption {
		return pnSnUpdate(controller);
	}

	private boolean pnSnUpdate(IController controller) {
		boolean updated = false;
		try {
			// Call SAP if it is enabled by the configuration
			if (ServerSAPAssemblyInterfacesService.getInstance().isInterfaceEnabled()) {
				// SAP calls for PN/SN update
				updated = callSapForPnSnUpdate(controller, true);
			} else {
				updated = callSapForPnSnUpdate(controller, false);
			}
		} catch (Exception e) {
			logger.error(" callSap - pnSn - ", e);
		}
		return updated;
	}

	/**
	 * Proceed to SAP calls needed for PN/SN update then process the response to
	 * launch the PN/SN update action.
	 * 
	 * @param controller
	 * @return
	 * @throws Exception
	 */
	private boolean callSapForPnSnUpdate(IController controller, boolean useSap) throws Exception {
		boolean success = false;

		AAssemblyScheduleService scheduleService = (AAssemblyScheduleService) getModelProvider().getModelScheduleService();


		getLoggerHmi().info(PropertyConstants.PROPERTY_CALL_SAP_GET_PN_SN);

		APnSnUpdater sapUpdater = null;
		
		if (!useSap) {
			sapUpdater = new PnSnUpdater();
		} else {
			// Calling extractUfi SAP web-service if MRO (assembly repaired or disassembly) schedule
			if (AssemblyConstants.ASSEMBLY_REPAIRED.equals(scheduleService.getSubOfficialRangeName())
					|| AssemblyConstants.DISASSEMBLY.equals(scheduleService.getSubOfficialRangeName())) {
				sapUpdater = callExtractUfiSapForMRO(controller, scheduleService);
			}
			// Call SAP getSnFromOs SAP web-service if assembly new schedule
			else {
				sapUpdater = callGetSnFromOsSapForAssemblyNew(controller, scheduleService);
			}
		}
		
		success = callPnSnUpdateAndNotifyThatTheModelHasChanged(scheduleService, sapUpdater);
		if (success) {
			scheduleService.getWrapperService().getInstantiation().setSynchronizedWithSap(true);
		}

		return success;
	}
	
	
	/**
	 * 	Method to call getSnFromOs SAP web service for assembly NEW
	 * @param controller
	 * @param scheduleService
	 * @return pnSnUpdater
	 */
	private APnSnUpdater callGetSnFromOsSapForAssemblyNew(IController controller, AAssemblyScheduleService scheduleService) {
		DataResponsePnSnDerog mappedResponseSap = new DataResponsePnSnDerog();
		mappedResponseSap = ServerSAPAssemblyInterfacesService.getInstance().getPnSn(scheduleService.getWrapperService().getInstantiation().getOrder());
		
		logger.debug("Must call GetSnFromOsPnSnUpdater");
		
		return new GetSnFromOsPnSnUpdater(controller, mappedResponseSap);
	}
	
	
	/**
	 * Method to call extractUfi SAP web service for assembly MRO (assembly repaired and disassembly)
	 * @param controller
	 * @param scheduleService
	 * @return pnSnUpdater
	 * @throws Exception 
	 */
	private APnSnUpdater callExtractUfiSapForMRO(IController controller, AAssemblyScheduleService scheduleService) throws Exception {
		
		Instanciation instanciation = scheduleService.getWrapperService().getInstantiation();
		Identification identification = scheduleService.getWrapperService().getIdentification();
		
		getLoggerHmi().info(PropertyConstants.PROPERTY_CALL_SAP_EXTRACT_UFI);

		DataResponseMappedMaterialsMarks mappedResponseExtractUfi = null;
		SapExtractUFIResponseContext response = sapLoader.loadExtractUfi(instanciation.getAffair(), "", true);

		if (response == null) {
			getLoggerHmi().error(PropertyConstants.PROPERTY_ERROR_CALL_SAP_EXTRACT_UFI);
		} else {
			mappedResponseExtractUfi = new DataResponseMappedMaterialsMarks();
			MapperBuilderSAP.convertResponseToConfigResultAtaPnSnDerog(response.getSapStructure(), mappedResponseExtractUfi, identification.getMaterial(),instanciation.getPn(), scheduleService.getSubOfficialRangeName());
		}

		// PN/SN updater must be called even if SAP call fails to set marks
		// at read-only state
		logger.debug("Must call ExtractUfiPnSnUpdater");
		return new ExtractUfiPnSnUpdater(controller, mappedResponseExtractUfi);
	}
	
	
	/**
	 * Method to update PN and SN with or without SAP, <br>
	 * And to notify than the model has changed 
	 * 
	 * @param instanciation
	 * @param pnSnUpdater
	 * @return 
	 * @return
	 * @throws Exception 
	 */
	private boolean callPnSnUpdateAndNotifyThatTheModelHasChanged(AAssemblyScheduleService scheduleService, APnSnUpdater pnSnUpdater) throws Exception {
		
		// Apply update marks/header material update process
		pnSnUpdater.update(scheduleService.getWrapperService().getInstantiation());
		
		// Notify action has modified model 
		return ((AModelObjectService) getModelProvider().getModelScheduleService()).isModified();
	}
	
	protected boolean isSapSchedule(IController controller) {
		boolean result = false;
		AAssemblyScheduleService scheduleService = (AAssemblyScheduleService) getModelProvider()
				.getModelScheduleService();
		if (scheduleService.getWrapperService().getParameters().getIsSapSchedule() != null) {
			result = scheduleService.getWrapperService().getParameters().getIsSapSchedule().getIsSapSchedule();
		}
		logger.debug("[SAP] Schedule is configured for sap " + Boolean.toString(result));
		return result;
	}

}
