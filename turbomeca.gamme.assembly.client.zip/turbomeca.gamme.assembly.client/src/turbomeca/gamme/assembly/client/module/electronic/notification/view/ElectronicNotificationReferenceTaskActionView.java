package turbomeca.gamme.assembly.client.module.electronic.notification.view;

import turbomeca.gamme.assembly.client.model.edit.utils.ModelUtils;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.constants.PropertyConstants;
import turbomeca.gamme.ecran.client.model.edit.instructions.IModelSubPhaseService;
import turbomeca.gamme.ecran.client.module.action.AActionServiceView;
import turbomeca.gamme.ecran.services.constants.XsltConstants;

public class ElectronicNotificationReferenceTaskActionView extends AActionServiceView {

    public ElectronicNotificationReferenceTaskActionView(String taskActionId) {
        super(taskActionId, XsltConstants.XSLT_NOTIFICATION_ELECTRONIC_REFERENCE_TASKACTION.value());
    }

    @Override
    public boolean run() throws ClientException {
        IModelSubPhaseService subPhaseService = ModelUtils.getSubPhaseParent(getModelService());
        getView().addParameter(XsltConstants.XSLT_PARAMETER_TASKACTION_ID.value(), getServiceId());
        getView().addParameter(XsltConstants.XSLT_PARAMETER_SUBPHASE_ID.value(), subPhaseService.getIdentifier());
        getView().addParameter(XsltConstants.XSLT_PARAMETER_DISPLAY_CHECKBOX_FOR_ORIGIN_NCR.value(), "false");
        getView().bindService(subPhaseService);
        return getView().displayModal(PropertyConstants.PROPERTY_MODAL_TITLE_ELECTRONIC_NOTIFICATION, true);
    }
}
