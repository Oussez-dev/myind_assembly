package turbomeca.gamme.assembly.client.module.instruction.action;

import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.dispatcher.ActionDispatcherManager;
import turbomeca.gamme.ecran.client.model.edit.instructions.IModelTaskActionService;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.client.module.instruction.action.ActionContinue;

public class ActionValidateInput extends AActionInput {

	public ActionValidateInput(String taskActionId, String value) {
		super(taskActionId, value);
	}
	
	@Override
	public boolean run(IController controller) throws ClientException, ClientInterruption {
		IModelTaskActionService taskActionService = getTaskActionService();
		checkRun(taskActionService);
		if (taskActionService.setValue(getValue())) {
		    if (!ActionDispatcherManager.getInstance().run()) {
                new ActionContinue(taskActionService).run(controller);
            }
		}
		return true;
	}
}
