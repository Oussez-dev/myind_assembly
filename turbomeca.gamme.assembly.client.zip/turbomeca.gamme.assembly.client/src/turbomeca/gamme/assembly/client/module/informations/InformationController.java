package turbomeca.gamme.assembly.client.module.informations;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.ClientAssemblyControllersProvider;
import turbomeca.gamme.assembly.client.interfaces.server.runtime.RuntimeServerScheduleOpenedByUserAssemblyService;
import turbomeca.gamme.assembly.client.model.edit.schedule.AAssemblyScheduleService;
import turbomeca.gamme.assembly.client.module.electronic.notification.ElectronicNotificationController;
import turbomeca.gamme.assembly.client.module.informations.view.InformationCompoundsView;
import turbomeca.gamme.assembly.client.module.informations.view.InformationDifferenceVersionView;
import turbomeca.gamme.assembly.client.module.informations.view.InformationNewPassing;
import turbomeca.gamme.assembly.client.module.informations.view.InformationObservationsView;
import turbomeca.gamme.assembly.client.module.informations.view.InformationSummaryViewAssembly;
import turbomeca.gamme.assembly.client.module.synthesis.view.SynthesisSapView;
import turbomeca.gamme.assembly.services.constants.AssemblyXsltConstants;
import turbomeca.gamme.assembly.services.constants.ConstantsGenerationPDF;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.IClientControllersProvider;
import turbomeca.gamme.ecran.client.module.informations.ADefaultInformationController;
import turbomeca.gamme.ecran.client.module.informations.view.InformationReferentialView;
import turbomeca.gamme.ecran.client.module.informations.view.InformationSynthesisView;

/**
 * 
 * @author Sopra Group
 * 
 */
public class InformationController extends ADefaultInformationController {

	/** Logger */
	private static Logger logger = Logger.getLogger(InformationController.class);
	
	/**
	 * 
	 * @param hmiProviderObject
	 * @param config
	 */
	public InformationController(IClientControllersProvider provider) {
		super(provider);
	}

	@Override
	public boolean init() throws ClientException {
		if (!super.init()) {
			return false;
		}

		// Check if must show differences modal at schedule opening (only if writing mode)
		boolean isFirstOpening = false;

		if(getContext().getContextUser().getWritingMode() != 0) {
			isFirstOpening = RuntimeServerScheduleOpenedByUserAssemblyService.getInstance().isScheduleFirstOpening();
		}
		
		AAssemblyScheduleService scheduleService = (AAssemblyScheduleService) getModelProvider().getModelScheduleService();
		
		if (isFirstOpening && scheduleService.hasDifferences()) {
			logger.info("Detected as schedule first opening and differences available: show modifications modal window");
			return actionDisplayDifferences(true);
		}
		// Open post-it modal if no differences modal to show
		else {
			ElectronicNotificationController eletronicNotifController = (ElectronicNotificationController) getControllersProvider().getController(ClientAssemblyControllersProvider.INTERFACE_NOTIFICATION);
			eletronicNotifController.actionDisplayElectronicPostItFromDifferences();
		}

		return true;
	}
	
	public boolean actionDisplayReferential() {
		return execute(new InformationReferentialView(AssemblyXsltConstants.XSLT_INFORMATION_IDENTIFICATION.value()));
	}

	public boolean actionDisplayCompounds() {
        return execute(new InformationCompoundsView());
    }
	
	@Override
	public boolean actionDisplaySummary() {
		return execute(new InformationSummaryViewAssembly());
	}
	
	
	/**
     * Display schedule differences modal
     * @return true if succeed
     */
	@Override
	public boolean actionDisplayDifferences() {
		return actionDisplayDifferences(false);
	}
	
	/**
	 * Display schedule differences modal
	 * @param isShownAtOpening true if the modal must show a read term version, false if not
	 * @return
	 */
	public boolean actionDisplayDifferences(boolean isShownAtOpening) {
		return execute(new InformationDifferenceVersionView(isShownAtOpening));
	}
	
	public boolean actionDisplayCommentNewPassing() {
		return execute(new InformationNewPassing());
	}
	
	/**
	 * Display Synthesis
	 * @return true if succeed
	 */
	@Override
	public boolean actionDisplaySynthesis() {
        return execute(new InformationSynthesisView(AssemblyXsltConstants.XSLT_INFORMATION_SYNTHESIS.value()));
    }
	
	/**
	 * Display marks synthesis view
	 * @return true if succeed
	 */
	public boolean actionDisplaySynthesisMarks() {
        return execute(new InformationSynthesisView(AssemblyXsltConstants.XSLT_INFORMATION_SYNTHESIS_MARKS.value()));
    }
	
	
	/**
	 * Display notifications synthesis view
	 * @return true if succeed
	 */
	public boolean actionDisplaySynthesisNotifications() {
        return execute(new InformationSynthesisView(AssemblyXsltConstants.XSLT_INFORMATION_SYNTHESIS_NOTIFICATIONS.value()));
    }
	
	/**
	 * Display documents synthesis view
	 * @return true if succeed
	 */
	public boolean actionDisplaySynthesisDocuments() {
        return execute(new InformationSynthesisView(AssemblyXsltConstants.XSLT_INFORMATION_SYNTHESIS_DOCUMENTS.value()));
    }
	
	/**
	 * Display tools synthesis view
	 * @return true if succeed
	 */
	public boolean actionDisplaySynthesisTools() {
        return execute(new InformationSynthesisView(AssemblyXsltConstants.XSLT_INFORMATION_SYNTHESIS_TOOLS.value()));
    }
	
	/**
	 * Display sap synthesis view
	 * @return true if succeed
	 */
	public boolean actionDisplaySynthesisSap() {
        return execute(new SynthesisSapView(getModelProvider().getModelScheduleService()));
    }
	
	/**
	 * Display tools synthesis view
	 * @return true if succeed
	 */
	public boolean actionNavigationObservations() {
        return execute(new InformationObservationsView(AssemblyXsltConstants.XSLT_INFORMATION_OBSERVATIONS.value()));
    }
	
	@Override
	protected int getPdfSynthesisType() {
		return ConstantsGenerationPDF.GENERATION_PDF_SYNTHESIS;
	}
}
