package turbomeca.gamme.assembly.client.module.externaltools.player.piloting;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskPilotingService;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.constants.PropertyConstants;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.module.externaltools.player.APlayerInstruction;
import turbomeca.gamme.ecran.client.module.externaltools.player.IPlayerInstruction;
import turbomeca.gamme.ecran.services.devices.ExternalsToolsExceptions;

public class PlayerTaskPilotingIsConnectedBackground  extends APlayerInstruction implements
IPlayerInstruction {

	private static Logger logger = Logger.getLogger(PlayerTaskPilotingIsConnectedBackground.class);
	
	public PlayerTaskPilotingIsConnectedBackground(ModelTaskPilotingService modelService) {
		super();
		setModelService(modelService);
	}

	@Override
	public boolean play() throws ClientException, ClientInterruption, ExternalsToolsExceptions {
		ModelTaskPilotingService taskPilotingService = (ModelTaskPilotingService) getModelService();
		String snTool = taskPilotingService.getSnTool();
		String acquisitionResult = "false";
		PlayerAcquisitionIsToolConnected acquisition = new PlayerAcquisitionIsToolConnected(getContext().getContextConfig().getContextTool().getUrlServletPilotingIsConnected(), snTool);
		try{
			acquisitionResult = acquisition.acquire();
		}catch(ExternalsToolsExceptions e) {
			logger.error("[PILOTING] : Play - Unable to reach the tool");
			throw new ExternalsToolsExceptions(ExternalsToolsExceptions.PROPERTY_ERROR_NOT_YET_CONNECTED_TOOLS_PILOTING);
		}
		if(!acquisitionResult.contains("true")) {
			throw new ExternalsToolsExceptions(ExternalsToolsExceptions.PROPERTY_ERROR_NOT_YET_CONNECTED_TOOLS_PILOTING);
		}else {
			getLoggerHmi().info(PropertyConstants.PILOTING_TOOLS_CONNECTED);
		}
		getEngine().next(taskPilotingService, true);
		return true;
	}

	@Override
	public boolean stop(IModelObjectService service) throws ClientException, ClientInterruption {
		return true;
	}

}
