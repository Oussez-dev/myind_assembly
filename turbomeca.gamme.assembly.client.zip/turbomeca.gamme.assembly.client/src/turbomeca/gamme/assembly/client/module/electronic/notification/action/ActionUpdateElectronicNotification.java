package turbomeca.gamme.assembly.client.module.electronic.notification.action;

import java.util.List;

import turbomeca.gamme.assembly.client.model.edit.notifications.AModelNotificationService;
import turbomeca.gamme.assembly.client.model.edit.provider.ModelNotificationProvider;
import turbomeca.gamme.assembly.services.model.data.ElectronicNotification;
import turbomeca.gamme.assembly.services.model.data.types.StatusNotificationType;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.module.IController;

public class ActionUpdateElectronicNotification extends AActionCreateElectronicNotification {

    /** Notification id */
    private String notificationId;
    
    /** Notification status */ 
    private String status;
    
    /**
     * Constructor
     * 
     * @param notificationId the notification id
     * @param status the new status to update
     */
    public ActionUpdateElectronicNotification(String notificationId, String status) {
        setNotificationId(notificationId);
        setStatus(status);
    }

    @Override
    public boolean run(IController controller) throws ClientException, ClientInterruption {
        StatusNotificationType statusNotification = StatusNotificationType.valueOf(getStatus());
        List<AModelNotificationService> notificationsService = ModelNotificationProvider.getInstance().getNotifications(getNotificationId());
        if (notificationsService != null) {
            for(AModelNotificationService notificationService : notificationsService) {
            	notificationService.update(statusNotification, null);
            	ElectronicNotification  elec = (ElectronicNotification) notificationService.getWrapperService().getObject();
            	elec.setUpdated(true);
            }
        }
        synchronizeOnServer(false);
        return true;
    }

    /**
     * @return the notificationId
     */
    public String getNotificationId() {
        return notificationId;
    }

    /**
     * @param notificationId the notificationId to set
     */
    public void setNotificationId(String notificationId) {
        this.notificationId = notificationId;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }
}