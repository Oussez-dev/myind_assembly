package turbomeca.gamme.assembly.client.module.externaltools.action;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelResourcesService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskActionMeasureService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.module.action.AActionModify;

public abstract class AActionRunPlayer extends AActionModify {

	/**
	 * Function who verify That Resources finished to execute player
	 * @param taskMeasureService
	 * @return
	 */
	
	protected boolean isResourcesFinished(IModelObjectService playerTaskService) {
		boolean finish = true;
		ModelSubPhaseService subPhasesService = (ModelSubPhaseService) playerTaskService
					.getAncestor(ModelSubPhaseService.class);
		ModelResourcesService ressources = subPhasesService.getResourcesService();
		if (ressources != null && !ressources.getRunnableService().isFinished()) {
			finish = false;
		}
		return finish;
	}
	
	protected boolean isSubPhaseFinished(IModelObjectService playerTaskService) {
		ModelSubPhaseService subPhasesService = (ModelSubPhaseService) playerTaskService
		.getAncestor(ModelSubPhaseService.class);
		return subPhasesService.getRunnableService().isFinished();
	}
	
	protected abstract boolean canRunPlayer(ModelTaskActionMeasureService taskActionMeasure);
}
