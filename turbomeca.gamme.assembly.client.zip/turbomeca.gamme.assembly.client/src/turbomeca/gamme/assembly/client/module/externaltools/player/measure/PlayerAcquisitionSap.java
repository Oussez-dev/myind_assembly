package turbomeca.gamme.assembly.client.module.externaltools.player.measure;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.interfaces.server.action.sap.getCarac.DataCaracSap;
import turbomeca.gamme.assembly.client.interfaces.server.sap.ServerSAPAssemblyInterfacesService;
import turbomeca.gamme.assembly.services.model.data.CaracDef;
import turbomeca.gamme.assembly.services.model.data.MeasureSap;
import turbomeca.gamme.ecran.services.devices.ExternalsToolsExceptions;

public class PlayerAcquisitionSap extends APlayerAcquisition {

	/** Logger for current class */
	private static Logger logger = Logger.getLogger(PlayerAcquisitionSap.class);

	private  MeasureSap measure;
	
	/** */
	public PlayerAcquisitionSap (MeasureSap measure){
		super(ServiceType.SAP);
		setMeasure(measure);
		setState(getMeasure().getState());
	}

	@Override
	public String acquireAcquistion() throws ExternalsToolsExceptions {
		
		logger.debug("PlayerAcquisitionSap -Call - acquireInternal");
		
		String dataFromCarac = null;
		
		if (ServerSAPAssemblyInterfacesService.getInstance().isInterfaceEnabled()) {
			if(!analyzeMeasure(getMeasure())){
				throw new ExternalsToolsExceptions (ExternalsToolsExceptions.ERROR_BAD_CONFIGURATION_MEASURE_SAP_FROM_MARKS);
			}
			List<MeasureSap> measuresSap=new ArrayList<MeasureSap>();
			measuresSap.add(getMeasure());

			DataCaracSap  configCarac= ServerSAPAssemblyInterfacesService.getInstance().getCaract(measuresSap);
			dataFromCarac = configCarac.getDataValue();
			
			if(dataFromCarac==null){
				throw new ExternalsToolsExceptions (ExternalsToolsExceptions.ERROR_ACQUISITION_SAP);
			}
		}
		
		return dataFromCarac;
	}
	
	private boolean analyzeMeasure(MeasureSap measureSap){
		boolean isPnPresent=false;
		String Pn = measureSap.getPN().getTaskAction().getInputAction().getInputValue().getValue();
		for(CaracDef caracDef: measureSap.getCaracDef()){
			if(caracDef.getPN().equals(Pn)){
				isPnPresent=true;
				break;
			}
		}
		return isPnPresent;
	}

	public void setMeasure(MeasureSap measure) {
		this.measure = measure;
	}

	public MeasureSap getMeasure() {
		return measure;
	}
}
