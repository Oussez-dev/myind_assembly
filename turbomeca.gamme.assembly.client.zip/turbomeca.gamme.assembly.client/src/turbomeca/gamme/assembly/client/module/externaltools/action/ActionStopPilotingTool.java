package turbomeca.gamme.assembly.client.module.externaltools.action;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskActionMeasureService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskPilotingService;
import turbomeca.gamme.assembly.client.module.externaltools.ExternalToolsController;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.client.module.externaltools.player.IPlayerInstruction;

public class ActionStopPilotingTool  extends AActionRunPlayer {
	

	private String serviceId;
	private static Logger logger = Logger.getLogger(ActionRunMeasureTool.class);

	public ActionStopPilotingTool(String serviceId) {
		setServiceId(serviceId);
	}

	@Override
	public boolean run(IController controller) throws ClientException,
	ClientInterruption {
		logger.debug("ActionStopPilotingTool - Run");
		ModelTaskPilotingService taskPilotingService = ((ModelTaskPilotingService) getModelProvider()
				.getModelService(getServiceId()));
		IPlayerInstruction playerInstruction = ((ExternalToolsController) controller).getPlayerInProgress();
		if(playerInstruction != null){
			playerInstruction.stop(taskPilotingService);
		}
		return false;
	}

	public String getServiceId() {
		return serviceId;
	}

	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}


	@Override
	protected boolean canRunPlayer(ModelTaskActionMeasureService taskActionMeasure) {
		// TODO Auto-generated method stub
		return false;
	}

}
