package turbomeca.gamme.assembly.client.module.instruction.action;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelMarkService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskActionService;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.constants.PropertyConstants;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.client.module.instruction.action.AActionInput;

public class ActionDuplicateInput extends AActionInput {

	/**
	 * 
	 * @param taskActionId
	 * @param value
	 * @param overwriteValue
	 */
	public ActionDuplicateInput(String taskActionId) {
		super(taskActionId, null);
	}

	@Override
	public boolean run(IController controller) throws ClientException, ClientInterruption {
		boolean success = true;
	    ModelTaskActionService taskActionService = (ModelTaskActionService) getTaskActionService();
	    if (taskActionService.getStatusService().isAlterable()) {
			if (taskActionService.getParent() instanceof ModelMarkService) {
				success = handleMarkSpecific(taskActionService);	
			} else {
		        ModelTaskActionService taskActionServiceCloned = taskActionService.cloneService();
		        getModelProvider().addModelService(taskActionServiceCloned.getIdentifier(), taskActionServiceCloned);
			}
	    }
		return success;
	}
	
	/***
	 * Perform the duplication action on this mark on all schedule. <br>
	 * The duplication has to be performed on TaskActionService provided and on its associated getServicesToDuplicateOnDuplication()
	 * 
	 * @param taskActionService the mark TaskActionService on which a duplicated action has been performed
	 * @throws ClientException
	 * @throws ClientInterruption
	 */
	private boolean handleMarkSpecific(ModelTaskActionService taskActionService) throws ClientException, ClientInterruption {
		boolean success = true;
		List<ModelTaskActionService> taskActionServicesToDuplicate = new ArrayList<ModelTaskActionService>();
		taskActionServicesToDuplicate.add(taskActionService);
		taskActionServicesToDuplicate.addAll(taskActionService.getServicesToDuplicateOnDuplication());
		
    	ModelMarkService modelMarkService = (ModelMarkService) taskActionService.getParent();
    	
    	//first of all, we have to check if the duplication is allowed :
    	//If a reference of the mark is present in an other subPhase which is not in edition -> error
    	if(!checkIfThisMarkHasReferencesInSubPhaseNotTakenInEdition(modelMarkService)) {
	        for (ModelMarkService modelMarkServiceLinked : modelMarkService.getMarkReferences()) {
	    		for (IModelObjectService childService : modelMarkServiceLinked.getChildren()) {
	    			if (childService instanceof ModelTaskActionService) {
	    				for(ModelTaskActionService taskActionServiceToDuplicate :  taskActionServicesToDuplicate ) {
		    		        if (((ModelTaskActionService)childService).isTaskActionLinked(taskActionServiceToDuplicate)) {
		        				ModelTaskActionService childServiceClone = ((ModelTaskActionService) childService).cloneService();
		        				// FIXME ? taskActionDerogService are optional ?
		        				childServiceClone.setOptional(true);
		        				getModelProvider().addModelService(childServiceClone.getIdentifier(), childServiceClone);
		    		        }
	    				}
	    			}
	    		}
	    	}
    	} else {
    		success = false;
    		getLoggerHmi().error(PropertyConstants.PROPERTY_ERROR_DUPLICATION_NOT_ALLOWED_DUE_TO_REFERENCE_INSIDE_NOT_EDITED_SUBPHASE);
    	}
    	
    	return success;
    }
	
	
	/**
	 * @param modelMarkService
	 * @return true if a reference of the mark passed by parameter is inside a subPhase which is not in edition
	 */
	private boolean checkIfThisMarkHasReferencesInSubPhaseNotTakenInEdition(ModelMarkService modelMarkService) {
		boolean atLeastOneReferenceIsInsideASubPhaseNotTakenInEdition = false;		 
		List<String> subPhasesInEdition = new ArrayList<String>(Arrays.asList(getContext().getContextEditing().getObjectEdited()));
		
		if (modelMarkService.getMarkReferences() != null && modelMarkService.getMarkReferences().size() > 0) {
			for (ModelMarkService modelMarkServiceLinked : modelMarkService.getMarkReferences()) {
				ModelSubPhaseService subphaseService = (ModelSubPhaseService) modelMarkServiceLinked.getAncestor(ModelSubPhaseService.class);
				if(subphaseService != null && !subPhasesInEdition.contains(subphaseService.getIdentifier())) {
					atLeastOneReferenceIsInsideASubPhaseNotTakenInEdition = true;
					break;
				}
			}
		}
		return atLeastOneReferenceIsInsideASubPhaseNotTakenInEdition;	
	}
}
