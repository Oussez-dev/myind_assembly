package turbomeca.gamme.assembly.client.module.externaltools.player.piloting;

import java.io.StringReader;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.config.AssemblyPropertyConstants;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskPilotingService;
import turbomeca.gamme.assembly.client.module.externaltools.ExternalToolsController;
import turbomeca.gamme.assembly.client.module.externaltools.ExternalToolsView;
import turbomeca.gamme.assembly.client.module.externaltools.view.PilotingToolAcquireView;
import turbomeca.gamme.assembly.client.module.instruction.action.ActionSetInput;
import turbomeca.gamme.assembly.services.constants.AssemblyXsltConstants;
import turbomeca.gamme.assembly.services.constants.Constants;
import turbomeca.gamme.assembly.services.schedule.model.types.StatusType;
import turbomeca.gamme.assembly.services.screwdriver.dto.TaskActionPiloting;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.constants.PropertyConstants;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.client.module.externaltools.player.IPlayerInstruction;
import turbomeca.gamme.ecran.services.common.utils.multithread.DeamonThread;
import turbomeca.gamme.ecran.services.constants.XsltConstants;
import turbomeca.gamme.ecran.services.model.tool.ScrewDriverPilotingStatusType;

/***
 * This class is in charge of running an IPlayerInstruction in the background.
 * <p>
 * This is useful in order to let the user to interact with MMI like a stop
 * button. <br>
 * All acquisition logic and functional is delegated to the IPlayerInstruction
 * provided during this instance creation.
 *
 */
public class BackgroundPlayer implements IPlayerInstruction, IInstructionPlayerListener {
	private IPlayerInstruction foregroundPlayer;
	private Thread runThread;
	private ExternalToolsView extToolView;

	private Logger logger = Logger.getLogger(BackgroundPlayer.class);
	private IModelObjectService modelService;

	private IController controller;

	public BackgroundPlayer(IPlayerInstruction foregroundPlayer, IModelObjectService modelService) {
		this.foregroundPlayer = foregroundPlayer;
		this.modelService = modelService;
	}

	@Override
	public boolean run(IController controller) throws ClientException, ClientInterruption {
		this.controller = controller;
		extToolView = ((ExternalToolsController) controller).getView();
		startModal();
		PlayerInstructionBackground pib = new PlayerInstructionBackground(foregroundPlayer, controller, this);
		runThread = new DeamonThread(pib);
		runThread.start();
		return false;
	}

	@Override
	public boolean stop(final IModelObjectService service) throws ClientException, ClientInterruption {
		stopAcquisition();
		runThread.interrupt();
		Thread stopThread = new DeamonThread(new Runnable() {

			@Override
			public void run() {
				try {
					foregroundPlayer.stop(service);
				} catch (ClientException e) {
					logger.error("[PILOTING] : BackgroundPlayer - stop()", e);
					extToolView.getLoggerHmi().error(e.getPropertyKey());
				} catch (ClientInterruption e) {
					logger.error("[PILOTING] : BackgroundPlayer - stop()", e);
					extToolView.getLoggerHmi().error(e.getPropertyKey());
				}

			}
		});
		stopThread.start();
		controller.getNotificationsService().notifyStatusChanged(modelService);
		return true;
	}

	/**
	 * 
	 * parse the response from the piloting server and fill inputs taskAction
	 * 
	 * @param xmlStream
	 * @return
	 */
	private boolean fillModel(String xmlStream) {
		TaskActionPiloting tap = null;
		try {
			JAXBContext jaxbContext = JAXBContext.newInstance(TaskActionPiloting.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			StringReader reader = new StringReader(xmlStream);
			tap = (TaskActionPiloting) jaxbUnmarshaller.unmarshal(reader);
		} catch (JAXBException e) {
			logger.error("[PILOTING] : BackgroundPlayer - fillModel()", e);
			extToolView.getLoggerHmi().error(PropertyConstants.PROPERTY_ERROR_TOOLS_UNEXPECTED_TYPE);
		}

		if (tap == null)
			return false;
		
		
		boolean stopTreatment = computeStatus(tap.getStatus());
		if(stopTreatment)
			return false;
	
		if (modelService instanceof ModelTaskPilotingService) {
			
				ModelTaskPilotingService modelTaskPilotingService = (ModelTaskPilotingService) modelService;
				List<String> ids = modelTaskPilotingService.getTaskActionPilotingResultIds();

				for (int i = 0; i < ids.size() && i < tap.getPilotingResults().size(); i++) {
					try { 
						if (tap.getPilotingResults().get(i).getMessage() == null || tap.getPilotingResults().get(i).getMessage().equals("")) {
							
							ActionSetInput setActionInput = new ActionSetInput(ids.get(i), String.valueOf(tap.getPilotingResults().get(i).getTorqueExpected()), true);
							
							if(!controller.execute(setActionInput)) {
								extToolView.getLoggerHmi().error(PropertyConstants.PROPERTY_ERROR_TASK_VALUE_BAD_FORMAT); 	
								modifyStatus(StatusType.KO.value());							
							}
						} else {
							extToolView.getLoggerHmi().error(PropertyConstants.PROPERTY_ERROR_TASK_VALUE_BAD_FORMAT); 
							new ActionSetInput(ids.get(i), tap.getPilotingResults().get(i).getMessage(),  true).run(controller);
						}
					} catch (ClientException e) {
						logger.error("[PILOTING] : BackgroundPlayer - fillModel()", e);
						extToolView.getLoggerHmi().error(PropertyConstants.PROPERTY_ERROR_TASK_VALUE_BAD_FORMAT);
					} catch (ClientInterruption e) {
						logger.error("[PILOTING] : BackgroundPlayer - fillModel()", e);
						extToolView.getLoggerHmi().error(PropertyConstants.PROPERTY_ERROR_TASK_VALUE_BAD_FORMAT);
					}
				}
				
				
		}
		return true;
	}
	
	/**
	 * Not yet connected means that the piloting was not found by the piloting server
	 * Partial means that at least one result is not set.
	 * 
	 * @param status
	 * @return return true if the treatment must be stop
	 */
	private boolean computeStatus(String status) {
		boolean stopTreatment = true;
		StatusType statusType = null;
		if(status == null) return stopTreatment;
		
		if(!ScrewDriverPilotingStatusType.OK.value().equalsIgnoreCase(status)) {
			statusType = StatusType.KO;
			if(ScrewDriverPilotingStatusType.NOT_YET_CONNECTED.value().equalsIgnoreCase(status)) {
				logger.error("[PILOTING] : BackgroundPlayer - computeStatus()");
				extToolView.getLoggerHmi().error(PropertyConstants.PROPERTY_ERROR_NOT_YET_CONNECTED_TOOLS_PILOTING);	
			} else if(ScrewDriverPilotingStatusType.PARTIAL.value().equalsIgnoreCase(status)){
				stopTreatment = false;
			} else {
				logger.error("[PILOTING] : BackgroundPlayer - computeStatus()");
				extToolView.getLoggerHmi().error(PropertyConstants.PROPERTY_ERROR_RETURN_BY_TOOLS_PILOTING_SERVER);					
			} 
		}else {
			statusType = StatusType.OK;
			stopTreatment = false;
		}
		modifyStatus(statusType.value());
		return stopTreatment;
	}
	
	private void modifyStatus(String status) {

		try {
			modelService.getStatusService().updateState(status, true, "", null);
			modelService.getParent().getStatusService().computeStatus(true);
			controller.getNotificationsService().notifyStatusChanged(modelService);
		} catch (ClientException e) {
			logger.error("[PILOTING] : BackgroundPlayer - computeStatus()");
			extToolView.getLoggerHmi().error(PropertyConstants.PROPERTY_ERROR_INTERNAL_UNKNOWN);	
		} catch (ClientInterruption e) {
			logger.error("[PILOTING] : BackgroundPlayer - computeStatus()");
			extToolView.getLoggerHmi().error(PropertyConstants.PROPERTY_ERROR_INTERNAL_UNKNOWN);	
		}
		
	}

	/**
	 * Open Modal
	 * @throws ClientException 
	 */
	private void startModal() throws ClientException {
		new PilotingToolAcquireView(AssemblyXsltConstants.XSLT_PILOTING_TOOL_ACQUIRE.value(), modelService.getIdentifier()).run();
	}

	/**
	 * Stop the JS instruction "BlockUi"
	 */
	private void stopCloseModal() {
		extToolView.closeModal();
	}

	private void stopAcquisition() {
		stopCloseModal();
		extToolView.getLoggerHmi().error(AssemblyPropertyConstants.PROPERTY_INFO_STOP_PILOTING_TOOL);
		if (runThread.isAlive())
			runThread.interrupt();

		((ExternalToolsController) controller).setPlayerInProgress(null);
	}

	@Override
	public boolean isModify() {
		return foregroundPlayer.isModify();
	}

	@Override
	public boolean autoRun() throws ClientInterruption {
		return foregroundPlayer.autoRun();
	}

	@Override
	public void notifyError(String propertyKey) {
		stopCloseModal();
		logger.error("[PILOTING] : BackgroundPlayer - notifyError()");
		extToolView.getLoggerHmi().error(propertyKey);
		if (runThread.isAlive())
			runThread.interrupt();
	}

	@Override
	public void notifyResponse(String response) {
		stopCloseModal();
		if(((ExternalToolsController) controller).getPlayerInProgress() != null) {
			fillModel(response);
			if (runThread.isAlive())
				runThread.interrupt();
			((ExternalToolsController) controller).setPlayerInProgress(null); 
		}
	}
	
	public void setController(IController controller) {
		this.controller = controller;
	}
	
	public IController getController() {
		return controller;
	}
}
