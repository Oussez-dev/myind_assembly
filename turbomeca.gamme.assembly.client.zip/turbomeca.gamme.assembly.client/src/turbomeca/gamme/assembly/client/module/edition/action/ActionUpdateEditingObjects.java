package turbomeca.gamme.assembly.client.module.edition.action;

import java.util.Arrays;
import java.util.LinkedHashSet;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseGroupService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.client.model.edit.runnable.ModelRunnableScheduleService;
import turbomeca.gamme.assembly.services.schedule.merge.AssemblyModelMergeFactory;
import turbomeca.gamme.ecran.client.constants.PropertyConstants;
import turbomeca.gamme.ecran.client.context.ContextLoaderMultiEdition;
import turbomeca.gamme.ecran.client.context.ContextLoaderProvider;
import turbomeca.gamme.ecran.client.context.ContextLoaderSingleEdition;
import turbomeca.gamme.ecran.client.context.IContextLoader;
import turbomeca.gamme.ecran.client.interfaces.server.editing.EditingServerInterfaceService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.services.common.constants.GlobalConstants;
import turbomeca.gamme.ecran.services.common.constants.OpenMode;
import turbomeca.gamme.ecran.services.common.utils.misc.FormatUtils;
import turbomeca.gamme.ecran.services.schedule.service.merge.IModelMerge;

public class ActionUpdateEditingObjects extends turbomeca.gamme.ecran.client.module.edition.action.ActionUpdateEditingObjects {

	private StringBuilder objectsList;
	
	/** logger for current class */
	private static Logger logger = Logger.getLogger(ActionUpdateEditingObjects.class);

	public ActionUpdateEditingObjects(String objectsList) {
		super();
		this.objectsList = new StringBuilder();
		this.objectsList.append(objectsList);
	}
	
	@Override
	public boolean run(IController controller) {
		boolean succeed = false;
		getLoggerHmi().info(PropertyConstants.PROPERTY_AQUIRE_OBJECTS_IN_PROGRESS);
		
		String[] objectsSelected;
		objectsSelected = objectsList.toString().split(GlobalConstants.SEPARATOR_DOT_COMA);
		
		for(String objectId : objectsSelected){
			IModelObjectService objectService = getModelProvider().getModelService(objectId);
			
			//If the sub-phase has alternatives, then we need to take all alternatives in edition too
			if(objectService instanceof ModelSubPhaseService
					&& ((ModelSubPhaseService) objectService).hasAlternatives()) {
				ModelSubPhaseService subphaseService = (ModelSubPhaseService) objectService;
				for(IModelObjectService alternativeSubphase : subphaseService.getAlternatives()) {
					objectsList.append(";").append(alternativeSubphase.getIdentifier());
				}
			}
			
			// Sub-phases group special handle
			if(objectService instanceof ModelSubPhaseGroupService){
				for(IModelObjectService subphase : objectService.getChildrenDeep(ModelSubPhaseService.class)){
					objectsList.append(";").append(subphase.getIdentifier());
				}						
			}
		}
		objectsSelected = filterStringArrayByUnicity(objectsList.toString().split(GlobalConstants.SEPARATOR_DOT_COMA));

		boolean hasAllObjectInEdition = checkIfAllObjectIdEditedInRange(objectsList.toString());
		if (EditingServerInterfaceService.getInstance().synchronizeContextEditing(objectsSelected, hasAllObjectInEdition, false)) {
			hasAllObjectInEdition = checkIfAllObjectIdEditedInRange(FormatUtils.getStringValues(getContext().getContextEditing().getObjectEdited()));
			getLoggerHmi().info(PropertyConstants.PROPERTY_AQUIRE_OBJECTS_DONE);
			controller.getNotificationsService().setEditionChanged();
			IContextLoader contextLoader = new ContextLoaderSingleEdition();
			
			if(hasAllObjectInEdition){
				getContext().getContextUser().setWritingMode(OpenMode.OPEN_MODE_EDIT);
				getConfiguration().getConfigRange().setWritingMode(OpenMode.OPEN_MODE_EDIT);
			}
			else{
				IModelMerge merger = AssemblyModelMergeFactory.create(getConfiguration().getConfigRange().getRangeType());
				contextLoader = new ContextLoaderMultiEdition(merger);
				getContext().getContextUser().setWritingMode(OpenMode.OPEN_MODE_MULTI_EDIT);
				getConfiguration().getConfigRange().setWritingMode(OpenMode.OPEN_MODE_MULTI_EDIT);
			}
			ContextLoaderProvider.setInstance(contextLoader);
			succeed = true;
		} else {
			getLoggerHmi().error(PropertyConstants.PROPERTY_ERROR_AQUIRE_OBJECTS);
		}
		
		return succeed;
	}
	
	protected boolean checkIfAllObjectIdEditedInRange(String objectsList) {
		ModelRunnableScheduleService modelRunnnableScheduleService = (ModelRunnableScheduleService) getModelProvider().getModelScheduleService().getRunnableService();
		return modelRunnnableScheduleService.hasAllObjectInEditionWithList(objectsList);
	}
	
	
	/**
	 * 
	 * @param objectsSelected
	 * @return array of string without duplicate element are removed
	 */
	protected String[] filterStringArrayByUnicity(String[] objectsSelected) {
		LinkedHashSet<String> objectsSelectedTmp =  
                new LinkedHashSet<String>(Arrays.asList(objectsSelected));
		return objectsSelectedTmp.toArray(new String[ objectsSelectedTmp.size() ]);
	}
}
