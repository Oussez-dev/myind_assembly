package turbomeca.gamme.assembly.client.module.instruction.view;

import turbomeca.gamme.assembly.services.constants.AssemblyXsltConstants;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.constants.PropertyConstants;
import turbomeca.gamme.ecran.client.module.action.AActionServiceView;
import turbomeca.gamme.ecran.services.constants.XsltConstants;

public class ChangeInputChoiceManualView extends AActionServiceView {
	
	public ChangeInputChoiceManualView(String taskActionId) {
		super(taskActionId, AssemblyXsltConstants.XSLT_INTERVENTION_CHANGE_INPUT_CHOICE_VALUE_MANUAL.value());
	}
	
	@Override
	public boolean run() throws ClientException {
        getView().addParameter(XsltConstants.XSLT_PARAMETER_TASKACTION_ID.value(), getServiceId());
		return getView().displayModal(PropertyConstants.PROPERTY_MODAL_TITLE_MANUAL_EDITION, false);
	}
}
