package turbomeca.gamme.assembly.client.module.electronic.notification;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.ClientAssemblyControllersProvider;
import turbomeca.gamme.assembly.client.model.edit.IModelAssemblyWrapperScheduleService;
import turbomeca.gamme.assembly.client.model.edit.provider.ModelNotificationProvider;
import turbomeca.gamme.assembly.client.module.electronic.notification.action.ActionCheckElectronicNotification;
import turbomeca.gamme.assembly.client.module.electronic.notification.action.ActionCheckElectronicValidation;
import turbomeca.gamme.assembly.client.module.electronic.notification.action.ActionCreateElectronicNotificationUser;
import turbomeca.gamme.assembly.client.module.electronic.notification.action.ActionCreateElectronicValidation;
import turbomeca.gamme.assembly.client.module.electronic.notification.action.ActionDeleteElectronicPostIt;
import turbomeca.gamme.assembly.client.module.electronic.notification.action.ActionUpdateElectronicCrossValidations;
import turbomeca.gamme.assembly.client.module.electronic.notification.action.ActionUpdateElectronicNotification;
import turbomeca.gamme.assembly.client.module.electronic.notification.action.ActionUpdateElectronicPostIt;
import turbomeca.gamme.assembly.client.module.electronic.notification.view.CreateElectronicNotificationView;
import turbomeca.gamme.assembly.client.module.electronic.notification.view.ElectronicNotificationReferenceTaskActionView;
import turbomeca.gamme.assembly.client.module.electronic.notification.view.ElectronicPostItView;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.IClientControllersProvider;
import turbomeca.gamme.ecran.client.module.AController;
import turbomeca.gamme.ecran.client.module.electronic.notification.action.ActionCheckCrossElectronicValidations;
import turbomeca.gamme.ecran.client.module.io.IoController;
import turbomeca.gamme.ecran.services.common.constants.OpenMode;

public class ElectronicNotificationController extends AController {

	/** logger for current class */
	private static Logger logger = Logger.getLogger(ElectronicNotificationController.class);
	
	private ElectronicNotificationListener notificationListener;
	
	public ElectronicNotificationController(IClientControllersProvider provider) {
		super(provider);
	}

	@Override
	public boolean init() throws ClientException { 
	    
	    // Create notification listener
        notificationListener = new ElectronicNotificationListener();
        getNotificationsService().addDynamicListener(notificationListener);
        
        if (getConfiguration().getConfigRange().getWritingMode() == OpenMode.OPEN_MODE_MULTI_EDIT) {
            // Load all notifications from server
            try {
                getNotificationsService().setDisableNotifications(true);
                new ActionCheckElectronicNotification().run(this);
                new ActionCheckElectronicValidation().run(this);
            } catch (ClientInterruption e) {
                logger.error(e);
            } finally {
                getNotificationsService().setDisableNotifications(false);
            }
        }
        
		return true;
	}

	@Override
	public boolean destroy() {
	    getNotificationsService().removeDynamicListener(notificationListener);
        notificationListener = null;
        ModelNotificationProvider.getInstance().destroy();
		return true;
	}

	/**
	 * DIRTY FIXME Detect and show post-it modal if needed. Must be called at differences modal window shown at UFI opening.
	 * 
	 * @return
	 */
	public boolean actionDisplayElectronicPostItFromDifferences() {
		// Check if post-it must be displayed
	    IModelAssemblyWrapperScheduleService wrapper = (IModelAssemblyWrapperScheduleService) getModelProvider().getModelScheduleService().getWrapperService();
	    if (wrapper.getElectronicPostIt() != null) {
			logger.info("Must show post-it modal at opening!");
	        return actionDisplayElectronicPostIt();
	    }
	    
	    return false;
	}
	
	/**
	 * 
	 * @return
	 */
	public boolean actionCheckElectronicNotification() {
	    logger.info("actionCheckElectronicNotification ");
	    return execute(new ActionCheckElectronicNotification());
	}
	
	/**
     * 
     * @param subPhaseId
     * @return
     */
    public boolean actionDisplayElectronicNotificationReferenceTask(String notificationId) {
        logger.info("actionDisplayElectronicNotification ");
        return execute(new ElectronicNotificationReferenceTaskActionView(notificationId));
    }
	
	/**
     * 
     * @param subPhaseId
     * @return
     */
    public boolean actionDisplayCreateNotification(String subPhaseId) {
        logger.info("actionDisplayElectronicNotificationUser ");
        return execute(new CreateElectronicNotificationView(subPhaseId));
    }
    
	/**
	 * 
	 * @return
	 */
	public boolean actionCreateElectronicNotificationUser(String subPhaseId, String comment) {
        logger.info("actionCreateElectronicNotificationUser ");
        return execute(new ActionCreateElectronicNotificationUser(subPhaseId, comment));
    }
	
	/**
     * 
     * @return
     */
    public boolean actionUpdateElectronicNotification(String notificationId, String status) {
        logger.info("actionUpdayeElectronicNotification ");
        return execute(new ActionUpdateElectronicNotification(notificationId, status));
    }
    
	/**
	 * Create Electronic validation Action
	 * @return
	 */
	public boolean actionCreateElectronicValidation(String taskActionId, String userLogin, String userName) {
		logger.info("actionCreateElectronicValidation - "+taskActionId+" - "+userLogin+" - "+ userName);
	    return execute(new ActionCreateElectronicValidation(taskActionId, userLogin, userName));
    }
    
	/**
	 * 
	 * @return
	 */
	public boolean actionCheckElectronicValidation() {
	    logger.info("actionCheckElectronicValidation ");
	    return execute(new ActionCheckElectronicValidation());
	}
    
	
	/**
	 * 
	 * @return
	 */
	public boolean actionCheckCrossElectronicValidations(String appletId) {
	    logger.info("actionCheckCrossElectronicValidations");
	    return execute(new ActionCheckCrossElectronicValidations(appletId));
	}
    
	/**
	 * 
	 * @return
	 */
	public boolean actionUpdateDoubleValidation(String listIdTaskAction, 
			Boolean booleanDeleteDoubleValidationUser) {
	    logger.info("actionUpdateDoubleValidation");
	    boolean success = execute(new ActionUpdateElectronicCrossValidations(listIdTaskAction));
	    if(success){
	    	return actionCheckElectronicValidation(); 
	    }
	    return success;
	}
	
	/**
	 * 
	 * @return
	 */
	public boolean actionDisplayElectronicPostIt() {
        logger.info("actionCheckElectronicNotification ");
        return execute(new ElectronicPostItView());
    }
	
	/**
	 * 
	 * @return
	 */
	public boolean actionUpdateElectronicPostIt(String comment) {
        logger.info("actionValidateElectronicPostIt ");
        boolean success = execute(new ActionUpdateElectronicPostIt(comment));
        if(success){
        	((IoController) getControllersProvider().getController(ClientAssemblyControllersProvider.INTERFACE_IO)).actionSaveOnServer();
        }
        return success;
    }
	
	/**
	 * 
	 * @return
	 */
	public boolean actionDeleteElectronicPostIt() {
        logger.info("actionDeleteElectronicPostIt ");
        boolean success = execute(new ActionDeleteElectronicPostIt());
        if(success){
        	((IoController) getControllersProvider().getController(ClientAssemblyControllersProvider.INTERFACE_IO)).actionSaveOnServer();
        }
		return success;
    }
}
