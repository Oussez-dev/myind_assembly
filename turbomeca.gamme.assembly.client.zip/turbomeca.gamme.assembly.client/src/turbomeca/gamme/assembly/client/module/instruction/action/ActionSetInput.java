package turbomeca.gamme.assembly.client.module.instruction.action;

import turbomeca.gamme.assembly.client.ClientAssemblyControllersProvider;
import turbomeca.gamme.assembly.client.ClientAssemblyException;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelMarkService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskActionService;
import turbomeca.gamme.assembly.client.model.edit.schedule.AAssemblyScheduleService;
import turbomeca.gamme.assembly.client.model.edit.schedule.AssemblyScheduleService;
import turbomeca.gamme.assembly.client.module.edition.AssemblyEditionController;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.dispatcher.ActionDispatcherManager;
import turbomeca.gamme.ecran.client.model.edit.instructions.IModelTaskActionService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.client.module.instruction.action.ActionContinue;
import turbomeca.gamme.ecran.client.module.instruction.view.ErrorConfirmationView;

public class ActionSetInput extends AActionInput {

	private boolean desableInvalidMessage;
	/**
	 * 
	 * @param taskActionId
	 * @param value
	 * @param overwriteValue
	 */
	public ActionSetInput(String taskActionId, String value) {
		super(taskActionId, value);
		this.desableInvalidMessage = false;
	}

	public ActionSetInput(String taskActionId, String value, boolean desableInvalidMessage) {
		super(taskActionId, value);
		this.desableInvalidMessage = desableInvalidMessage;
	}

	@Override
	public boolean run(IController controller) throws ClientException,
			ClientInterruption {
		IModelTaskActionService taskActionService = getTaskActionService();
		boolean success = true;
			if (taskActionService.isValueDifferent(getValue())) {
			checkRun(taskActionService);
			IModelObjectService markObjectService = taskActionService
					.getAncestor(ModelMarkService.class);
			if (markObjectService != null || taskActionService.getParent() instanceof AAssemblyScheduleService) {
				success = internalRun(controller, markObjectService, (ModelTaskActionService) taskActionService);
			} else {
				success = internalRun(controller, (ModelTaskActionService) taskActionService);
			}
		}
		return success;
	}

	/**
	 * 
	 * @param instructionController
	 * @param taskActionService
	 * @return
	 * @throws ClientException
	 * @throws ClientInterruption
	 */
	public boolean internalRun(IController controller,
			ModelTaskActionService taskActionService) throws ClientException,
			ClientInterruption {
		String value = getValue();

		if (value == null || value.isEmpty() || value.equals(Boolean.FALSE.toString())) {
			taskActionService.resetValue(true);
			forceResetRessource(taskActionService);
		} else {
			boolean isValueValid = true;
			
			// Format value before checking and setting it in the taskAction
			String formattedValue = taskActionService.formatValue(value);
			
			try {
				isValueValid = taskActionService.checkValue(formattedValue);
			} catch (ClientInterruption e) {
				taskActionService.setValue(null);
				throw new ClientAssemblyException(
						ClientAssemblyException.EXCEPTION_SEQUENCE);
			}

			if (!isValueValid
					&& getContext().getContextConfig().getNotifyBadInput() && !this.desableInvalidMessage) {
				new ErrorConfirmationView(taskActionService, formattedValue).run();
			} else {
				taskActionService.setValue(formattedValue);
				
				controller.getNotificationsService().notifyValueChanged(taskActionService);
				
				if (!ActionDispatcherManager.getInstance().run()) {
					new ActionContinue(taskActionService).run(controller);
				}
			}
		}
		return true;
	}

	/**
	 * 
	 * @param controller
	 * @param markObjectService
	 * @param taskActionService
	 * @return
	 * @throws ClientException
	 * @throws ClientInterruption
	 */
	private boolean internalRun(IController controller,
	        IModelObjectService modelObjectService,
			ModelTaskActionService taskActionService) throws ClientException,
			ClientInterruption {
		String value = getValue();
		if (value == null || value.isEmpty() || (value.equals(Boolean.FALSE.toString()))) {
			taskActionService.resetValue(true);
			if(!taskActionService.isOptional()){
				forceResetRessource(taskActionService);
			}
			applyValueToReference(controller, modelObjectService, taskActionService);
		} else {
			boolean applyFieldValue = true;
			if (taskActionService.getParent() instanceof AssemblyScheduleService) {
				
				// If the modified field isn't part of a sub-phase, we take the field in edition to force the merger to save it on server
				applyFieldValue = ((AssemblyEditionController) controller.getControllersProvider()
						.getController(ClientAssemblyControllersProvider.INTERFACE_EDITION))
								.forceObjectEdition(taskActionService.getIdentifier());

			}
			if (applyFieldValue) {
				applyReferenceValue(controller, modelObjectService, taskActionService);
				new ActionContinue(taskActionService).run(controller);
			} else {
				taskActionService.resetValue(false);
			}
		}
		return true;
	}
}
