package turbomeca.gamme.assembly.client.module.edition.action;

import turbomeca.gamme.assembly.client.module.instruction.action.ActionUpdateReferences;
import turbomeca.gamme.ecran.client.module.action.ActionComposite;

/**
 * This class is a composite Action launching:
 * <li>ActionRefresh Action in order to refresh schedule from server
 * <li>ActionUpdateReferences in order to update references from not editing subphases
 * <p>
 * 
 * @author jguerrin
 *
 */
public class ActionRefreshAndUpdateReferences extends ActionComposite {
	
	public ActionRefreshAndUpdateReferences() {
		addAction(new ActionRefresh());
		addAction(new ActionUpdateReferences(ActionUpdateReferences.SCHEDULE_ID));
	}

}
