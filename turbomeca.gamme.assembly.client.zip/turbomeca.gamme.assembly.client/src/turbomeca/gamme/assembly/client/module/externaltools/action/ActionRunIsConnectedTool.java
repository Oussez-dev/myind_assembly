package turbomeca.gamme.assembly.client.module.externaltools.action;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskPilotingService;
import turbomeca.gamme.assembly.client.module.externaltools.player.piloting.BackgroundPlayer;
import turbomeca.gamme.assembly.client.module.externaltools.player.piloting.PlayerTaskPilotingIsConnectedBackground;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.client.module.action.AAction;
import turbomeca.gamme.ecran.client.module.action.IAction;
import turbomeca.gamme.ecran.client.module.externaltools.player.IPlayerInstruction;

public class ActionRunIsConnectedTool extends AAction implements IAction {

	private String serviceId;

	public ActionRunIsConnectedTool(String serviceId) {
		this.serviceId = serviceId;
	}

	@Override
	public boolean run(IController controller) throws ClientException, ClientInterruption {
		ModelTaskPilotingService taskPilotingService = ((ModelTaskPilotingService) getModelProvider().getModelService(serviceId));
		IPlayerInstruction  playerInstruction = new BackgroundPlayer(new PlayerTaskPilotingIsConnectedBackground(taskPilotingService), taskPilotingService);
		playerInstruction.run(controller);
		return false;
	}

}
