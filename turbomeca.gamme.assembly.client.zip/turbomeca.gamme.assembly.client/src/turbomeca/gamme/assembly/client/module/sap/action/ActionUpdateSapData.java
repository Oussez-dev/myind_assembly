package turbomeca.gamme.assembly.client.module.sap.action;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.ClientAssemblyControllersProvider;
import turbomeca.gamme.assembly.client.config.AssemblyConstants;
import turbomeca.gamme.assembly.client.config.AssemblyPropertyConstants;
import turbomeca.gamme.assembly.client.model.edit.instructions.AModelTaskActionService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskActionService;
import turbomeca.gamme.assembly.client.model.edit.schedule.AAssemblyScheduleService;
import turbomeca.gamme.assembly.client.module.sap.services.UpdateSapInputControlService;
import turbomeca.gamme.assembly.client.module.sap.services.UpdateSapInputPosteService;
import turbomeca.gamme.assembly.client.module.sap.services.UpdateSapScheduleService;
import turbomeca.gamme.assembly.services.model.data.InputActionChoice;
import turbomeca.gamme.assembly.services.model.data.Instanciation;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.client.module.action.AActionModify;
import turbomeca.gamme.ecran.client.module.edition.EditionController;
import turbomeca.gamme.ecran.server.ws.sap.client.interfaces.ISapContextLoader;
import turbomeca.gamme.ecran.server.ws.sap.client.model.ExtractUfi.SapExtractUFIResponseContext;

/**
 * This action manages schedule update with SAP context
 * @author Sopra Group
 */
public class ActionUpdateSapData extends AActionModify {
	private static Logger logger = Logger.getLogger(ActionUpdateSapData.class);

	/** Flag to force no HMI notifications */ 
	private boolean disableHmiNotifications;
	/** Schedule updater service */
	private UpdateSapScheduleService updaterSchedule;
	/** Post input updater service */
	private UpdateSapInputPosteService updaterInputPoste;
	/** Control input updater service */
	private UpdateSapInputControlService updaterInputControl;

	/** SAP context builder */
	private ISapContextLoader sapContextLoader;
	/** Schedule operation class */
	private Class<?> operationClass;

	/**
	 * Constructor
	 */
	public ActionUpdateSapData(ISapContextLoader sapContextLoader) {
		this.sapContextLoader = sapContextLoader;
		this.updaterSchedule = new UpdateSapScheduleService();
		this.updaterInputControl = new UpdateSapInputControlService();
		this.updaterInputPoste = new UpdateSapInputPosteService();

		this.disableHmiNotifications = false;
		this.operationClass = ModelSubPhaseService.class;
	}

	public ActionUpdateSapData(ISapContextLoader sapContextLoader, boolean disableHmiNotifications) {
		this(sapContextLoader);
		this.disableHmiNotifications = disableHmiNotifications;
	}

	@Override
	public boolean run(IController controller) throws ClientException, ClientInterruption {
		boolean updated = true;

		if (isSapSchedule(controller)) {
			AAssemblyScheduleService scheduleService = (AAssemblyScheduleService) getModelProvider().getModelScheduleService();
			if (AssemblyConstants.ASSEMBLY_REPAIRED.equals(scheduleService.getSubOfficialRangeName())
					|| AssemblyConstants.DISASSEMBLY.equals(scheduleService.getSubOfficialRangeName())) {
				updated = runRepairedTreatment(controller, scheduleService);
			} else {
				updated = runNewTreatment(controller, scheduleService);
			}
		}
		return updated;
	}

	private boolean runRepairedTreatment(IController controller, AAssemblyScheduleService scheduleService) throws ClientException {
		getLoggerHmi().info(AssemblyPropertyConstants.PROPERTY_RANGE_SAP_UPDATING);

		boolean updated = true;

		controller.getNotificationsService().setDisableNotifications(true);

		// Get edition controller
		EditionController editionController = (EditionController) controller.getControllersProvider().getController(ClientAssemblyControllersProvider.INTERFACE_EDITION);

		// Call web service interface for getting SAP context
		Instanciation instanciation = scheduleService.getWrapperService().getInstantiation();
		String affair = instanciation.getAffair();
		String material = "";

		SapExtractUFIResponseContext sapContext = null;
		try {
			sapContext = sapContextLoader.loadExtractUfi(affair, material, true);
		} catch (Exception e) {
			logger.error("[SAP] Error during load extract ufi from sap " + e.getMessage());
		}

		if (sapContext == null) {
			getLoggerHmi().error(AssemblyPropertyConstants.PROPERTY_ERROR_SAP_COMMUNICATION);
			updated = false;
		} else {
			// Update schedule information
			getUpdaterSchedule().update(scheduleService, sapContext);

			// Build the SAP taskAction list needing an update and their associated operations id
			boolean hasSapInput = false;
			List<AModelTaskActionService> sapTaskActions = new ArrayList<AModelTaskActionService>();
			List<String> operationsIdToEdit = null;

			if(getContext().getContextEditing().getObjectEdited() != null && getContext().getContextEditing().getObjectEdited().length >0) {
				operationsIdToEdit = new ArrayList<String>(Arrays.asList(getContext().getContextEditing().getObjectEdited()));
			} else {
				operationsIdToEdit = new ArrayList<String>();
			}

			Class<?> taskActionClass = ModelTaskActionService.class;
			List<IModelObjectService> taskActionsService = scheduleService.getChildrenDeep(taskActionClass);
			for(IModelObjectService modelService : taskActionsService) {
				AModelTaskActionService taskActionService = (AModelTaskActionService) modelService;
				boolean isSapTaskAction = taskActionService.isSapTaskAction();
				hasSapInput |= isSapTaskAction;
				if (isSapTaskAction && needUpdate(taskActionService, sapContext)) {
					sapTaskActions.add(taskActionService);

					String operationId = taskActionService.getAncestor(operationClass).getIdentifier();
					if (!operationsIdToEdit.contains(operationId) && !editionController.isOperationEditable(operationId)) {
						operationsIdToEdit.add(operationId);
					}
				}
			}

			// Update taskActions needed update
			scheduleService.setHasSapInput(hasSapInput);
			if (!sapTaskActions.isEmpty()) {
				// Acquire edition for all impacted operations (only for inventory schedule)
				//set prends context d'editioon
				//				editionController.updateOperationsEdited(Utils.getStringValues(operationsIdToEdit));

				// Apply modification for all SAP taskAction
				for(AModelTaskActionService taskActionService : sapTaskActions) {
					IModelObjectService operationService = taskActionService.getAncestor(operationClass);
					if (editionController.isOperationEditable(operationService.getIdentifier())) {
						logger.debug("SAP update " + taskActionService);
						update(taskActionService, sapContext);
					}
				}
				updated = true;
				if (!isDisableHmiNotifications()) {
					controller.getNotificationsService().setDisableNotifications(false);
					controller.getNotificationsService().setModelReload();
				}
			}

		}
		getLoggerHmi().info(AssemblyPropertyConstants.PROPERTY_RANGE_SAP_UPDATED);
		return updated;
	}

	protected boolean isSapSchedule(IController controller) {
		boolean result = false;
		AAssemblyScheduleService scheduleService = (AAssemblyScheduleService) getModelProvider()
				.getModelScheduleService();
		if (scheduleService.getWrapperService().getParameters().getIsSapSchedule() != null) {
			result = scheduleService.getWrapperService().getParameters().getIsSapSchedule().getIsSapSchedule();
		}
		logger.debug("[SAP] Schedule is configured for sap " + Boolean.toString(result));
		return result;
	}

	private boolean runNewTreatment(IController controller, AAssemblyScheduleService scheduleService) {
		return true;
	}


	/**
	 * Check if taskAction needs an update
	 * @param taskActionService taskAction service to analyze
	 * @return true if an update is needed
	 */
	private boolean needUpdate(AModelTaskActionService taskActionService, SapExtractUFIResponseContext sapContext) {
		return update(taskActionService, sapContext, false);
	}

	/**
	 * Update taskAction with SAP context
	 * @param taskActionService the taskAction service to update
	 * @return true if succeed
	 */
	private boolean update(AModelTaskActionService taskActionService, SapExtractUFIResponseContext sapContext) {
		return update(taskActionService, sapContext, true);
	}

	/**
	 * Internal function to analyze (check if update is needed) or update a taskAction service
	 * @param taskActionService the taskAction service
	 * @param sapContext flag to indicate an update or an analyze
	 * @return true if update
	 */
	private boolean update(AModelTaskActionService taskActionService, SapExtractUFIResponseContext sapContext, boolean update) {
		boolean updated = false;
		try {
			InputActionChoice inputActionChoice = taskActionService.getTaskAction().getInputAction().getInputActionChoice();
			if (inputActionChoice.getInputSap() != null) {
				updated = getUpdaterInputPoste().update(taskActionService, sapContext, update);
			} else {
				updated = getUpdaterInputControl().update(taskActionService, sapContext, update);
			}
		} catch(Exception e) {
			logger.error("Error during sap input update", e);
		}
		return updated;
	}

	/**
	 * @return the updaterSchedule
	 */
	private UpdateSapScheduleService getUpdaterSchedule() {
		return updaterSchedule;
	}

	/**
	 * @return the updaterInputPoste
	 */
	private UpdateSapInputPosteService getUpdaterInputPoste() {
		return updaterInputPoste;
	}

	/**
	 * @return the updaterInputControl
	 */
	private UpdateSapInputControlService getUpdaterInputControl() {
		return updaterInputControl;
	}

	/**
	 * @return the disableHmiNotifications
	 */
	private boolean isDisableHmiNotifications() {
		return disableHmiNotifications;
	}
}
