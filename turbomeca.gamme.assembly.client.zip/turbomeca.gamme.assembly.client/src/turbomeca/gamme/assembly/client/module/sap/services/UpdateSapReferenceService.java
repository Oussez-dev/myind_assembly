package turbomeca.gamme.assembly.client.module.sap.services;

import org.apache.log4j.Logger;

import turbomeca.gamme.ecran.client.AClientInstancesProvider;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.server.ws.sap.client.model.ExtractUfi.SapExtractUFIResponseContext;
import turbomeca.gamme.ecran.server.ws.sap.client.model.ExtractUfi.SapUfiAffairePoste;
import turbomeca.gamme.ecran.services.common.constants.GlobalConstants;

public class UpdateSapReferenceService extends AClientInstancesProvider {

	private static Logger logger = Logger.getLogger(UpdateSapReferenceService.class);

	public boolean update(SapExtractUFIResponseContext sapContext) throws ClientException {
		boolean needUpdate = false; 
		// Call web service interface for getting SAP context
		StringBuilder builder = new StringBuilder();

		for(String itemConf : getConfiguration().getConfigRange().getItems()) {
			String[] itemConfTable = itemConf.split(GlobalConstants.SEPARATOR_ITEM_ID);
			String ufiInstanceId = itemConfTable[0];
			String ufiPn = itemConfTable[1];
			String ufiSn = itemConfTable[2];

			String sapInstanceId = itemConfTable[3];
			String sapPn = getSapPnValue(sapInstanceId, sapContext);
			String sapSn = getSapSnValue(sapInstanceId, sapContext);

			if(hasDifference(ufiPn,sapPn) || hasDifference(ufiSn,sapSn) ) {
				needUpdate = true;
			}

			builder.append(ufiInstanceId + GlobalConstants.SEPARATOR_ITEM_ID);
			if (sapPn != null) {
				builder.append(sapPn);
			} else {
				builder.append(itemConfTable[1]);
			}

			builder.append(GlobalConstants.SEPARATOR_ITEM_ID);
			if (sapSn != null) {
				builder.append(sapSn);
			} else {
				builder.append(itemConfTable[2]);
			}
			builder.append(GlobalConstants.SEPARATOR_ITEM_ID);
			builder.append(sapInstanceId);
		}

		if(needUpdate) {
			logger.debug("Update Items references with " + builder.toString());
			getConfiguration().getConfigRange().setItemsSAP(builder.toString());
		}
		return needUpdate;
	}

	private boolean hasDifference(String ufiValue, String sapValue) {
		return   (!ufiValue.equals(sapValue));
	}

	public String getSapPnValue(String instanceId, SapExtractUFIResponseContext sapContext) {
		String value = null;
		SapUfiAffairePoste dataPoste = sapContext.getPostes().get(instanceId);
		if (dataPoste != null) {
			Object valueObject = dataPoste.getPn();
			if (valueObject != null) {
				value = valueObject.toString();
			} else {
				value = "";
			}
		}
		return value;
	}

	public String getSapSnValue(String instanceId, SapExtractUFIResponseContext sapContext) {
		String value = null;
		SapUfiAffairePoste dataPoste = sapContext.getPostes().get(instanceId);
		if (dataPoste != null) {
			Object valueObject = dataPoste.getSn();
			if (valueObject != null) {
				value = valueObject.toString();
			} else {
				value = "";
			}
		}
		return value;
	}

}
