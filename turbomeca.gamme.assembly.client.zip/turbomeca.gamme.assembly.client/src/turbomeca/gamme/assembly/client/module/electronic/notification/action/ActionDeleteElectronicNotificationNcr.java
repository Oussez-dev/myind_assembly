package turbomeca.gamme.assembly.client.module.electronic.notification.action;

import java.util.List;

import turbomeca.gamme.assembly.client.model.edit.IModelAssemblyWrapperScheduleService;
import turbomeca.gamme.assembly.client.model.edit.instructions.AModelTaskActionService;
import turbomeca.gamme.assembly.client.model.edit.notifications.AModelNotificationService;
import turbomeca.gamme.assembly.client.model.edit.notifications.ModelNotificationsService;
import turbomeca.gamme.assembly.client.model.edit.provider.ModelNotificationProvider;
import turbomeca.gamme.assembly.services.model.data.ElectronicNotificationRef;
import turbomeca.gamme.assembly.services.model.data.types.StatusNotificationType;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.services.common.constants.GlobalConstants;

public class ActionDeleteElectronicNotificationNcr extends AActionCreateElectronicNotification {

	/** */
	private AModelTaskActionService modelService;

	/**
	 * 
	 * @param taskActionService
	 */
	public ActionDeleteElectronicNotificationNcr(AModelTaskActionService modelService) {
		setModelService(modelService);
	}

	@Override
	public boolean run(IController controller) throws ClientException {
		for(ElectronicNotificationRef notifRef : getModelService().getWrapperService().getElectronicNotificationRef()) {
			List<AModelNotificationService> notifications = ModelNotificationProvider.getInstance().getNotifications(notifRef.getRefId());
			if (notifications != null) {
				for(AModelNotificationService notification : notifications) {
					ModelNotificationProvider.getInstance().addNotificationServiceToErase(notification);
					notification.getElectronicNotification().setActive(false);
				}
			}
		}
		boolean successSynchronizeOnServer = true;
		successSynchronizeOnServer = synchronizeOnServer(true);
		for(ElectronicNotificationRef notifRef : getModelService().getWrapperService().getElectronicNotificationRef()) {
			List<AModelNotificationService> notifications = ModelNotificationProvider.getInstance().getNotifications(notifRef.getRefId());
			if (notifications != null) {
				for(AModelNotificationService notification : notifications) {
					getModelService().getWrapperService().removeElectronicNotificationRef();
					controller.getNotificationsService().notifyServiceChanged(notification.getParent());
					controller.getNotificationsService().notifyElectronicNotificationChanged(getModelService());
					((ModelNotificationsService) notification.getParent()).removeInactiveNotifications();
					if(!successSynchronizeOnServer) {
						IModelAssemblyWrapperScheduleService wrapper = (IModelAssemblyWrapperScheduleService) getModelProvider().getModelScheduleService().getWrapperService();
						wrapper.updateObjectsToSynchronize(notification.getElectronicNotification().getId(),
								StatusNotificationType.CANCELED.toString(), GlobalConstants.ELECTRONIC_NOTIFICATION);
					}
				}
			}
			getNotificationProvider().getNotifications().remove(notifRef.getRefId());
		}
		controller.getNotificationsService().notifyServiceChanged(getModelService().getSubPhase());
		return true;
	}

	public AModelTaskActionService getModelService() {
		return modelService;
	}

	public void setModelService(AModelTaskActionService modelService) {
		this.modelService = modelService;
	}
}