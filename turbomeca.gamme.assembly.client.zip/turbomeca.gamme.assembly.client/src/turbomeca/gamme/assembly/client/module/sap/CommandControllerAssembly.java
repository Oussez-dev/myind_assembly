package turbomeca.gamme.assembly.client.module.sap;

import java.util.ArrayList;
import java.util.List;

import turbomeca.gamme.assembly.client.config.AssemblyRoleConstants;
import turbomeca.gamme.assembly.client.module.sap.action.ActionExecuteCommandAssembly;
import turbomeca.gamme.ecran.client.IClientControllersProvider;
import turbomeca.gamme.ecran.client.module.sap.ADefaultCommandController;
import turbomeca.gamme.ecran.client.module.sap.action.AActionExecuteCommand;

public class CommandControllerAssembly extends ADefaultCommandController {

    
    public CommandControllerAssembly(IClientControllersProvider provider) {
        super(provider);
    }

	@Override
	protected List<String> getUserRoles() {
		List<String> listeRoles = new ArrayList<String>();
		for (String userRole : getConfiguration().getConfigUser().getUserRoles()) {
			listeRoles.add(AssemblyRoleConstants.mapRoleFromKey(Integer.parseInt(userRole)));
		}
		return listeRoles;
	}

	@Override
	public AActionExecuteCommand getCommandAction(int commandId) {
		return new ActionExecuteCommandAssembly(getCommandManager().getCommand(commandId));
	}
}
