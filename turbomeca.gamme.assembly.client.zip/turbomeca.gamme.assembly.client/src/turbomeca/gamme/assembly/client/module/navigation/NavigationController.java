package turbomeca.gamme.assembly.client.module.navigation;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.module.instruction.InstructionController;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.IClientControllersProvider;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.module.AController;

/**
 * This controller is in charge of navigation action that come from HMI
 * javascript (for instance: navigate using navigation toolbar in tasks view).
 * 
 * @author ademartin
 *
 */
public class NavigationController extends AController {

	private static Logger logger = Logger.getLogger(NavigationController.class);

	private InstructionController instructionController;

	public NavigationController(
			IClientControllersProvider provider) {
		super(provider);
	}

	@Override
	public boolean init() throws ClientException, ClientInterruption {
		// Load view as a reference	
		this.instructionController = (InstructionController) getControllersProvider().getInstructionHmiInterface();
		return this.instructionController != null;
	}

	/**
	 * Action that notify the view to focus the specified service.
	 * 
	 * @param id
	 *            the service identifier
	 * @throws ClientException
	 *             see view focus failure cases
	 */
	public void actionFocusService(String id) throws ClientException {
		logger.debug("actionFocusService - start");

		IModelObjectService objectService = getModelProvider().getModelService(id);
		if(objectService == null) {
			logger.debug("Nothing to focus!");
			return;
		}
		// Focus service found in the view
		instructionController.getView().focusService(objectService);
	}

	@Override
	public boolean destroy() throws ClientException {
		// Nothing to destroy
		return true;
	}
}
