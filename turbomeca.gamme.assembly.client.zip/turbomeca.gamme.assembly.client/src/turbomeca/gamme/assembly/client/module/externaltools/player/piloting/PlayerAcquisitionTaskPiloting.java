package turbomeca.gamme.assembly.client.module.externaltools.player.piloting;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.module.externaltools.communication.ServletCommunication;
import turbomeca.gamme.assembly.client.module.externaltools.config.ConfigurationTaskPiloting;
import turbomeca.gamme.assembly.client.module.externaltools.player.measure.APlayerAcquisition;
import turbomeca.gamme.assembly.client.module.externaltools.player.measure.ServiceType;
import turbomeca.gamme.assembly.client.module.externaltools.provider.PlayerAcquisitionToolsProvider;
import turbomeca.gamme.assembly.services.model.data.State;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.services.devices.ExternalsToolsExceptions;

public class PlayerAcquisitionTaskPiloting extends APlayerAcquisition {
	
	private static Logger logger = Logger.getLogger(PlayerAcquisitionTaskPiloting.class);
	
	public PlayerAcquisitionTaskPiloting (ConfigurationTaskPiloting configuration, State state){
		super(ServiceType.TASK_PILOTING);
		setConfigurationMeasure(configuration);
		setState(state);
	}
	
	@Override
	public String acquireAcquistion() throws ExternalsToolsExceptions, InterruptedException  {
		logger.debug("[PILOTING] : PlayerAcquisitionTools - acquireAcquistion");
		String value = null;
		ServletCommunication communicator = null;
		try{
			communicator = (ServletCommunication) PlayerAcquisitionToolsProvider.getCommunicationWay(getConfigurationMeasure());
			communicator.listen();
			value= communicator.getData();
			logger.debug("[PILOTING] : PlayerAcquisitionTools - Acquired values : " + value);
		} finally{
			if(communicator != null){
				logger.debug("[PILOTING] : PlayerAcquisitionTools - Release communication");
				communicator.release();
			}
		}
		return value;
	}
	
	@Override
	public String acquire() throws ExternalsToolsExceptions, ClientInterruption {
		String value = null;
		try {
			value = acquireAcquistion();
		} catch (InterruptedException e) {
			logger.error("[PILOTING] : Interuption of acquisition", e);
			Thread.currentThread().interrupt();
		} 
		return value;
	}
}
