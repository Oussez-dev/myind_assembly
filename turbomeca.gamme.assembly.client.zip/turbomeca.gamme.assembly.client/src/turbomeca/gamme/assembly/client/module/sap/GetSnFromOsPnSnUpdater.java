package turbomeca.gamme.assembly.client.module.sap;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.services.model.data.Derogation;
import turbomeca.gamme.assembly.services.model.data.InputAction;
import turbomeca.gamme.assembly.services.model.data.InputActionChoice;
import turbomeca.gamme.assembly.services.model.data.InputChoice;
import turbomeca.gamme.assembly.services.model.data.InputValue;
import turbomeca.gamme.assembly.services.model.data.Mark;
import turbomeca.gamme.assembly.services.model.data.PN;
import turbomeca.gamme.assembly.services.model.data.SN;
import turbomeca.gamme.assembly.services.model.data.StringValue;
import turbomeca.gamme.assembly.services.model.data.SubPhase;
import turbomeca.gamme.assembly.services.model.data.TaskAction;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.interfaces.server.sap.mapper.DataResponsePnSnDerog;
import turbomeca.gamme.ecran.client.interfaces.server.sap.mapper.DataResponseSnDerog;
import turbomeca.gamme.ecran.client.module.IController;

/**
 * Class to update marks PN/SN and header material SN using a getSnFromOs SAP
 * web-service mapped response.
 * 
 * @author ademartin
 *
 */
public class GetSnFromOsPnSnUpdater extends APnSnUpdater {

	/** Logger for current class */
	private static Logger logger = Logger.getLogger(GetSnFromOsPnSnUpdater.class);
	
	/** The getSnFromOs response (intended to be already mapped) */
	private DataResponsePnSnDerog response;
	
	public GetSnFromOsPnSnUpdater(IController controller, DataResponsePnSnDerog response) {
		setController(controller);
		
		boolean isSapSynchronized = response != null && response.getPnSnMarks() != null && !response.getPnSnMarks().isEmpty();
		setSapSynchronized(isSapSynchronized);
		
		// Check data to process is given, consider the response as invalid if not
		// FIXME Kept for historical use, maybe the response data needs some specific controls ?
		if(response == null) {
			setSapResponseValid(false);
			this.response = new DataResponsePnSnDerog();
		} else {
			setSapResponseValid(true);
			this.response = response;
		}
	}
	
	@Override
	protected boolean checkMaterial(String pn, SN[] sns) throws ClientException {
		List<DataResponseSnDerog> listConfig = response.getPnSnMaterial().get(pn);
		boolean hasUpdated = false;
		
        if (listConfig != null) {
        	for(SN sn : sns) {
				if(isSnAlreadySeized(sn)) {
					logger.warn("Header material has already a SN manually seized, abort its updating process...");
					return hasUpdated;
				}
			}
        	
        	hasUpdated = buildUniquePn(response.getPnSnMaterial(), pn, null, sns);
            if (hasUpdated) {
            	addSnToEditionContext(sns);
            }
        } else {
            logger.warn("PN material not found in SAP data received");
        }
        
        return hasUpdated;
	}

	@Override
	protected boolean checkMark(Mark mark, SubPhase subPhase) throws ClientException {
		boolean hasUpdated = false;
        for (int i = 0; i < mark.getPNCount(); i++) {
            PN pn = mark.getPN(i);
            SN[] sn = mark.getSN();
            Derogation[] derog = mark.getDerogation();

            // Build list of applicable PN
             List<String> currentPns = getApplicablePns(pn);
            // There are multiple PN applicable
            if (currentPns.size() > 1 ) {
               hasUpdated = buildMultiplePn(response.getPnSnMarks(), currentPns, pn.getTaskAction(), sn, derog);
            }
            // There is only PN applicable
            else if (currentPns.size() == 1) {
            	 hasUpdated = buildUniquePn(response.getPnSnMarks(), currentPns.get(0), pn.getTaskAction(), sn);
            }
            // There is no PN applicable
            else {
            	 hasUpdated = buildNoPn(pn.getTaskAction());
            }
        }
        return hasUpdated;
	}
	
	/**
	 * Returns the list of PN values available in the given PN object that
	 * matches the PN defined in the response
	 * 
	 * @param pn
	 * @return
	 */
	private List<String> getApplicablePns(PN pn) {
        List<String> currentPns = new ArrayList<String>();
        TaskAction taskAction = pn.getTaskAction();
        if (taskAction != null) {
            // Build list of applicable PN
            InputAction inputAction = taskAction.getInputAction();
            InputActionChoice inputActionChoice = inputAction.getInputActionChoice();
            if (inputActionChoice.getInputChoice() != null) {
                InputChoice inputChoice = inputActionChoice.getInputChoice();
                for (StringValue stringValue : inputChoice.getStringValue()) {
                    List<DataResponseSnDerog> listConfig = response.getPnSnMarks().get(
                            stringValue.getContent());
                    if (listConfig != null) {
                        currentPns.add(stringValue.getContent());
                    }
                }
            } else if (inputActionChoice.getInputField() != null) {
                InputValue inputValue = taskAction.getInputAction().getInputValue();
                if (inputValue != null) {
                    List<DataResponseSnDerog> listConfig = response.getPnSnMarks().get(
                            inputValue.getValue());
                    if (listConfig != null) {
                        currentPns.add(inputValue.getValue());
                    }
                }
            }
        }
        return currentPns;
    }
}
