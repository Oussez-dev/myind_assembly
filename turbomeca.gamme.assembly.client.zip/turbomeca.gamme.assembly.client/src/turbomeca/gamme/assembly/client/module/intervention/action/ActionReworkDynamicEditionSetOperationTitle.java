package turbomeca.gamme.assembly.client.module.intervention.action;

import turbomeca.gamme.assembly.client.module.intervention.InterventionReworkDynamicManager;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.module.IController;

public class ActionReworkDynamicEditionSetOperationTitle extends AActionReworkDynamic {

    /** */
    private String title;
    
    /**
     * 
     * @param reworkManager
     */
    public ActionReworkDynamicEditionSetOperationTitle(InterventionReworkDynamicManager reworkManager, String title) {
        super(reworkManager);
        setTitle(title);
    }

    @Override
    public boolean run(IController controller) throws ClientException {
        getReworkManager().setOperationTitle(getTitle());
        return true;
    }

    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }

    /**
     * @param title the title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }
}