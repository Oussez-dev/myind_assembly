package turbomeca.gamme.assembly.client.module.externaltools.player.piloting;

public interface IInstructionPlayerListener {

	/**
	 * Notify that the thread have produce an error
	 * @param propertyKey the id of the error code
	 */
	void notifyError(String propertyKey);
	
	/**
	 * Notify that the thread has ended without error
	 * @param response the value returned by the treatment of the thread
	 */
	void notifyResponse(String response);

}
