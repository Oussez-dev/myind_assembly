package turbomeca.gamme.assembly.client.module.instruction.action;

import java.util.List;

import turbomeca.gamme.assembly.client.ClientAssemblyException;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelMarkService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskActionService;
import turbomeca.gamme.assembly.client.model.edit.schedule.AAssemblyScheduleService;
import turbomeca.gamme.assembly.client.model.edit.utils.ModelUtils;
import turbomeca.gamme.assembly.client.module.intervention.action.ActionUpdateScheduleTopStartOperation;
import turbomeca.gamme.assembly.services.model.data.InputChoice;
import turbomeca.gamme.assembly.services.model.data.StringValue;
import turbomeca.gamme.assembly.services.model.data.TaskAction;
import turbomeca.gamme.assembly.services.model.data.types.StatusType;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.constants.PropertyConstants;
import turbomeca.gamme.ecran.client.model.edit.instructions.IModelSubPhaseService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.client.module.action.AActionModify;
import turbomeca.gamme.ecran.client.module.instruction.action.ActionContinue;

public class ActionUpdateReferences extends AActionModify{
	
	public static final String SCHEDULE_ID = "schedule";

	private String elementId;

	public ActionUpdateReferences(String elementId) {
		super();
		this.elementId = elementId;
	}

	@Override
	public boolean run(IController controller) throws ClientException,
	ClientInterruption {
		boolean succeed = false;
		getLoggerHmi().info(PropertyConstants.PROPERTY_REFRESH_SUBPHASE_INPROGRESS);
		//test if the element is the top start subphase
		if(getElementId().equals("subphase_marks")){
			new ActionUpdateScheduleTopStartOperation().run(controller);
		}
		
		if(SCHEDULE_ID.equals(getElementId())){
			// for all the schedule
			IModelObjectService scheduleServiceObject = controller.getModelProvider().getModelScheduleService();
			if (scheduleServiceObject instanceof AAssemblyScheduleService) {
				AAssemblyScheduleService scheduleService = (AAssemblyScheduleService) scheduleServiceObject;
				List<IModelObjectService> subPhasesServices = scheduleService.getChildrenDeep(IModelSubPhaseService.class);
				if(subPhasesServices != null && !subPhasesServices.isEmpty()) {
	        		
					for (IModelObjectService serviceObject : subPhasesServices) {
						if(serviceObject instanceof ModelSubPhaseService){
							if(!serviceObject.getWrapperService().isArchived()) {
								succeed = successUpdateMark(controller, serviceObject);								
							}
						}
					}
	        	}
			} else {
				throw new ClientAssemblyException(ClientAssemblyException.EXCEPTION_SERVICE_NOT_FOUND);
			}
		} else {
			// for a unique subPhase
			IModelObjectService serviceObject = controller.getModelProvider().getModelService(getElementId());
			succeed = successUpdateMark(controller, serviceObject);
		}
		
		return succeed;
	}
	
	private boolean successUpdateMark(IController controller, IModelObjectService serviceObject) throws ClientException, ClientInterruption{
		boolean succeed = false;
		try {

			controller.getNotificationsService().setDisableNotifications(true);
			for (IModelObjectService modelMarkService : serviceObject.getChildrenDeep(ModelMarkService.class)) {
				
				ModelMarkService markServiceToUpdate = (ModelMarkService) modelMarkService;
				List<ModelMarkService> linkedMarksServices = markServiceToUpdate.getMarkReferences();
				if (linkedMarksServices != null && linkedMarksServices.size() > 0) {
					ModelMarkService markServiceForUpdate = null;
					for (ModelMarkService referenceService : linkedMarksServices) {
						ModelSubPhaseService subphaseService = (ModelSubPhaseService) referenceService.getAncestor(ModelSubPhaseService.class);
						if (referenceService.getIdentifier() != markServiceToUpdate.getIdentifier() 
								&& !subphaseService.isArchived() && !subphaseService.getStatusService().getStatus().equals(StatusType.NOT_TODO.toString())) {
							markServiceForUpdate = referenceService;
							break;
						}
					}
					updateMark(markServiceToUpdate, markServiceForUpdate, controller);
				}
			}
			
			// If parent model is not alterable don't update state of input computed (in case where suphase state is DONE)
			if (serviceObject.getStatusService().isAlterable()) {
				for(IModelObjectService modelTaskActionObjectService : serviceObject.getChildrenDeep(ModelTaskActionService.class)){
					ModelTaskActionService modelTaskActionService = (ModelTaskActionService) modelTaskActionObjectService;
					if(modelTaskActionService.getWrapperService().isInputComputed()){
						modelTaskActionService.getStatusService().update();
					}
				}				
			}
			succeed = true;
			new ActionContinue(serviceObject).run(controller);
			getLoggerHmi().info(PropertyConstants.PROPERTY_REFRESH_SUBPHASE_DONE);
		} finally {
			controller.getNotificationsService().setDisableNotifications(false);
			if(succeed) {
				controller.getNotificationsService().notifyServiceChanged(serviceObject);
			}
		}
		return succeed;
	}

	private void updateMark(ModelMarkService markServiceToUpdate, ModelMarkService markServiceForUpdate, IController controller) throws ClientException, ClientInterruption {
		ModelTaskActionService previousService = null;
		if(markServiceForUpdate != null) {

			for (IModelObjectService modelObjectServiceForUpdate : markServiceForUpdate.getChildrenDeep(ModelTaskActionService.class)) {
				boolean found = false;
				ModelTaskActionService taskActionServiceForUpdate = (ModelTaskActionService) modelObjectServiceForUpdate;
				for (IModelObjectService modelObjectServiceToUpdate : markServiceToUpdate.getChildrenDeep(ModelTaskActionService.class)) {
					ModelTaskActionService taskActionServiceToUpdate = (ModelTaskActionService) modelObjectServiceToUpdate;
					
					if (taskActionServiceToUpdate.isTaskActionLinked(taskActionServiceForUpdate)) {
						if(addValues(taskActionServiceForUpdate, taskActionServiceToUpdate)) {
							controller.getNotificationsService().notifyServiceChanged(taskActionServiceToUpdate);
						}
						previousService = taskActionServiceToUpdate;
						found = true;
						break;
					}
				}
				if (!found && taskActionServiceForUpdate.getType().equals(ModelMarkService.TASK_ACTION_DEROG_TYPE)
						&& markServiceToUpdate.getRunnableService().canRun()) {
					ModelTaskActionService newDerogationService = taskActionServiceForUpdate.cloneService(markServiceToUpdate, previousService);
					newDerogationService.setValue(taskActionServiceForUpdate.getValue());
					newDerogationService.setOptional(true);
					getModelProvider().addModelService(newDerogationService.getIdentifier(), newDerogationService);
					previousService = newDerogationService;
				}
			}
		}
	}

	private boolean addValues(ModelTaskActionService reference, ModelTaskActionService toUpdate) throws ClientException, ClientInterruption {
		boolean changed = false;
		if (reference.isInputChoice() && toUpdate.isInputChoice()) {
			int count = 0;
			StringValue[] valuesReference = reference.getWrapperService().getTaskAction().getInputAction().getInputActionChoice().getInputChoice().getStringValue();
			InputChoice inputToUpdate = toUpdate.getWrapperService().getTaskAction().getInputAction().getInputActionChoice().getInputChoice();
			StringValue[] valuesToUpdate = inputToUpdate.getStringValue();
			for (StringValue valueRef : valuesReference) {
				if (count < valuesToUpdate.length) {
					StringValue valueToUpdate = valuesToUpdate[count];
					if (!valueRef.getContent().equals(valueToUpdate.getContent())) {
						valueToUpdate.setContent(valueRef.getContent());
						changed = true;
					}
				} else {
					StringValue value = new StringValue();
					value.setContent(valueRef.getContent());
					inputToUpdate.addStringValue(value);
					changed = true;
				}
				count++;
			}
			String referenceValue = reference.getValue();
			String toUpdateValue = toUpdate.getValue();
			if(referenceValue != null && !referenceValue.isEmpty() && 
					(toUpdateValue == null || !toUpdateValue.equals(referenceValue))){
				toUpdate.setValue(referenceValue, true);
				changed = true;
			}
		}
		else if (reference.isInputChoice() && !toUpdate.isInputChoice()) {
			String valueReference = "";
			StringValue[] valuesReference = reference.getWrapperService().getTaskAction().getInputAction().getInputActionChoice().getInputChoice().getStringValue();
			int indexReference = -1;
			if(reference.getWrapperService().getTaskAction() != null 
					&& reference.getWrapperService().getTaskAction().getInputAction() != null
					&& reference.getWrapperService().getTaskAction().getInputAction().getInputValue() != null) {
				indexReference = Integer.parseInt(reference.getWrapperService().getTaskAction().getInputAction().getInputValue().getValue()) -1;
			}
			if(indexReference > -1 && indexReference < valuesReference.length){
				StringValue stringValueReference = valuesReference[indexReference];
				if(stringValueReference != null) {
					valueReference = stringValueReference.getContent();
				}
			}
			if(valueReference != "") {
				toUpdate.setValue(valueReference, true);
				changed = true;
			}
		}
		else if (!reference.isInputChoice() && toUpdate.isInputChoice()) {
			TaskAction taReference = null;
			if(reference.getWrapperService() != null 
					&& reference.getWrapperService().getTaskAction() != null) {
				taReference = reference.getWrapperService().getTaskAction();
			}
			TaskAction taskActionInputToUpdate = toUpdate.getWrapperService().getTaskAction();
			ModelUtils.addCurrentValue(taskActionInputToUpdate, taReference);
			changed = true;
		}
		else {
			String referenceValue = reference.getValue();
			String toUpdateValue = toUpdate.getValue();
			if(referenceValue != null && !referenceValue.isEmpty() && 
					(toUpdateValue == null || !toUpdateValue.equals(referenceValue))){
				toUpdate.setValue(referenceValue, true);
				changed = true;
			}
		}
		return changed;
	}

	public String getElementId() {
		return elementId;
	}

	public void setElementId(String elementId) {
		this.elementId = elementId;
	}


}
