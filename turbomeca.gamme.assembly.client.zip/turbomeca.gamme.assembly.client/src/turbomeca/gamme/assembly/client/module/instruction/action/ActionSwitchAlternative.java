package turbomeca.gamme.assembly.client.module.instruction.action;

import turbomeca.gamme.assembly.client.ClientAssemblyException;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelOperationService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.client.module.intervention.action.ActionUpdateScheduleTopStartOperation;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.context.ContextRequest;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.client.module.action.AActionModify;

public class ActionSwitchAlternative extends AActionModify {

	private String subPhaseId;
	private String alternativeSubPhaseId;

	public ActionSwitchAlternative(String subPhaseId, String alternativeSubPhaseIdd) {
		super();
		setSubPhaseId(subPhaseId);
		setAlternativeSubPhaseId(alternativeSubPhaseIdd);
	}

	@Override
	public boolean run(IController controller) throws ClientException, ClientInterruption {
		ModelSubPhaseService subPhaseService = (ModelSubPhaseService) getModelProvider().getModelService(getSubPhaseId());
		ModelSubPhaseService alternativeSubPhaseService = (ModelSubPhaseService) getModelProvider().getModelService(getAlternativeSubPhaseId());

		ModelOperationService operationService = (ModelOperationService) subPhaseService.getAncestor(ModelOperationService.class);
		ModelOperationService alternativeOperationService = (ModelOperationService) alternativeSubPhaseService.getAncestor(ModelOperationService.class);
		
		if (!subPhaseService.getStatusService().isAlterable()) {
			throw new ClientAssemblyException(ClientAssemblyException.EXCEPTION_INSTRUCTION_PARENT_FINISHED);
		} else if (subPhaseService.getParent().getClass() != alternativeSubPhaseService.getParent().getClass()) {
		    throw new ClientAssemblyException(ClientAssemblyException.EXCEPTION_INSTRUCTION_SAME_PARENT_TYPE);
		} else if (!operationService.getIdentifier().equals(alternativeOperationService.getIdentifier())) {
			throw new ClientAssemblyException(ClientAssemblyException.EXCEPTION_ALTERNATIVE_OPERATION_DIFFERENT);
		} else {
		    getContext().getContextRequest().setRequestType(ContextRequest.ACTIVITY_UPDATE);
			subPhaseService.switchToReplacement(alternativeSubPhaseService, null);
			controller.getNotificationsService().setModelReload();
			(new ActionUpdateScheduleTopStartOperation()).run(controller);
		}
		return true;
	}

	/**
	 * @param subPhaseId
	 *            the subPhaseId to set
	 */
	public void setSubPhaseId(String subPhaseId) {
		this.subPhaseId = subPhaseId;
	}

	/**
	 * @return the subPhaseId
	 */
	public String getSubPhaseId() {
		return subPhaseId;
	}

	/**
	 * @param alternativeSubPhaseId
	 *            the alternativeSubPhaseId to set
	 */
	public void setAlternativeSubPhaseId(String alternativeSubPhaseId) {
		this.alternativeSubPhaseId = alternativeSubPhaseId;
	}

	/**
	 * @return the alternativeSubPhaseId
	 */
	public String getAlternativeSubPhaseId() {
		return alternativeSubPhaseId;
	}
}
