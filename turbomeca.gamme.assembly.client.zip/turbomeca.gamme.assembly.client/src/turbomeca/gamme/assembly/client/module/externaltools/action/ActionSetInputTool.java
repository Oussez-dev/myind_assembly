package turbomeca.gamme.assembly.client.module.externaltools.action;

import turbomeca.gamme.assembly.client.model.edit.instructions.AModelTaskActionService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelOperationService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskActionMeasureService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskActionService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskPilotingService;
import turbomeca.gamme.assembly.client.model.edit.status.ModelStatusTaskActionMeasureService;
import turbomeca.gamme.assembly.services.model.data.MeasureTool;
import turbomeca.gamme.assembly.services.model.data.TaskAction;
import turbomeca.gamme.assembly.services.model.data.TaskActionMeasure;
import turbomeca.gamme.assembly.services.model.data.types.StatusType;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.client.module.action.AActionModify;

public class ActionSetInputTool extends AActionModify {

	/** Not user for moment */
	private String toolId;
	/** PN tool filled by user */
	private String toolPn;
	/** Tool type */
	private String toolType;

	/**
	 * 
	 * @param toolId
	 */
	public ActionSetInputTool(String toolId, String toolPn) {
		setToolId(toolId);
		setToolPn(toolPn);
	}

	@Override
	public boolean run(IController controller) throws ClientException, ClientInterruption {
		AModelTaskActionService taskActionService = ((AModelTaskActionService) getModelProvider().getModelService(getToolId()));
		if (getToolPn() != null && !getToolPn().isEmpty()) {
			if (taskActionService.getParent() instanceof ModelTaskPilotingService) {
				ModelTaskPilotingService taskActionPiloting = (ModelTaskPilotingService) taskActionService.getParent();
				applyToolIdPiloting(taskActionPiloting.getAncestor(ModelSubPhaseService.class), controller);
				taskActionPiloting.resetInputValues(taskActionService.getIdentifier());
			} else if (taskActionService.getParent() instanceof ModelTaskActionMeasureService) {
				ModelTaskActionMeasureService taskActionMeasure = (ModelTaskActionMeasureService) taskActionService.getParent();
				setToolType(taskActionMeasure.getMeasureTool().getType());
				applyToolIdMeasure(taskActionMeasure.getAncestor(ModelOperationService.class), controller);
			}	
		}else {
			if (taskActionService.getParent() instanceof ModelTaskPilotingService) {
				((ModelTaskPilotingService)taskActionService.getParent()).resetInputValues(taskActionService.getIdentifier());			
			}
		}
		taskActionService.setValue(getToolPn());
		return true;
	}

	/**
	 * 
	 * @param modelService
	 * @param controller
	 * @throws ClientException
	 * @throws ClientInterruption 
	 */
	private void applyToolIdPiloting(IModelObjectService modelService, IController controller) 
			throws ClientException, ClientInterruption {
		if (modelService instanceof ModelTaskPilotingService) {
			ModelTaskPilotingService taskPilotingService = (ModelTaskPilotingService) modelService;
			boolean reported = reportValue((ModelTaskActionService) taskPilotingService.getChildren().get(0), controller);
			if (reported) {
				taskPilotingService.setAutoMode(true);
				if(taskPilotingService.getRunnableService().isFinished()) {
					modelService.getStatusService().clean(null); 
					modelService.getStatusService().resetState(false, false, null);
				}
			}
		} else {
			for (IModelObjectService childService : modelService.getChildren()) {
				applyToolIdPiloting(childService, controller);
			}
		}
	}

	/**
	 * 
	 * @param modelService
	 * @param controller
	 * @throws ClientException
	 * @throws ClientInterruption 
	 */
	private void applyToolIdMeasure(IModelObjectService modelService, IController controller) 
			throws ClientException, ClientInterruption {
		if (modelService instanceof ModelTaskActionMeasureService) {
			applyToolIdMeasure((ModelTaskActionMeasureService) modelService,  controller);
		} else {
			for (IModelObjectService childService : modelService.getChildren()) {
				// Skip not runnable service like sub-phases not taken in edition and so on...
				if(childService.getRunnableService().isRunnable() && childService.getRunnableService().canRun()) {
					applyToolIdMeasure(childService, controller);
				}
			}
		}
	}
	
	private void applyToolIdMeasure(ModelTaskActionMeasureService modelService,  IController controller) throws ClientException, ClientInterruption {
		TaskActionMeasure taskMeasure = (TaskActionMeasure) modelService.getWrapperService().getObject();
		if (taskMeasure.getMeasureTool() != null && taskMeasure.getMeasureTool().getType().equals(getToolType())) {
			MeasureTool measureTool = taskMeasure.getMeasureTool();
			boolean reported = reportMeasureReference(measureTool.getTaskAction(), controller);
			if (reported) {
				if (measureTool.getState().getStatus() == StatusType.OK) {
					modelService.getStatusService().clean(null);
				}
				((ModelStatusTaskActionMeasureService) modelService.getStatusService()).updateStateToolsMeasure();
			}
		}
	}

	/**
	 * 
	 * @param taskAction
	 * @param controller
	 * @return
	 * @throws ClientException
	 * @throws ClientInterruption 
	 */
	private boolean reportMeasureReference(TaskAction taskAction, IController controller)
			throws ClientException, ClientInterruption {
		boolean reported = false;
		if (taskAction.getInputAction().getInputValue() == null) {
			reported = reportValue((ModelTaskActionService) getModelProvider().getModelService(taskAction.getId()),
					controller);
		}
		return reported;
	}

	/**
	 * 
	 * @param taskActionService
	 * @param controller
	 * @return
	 * @throws ClientException
	 * @throws ClientInterruption 
	 */
	private boolean reportValue(ModelTaskActionService taskActionService,
			IController controller) throws ClientException, ClientInterruption {
		boolean reported = false;
		if (!taskActionService.getRunnableService().isFinished()) {
			taskActionService.setValue(getToolPn());
			reported = true;
			controller.getNotificationsService().notifyValueChanged(taskActionService);
		}
		return reported;
	}

	/**
	 * @param toolId
	 *            the toolId to set
	 */
	public void setToolId(String toolId) {
		this.toolId = toolId;
	}

	/**
	 * @return the toolId
	 */
	public String getToolId() {
		return toolId;
	}

	/**
	 * @param toolPn
	 *            the toolPn to set
	 */
	public void setToolPn(String toolPn) {
		this.toolPn = toolPn;
	}

	/**
	 * @return the toolPn
	 */
	public String getToolPn() {
		return toolPn;
	}

	/**
	 * @return the toolType
	 */
	private String getToolType() {
		return toolType;
	}

	/**
	 * @param toolType the toolType to set
	 */
	private void setToolType(String toolType) {
		this.toolType = toolType;
	}
}
