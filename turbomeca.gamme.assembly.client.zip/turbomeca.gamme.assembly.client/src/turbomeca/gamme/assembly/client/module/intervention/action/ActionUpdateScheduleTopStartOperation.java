package turbomeca.gamme.assembly.client.module.intervention.action;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.model.edit.IModelAssemblyWrapperScheduleService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelMarkService;
import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperMarkService;
import turbomeca.gamme.assembly.services.model.data.types.StatusType;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.edit.instructions.IModelSubPhaseService;
import turbomeca.gamme.ecran.client.model.edit.wrappers.IModelWrapperSubPhaseService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.client.module.action.AActionModify;


/***
 * This class is in charge of updating the top start operation if exists
 * 
 * This is required only when applicable sub-phases is updated (level change,
 * sub-phase added through a rework , ..)
 * 
 * Note: To Run this service:
 *  - schedule MUST be taken in full edition
 *  - FIXME: recompute top-start sub-phase status ?
 * 
 * @author ahermo
 *
 *
 */
@Deprecated // On SOCLE REPORT, this class should be re-factored as a service not an action 
			// because it is not directly runs by the user
public class ActionUpdateScheduleTopStartOperation extends AActionModify {

	private final IModelObjectService topStartSubPhase;
	private static Logger logger = Logger.getLogger(ActionUpdateScheduleTopStartOperation.class);
	/**
	 * This hard coded identifier is identical to the one hard coded in
	 * publication XSL which are in charge of creating the top start operation
	 * 
	 */
	private static final String TOP_START_SUBPHASE_ID = "subphase_marks";
	private final int passingId;
	
	// Flag indicating when the top start operation status MUST be updated
	// This occurs only when adding new Mark to force sub-phase to be re-opened
	private boolean computeTopStartOperationStatus = false;

	public ActionUpdateScheduleTopStartOperation( ) {
		this.topStartSubPhase = getModelProvider().getModelService(TOP_START_SUBPHASE_ID);
		IModelAssemblyWrapperScheduleService wrapper = (IModelAssemblyWrapperScheduleService) getModelProvider()
				.getModelScheduleService().getWrapperService();
		passingId = wrapper.getPassingId();

	}

	
	@Override
	public boolean run(IController controller) throws ClientException,
			ClientInterruption {
		if( topStartSubPhase != null) {		
			List<ModelWrapperMarkService> topStartMarkWrappers = getTopStartMarksWrappers();
			for( ModelWrapperMarkService markWrapper: topStartMarkWrappers) {
				updateMarKApplicability(markWrapper);
			}
			
			if(computeTopStartOperationStatus) {
				topStartSubPhase.getStatusService().computeStatus(true);
			}
		}
		return false;
	}

	private List<ModelWrapperMarkService> getTopStartMarksWrappers() {
		List<IModelObjectService> markServices = topStartSubPhase.getChildrenDeep(ModelMarkService.class);
		List<ModelWrapperMarkService> markWrappers = new ArrayList<ModelWrapperMarkService>(markServices.size());
		
		for(IModelObjectService markService : markServices) {
			ModelWrapperMarkService wrapperService = (ModelWrapperMarkService) markService.getWrapperService();
			markWrappers.add(wrapperService);
		}
		return markWrappers;
	}
	
	private void updateMarKApplicability(ModelWrapperMarkService markWrapper) {
		String setApplicableFrom = markWrapper.getMark().getSetApplicableFrom();
		if(setApplicableFrom!=null && !setApplicableFrom.isEmpty()) {
			boolean previousApplicability = markWrapper.isApplicable();
			boolean newApplicability = areAllApplicable(setApplicableFrom.split(" "));
			markWrapper.setApplicable(newApplicability);
			if(newApplicability && !previousApplicability) {
				computeTopStartOperationStatus = true;
			}
		}
	}
	
	/**
	 * Check that all objects provided by its identifier is Applicable on current document
	 * 
	 * @param subPhasesIds
	 * @return
	 */
	private boolean areAllApplicable(String[] subPhasesIds) {
		for (String id : subPhasesIds) {
			IModelSubPhaseService subPhaseService = getSubPhaseService(id);
			if( subPhaseService!=null) {
				IModelWrapperSubPhaseService subPhaseWrapper = subPhaseService
						.getWrapperService();
				try {
					if (! (StatusType.NOT_APPLICATED.toString().equals(subPhaseService.getStatusService().getStatus()) ||
							subPhaseWrapper != null && !subPhaseWrapper.isApplicable()
							|| subPhaseWrapper.isAlternative() )) {
						return true;
					}
				} catch (ClientException e) {
					logger.error(e);
				}
			}
		}
		return false;
	}

	/**
	 * Reworks Operations are set in the main flow (under operations) with a
	 * passingId So its identifier is suffixed by _<passingId>
	 * 
	 * Do a reverse order lookup on sub-phase identifier from the last passingId
	 * to find the applicable sub-Phase
	 * 
	 * 
	 * @param subPhaseId
	 * @return
	 */
	private IModelSubPhaseService getSubPhaseService(String subPhaseId) {
		IModelSubPhaseService subPhaseService = null;
		
		int passingId = this.passingId;
		// First search from last passingId
		while( subPhaseService==null && passingId > 1 ) {
			/** This Id construction based upon passingId is hard coded in rework XSL integration **/
			String passingSubPhaseId = subPhaseId + "_" + passingId;
			subPhaseService =  (IModelSubPhaseService) getModelProvider()
					.getModelService(passingSubPhaseId);
			if (subPhaseService != null) {
				return subPhaseService;
			}
			passingId--;
		} 
		if(subPhaseService==null) {
			subPhaseService = (IModelSubPhaseService) getModelProvider()
					.getModelService(subPhaseId);
		}
		if(subPhaseService==null) {
			logger.error("Unable to find subPhase @id=" +subPhaseId + " assocaited with top start Mark");
		}
		return subPhaseService;
	}
}
