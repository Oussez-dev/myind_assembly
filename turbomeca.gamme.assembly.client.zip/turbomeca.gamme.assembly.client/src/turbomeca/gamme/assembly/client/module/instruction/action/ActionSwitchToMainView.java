package turbomeca.gamme.assembly.client.module.instruction.action;

import turbomeca.gamme.assembly.client.module.instruction.view.InstructionView;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.client.module.instruction.ADefaultInstructionController;
import turbomeca.gamme.ecran.client.module.instruction.view.IInstructionView;

public class ActionSwitchToMainView extends AActionSwitchView {

	/** The operation identifier to focus by returning to the main view */
	private String operationId;
	
	public ActionSwitchToMainView(String operationId) {
		this.operationId = operationId;
	}
	
	@Override
	protected IInstructionView getViewToSwitchTo() throws ClientException, ClientInterruption {
		return new InstructionView(getModelProvider().getModelScheduleService());
	}

	@Override
	public boolean run(IController controller) throws ClientException,
			ClientInterruption {
		boolean success = super.run(controller);
		
		if(!success) {
			return false;
		}
		
		IModelObjectService toFocusService = getModelProvider().getModelService(operationId);
		ADefaultInstructionController instructionController  = controller.getControllersProvider().getInstructionHmiInterface();
		
		if(toFocusService != null) {
			instructionController.getView().focusService(toFocusService);
		}
		
		return true;
	}
}
