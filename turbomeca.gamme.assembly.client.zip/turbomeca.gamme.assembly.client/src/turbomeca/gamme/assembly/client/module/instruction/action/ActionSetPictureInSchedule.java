package turbomeca.gamme.assembly.client.module.instruction.action;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.module.instruction.InstructionController;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.config.ConfigurationLocalProperties;
import turbomeca.gamme.ecran.client.constants.PropertyConstants;
import turbomeca.gamme.ecran.client.interfaces.server.runtime.RuntimeServerInterfaceService;
import turbomeca.gamme.ecran.client.module.IController;

/**
 * Action to set the picture taken by terminal 
 * in the server directory
 */
public class ActionSetPictureInSchedule extends ActionSetInput {
	
	private static Logger logger = Logger.getLogger(ActionSetPictureInSchedule.class);

	public ActionSetPictureInSchedule(String taskActionId) {
		super(taskActionId, null);
	}

	@Override
	public boolean run(IController controller) throws ClientException, ClientInterruption {
	
		// Get terminal id from local computer
		ConfigurationLocalProperties localproperties = ConfigurationLocalProperties.getInstance(getContext().getLocalPropertiesDirectory());
		String terminalId = localproperties.getProperty(PropertyConstants.PROPERTY_LOCAL_VOICE_TERMINAL_ID);
		
		// Get the directory in server with terminal path
		
		StringBuilder buf = new StringBuilder();
		buf.append(getContext().getContextConfig().getDirectoryPictures());
		buf.append("/");
		buf.append(terminalId);
		
		String pathPictures = buf.toString();
		
		logger.info("Voice Répertoire images : "+ pathPictures);
			
		// Get The last picture from server
		String picture = RuntimeServerInterfaceService.getInstance().getLastPictureUploaded(pathPictures, getContext().getContextConfig().getInputCopyImagePath() + "/");

		if(picture != null) {
			getLoggerHmi().info("Image récupérée : "+ picture);
			setValue(picture);
			((InstructionController)controller).setValuePictureFromCheck(picture);
		} else {
			getLoggerHmi().info("Aucune image dans le répertoire : "+ pathPictures);
		}

		controller.getNotificationsService().notifyServiceChanged(getTaskActionService());
		return super.run(controller);
	}

	
}
