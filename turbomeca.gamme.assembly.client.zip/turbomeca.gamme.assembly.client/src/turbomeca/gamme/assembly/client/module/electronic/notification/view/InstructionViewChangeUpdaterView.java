package turbomeca.gamme.assembly.client.module.electronic.notification.view;

import org.apache.log4j.Logger;

import turbomeca.gamme.ecran.client.module.InterfaceView;

public class InstructionViewChangeUpdaterView extends InterfaceView {

	/** logger for current class */
	private static Logger logger = Logger.getLogger(NotificationUpdaterView.class);

	private static final String JS_INTERFACE_VIEW_CHANGED_TO = "instructionViewChangedTo";
	
	/**
	 * 
	 * 
	 * @param instructionViewName : the IInstructionView implementation class name
	 */
	public void instructionViewChangedTo(String instructionViewName)  {
		 logger.debug("instructionViewChangedTo : [ " + instructionViewName + " ]");
	        getJsInterface().callJs(JS_INTERFACE_VIEW_CHANGED_TO,
	        		  new Object[] {instructionViewName} );
	}
}
