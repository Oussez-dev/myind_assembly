package turbomeca.gamme.assembly.client.module.sap.services;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.model.edit.instructions.AModelTaskActionService;
import turbomeca.gamme.assembly.services.model.data.InputControlSap;
import turbomeca.gamme.ecran.server.ws.sap.client.model.ExtractUfi.SapExtractUFIResponseContext;
import turbomeca.gamme.ecran.server.ws.sap.client.model.ExtractUfi.SapUfiAffaireControle;

public class UpdateSapInputControlService extends AUpdateSapInputService {

	private static final Logger logger = Logger.getLogger(UpdateSapInputControlService.class);

	@Override
	public String getSapValue(AModelTaskActionService taskActionService, SapExtractUFIResponseContext sapContext, String instanceId) {

		InputControlSap inputControlSap = taskActionService.getTaskAction().getInputAction().getInputActionChoice().getInputControlSap();
		String value = null;
		String key = getKey(inputControlSap, sapContext);

		SapUfiAffaireControle dataControl = sapContext.getControles().get(key);
		if (dataControl == null) {
			logger.error("Failed to retreive control data with key " + key);
			value = "";
		} else {
			value = dataControl.getValue();
		}
		return value;
	}

	@Override
	public boolean isCompletion(AModelTaskActionService taskActionService) {
		return taskActionService.getTaskAction().getInputAction().getInputActionChoice().getInputControlSap().getCompletion();
	}

	private String getKey(InputControlSap inputControlSap, SapExtractUFIResponseContext context) {
		String pn = getScheduleService().getWrapperService().getInstantiation().getPn();
		String module = context.getZNOModule(pn, isAssemblyRepaired());
		return inputControlSap.getCodeReference() + "_" + module + "_" + inputControlSap.getType() + "_" + getLang();
	}

}
