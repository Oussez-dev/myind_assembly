package turbomeca.gamme.assembly.client.module.intervention.action;

import turbomeca.gamme.assembly.client.module.instruction.view.AddCommentView;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.edit.instructions.IModelSubPhaseService;
import turbomeca.gamme.ecran.client.model.edit.instructions.IModelTaskActionService;
import turbomeca.gamme.ecran.client.model.edit.wrappers.IModelWrapperSubPhaseService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.client.module.action.AActionModify;

public class ActionDisplayModalComment extends AActionModify {
	
	private String objectId;
	private int groupId;
	
    public ActionDisplayModalComment(String objectId, int groupId) {
        super();
        setObjectId(objectId);
        setGroupId(groupId);
    }

    @Override
    public boolean run(IController controller) throws ClientException, ClientInterruption {
    	IModelObjectService objectService = getService();
    	String comment = null;
    	if (!objectService.getRunnableService().canRun()) {
            throw new ClientException(ClientException.EXCEPTION_PREDECESSOR_SEQUENCE);
        }
    	if(objectService instanceof IModelSubPhaseService) {
    		IModelWrapperSubPhaseService wrap = (IModelWrapperSubPhaseService) objectService.getWrapperService();
    		comment = wrap.getComment();
    	}
    	return new AddCommentView(getObjectId(), getGroupId(), comment) .run(controller);
    }
    
    /**
	 * @return the taskActionService
	 * @throws ClientEvalException
	 */
	private IModelObjectService getService() throws ClientException {
		IModelObjectService objectService = getModelProvider().getModelService(getObjectId());
		if (objectService instanceof IModelSubPhaseService) {
			return (IModelSubPhaseService) objectService;
		}else if(objectService instanceof IModelTaskActionService) {
			return (IModelTaskActionService) objectService;
		}else {
			throw new ClientException();
		}
	}

	public String getObjectId() {
		return objectId;
	}

	public void setObjectId(String objectId) {
		this.objectId = objectId;
	}

	public int getGroupId() {
		return groupId;
	}

	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}
}
