package turbomeca.gamme.assembly.client.module.sap.action.comparator;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.model.edit.schedule.AAssemblyScheduleService;
import turbomeca.gamme.assembly.services.model.data.Identification;
import turbomeca.gamme.assembly.services.model.data.Instanciation;
import turbomeca.gamme.assembly.services.model.data.Level;
import turbomeca.gamme.assembly.services.model.data.Parameters;
import turbomeca.gamme.ecran.client.module.sap.SapAnalyse;
import turbomeca.gamme.ecran.server.ws.sap.client.model.ASapContext;
import turbomeca.gamme.ecran.server.ws.sap.client.model.ExtractUfi.SapExtractUFIResponseContext;

public class ActionSapComparatorLevel extends AActionScheduleComparator {

	private static Logger logger = Logger.getLogger(ActionSapComparatorLevel.class);

	public static final String MAP_KEY = "level.analyse.key";

	@Override
	protected List<SapAnalyse> compare(Instanciation instanciation, Identification identification,
			ASapContext<?> sapContext) {
		logger.info("[SAP] Analyse change level from SAP");
		
		SapExtractUFIResponseContext sContext = (SapExtractUFIResponseContext) sapContext;
		List<SapAnalyse> result = new ArrayList<SapAnalyse>();
		AAssemblyScheduleService scheduleService = (AAssemblyScheduleService) getModelProvider()
				.getModelScheduleService();

		Parameters parameters = scheduleService.getWrapperService().getParameters();
		Level[] levelParameters = parameters.getLevels().getLevel();
		
		List<String> currentLevels = Arrays.asList(instanciation.getLevel());
		List<String> sapLevels = sContext.getLevels(sContext.getZNOModule(instanciation.getPn(), isAssemblyRepaired()));

		Set<String> mergedLevels = new HashSet<String>(); 
		
		boolean newLevel = false;
		
		for (String sapLevel : sapLevels) {
			for (Level levelParameter : levelParameters) {
				if (levelParameter.getLevel().compareTo(sapLevel) == 0) {
					mergedLevels.add(sapLevel);
					if (!currentLevels.contains(sapLevel)) {
						newLevel = true;
					}
				}
			}
		}
		
		if (newLevel) {
			result.add(SapAnalyse.newValue(new ArrayList<String>(mergedLevels)));
			logger.info("[SAP] Analayse Sap Levels : " + Arrays.toString(sapLevels.toArray()));
		}

		return result;
	}

	@Override
	protected String getMapKey() {
		return MAP_KEY;
	}

}
