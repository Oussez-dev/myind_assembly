package turbomeca.gamme.assembly.client.module.instruction.view;

import java.util.List;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.model.edit.IModelAssemblyWrapperService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.client.module.externaltools.player.measure.ThreadPlayerAcquisitionManager;
import turbomeca.gamme.assembly.services.constants.AssemblyXsltConstants;
import turbomeca.gamme.assembly.services.model.data.types.StatusType;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.model.edit.instructions.IModelOperationService;
import turbomeca.gamme.ecran.client.model.edit.instructions.IModelSubPhaseService;
import turbomeca.gamme.ecran.client.model.edit.instructions.IModelTaskService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelScheduleService;
import turbomeca.gamme.ecran.client.module.ViewConverter;
import turbomeca.gamme.ecran.services.common.utils.misc.FormatUtils;
import turbomeca.gamme.ecran.services.constants.XsltConstants;
import turbomeca.gamme.ecran.services.runtime.bean.ContextEditing;

public class TasksView extends InstructionView {

	/** logger for current class */
	private static Logger logger = Logger.getLogger(TasksView.class);

	/** JS method to update tasks view summary status */
	private final static String JS_INTERFACE_UPDATE_TASKS_VIEW_SUMMARY_STATUS = "updateTasksViewSummaryStatus";
	
	/** JS method to update tasks view summary conformity status */
	private final static String JS_INTERFACE_UPDATE_TASKS_VIEW_SUMMARY_CONFORMITY_STATUS = "updateTasksViewSummaryConformityStatus";
	
	/** JS method to update tasks view summary conformity status */
	private final static String JS_INTERFACE_UPDATE_TASKS_VIEW_COLLAPSE_NON_SELECTED_ELEMENT = "collapseNonSelectedElement";
	
	/** The task to show in tasks view */
	private String taskId;
	

	public TasksView(String taskId) {
		super(AssemblyXsltConstants.XSLT_TASKS_VIEW.value());
		this.taskId = taskId;
	}
	
	@Override
	protected void addEditingContextParameters(ViewConverter view) {
		ContextEditing contextEditing = getContext().getContextEditing();
		if (contextEditing != null) {
			getView().addParameter(XsltConstants.XSLT_PARAMETER_OBJECT_EDITED.value(),
					FormatUtils.getStringValues(getContext().getContextEditing().getObjectEdited()));
			getView().addParameter(XsltConstants.XSLT_PARAMETER_OBJECT_LOCKED.value(),
					FormatUtils.getStringValues(getContext().getContextEditing().getObjectLocked()));
		}
	}
	
	@Override
	public void addInstructionViewCustomParameters(ViewConverter view, IModelObjectService modelService) {
		getView().addParameter(XsltConstants.XLST_PARAMETER_TASKS_VIEW_MODE.value(), "true");
		getView().addParameter(XsltConstants.XSLT_PARAMETER_TASKS_VIEW_MODE_CURRENT_TASK.value(), taskId);
		
		IModelObjectService taskService = getModelProvider().getModelService(taskId);
		
		if(taskService != null) {
			IModelObjectService parentSubPhaseService = taskService.getAncestor(IModelSubPhaseService.class);
			IModelObjectService parentOperationService = taskService.getAncestor(IModelOperationService.class);
			
			getView().addParameter(XsltConstants.XSLT_PARAMETER_TASKS_VIEW_MODE_CURRENT_SUBPHASE.value(), parentSubPhaseService.getIdentifier());
			getView().addParameter(XsltConstants.XSLT_PARAMETER_TASKS_VIEW_MODE_CURRENT_OPERATION.value(), parentOperationService.getIdentifier());
		}
		
		
		IModelScheduleService schedule = getModelProvider().getModelScheduleService();
		
        getView().addParameter(XsltConstants.XSLT_PARAMETER_INSTANCES.value(), 
        		((IModelAssemblyWrapperService) schedule.getWrapperService()).getInstantiation().getInstances());
        getView().addParameter(XsltConstants.XSLT_PARAMETER_GEODE_URL_DEFAULT.value(), getContext().getContextConfig().getExternalWebLinkEncloser());
        getView().addParameter(XsltConstants.XSLT_PARAMETER_SUBPHASE_ID.value(), "");
        getView().addParameter(XsltConstants.XSLT_PARAMETER_SCHEDULE_TYPE.value(), schedule.getName());     
    }
	
	@Override
    public void focusService(IModelObjectService modelService) throws ClientException {
		ThreadPlayerAcquisitionManager.getInstance().stopAll();
		displayTaskHoldingService(modelService);
        super.focusService(modelService);
    }
	
	
	
	@Override
	public void focusTaskActionService(IModelObjectService modelService) throws ClientException {
		displayTaskHoldingService(modelService);
		super.focusTaskActionService(modelService);
	}
	
	private void displayTaskHoldingService(IModelObjectService modelService) throws ClientException {
		if(modelService==null) {
			logger.error("Invalid focus resquest");
			return ;
		}
		String taskToFocus = getTaskIdentifier(modelService);
		if( taskToFocus!=null && !taskToFocus.equals(taskId)) {
				this.taskId = taskToFocus;
				run();
				getView().getJsInterface().callJs(JS_INTERFACE_UPDATE_TASKS_VIEW_COLLAPSE_NON_SELECTED_ELEMENT,
						new Object[] {});
		}
	}
	
	private String getTaskIdentifier(IModelObjectService modelService) {
		IModelTaskService task = (IModelTaskService) modelService.getAncestor(IModelTaskService.class);
		if(task!=null) {
			return task.getIdentifier();
		}
		return null;
	}
	
	
	@Override
    public void setStatus(IModelObjectService modelService, String status) {
        getView().setStatus(modelService.getIdentifier(), status, modelService.getWrapperService().getObjectTagName());
        
        // Refresh tasks view summary status
        getView().getJsInterface().callJs(JS_INTERFACE_UPDATE_TASKS_VIEW_SUMMARY_STATUS,
				new Object[] { String.valueOf(modelService.getIdentifier()), status});
        
        // Update parent sub-phase conformity status (or itself if it is a sub-phase)
        updateSubPhaseParentConformityStatus(modelService);
        
        // Update parent operation conformity status (or itself if it is a sub-phase)
        updateOperationParentConformityStatus(modelService);
    }

	/**
	 * Method to build parent sub-phase conformity status and update it in the
	 * view.
	 * 
	 * @param modelService
	 */
	private void updateSubPhaseParentConformityStatus(IModelObjectService modelService) {
		 IModelSubPhaseService subPhaseParentService = null;
	        
	        // Compute conformity status on parent sub-phase (or itself if already a sub-phase)
	        if(modelService instanceof IModelSubPhaseService) {
	        	subPhaseParentService = (IModelSubPhaseService) modelService;
	        } else {
	        	subPhaseParentService = (IModelSubPhaseService) modelService.getAncestor(IModelSubPhaseService.class);
	        }
	        
	        if(subPhaseParentService != null) {
	        	String conformityStatus = computeConformityStatus(subPhaseParentService);
	        	getView().getJsInterface().callJs(JS_INTERFACE_UPDATE_TASKS_VIEW_SUMMARY_CONFORMITY_STATUS,
						new Object[] { String.valueOf(subPhaseParentService.getIdentifier()), conformityStatus});
	        } 
	}
	
	/**
	 * Method to build parent operation conformity status and update it in the
	 * view.
	 * 
	 * @param modelService
	 */
	private void updateOperationParentConformityStatus(IModelObjectService modelService) {
		IModelOperationService operationParentService = null;
	        
	        // Compute conformity status on parent sub-phase (or itself if already a sub-phase)
	        if(modelService instanceof IModelOperationService) {
	        	operationParentService = (IModelOperationService) modelService;
	        } else {
	        	operationParentService = (IModelOperationService) modelService.getAncestor(IModelOperationService.class);
	        }
	        
	        String conformityStatus = computeConformityStatus(operationParentService);
	        
	        
	        getView().getJsInterface().callJs(JS_INTERFACE_UPDATE_TASKS_VIEW_SUMMARY_CONFORMITY_STATUS,
					new Object[] { String.valueOf(operationParentService.getIdentifier()), conformityStatus});
	        
	}
	
	/**
	 * Algorithm to compute conformity status of given object. Conformity status
	 * is computed by analyzing tasks children status (by ascending priority):
	 * 
	 * <ul>
	 * <li>If one of the child task is KO, conformity status is KO</li>
	 * <li>If one of the child task is TODO, conformity status is TODO</li>
	 * <li>If it reaches this rule, conformity status is DONE (all tasks are OK or NOT TODO)</li>
	 * </ul>
	 * 
	 * @param modelService
	 * @return
	 */
	private String computeConformityStatus(IModelObjectService modelService) {
        List<IModelObjectService> tasksChildren = modelService.getChildrenDeep(IModelTaskService.class);
        
        String conformityStatus = StatusType.DONE.value();
        
        for(IModelObjectService taskChild : tasksChildren) {
        	String taskStatus = StatusType.KO.value();
        	try {
				taskStatus = taskChild.getStatusService().getStatus();
			} catch (ClientException e) {
				logger.error("Unable to read task child status to compute conformity status!");
				return null;
			}
        	
        	// At least one sub-phase task is KO: conformity status is KO
        	// At least one task must be done: conformity status is TODO
        	if(taskStatus.equals(StatusType.KO.value()) || taskStatus.equals(StatusType.TODO.value())) {
        		conformityStatus = taskStatus;
        		break;
        	} 
        }
        
        return conformityStatus;
	}
	
	@Override
	public void refreshService(IModelObjectService modelService) throws ClientException {
		// Override it to refresh only current displayed task
		IModelObjectService currentTask = getModelProvider().getModelService(taskId);

		if(currentTask != null) {
			super.refreshService(currentTask);
			
			if(modelService instanceof ModelSubPhaseService) {
				updateSubPhaseStatus((ModelSubPhaseService) modelService);
			}
			
		} else {
			logger.debug("Could not find current task service to refresh it!");
		}
	}
}
