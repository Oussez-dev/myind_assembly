package turbomeca.gamme.assembly.client.module.setting.bench;

import turbomeca.gamme.assembly.client.model.edit.schedule.AAssemblyScheduleService;
import turbomeca.gamme.assembly.services.schedule.creation.utils.XpathConstantsUtils;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.IClientControllersProvider;
import turbomeca.gamme.ecran.client.constants.PropertyConstants;
import turbomeca.gamme.ecran.client.model.interfaces.IModelScheduleService;
import turbomeca.gamme.ecran.client.module.setting.bench.ASettingBenchController;

public class SettingBenchController extends ASettingBenchController {

	
	public SettingBenchController(IClientControllersProvider provider) {
		super(provider, XpathConstantsUtils.XPATH_SETTING_BENCH_STATUS_KO);
	}
	
	@Override
	public boolean init() throws ClientException, ClientInterruption {
		return true;
	}

	@Override
	public boolean destroy() throws ClientException {
		return true;
	}

	@Override
	protected String buildOutputFilePrefix(IModelScheduleService genericScheduleSvc, String separator) {
		AAssemblyScheduleService scheduleSvc = (AAssemblyScheduleService)genericScheduleSvc;
		// Check SN
		String sn = emptyIfNull(scheduleSvc.getSn());
		if (sn.isEmpty()) {
			getLoggerHmi().error(PropertyConstants.PROPERTY_ERROR_BENCH_OUTPUT_LOAD_MISSING_SN);
			return "";
		}
		// Build file name prefix
		return  emptyIfNull(scheduleSvc.getOrder()) + separator +
				emptyIfNull(scheduleSvc.getPn()) + separator +
				sn + separator ;
	}




}
