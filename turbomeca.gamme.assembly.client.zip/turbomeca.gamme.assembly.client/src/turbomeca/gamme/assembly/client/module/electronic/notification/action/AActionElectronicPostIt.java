package turbomeca.gamme.assembly.client.module.electronic.notification.action;

import turbomeca.gamme.assembly.client.model.edit.IModelAssemblyWrapperScheduleService;
import turbomeca.gamme.ecran.client.module.action.AActionModify;

public abstract class AActionElectronicPostIt extends AActionModify {

    protected IModelAssemblyWrapperScheduleService getScheduleWrapper() {
        return (IModelAssemblyWrapperScheduleService) getModelProvider().getModelScheduleService().getWrapperService();
    }
}
