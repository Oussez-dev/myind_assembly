package turbomeca.gamme.assembly.client.module.edition.view;

import turbomeca.gamme.ecran.client.constants.PropertyConstants;
import turbomeca.gamme.ecran.client.interfaces.server.editing.EditingServerInterfaceService;
import turbomeca.gamme.ecran.client.module.action.AActionView;
import turbomeca.gamme.ecran.services.constants.XsltConstants;

public abstract class AEditionView extends AActionView {

	private String listSubhaseIdQualified;
	
    @Override
    public boolean needWritableRight() {
        return true;
    }
    
	/**
	 * 
	 * @param xsltFile
	 * @param title
	 */
	protected AEditionView(String xsltFile) {
		super(xsltFile);
	}

	public AEditionView(String xsltEditionSubphases, String listSubphaseIdQualified) {
		super(xsltEditionSubphases);
		setListSubhaseIdQualified(listSubphaseIdQualified);
	}

	@Override
	public boolean run() {
		boolean displayed = false;
		if (EditingServerInterfaceService.getInstance().loadEditing()) {
			displayed = display(true);
		}
		return displayed;
	}

	/**
	 * 
	 */
	public abstract void addSpecifiParameters();
	
	/**
	 * Display modal for selecting operation to edit
	 * 
	 * @param selectAll
	 *            must select by default all operations
	 * @param string 
	 * @return true if succeed, false otherwise
	 */
	public boolean display(boolean selectAll) {
		getView().reset();
		getView().bindService(getModelProvider().getModelScheduleService());
		getView().addEditingContextParameters();
		getView().addParameter(XsltConstants.XSLT_PARAMETER_OUT_OF_DATE.value(),
				getContext().getContextEditing().isOutOfDate());
		getView().addParameter(XsltConstants.XSLT_PARAMETER_SELECT_ALL.value(), selectAll);
		getView().addParameter(XsltConstants.XSLT_PARAMETER_LIST_SUBPHASE_ID.value(), getListSubhaseIdQualified());
		addSpecifiParameters();
		return getView().displayModal(PropertyConstants.PROPERTY_MODAL_TITLE_EDTION, true);
	}

	public String getListSubhaseIdQualified() {
		return listSubhaseIdQualified;
	}

	public void setListSubhaseIdQualified(String listSubhaseIdQualified) {
		this.listSubhaseIdQualified = listSubhaseIdQualified;
	}
}
