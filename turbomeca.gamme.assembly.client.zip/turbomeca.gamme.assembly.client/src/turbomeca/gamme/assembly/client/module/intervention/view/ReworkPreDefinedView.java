package turbomeca.gamme.assembly.client.module.intervention.view;

import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.constants.PropertyConstants;
import turbomeca.gamme.ecran.client.module.action.AActionView;
import turbomeca.gamme.ecran.services.constants.XsltConstants;

public class ReworkPreDefinedView extends AActionView {
	
	public ReworkPreDefinedView() {
		super(XsltConstants.XSLT_INTERVENTION_TUNING_PREDEFINED.value());
	}
	
	@Override
	public boolean run() throws ClientException {
		getView().bindService(getModelProvider().getModelScheduleService());
		return getView().displayModal(PropertyConstants.PROPERTY_MODAL_TITLE_TUNING_PREDEFINED, true);
	}
}
