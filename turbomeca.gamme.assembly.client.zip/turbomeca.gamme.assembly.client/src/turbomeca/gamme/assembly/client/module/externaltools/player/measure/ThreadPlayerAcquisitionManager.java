package turbomeca.gamme.assembly.client.module.externaltools.player.measure;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.locks.ReentrantLock;

/**
 * This class is responsible for the persistence of the players, storing ThreadPlayerAcquisition objects in a unique instance.
 * The removal and stopping of the players is also realized by this class. Concurrency access is managed by a ReentrantLock, 
 * which locks a thread A before accessing a part of code processed by another thread B. Thread A will access this code once freed 
 * by thread B. This implementation avoids using a synchronize.
 * 
 */
public class ThreadPlayerAcquisitionManager {

	private static final ThreadPlayerAcquisitionManager INSTANCE = new ThreadPlayerAcquisitionManager();
	private final Set<ThreadPlayerAcquisition> threadPlayers = new HashSet<ThreadPlayerAcquisition>();
	private final ReentrantLock lock = new ReentrantLock();
	
    public static ThreadPlayerAcquisitionManager getInstance() {
        return INSTANCE;
    }
    
    public void registerPlayer(ThreadPlayerAcquisition threadPlayer) {
    	lock.lock();
    	try {
    		threadPlayers.add(threadPlayer);
    	}
    	finally {
    		lock.unlock();
    	}
    }
    
    public void unRegisterPlayer(ThreadPlayerAcquisition threadPlayer) {
    	lock.lock();
    	try {
    		threadPlayers.remove(threadPlayer);
    	}
    	finally { 
    		lock.unlock();
    	}
    }
    
    public void stopAll() {
    	lock.lock();
    	try {
    		for (ThreadPlayerAcquisition threadPlayer : new ArrayList<ThreadPlayerAcquisition>(threadPlayers)) {
    			threadPlayer.stopThread();
    		}
    	}
    	finally {
    		lock.unlock();
    	}
    }
}
