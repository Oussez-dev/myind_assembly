package turbomeca.gamme.assembly.client.module.electronic.notification.action;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskActionService;
import turbomeca.gamme.assembly.client.model.edit.utils.ModelUtils;
import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperTaskActionService;
import turbomeca.gamme.assembly.services.model.data.InputValue;
import turbomeca.gamme.ecran.client.model.edit.instructions.IModelTaskActionService;
import turbomeca.gamme.ecran.client.module.electronic.notification.action.AActionCheckElectronicValidation;


public class ActionCheckElectronicValidation  extends AActionCheckElectronicValidation {

	@Override
	protected boolean setDoubleValidation(IModelTaskActionService modelTaskActionService, String validatorUserLogin,
			String userName) {

		InputValue inputValue = ((ModelWrapperTaskActionService) modelTaskActionService.getWrapperService()).getTaskAction()
				.getInputAction().getInputValue();
		
		boolean updateTaskAction = inputValue != null && inputValue.getUserMarkValidation() == null;
		if (updateTaskAction) {
			((ModelTaskActionService) modelTaskActionService)
					.setDoubleValidation(ModelUtils.buildUserMarkValidation(validatorUserLogin, userName));
		}
		return updateTaskAction;
	}
}
