package turbomeca.gamme.assembly.client.module.externaltools.player.piloting;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import turbomeca.gamme.ecran.services.devices.ExternalsToolsExceptions;

public class ModelWrapperResponsePlayerAcquisitionTaskPiloting {

	private Logger logger = Logger.getLogger(ModelWrapperResponsePlayerAcquisitionTaskPiloting.class);
	private String status;
	private List<ModelTaskPilotingValue> values;
	
	public static final String OK = "OK";
	public static final String NOT_YET_CONNECTED = "NOT_YET_CONNECTED";
	public static final String KO = "KO";

	public ModelWrapperResponsePlayerAcquisitionTaskPiloting(String xmlValue)
			throws ExternalsToolsExceptions {
		values = new ArrayList<ModelTaskPilotingValue>();
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		try {
			DocumentBuilder db = dbf.newDocumentBuilder();
			ByteArrayInputStream bis = new ByteArrayInputStream(xmlValue.getBytes());
			Document doc = db.parse(bis);
			Node taskActionPiloting = doc.getFirstChild();
			NodeList nodes = taskActionPiloting.getChildNodes();
			for (int i = 0; i < nodes.getLength(); i++) {
				Node n = nodes.item(i);
				if (n != null) {
					String name = n.getNodeName();
					if ("status".equals(name)) {
						this.status = n.getNodeValue();
					} else if ("pilotingResults".equals(name)) {
						unmarshalResult(n);
					}
				}
			}
		} catch (SAXException e) {
			logger.error("[PILOTING] : Unable to transform the response from the piloting tool");
			throw new ExternalsToolsExceptions(ExternalsToolsExceptions.ERROR_PILOTING_TOOLS_INTERNAL_ERROR, "Unable to transform the response from the piloting tool", e);
		} catch (IOException e) {
			logger.error("[PILOTING] : Unable to transform the response from the piloting tool");
			throw new ExternalsToolsExceptions(ExternalsToolsExceptions.ERROR_PILOTING_TOOLS_INTERNAL_ERROR, "Unable to transform the response from the piloting tool", e);
		} catch (ParserConfigurationException e) {
			logger.error("[PILOTING] : Unable to transform the response from the piloting tool");
			throw new ExternalsToolsExceptions(ExternalsToolsExceptions.ERROR_PILOTING_TOOLS_INTERNAL_ERROR, "Unable to transform the response from the piloting tool", e);
		}		
	}

	private void unmarshalResult(Node n) throws ExternalsToolsExceptions {
		NodeList pilotingResults = n.getChildNodes();
		for (int y = 0; y < pilotingResults.getLength(); y++) {
			Node pilotingResult = pilotingResults.item(y);
			try {
				JAXBContext jaxbContext = JAXBContext.newInstance(ModelTaskPilotingValue.class);
				Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
				ModelTaskPilotingValue taskPilotingValue = (ModelTaskPilotingValue) jaxbUnmarshaller.unmarshal(pilotingResult);
				values.add(taskPilotingValue);
			} catch (JAXBException e) {
				logger.error("[PILOTING] : Unable to transform the response from the piloting tool");
				throw new ExternalsToolsExceptions(ExternalsToolsExceptions.ERROR_PILOTING_TOOLS_INTERNAL_ERROR, "Unable to transform the response from the piloting tool", e);
			}
		}
	}

	public Object getStatus() {
		return status;
	}

}
