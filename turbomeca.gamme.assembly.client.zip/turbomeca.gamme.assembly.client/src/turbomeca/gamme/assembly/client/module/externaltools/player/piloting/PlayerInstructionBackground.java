package turbomeca.gamme.assembly.client.module.externaltools.player.piloting;

import org.apache.log4j.Logger;

import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.client.module.externaltools.player.IPlayerInstruction;

public class PlayerInstructionBackground implements Runnable{
	private volatile IPlayerInstruction playerInstruction;
	private volatile IController controller;
	private volatile IInstructionPlayerListener listener;
	
	private Logger logger = Logger.getLogger(PlayerInstructionBackground.class);
	

	public PlayerInstructionBackground(IPlayerInstruction foregroundPlayer, IController iControler, IInstructionPlayerListener listener) {
		playerInstruction = foregroundPlayer;
		controller = iControler;
		this.listener = listener;
	}

	@Override
	public void run() {	
		try {
			logger.debug("PlayerInstructionBackground - run");
			playerInstruction.run(controller);
			
			if(playerInstruction instanceof PlayerTaskPiloting) {		
				listener.notifyResponse(((PlayerTaskPiloting) playerInstruction).getAcquisitionResult());	
			}else  {
				listener.notifyResponse(null);
			}
		} catch (ClientException e) {
			logger.error("PlayerInstructionBackground - run", e);
			listener.notifyError(e.getPropertyKey());
		} catch (ClientInterruption e) {
			logger.error("PlayerInstructionBackground - run", e);
			listener.notifyError(e.getPropertyKey());
		} 
	}
	
}