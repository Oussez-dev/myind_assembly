package turbomeca.gamme.assembly.client.module.intervention.action;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import turbomeca.gamme.assembly.client.ClientAssemblyException;
import turbomeca.gamme.assembly.client.config.AssemblyPropertyConstants;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelMarkService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskActionService;
import turbomeca.gamme.assembly.client.model.edit.notifications.AModelNotificationService;
import turbomeca.gamme.assembly.client.model.edit.notifications.ModelNotificationMarkService;
import turbomeca.gamme.assembly.client.model.edit.utils.ModelUtils;
import turbomeca.gamme.assembly.client.module.electronic.notification.action.AActionCreateElectronicNotification;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.edit.instructions.IModelSubPhaseService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.services.common.constants.GlobalConstants;

public class ActionChangeMark extends AActionCreateElectronicNotification {

	private String markServiceId;
	private String PN;
	private boolean newPn;
	private String instanceId;
	private String alternativeId;
	private String subPhaseId;
	private String optionnalComment;
	private boolean editable;
    
	/**
	 * 
	 * @param newDerog
	 * @param newSn
	 * @param newPn
	 * @param selectedSubPhasesForTuning
	 * @param instancesId
	 */
	public ActionChangeMark(String serviceId, String instanceId, String alternativeId, boolean newPn, String PN,
			@Deprecated  boolean newSn, @Deprecated String SN, boolean newDerog, String derogation, String subPhaseId, String optionnalComment, boolean editable) {
		setMarkServiceId(serviceId);
		setInstanceId(instanceId);
		setAlternativeId(alternativeId);
		setPN(PN);
		setNewPn(newPn);
		setSubPhaseId(subPhaseId);
		setOptionnalComment(optionnalComment);
		this.editable = editable;
		
	}
	public ActionChangeMark(String serviceId, String instanceId, String alternativeId, boolean newPn, String PN,
			@Deprecated  boolean newSn, @Deprecated String SN, boolean newDerog, String derogation, String subPhaseId, String optionnalComment) {
		this(serviceId, instanceId, alternativeId, newPn, PN, newSn, SN, newDerog, derogation, subPhaseId, optionnalComment, false);
	}

	@Override
	public boolean run(IController controller) throws ClientException, ClientInterruption {
		boolean succeed = false;

		List<IModelObjectService> listServiceToUpdate = new ArrayList<IModelObjectService>();
		controller.getNotificationsService().setDisableNotifications(true);
		try {
			ModelMarkService markService = (ModelMarkService) getModelProvider().getModelService(getMarkServiceId());

			ModelTaskActionService taskActionPn = markService.getTaskActionPn(getInstanceId(), getAlternativeId());
			List<ModelTaskActionService> taskActionsSn = markService.getTaskActionsType(ModelMarkService.TASK_ACTION_SN_TYPE, getInstanceId(), getAlternativeId());
			List<ModelTaskActionService> taskActionsDerog = markService.getTaskActionsType(ModelMarkService.TASK_ACTION_DEROG_TYPE, getInstanceId(), getAlternativeId());

			if (getPN() == null && taskActionPn != null) {
				throw new ClientAssemblyException(ClientAssemblyException.EXCEPTION_CHANGE_MARK_VALUE_EMPTY);
			} else if (getPN().equals(taskActionPn.getTextValue())) {
				throw new ClientAssemblyException(ClientAssemblyException.EXCEPTION_CHANGE_MARK_VALUE_IDENTICAL);
			}

			// Get text values
			String pnValue = getTextValue(taskActionPn, getPN(), isNewPn());
			
			String notificationId = UUID.randomUUID().toString();
			ModelNotificationMarkService notificationService =  new ModelNotificationMarkService(markService, notificationId, 
			getInstanceId(), getAlternativeId(), pnValue, getOptionnalComment());
			
			ModelSubPhaseService modelServiceSubPhase = (ModelSubPhaseService) getModelProvider().getModelService(getSubPhaseId());
			
			boolean createOnServer = createNotification(notificationService, modelServiceSubPhase);
			String mustSynchronize = null;
	        if(!createOnServer){
	        	mustSynchronize = GlobalConstants.NOTIFICATION_STATUS_CREATED;
	        }
//			notificationService.bindService(modelServiceSubPhase, mustSynchronize);
	        
			for (ModelMarkService markReferenceService : markService.getMarkReferences()) {
				if (markReferenceService.impactedByInstance(getInstanceId())) {

					IModelSubPhaseService subPhaseService = ModelUtils.getSubPhaseParent(markReferenceService);
					if (subPhaseService.getRunnableService().isRunnable() && !subPhaseService.getWrapperService().isArchived()) {
						AModelNotificationService notificationServiceLinked = 
								new ModelNotificationMarkService(markReferenceService, notificationId, 
										getInstanceId(), getAlternativeId(), pnValue, getOptionnalComment());

						subPhaseService.getStatusService().setAlterable(null);
						listServiceToUpdate.add(subPhaseService);

						notificationServiceLinked.bindService(markReferenceService, mustSynchronize);
					}
				}

				// Update delete notifications on server 
				synchronizeOnServer(false);

				// Update PN, SN and derogation
				forceEditable(taskActionPn, isNewPn());
				updateIfNeeded(controller, markService, taskActionPn, getPN(), isNewPn());
				for (ModelTaskActionService taskActionSn : taskActionsSn) {
					updateIfNeeded(controller, markService, taskActionSn, null, false);
				}
				for (ModelTaskActionService taskActionDerog : taskActionsDerog) {
					updateIfNeeded(controller, markService, taskActionDerog, null, false);
				}

				getLoggerHmi().info(AssemblyPropertyConstants.PROPERTY_MARK_CHANGED);
				succeed = true;
			}
		} finally {
			controller.getNotificationsService().setDisableNotifications(false);
			if (succeed) {
				for (IModelObjectService modelService : listServiceToUpdate) {
					controller.getNotificationsService().notifyServiceChanged(modelService);
				}
			}
		}
		return succeed;
	}

	/**
	 * 
	 * @param taskAction
	 * @param value
	 * @param isNewValue
	 * @return
	 */
	private String getTextValue(ModelTaskActionService taskAction, String value, boolean isNewValue) {
		String textValue = null;
		if (isNewValue) {
			textValue = value;
		} else if (taskAction != null) {
			textValue = ModelUtils.getTextValue(value, taskAction.getTaskAction().getInputAction());
		}
		return textValue;
	}

	/**
	 * forceEditable only For TaskAction PN
	 * @param taskActionService
	 * @param isNewValue
	 * @throws ClientException
	 */
	private void forceEditable(ModelTaskActionService taskActionService, boolean isNewValue) throws ClientException {
		if (taskActionService != null) {
			if (isNewValue && taskActionService.isInputChoice()) {
				taskActionService.setForceEditable(editable, false);
			} else {
				taskActionService.setForceEditable(editable, true);
			}
		}
	}

	/**
	 * 
	 * @param taskActionService
	 * @param value
	 * @throws ClientException
	 * @throws ClientInterruption 
	 */
	private void updateIfNeeded(IController controller, ModelMarkService markService,
			ModelTaskActionService taskActionService, 
			String value, boolean isNewValue)
					throws ClientException, ClientInterruption {
		if (taskActionService != null) {
			if (isNewValue && taskActionService.isInputChoice()) {
				taskActionService.addChoiceValue(value, true);
				markService.applyValueToReference(controller, taskActionService, value);
			} else {
				taskActionService.setValue(value, true);
				markService.applyValueToReference(controller, taskActionService);
			}
		}
	}

	/**
	 * @return the markServiceId
	 */
	public String getMarkServiceId() {
		return markServiceId;
	}

	/**
	 * @param markServiceId
	 *            the markServiceId to set
	 */
	public void setMarkServiceId(String markServiceId) {
		this.markServiceId = markServiceId;
	}

	/**
	 * @return the pN
	 */
	public String getPN() {
		return PN;
	}
	
	public String getOptionnalComment() {
		return optionnalComment;
	}
	
	public void setOptionnalComment(String optionnalComment) {
		this.optionnalComment = optionnalComment;
	}
	/**
	 * @return the newPn
	 */
	public boolean isNewPn() {
		return newPn;
	}

	/**
	 * @param newPn
	 *            the newPn to set
	 */
	public void setNewPn(boolean newPn) {
		this.newPn = newPn;
	}

	//    /**
	//     * @return the newSn
	//     */
	//    public boolean isNewSn() {
	//        return newSn;
	//    }
	//
	//    /**
	//     * @param newSn
	//     *            the newSn to set
	//     */
	//    public void setNewSn(boolean newSn) {
	//        this.newSn = newSn;
	//    }
	//
	//    /**
	//     * @return the newDerog
	//     */
	//    public boolean isNewDerog() {
	//        return newDerog;
	//    }
	//
	//    /**
	//     * @param newDerog
	//     *            the newDerog to set
	//     */
	//    public void setNewDerog(boolean newDerog) {
	//        this.newDerog = newDerog;
	//    }

	/**
	 * @param pN
	 *            the pN to set
	 */
	public void setPN(String pN) {
		PN = pN;
	}

	//    /**
	//     * @return the sN
	//     */
	//    public String getSN() {
	//        return SN;
	//    }
	//
	//    /**
	//     * @param sN
	//     *            the sN to set
	//     */
	//    public void setSN(String sN) {
	//        SN = sN;
	//    }

	//    /**
	//     * @return the derogation
	//     */
	//    public String getDerogation() {
	//        return derogation;
	//    }
	//
	//    /**
	//     * @param derogation
	//     *            the derogation to set
	//     */
	//    public void setDerogation(String derogation) {
	//        this.derogation = derogation;
	//    }

	/**
	 * @return the instanceId
	 */
	public String getInstanceId() {
		return instanceId;
	}

	/**
	 * @param instanceId
	 *            the instanceId to set
	 */
	public void setInstanceId(String instanceId) {
		if (instanceId != null && instanceId.isEmpty()) {
			this.instanceId = null;
		} else {
			this.instanceId = instanceId;
		}
	}

	/**
	 * @return the alternativeId
	 */
	public String getAlternativeId() {
		return alternativeId;
	}

	/**
	 * @param alternativeId the alternativeId to set
	 */
	public void setAlternativeId(String alternativeId) {
		if (alternativeId != null && alternativeId.isEmpty()) {
			this.alternativeId = null;
		} else {
			this.alternativeId = alternativeId;
		}
	}

	public String getSubPhaseId() {
		return subPhaseId;
	}

	public void setSubPhaseId(String subPhaseId) {
		this.subPhaseId = subPhaseId;
	}
	public boolean isEditable() {
		return editable;
	}
	public void setEditable(boolean editable) {
		this.editable = editable;
	}
}