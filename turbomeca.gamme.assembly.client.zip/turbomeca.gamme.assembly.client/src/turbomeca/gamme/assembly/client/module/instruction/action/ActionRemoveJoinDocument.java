package turbomeca.gamme.assembly.client.module.instruction.action;

import java.util.Vector;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.services.model.data.DocumentJoined;
import turbomeca.gamme.assembly.services.model.data.DocumentsJoined;
import turbomeca.gamme.assembly.services.model.data.SubPhase;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.client.module.action.AActionModify;
import turbomeca.gamme.ecran.client.module.io.action.ActionDeleteDocument;

public class ActionRemoveJoinDocument extends AActionModify {

    /** SubPhase identifier */
    private String subPhaseId;
    
    /** Document identifier*/
    private String documentId;
    
	public ActionRemoveJoinDocument(String subPhaseId, String documentId) {
	    setSubPhaseId(subPhaseId);
	    setDocumentId(documentId);
	}

	@Override
	public boolean run(IController controller) throws ClientException, ClientInterruption {
	    boolean deleted = false;
        ModelSubPhaseService subPhaseService = (ModelSubPhaseService) getModelProvider().getModelService(getSubPhaseId());
        if (!subPhaseService.getRunnableService().isFinished()) {
            SubPhase subPhase = subPhaseService.getWrapperService().getSubPhase();
            
            if (new ActionDeleteDocument(documentId).run(controller)) {
                DocumentsJoined documents = subPhase.getDocumentsJoined();
                Vector<DocumentJoined> subPhaseDocuments = new Vector<DocumentJoined>();
                for(DocumentJoined document : documents.getDocumentJoined()) {
                    if (!document.getId().equals(getDocumentId())) {
                        subPhaseDocuments.add(document);
                    }
                }
                subPhase.getDocumentsJoined().setDocumentJoined(subPhaseDocuments);
                controller.getNotificationsService().notifyServiceChanged(subPhaseService);
                deleted = true;
            } else {
                getLoggerHmi().error("Failed to delete document on server");
            }
        }
		return deleted;
	}

    /**
     * @return the subPhaseId
     */
    public String getSubPhaseId() {
        return subPhaseId;
    }

    /**
     * @param subPhaseId the subPhaseId to set
     */
    public void setSubPhaseId(String subPhaseId) {
        this.subPhaseId = subPhaseId;
    }

    /**
     * @return the documentId
     */
    public String getDocumentId() {
        return documentId;
    }

    /**
     * @param documentId the documentId to set
     */
    public void setDocumentId(String documentId) {
        this.documentId = documentId;
    }
}
