package turbomeca.gamme.assembly.client.module.intervention.view;

import turbomeca.gamme.assembly.client.config.AssemblyPropertyConstants;
import turbomeca.gamme.assembly.services.constants.AssemblyXsltConstants;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.module.action.AActionView;

public class SelectionInstructionLevelView extends AActionView {
	
	public SelectionInstructionLevelView() {
		super(AssemblyXsltConstants.XSLT_INTERVENTION_MANUAL_LEVEL_INSTRUCTION.value());
	}
	
	@Override
	public boolean run() throws ClientException {
		addSpecificParameters();
		getView().bindService(getModelProvider().getModelScheduleService());
		return getView().displayModal(AssemblyPropertyConstants.PROPERTY_MODAL_TITLE_SELECT_MANUAL_INSTRUCTION_LEVEL, true);
	}
	
	/**
	 * Add specific parameter for Add Indication
	 */
	private void addSpecificParameters() {
	}
	
}
