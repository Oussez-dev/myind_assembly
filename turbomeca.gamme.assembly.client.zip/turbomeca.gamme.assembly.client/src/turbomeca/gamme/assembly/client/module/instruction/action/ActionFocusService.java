package turbomeca.gamme.assembly.client.module.instruction.action;

import turbomeca.gamme.assembly.client.ClientAssemblyException;
import turbomeca.gamme.assembly.client.module.instruction.InstructionController;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.client.module.action.AAction;

public class ActionFocusService extends AAction {

	private String serviceId;
	
	public ActionFocusService(String serviceId) {
		setServiceId(serviceId);
	}

	@Override
	public boolean run(IController controller) throws ClientException, ClientInterruption {
		InstructionController instructionController = (InstructionController) controller;
		IModelObjectService modelService = getModelProvider().getModelService(getServiceId());
		if (modelService == null) {
			throw new ClientAssemblyException(ClientAssemblyException.EXCEPTION_SERVICE_NOT_FOUND);
		}
		instructionController.getView().focusService(modelService);
		return false;
	}

	/**
	 * @param serviceId the serviceId to set
	 */
	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}

	/**
	 * @return the serviceId
	 */
	public String getServiceId() {
		return serviceId;
	}

}
