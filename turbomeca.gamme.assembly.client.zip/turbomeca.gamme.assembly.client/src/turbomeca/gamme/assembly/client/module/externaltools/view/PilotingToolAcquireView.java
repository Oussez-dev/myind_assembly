package turbomeca.gamme.assembly.client.module.externaltools.view;

import turbomeca.gamme.assembly.services.constants.AssemblyXsltConstants;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.constants.PropertyConstants;
import turbomeca.gamme.ecran.client.module.action.AActionView;

public class PilotingToolAcquireView extends AActionView {

	private String toolId;

	public PilotingToolAcquireView(String xsltFile, String toolId) {
		super(xsltFile);
		this.toolId = toolId;
	}

	@Override
	public boolean run() throws ClientException {
		getView().bindService(getModelProvider().getModelScheduleService());
		getView().addParameter(AssemblyXsltConstants.XSLT_PARAMETER_TOOL_ID.value(), toolId);
		return getView().displayModal(PropertyConstants.PROPERTY_MODAL_TITLE_PILOTING_TOOL_ACQUIRE, true);
	}

}
