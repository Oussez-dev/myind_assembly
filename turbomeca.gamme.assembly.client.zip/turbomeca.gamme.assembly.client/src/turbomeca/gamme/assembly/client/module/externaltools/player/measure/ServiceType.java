package turbomeca.gamme.assembly.client.module.externaltools.player.measure;

import turbomeca.gamme.ecran.services.model.constants.ModelGlobalConstants;

/**
 * This Enum gathers the different type of players
 *
 */
public enum ServiceType {
	  RDD(ModelGlobalConstants.TAG_MEASURE_RDD),
	  TOOL(ModelGlobalConstants.TAG_MEASURE_TOOL),
	  SAP(ModelGlobalConstants.TAG_MEASURE_SAP),
	  TASK_PILOTING(ModelGlobalConstants.TAG_TASK_PILOTING),
	  TOOL_CONNECTED(ModelGlobalConstants.TAG_TOOL_CONNECTED);

	  private String value = "";
	  
	  ServiceType(String value){
	    this.value = value;
	  }
	   
	  public String value(){
	    return value;
	  }
}
