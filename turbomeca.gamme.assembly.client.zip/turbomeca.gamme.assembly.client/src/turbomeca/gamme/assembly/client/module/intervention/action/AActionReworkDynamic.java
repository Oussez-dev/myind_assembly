package turbomeca.gamme.assembly.client.module.intervention.action;

import turbomeca.gamme.assembly.client.module.intervention.InterventionReworkDynamicManager;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.client.module.action.AAction;

public class AActionReworkDynamic extends AAction {

    private InterventionReworkDynamicManager reworkManager;
    
    /**
     * 
     * @param newDerog 
     * @param newSn 
     * @param newPn 
     * @param services
     * @param instancesId
     */
    public AActionReworkDynamic(InterventionReworkDynamicManager reworkManager) {
        setReworkManager(reworkManager);
    }

    @Override
    public boolean run(IController controller) throws ClientException {
        return true;
    }

    /**
     * @return the reworkManager
     */
    public InterventionReworkDynamicManager getReworkManager() {
        return reworkManager;
    }

    /**
     * @param reworkManager the reworkManager to set
     */
    public void setReworkManager(InterventionReworkDynamicManager reworkManager) {
        this.reworkManager = reworkManager;
    }
}