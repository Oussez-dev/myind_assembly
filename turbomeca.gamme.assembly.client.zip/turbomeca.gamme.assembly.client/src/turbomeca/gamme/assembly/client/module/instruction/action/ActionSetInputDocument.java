package turbomeca.gamme.assembly.client.module.instruction.action;

import java.util.Arrays;
import java.util.List;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskActionService;
import turbomeca.gamme.assembly.services.model.data.InputDocument;
import turbomeca.gamme.assembly.services.model.data.InputPicture;
import turbomeca.gamme.assembly.services.model.data.types.InputDocumentType;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.constants.PropertyConstants;
import turbomeca.gamme.ecran.client.module.IController;

public class ActionSetInputDocument extends turbomeca.gamme.ecran.client.module.instruction.action.ActionSetInputDocument {

	private List<String> FILE_EXTENSIONS_PICTURE = Arrays.asList("png", "jpg", "svg", "JPG", "jpeg");
	private List<String> FILE_EXTENSIONS_PDF = Arrays.asList("pdf");

	public ActionSetInputDocument(String taskActionId, String value) {
		super(taskActionId, value);
	}

	@Override
	public boolean run(IController controller) throws ClientException, ClientInterruption {
		boolean succeed = false;
		if (checkDocumentType()) {
			succeed = super.run(controller);
		}
		return succeed;
	}

	private boolean checkDocumentType() throws ClientException {
		boolean valid = true;
		if (getValue() != null) {
			String fileExtension = getValue().substring((getValue().lastIndexOf('.') + 1), getValue().length());
			ModelTaskActionService modelTaskActionService = (ModelTaskActionService) getTaskActionService();
			InputDocument inputDocument = (InputDocument) modelTaskActionService.getWrapperService().getTaskAction().getInputAction().getInputActionChoice().getInputDocument();
			List<String> allowedExtensions = null;
			if(inputDocument != null){
				allowedExtensions = getAllowedExtensions(inputDocument.getType());
			}
			else{
				InputPicture inputPicture = (InputPicture) modelTaskActionService.getWrapperService().getTaskAction().getInputAction().getInputActionChoice().getInputPicture();
				if(inputPicture != null){
					allowedExtensions = getAllowedExtensions(InputDocumentType.PICTURE);
				}
			}
			if (allowedExtensions != null && !allowedExtensions.contains(fileExtension)) {
				String errorMessage = getConfiguration().getProperty(PropertyConstants.PROPERTY_ERROR_INPUT_DOCUMENT_EXTENSION);
				getLoggerHmi().errorMsg(String.format(errorMessage, allowedExtensions));
				valid = false;
			}
		}
		return valid;
	}

	private List<String> getAllowedExtensions(InputDocumentType inputDocumentType) {
		switch (inputDocumentType) {
		case PICTURE:
			return FILE_EXTENSIONS_PICTURE;
		case PDF:
			return FILE_EXTENSIONS_PDF;
		default:
			return null;
		}
	}
}
