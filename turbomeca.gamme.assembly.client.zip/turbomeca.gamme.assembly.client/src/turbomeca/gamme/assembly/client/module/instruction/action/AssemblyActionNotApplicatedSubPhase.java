package turbomeca.gamme.assembly.client.module.instruction.action;


import turbomeca.gamme.assembly.client.module.intervention.action.ActionDisplayModalComment;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.client.module.instruction.action.ActionNotApplicatedSubPhase;

public class AssemblyActionNotApplicatedSubPhase extends ActionNotApplicatedSubPhase {

	public AssemblyActionNotApplicatedSubPhase(String subPhaseId) {
		super(subPhaseId);
	}

	@Override
	public boolean run(IController controller) throws ClientException, ClientInterruption {
		return new ActionDisplayModalComment(getSubPhaseId(), 0).run(controller);
	}		
}
