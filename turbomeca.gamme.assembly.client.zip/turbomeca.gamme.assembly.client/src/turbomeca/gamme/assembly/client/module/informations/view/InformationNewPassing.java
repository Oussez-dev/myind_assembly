package turbomeca.gamme.assembly.client.module.informations.view;

import turbomeca.gamme.assembly.client.model.edit.IModelAssemblyWrapperScheduleService;
import turbomeca.gamme.assembly.services.constants.AssemblyXsltConstants;
import turbomeca.gamme.assembly.services.model.data.HistoricalPassing;
import turbomeca.gamme.assembly.services.model.data.Passing;
import turbomeca.gamme.assembly.services.model.data.UserMark;
import turbomeca.gamme.ecran.client.constants.PropertyConstants;
import turbomeca.gamme.ecran.client.model.interfaces.IModelScheduleService;
import turbomeca.gamme.ecran.client.module.action.AActionView;
import turbomeca.gamme.ecran.services.common.utils.date.DateUtils;

public class InformationNewPassing extends AActionView{

	public InformationNewPassing() {
		super(AssemblyXsltConstants.XSLT_INFORMATION_NEW_PASSING.value());
	}

	@Override
	public boolean run() {
		IModelScheduleService scheduleService = getModelProvider().getModelScheduleService();
		getView().bindService(scheduleService);
		IModelAssemblyWrapperScheduleService wrapperScheduleService = (IModelAssemblyWrapperScheduleService) scheduleService.getWrapperService();
		String currentComment = "";
		String currentDate = "";
		String currentUserName = "";
		if (wrapperScheduleService.getHistoricalPassing() != null && ((HistoricalPassing)wrapperScheduleService.getHistoricalPassing()).getPassingCount() > 0) {
			Passing currentPassing = ((HistoricalPassing)wrapperScheduleService.getHistoricalPassing()).getPassing(((HistoricalPassing)wrapperScheduleService.getHistoricalPassing()).getPassingCount() - 1);
			if(currentPassing != null) {
				currentComment = currentPassing.getComment();
				if(currentComment == null){
					currentComment = "";
				}
				UserMark currentUser = currentPassing.getUserMark();
				if(currentUser != null && currentUser.getUser() != null && currentUser.getDateTime() != null) {
					currentUserName = currentUser.getUser().getName();
					currentDate = DateUtils.getDateFormat(currentUser.getDateTime());
				}
			}
		}
		getView().addParameter(AssemblyXsltConstants.XSLT_PARAMETER_NEW_PASSING_COMMENT.value(), currentComment);
		getView().addParameter(AssemblyXsltConstants.XSLT_PARAMETER_NEW_PASSING_USER.value(), currentUserName);
		getView().addParameter(AssemblyXsltConstants.XSLT_PARAMETER_NEW_PASSING_DATE.value(), currentDate);
		getView().displayModal(PropertyConstants.PROPERTY_MODAL_TITLE_SCHEDULE_NEW_PASSING, true);
		return true;
	}
}
