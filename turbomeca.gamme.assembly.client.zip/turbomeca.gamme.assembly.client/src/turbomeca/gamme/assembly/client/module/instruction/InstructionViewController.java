package turbomeca.gamme.assembly.client.module.instruction;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.module.instruction.action.ActionSwitchToMainView;
import turbomeca.gamme.assembly.client.module.instruction.action.ActionSwitchToTasksView;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.IClientControllersProvider;
import turbomeca.gamme.ecran.client.module.AController;

public class InstructionViewController extends AController {

	private static Logger logger = Logger.getLogger(InstructionViewController.class);
			
	/** To persist the last operation identifier opened in tasks view */
	private String tasksViewOperationId;
	
	public InstructionViewController(IClientControllersProvider controllersProvider) {
		super(controllersProvider);
	}
	
	@Override
	public boolean init() throws ClientException, ClientInterruption {
		return true;
	}

    public void actionDisplayTasksView(String operationId) {
        logger.info("actionDisplayTasksView : id=" + operationId);
        tasksViewOperationId = operationId;
        execute(new ActionSwitchToTasksView(operationId));
    }
    

    public void actionDisplayMainView() {
        logger.info("actionDisplayMainView, must focus previous operation : id=" + tasksViewOperationId);
        execute(new ActionSwitchToMainView(tasksViewOperationId));
    }

	@Override
	public boolean destroy() throws ClientException {
		return true;
	}

}
