package turbomeca.gamme.assembly.client.module.externaltools.player.piloting;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskPilotingService;
import turbomeca.gamme.assembly.client.module.externaltools.communication.ServletCommunication;
import turbomeca.gamme.assembly.client.module.externaltools.config.ConfigurationTaskPiloting;
import turbomeca.gamme.assembly.client.module.externaltools.provider.PlayerAcquisitionToolsProvider;
import turbomeca.gamme.assembly.services.model.data.State;
import turbomeca.gamme.assembly.services.model.data.TaskPiloting;
import turbomeca.gamme.assembly.services.model.data.types.StatusType;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.module.externaltools.player.APlayerInstruction;
import turbomeca.gamme.ecran.client.module.externaltools.player.IPlayerInstruction;
import turbomeca.gamme.ecran.services.devices.ExternalsToolsExceptions;

public class PlayerTaskPiloting extends APlayerInstruction implements
		IPlayerInstruction {

	/** logger for current class */
	private static Logger logger = Logger.getLogger(PlayerTaskPiloting.class);
	
	private String acquisitionResult;
	
	/**
	 * 
	 * 
	 * 
	 * @param modelService of the taskPiloting to run
	 */
	public PlayerTaskPiloting(IModelObjectService modelService) {
		super();
		setModelService(modelService);
	}

	@Override
	public boolean play() throws ClientException, ClientInterruption, ExternalsToolsExceptions  {
		ModelTaskPilotingService taskPilotingService = (ModelTaskPilotingService) getModelService();
		TaskPiloting taskPiloting = (TaskPiloting) taskPilotingService.getWrapperService().getObject();
		ConfigurationTaskPiloting config = new ConfigurationTaskPiloting(taskPiloting);
		State state = taskPiloting.getState();
		PlayerAcquisitionTaskPiloting acquisition = new PlayerAcquisitionTaskPiloting(config, state);
		
		try {
			acquisitionResult = acquisition.acquire();
		} catch(ExternalsToolsExceptions e) {
			taskPiloting.getState().setStatus(StatusType.KO);
			throw e;
		}
		
		return true;
	}
	
	
	
	@Override
	public boolean autoRun() throws ClientInterruption {
		return true;
	}

	@Override
	public boolean stop(IModelObjectService service) throws ClientException, ClientInterruption {	
		ServletCommunication communicator = null;
		ModelTaskPilotingService taskPilotingService = (ModelTaskPilotingService) getModelService();
		TaskPiloting taskPiloting = (TaskPiloting) taskPilotingService.getWrapperService().getObject();
		ConfigurationTaskPiloting config = new ConfigurationTaskPiloting(taskPiloting);
		
		try {
			communicator = (ServletCommunication) PlayerAcquisitionToolsProvider.getCommunicationWay(config);
			communicator.stop();
		} catch(ExternalsToolsExceptions e) {
			logger.warn("[PILOTING] : exception due to acquisition interruption", e);
		} catch(RuntimeException e) {
			logger.warn("[PILOTING] : exception due to acquisition interruption", e);
		} catch(Exception e) {
			logger.warn("[PILOTING] : exception due to acquisition interruption", e);
		} finally{
			if(communicator != null) {
				communicator.release();
			}
		}
		
		taskPiloting.getState().setStatus(StatusType.KO);
		return false;
	}

	public String getAcquisitionResult() {
		return acquisitionResult;
	}
	
	protected void setAcquisitionResult(String res) {
		acquisitionResult = res;
	}
}
