package turbomeca.gamme.assembly.client.module.sap.services;

import java.lang.reflect.InvocationTargetException;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.model.edit.instructions.AModelTaskActionService;
import turbomeca.gamme.assembly.services.model.data.InputSap;
import turbomeca.gamme.ecran.server.ws.sap.client.model.ExtractUfi.SapExtractUFIResponseContext;
import turbomeca.gamme.ecran.server.ws.sap.client.model.ExtractUfi.SapUfiAffairePoste;

public class UpdateSapInputPosteService extends AUpdateSapInputService {

	private static Logger logger = Logger.getLogger(UpdateSapInputPosteService.class);
	
    @Override
    public String getSapValue(AModelTaskActionService taskActionService, SapExtractUFIResponseContext sapContext, String instanceId) 
            throws NoSuchMethodException, IllegalAccessException, InvocationTargetException {
    	
        InputSap inputSap = taskActionService.getTaskAction().getInputAction().getInputActionChoice().getInputSap();
        String instanceIdValue = inputSap.getAta();
        
        String value = null;
        String key = getKey(inputSap, instanceIdValue);
        SapUfiAffairePoste dataPoste = sapContext.getPostes().get(key);
        if (dataPoste == null) {
            logger.error("Failed to retreive poste data with key " + key);
            value = "";
        } else {
        	value = dataPoste.getDataTypeValue(inputSap.getItemDataType());
        }
        return value;
    }

    @Override
    public boolean isCompletion(AModelTaskActionService taskActionService) {
        return taskActionService.getTaskAction().getInputAction().getInputActionChoice().getInputSap().isCompletion();
    }
    
    private String getKey(InputSap inputSap, String sapInstanceId) {
        return inputSap.getAta();
    }    
}
