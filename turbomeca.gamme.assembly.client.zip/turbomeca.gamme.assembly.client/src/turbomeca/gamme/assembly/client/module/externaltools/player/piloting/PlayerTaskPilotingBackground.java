package turbomeca.gamme.assembly.client.module.externaltools.player.piloting;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskPilotingService;
import turbomeca.gamme.assembly.client.module.externaltools.config.ConfigurationTaskPiloting;
import turbomeca.gamme.assembly.services.model.data.State;
import turbomeca.gamme.assembly.services.model.data.TaskPiloting;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.services.devices.ExternalsToolsExceptions;

public class PlayerTaskPilotingBackground extends PlayerTaskPiloting{
	private TaskPiloting taskPiloting;
	private ModelTaskPilotingService taskPilotingService;
	private Logger logger = Logger.getLogger(PlayerTaskPilotingBackground.class);
	
	public PlayerTaskPilotingBackground(IModelObjectService modelService) {
		super(modelService);
	}
	
	@Override
	public boolean play() throws ClientException, ClientInterruption, ExternalsToolsExceptions {
		taskPilotingService = (ModelTaskPilotingService) getModelService();
		taskPiloting = (TaskPiloting) taskPilotingService
				.getWrapperService().getObject();
		ConfigurationTaskPiloting config = new ConfigurationTaskPiloting(
				taskPiloting);
		State state = taskPiloting.getState();
		PlayerAcquisitionTaskPiloting acqusition = new PlayerAcquisitionTaskPiloting(config, state);
		setAcquisitionResult(acqusition.acquire());
		return getAcquisitionResult()!=null && !getAcquisitionResult().isEmpty();
	}

}
