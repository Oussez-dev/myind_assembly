package turbomeca.gamme.assembly.client.module.instruction.action;

import turbomeca.gamme.assembly.client.ClientAssemblyException;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.client.model.edit.utils.ModelUtils;
import turbomeca.gamme.assembly.client.module.intervention.action.ActionUpdateScheduleTopStartOperation;
import turbomeca.gamme.assembly.services.model.data.types.StatusType;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.client.module.action.AActionModify;

public class ActionAlterableSubPhase extends AActionModify {

    /** SubPhase identifier */
    private String subPhaseId;

    /**
     * Constructor
     * 
     * @param subPhaseId the subPhase identifier
     */
    public ActionAlterableSubPhase(String subPhaseId) {
        setSubPhaseId(subPhaseId);
    }

    @Override
    public boolean run(IController controller) throws ClientException, ClientInterruption {
        Object subPhaseServiceObject = getModelProvider().getModelService(getSubPhaseId());
        if (subPhaseServiceObject instanceof ModelSubPhaseService) {
            ModelSubPhaseService subPhaseService = (ModelSubPhaseService) subPhaseServiceObject;
            StatusType subPhaseStatus = subPhaseService.getStatus(null);
            if (subPhaseStatus == StatusType.DONE) {
            	// When reopening a subphase, clean it if parameter cleanSubphase is true and if subPhase dont belong to current user
                boolean clean = !ModelUtils.isCurrentUser(subPhaseService.getWrapperService().getState().getUserMark())
                		&& getContext().getContextConfig().isCleanSubPhase();
            	subPhaseService.getStatusService().setAlterable(null);
                if (!clean) {
                	subPhaseService.getStatusService().updateState(StatusType.TO_SIGN.value(), true, null, null);
                } else {
                	// Clean subPhase and compute recursively its status (subPhase could be without taskAction or not)
                	subPhaseService.cleanSubPhase();
                	subPhaseService.getStatusService().computeStatus(true);
                }
            } else if (subPhaseStatus == StatusType.NOT_APPLICATED) {
                subPhaseService.getStatusService().updateState(StatusType.TODO.value(), true, null, null);
                subPhaseService.updateComment(null);
                if (subPhaseService.getParent().getRunnableService().isFinished()) {
                    subPhaseService.getParent().getStatusService().resetState(false, true, null);
                }
        	    controller.getNotificationsService().setModelReload();
            }
            //refresh top start subphase when reopening optional subphase
            if(subPhaseService.getWrapperService().getSubPhase() != null && subPhaseService.getWrapperService().getSubPhase().hasOptional()
            		&& subPhaseService.getWrapperService().getSubPhase().getOptional()) {
            	new ActionUpdateScheduleTopStartOperation().run(controller);
            }

            controller.getNotificationsService().notifyServiceChanged(subPhaseService);
            return true;
        } else {
            throw new ClientAssemblyException();
        }
    }


    /**
     * @param subPhaseId
     *            the subPhaseId to set
     */
    public void setSubPhaseId(String subPhaseId) {
        this.subPhaseId = subPhaseId;
    }

    /**
     * @return the subPhaseId
     */
    public String getSubPhaseId() {
        return subPhaseId;
    }
}
