package turbomeca.gamme.assembly.client.module.electronic.notification.action;

import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.constants.PropertyConstants;
import turbomeca.gamme.ecran.client.interfaces.server.notification.NotificationServerInterfaceService;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.client.module.action.AActionModify;

public class ActionUpdateElectronicCrossValidations extends AActionModify{
	
	private String[] listInformations;
	
	public ActionUpdateElectronicCrossValidations(String listInformationsValidations) {
		setListInformations(listInformationsValidations.split(";"));
	}

	@Override
	public boolean run(IController controller) throws ClientException, ClientInterruption {
		boolean isUpdated = false;
        isUpdated = NotificationServerInterfaceService.getInstance().updateCrossValidations(getListInformations());
        
        if(isUpdated) {
			getLoggerHmi().info(PropertyConstants.PROPERTY_VALIDATION_CHECK_DONE);
		} else {
	    	getLoggerHmi().error(PropertyConstants.PROPERTY_ERROR_VALIDATION_CHECK_DONE);
		}
        
        return isUpdated;
	}

	public String[] getListInformations() {
		return listInformations;
	}

	public void setListInformations(String[] listInformations) {
		this.listInformations = listInformations;
	}

}
