package turbomeca.gamme.assembly.client.module.electronic.notification.action;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.ClientAssemblyControllersProvider;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.client.model.edit.notifications.AModelNotificationService;
import turbomeca.gamme.assembly.client.model.edit.notifications.ModelNotificationUserService;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.constants.PropertyConstants;
import turbomeca.gamme.ecran.client.model.provider.ModelXmlProvider;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.client.module.io.IoController;
import turbomeca.gamme.ecran.services.common.constants.GlobalConstants;

public class ActionCreateElectronicNotificationUser extends AActionCreateElectronicNotification {

    private static Logger logger = Logger.getLogger(ActionCreateElectronicNotificationUser.class);

    /** */
    private String subPhaseId;
    /** */
    private String comment;
    
    /**
     * 
     * @param taskActionService
     */
    public ActionCreateElectronicNotificationUser(String subPhaseId, String comment) {
        setSubPhaseId(subPhaseId);
        setComment(comment);
    }

    @Override
    public boolean run(IController controller) throws ClientException {
        boolean succeed = false;
        ModelSubPhaseService modelServiceSubPhase = (ModelSubPhaseService) getModelProvider().getModelService(getSubPhaseId());
        AModelNotificationService notificationService = new ModelNotificationUserService(modelServiceSubPhase, getComment());
        boolean createOnServer = createNotification(notificationService, modelServiceSubPhase);
        String mustSynchronize = null;
        if(!createOnServer){
        	mustSynchronize = GlobalConstants.NOTIFICATION_STATUS_CREATED;
        }
       	notificationService.bindService(modelServiceSubPhase, mustSynchronize);
        getLoggerHmi().info(PropertyConstants.PROPERTY_NOTIFICATION_CREATED);
        getModelProvider().setModelStatus(ModelXmlProvider.MODEL_STATUS_MODIFIED);
        ((IoController) controller.getControllersProvider().getController(ClientAssemblyControllersProvider.INTERFACE_IO)).actionSaveOnServer();
        succeed = true;
        return succeed;
    }

    /**
     * @return the comment
     */
    public String getComment() {
        return comment;
    }

    /**
     * @param comment the comment to set
     */
    public void setComment(String comment) {
        this.comment = comment;
    }

    /**
     * @return the subPhaseId
     */
    public String getSubPhaseId() {
        return subPhaseId;
    }

    /**
     * @param subPhaseId the subPhaseId to set
     */
    public void setSubPhaseId(String subPhaseId) {
        this.subPhaseId = subPhaseId;
    }
}