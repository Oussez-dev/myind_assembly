package turbomeca.gamme.assembly.client.module.sap.action.comparator;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.services.model.data.Identification;
import turbomeca.gamme.assembly.services.model.data.Instanciation;
import turbomeca.gamme.ecran.client.module.sap.SapAnalyse;
import turbomeca.gamme.ecran.server.ws.sap.client.model.ASapContext;
import turbomeca.gamme.ecran.server.ws.sap.client.model.ExtractUfi.SapExtractUFIResponseContext;


public class ActionSapComparatorTU extends AActionScheduleComparator {

	private static Logger logger = Logger.getLogger(ActionSapComparatorTU.class);

	public static final String MAP_KEY = "tu.analyse.key";

	@Override
	protected List<SapAnalyse> compare(Instanciation instanciation, Identification identification,
			ASapContext<?> sapContext) {
		
		logger.info("[SAP] Analyse change TU from SAP");
		
		SapExtractUFIResponseContext sContext = (SapExtractUFIResponseContext) sapContext;

		List<SapAnalyse> result = new ArrayList<SapAnalyse>();

		List<String> sapModifications = null;
		if (isAssemblyRepaired()) {
			sapModifications = sContext.getActiveModifications("S", sContext.getZNOModule(instanciation.getPn(), true));
		} else if (isDisassembly()){
			sapModifications = sContext.getActiveModifications("A", sContext.getZNOModule(instanciation.getPn(), false));
		}

		String[] currentModifs = instanciation.getModifications().getModification();

		boolean newValue = false;
		for (String sapModification : sapModifications) {
			boolean contains = false;
			for (String currentModif : currentModifs) {
				if (currentModif.compareTo(sapModification) == 0) {
					contains = true;
					break;
				}
			}
			if (!contains) {
				newValue = true;
			}
		}
		

		if (newValue) {
			List<SapAnalyse> missing = new ArrayList<SapAnalyse>();
			missing.add(SapAnalyse.updateValue(sapModifications, instanciation.getModifications().getModificationAsReference()));
			result.addAll(missing);
			logger.info("[SAP] Analyse Modification SAP : " + Arrays.toString(missing.toArray()));
		}
		return result;
	}

	@Override
	protected String getMapKey() {
		return MAP_KEY;
	}



}
