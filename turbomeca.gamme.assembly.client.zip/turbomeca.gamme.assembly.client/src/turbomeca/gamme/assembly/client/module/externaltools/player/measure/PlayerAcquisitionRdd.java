package turbomeca.gamme.assembly.client.module.externaltools.player.measure;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.services.model.data.State;
import turbomeca.gamme.ecran.client.module.externaltools.communication.FileCommunication;
import turbomeca.gamme.ecran.client.module.externaltools.config.ConfigurationRDD;
import turbomeca.gamme.ecran.client.module.externaltools.measure.IPlayerAcquisition;
import turbomeca.gamme.ecran.services.devices.ExternalsToolsExceptions;

public class PlayerAcquisitionRdd extends APlayerAcquisition implements IPlayerAcquisition {
	
	private static Logger logger = Logger.getLogger(PlayerAcquisitionRdd.class);
	
	public PlayerAcquisitionRdd (ConfigurationRDD configurationRdd, State measureState){
		super(ServiceType.RDD);
		setConfigurationMeasure(configurationRdd);
		setState(measureState);
	}
		
	@Override
	public String acquireAcquistion()  throws ExternalsToolsExceptions, InterruptedException  {
		logger.debug("PlayerAcquisitionRdd - Call - AcquireInternal");
		FileCommunication  communicator = new FileCommunication();
		communicator.init(getConfigurationMeasure());
		communicator.listen();
		return communicator.getData();
	}

		
}
