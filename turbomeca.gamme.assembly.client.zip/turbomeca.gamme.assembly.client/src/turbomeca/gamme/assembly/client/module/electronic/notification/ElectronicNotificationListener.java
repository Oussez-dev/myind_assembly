package turbomeca.gamme.assembly.client.module.electronic.notification;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelMarkService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskActionService;
import turbomeca.gamme.assembly.client.model.edit.wrappers.IModelNotificationRefWrapper;
import turbomeca.gamme.assembly.client.module.electronic.notification.view.NotificationUpdaterView;
import turbomeca.gamme.assembly.services.model.data.ElectronicNotificationRef;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelWrapperService;
import turbomeca.gamme.ecran.client.notifications.listener.DefaultNotificationListener;

public class ElectronicNotificationListener extends DefaultNotificationListener {

	/** logger for current class */
	private static Logger logger = Logger.getLogger(ElectronicNotificationListener.class);

	/** Instruction page view */
	private NotificationUpdaterView notificationUpdaterView;

	/**
	 * Constructor
	 * 
	 * @param view
	 *            instruction page view
	 */
	public ElectronicNotificationListener() {
		notificationUpdaterView = new NotificationUpdaterView();
	}

	@Override
    public void electronicNotificationChanged(IModelObjectService modelService) throws ClientException {
	    logger.debug("electronicNotificationChanged : " + modelService);
        if (modelService instanceof ModelTaskActionService) {
        	ModelTaskActionService taskActionService = (ModelTaskActionService) modelService;
        	if (taskActionService.getTaskAction().isDoubleValidation()) {
        		getNotificationUpdaterView().setStatusValidation(modelService.getIdentifier(), modelService.getStatusService().getStatus());
        	} 
        	if (taskActionService.getTaskAction().isNotification()) {
        	    updateNotification(modelService);
        	}
        } else if (modelService instanceof ModelMarkService) {
            updateNotification(modelService);
        }
    }

	/**
	 * 
	 * @param modelService
	 */
	private void updateNotification(IModelObjectService modelService) {
	    IModelWrapperService wrapper = modelService.getWrapperService();
        if (wrapper instanceof IModelNotificationRefWrapper) {
            IModelNotificationRefWrapper wrapperNotif = (IModelNotificationRefWrapper) wrapper;
            if(wrapperNotif.getElectronicNotificationRef() != null && wrapperNotif.getElectronicNotificationRef().length != 0){
                for(ElectronicNotificationRef electNotifRef : wrapperNotif.getElectronicNotificationRef()) {
                    String instance = electNotifRef.getInstance(); 
                    if (electNotifRef.getInstance() == null) {
                        instance = "";
                    }
                    String alternative = electNotifRef.getAlternative();
                    if (electNotifRef.getAlternative() == null) {
                        alternative = "";
                    }
                    getNotificationUpdaterView().setStatusNotification(
                            modelService.getIdentifier() + "_" + instance + "_" + alternative, 
                            electNotifRef.getStatusNotification().value());
                }
            } else {
                getNotificationUpdaterView().setStatusNotification(modelService.getIdentifier() + "_", "");
            }
        }
	}

    /**
     * @return the notificationUpdaterView
     */
    public NotificationUpdaterView getNotificationUpdaterView() {
        return notificationUpdaterView;
    }

    /**
     * @param notificationUpdaterView the notificationUpdaterView to set
     */
    public void setNotificationUpdaterView(NotificationUpdaterView notificationUpdaterView) {
        this.notificationUpdaterView = notificationUpdaterView;
    }
}
