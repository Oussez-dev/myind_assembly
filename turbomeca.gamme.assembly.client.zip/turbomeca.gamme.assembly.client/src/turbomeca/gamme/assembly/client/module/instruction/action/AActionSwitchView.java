package turbomeca.gamme.assembly.client.module.instruction.action;

import turbomeca.gamme.assembly.client.module.electronic.notification.view.InstructionViewChangeUpdaterView;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.client.module.action.AAction;
import turbomeca.gamme.ecran.client.module.instruction.ADefaultInstructionController;
import turbomeca.gamme.ecran.client.module.instruction.view.IInstructionView;

public abstract class AActionSwitchView extends AAction  {
	
	protected abstract IInstructionView getViewToSwitchTo() throws ClientException, ClientInterruption ;

	@Override
	public boolean run(IController controller) throws ClientException, ClientInterruption {
		IInstructionView tasksView = getViewToSwitchTo();
		controller.getNotificationsService().notifyViewChanged(tasksView);
		notifyInstructionController(controller, tasksView);
		tasksView.run(controller);
		
		InstructionViewChangeUpdaterView instructionViewChangeUpdaterView = 
				new InstructionViewChangeUpdaterView();
		instructionViewChangeUpdaterView.instructionViewChangedTo(tasksView.getClass().getName());
		return true;
	}

	private void notifyInstructionController(IController controller, IInstructionView tasksView) {
		ADefaultInstructionController instructionController  = 
				controller.getControllersProvider().getInstructionHmiInterface();
		instructionController.setView(tasksView);
	}
}


