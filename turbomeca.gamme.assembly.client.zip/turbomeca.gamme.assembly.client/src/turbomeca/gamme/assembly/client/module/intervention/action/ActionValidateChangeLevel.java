package turbomeca.gamme.assembly.client.module.intervention.action;

import java.util.List;

import turbomeca.gamme.assembly.client.config.AssemblyPropertyConstants;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseGroupService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.client.model.edit.status.ModelStatusSubPhaseService;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelWrapperService;

public class ActionValidateChangeLevel extends AActionChangeLevel {
	
    /**
     * 
     * @param level
     */
	public ActionValidateChangeLevel(String level) {
		super(level);
	}
	
	@Override
	protected boolean checkConditions(IModelObjectService scheduleService) throws ClientException {
		List<IModelObjectService> operationsService = scheduleService.getChildren();
		for (IModelObjectService operationService : operationsService) {
			for (IModelObjectService service : operationService.getChildren()) {
				if (service instanceof ModelSubPhaseService) {
				    if (!checkSubPhase((ModelSubPhaseService) service)) {
				        return false;
				    }
				} else if (service instanceof ModelSubPhaseGroupService) {
				    for (IModelObjectService childService : service.getChildren()) {
				        if (!checkSubPhase((ModelSubPhaseService) childService)) {
	                        return false;
	                    }
				    }
				}
			}
		}
		return true;
	}

	private boolean checkSubPhase(ModelSubPhaseService subPhaseService) throws ClientException {
	    IModelWrapperService wrapper = subPhaseService.getWrapperService();
	    if (!wrapper.isArchived()) {
            if (subPhaseService.isLevelApplicable(getCurrentLevel())) {
                getSubPhaseModified().put(subPhaseService.getIdentifier(), Boolean.TRUE);
            } else {
                if (((ModelStatusSubPhaseService) subPhaseService.getStatusService()).checkTasksToChangeLevel() 
                		|| ((ModelStatusSubPhaseService) subPhaseService.getStatusService()).checkRessourcesToChangeLevel()
                		|| subPhaseService.getRunnableService().isFinished()
                		|| subPhaseService.getWrapperService().getPassingId() > 1) {
                    getLoggerHmi().error(AssemblyPropertyConstants.PROPERTY_ERROR_CHANGE_LEVEL_IN_PROGRESS);
                    return false;
                } else {
                    getSubPhaseModified().put(subPhaseService.getIdentifier(), Boolean.FALSE);
                }
            }
        }
	    return true;
	}
}
