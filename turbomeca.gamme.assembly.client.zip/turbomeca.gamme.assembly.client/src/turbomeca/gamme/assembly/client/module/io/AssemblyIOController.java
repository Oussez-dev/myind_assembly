package turbomeca.gamme.assembly.client.module.io;

import turbomeca.gamme.assembly.client.module.edition.action.ActionRefreshAssemblyFactory;
import turbomeca.gamme.ecran.client.IClientControllersProvider;
import turbomeca.gamme.ecran.client.module.io.IoController;
import turbomeca.gamme.ecran.client.module.io.action.ActionGenerationPdfFactory;
import turbomeca.gamme.ecran.client.module.io.action.ActionSaveOnDatabaseFactory;
import turbomeca.gamme.ecran.client.module.io.action.ActionSaveOnServerFactory;

public class AssemblyIOController extends IoController{
	
	public AssemblyIOController(IClientControllersProvider provider) {
		super(provider, new ActionGenerationPdfFactory(), new ActionRefreshAssemblyFactory(), new ActionSaveOnServerFactory(), new ActionSaveOnDatabaseFactory());
	}
    
    /**
     * 
     * @param pdfType
     */
    @Override
	public void actionSynchronizeThenRefreshThenGeneratePdf(String pdfType, String operationNumber) {
    	synchronizeThenRefreshSchedule();
    	// Action Generation PDF
    	actionGenerationPdf(pdfType, operationNumber);
    }
    
    /**
     * 
     * @param pdfType
     */
    @Override
	public void actionSynchronizeThenRefreshThenGeneratePdf(String pdfType) {
    	synchronizeThenRefreshSchedule();
    	// Action Generation PDF
    	actionGenerationPdf(pdfType); 
    }
    
}
