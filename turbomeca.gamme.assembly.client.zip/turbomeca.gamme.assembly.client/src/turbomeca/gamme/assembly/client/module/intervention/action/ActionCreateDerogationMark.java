package turbomeca.gamme.assembly.client.module.intervention.action;

import turbomeca.gamme.assembly.client.config.AssemblyPropertyConstants;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelDerogationMarksService;
import turbomeca.gamme.assembly.client.model.edit.schedule.AAssemblyScheduleService;
import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperDerogationMarksService;
import turbomeca.gamme.assembly.services.model.data.DerogationMark;
import turbomeca.gamme.assembly.services.model.data.DerogationMarks;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.client.module.action.AActionModify;

public class ActionCreateDerogationMark extends AActionModify {

	private String idDerogation;
	private String pn;
	private String sn;
	private String derog;

	public ActionCreateDerogationMark(String servicesId, String pn, String sn,
			String derog) {
		setIdDerogation(servicesId);
		setPn(pn);
		setSn(sn);
		setDerog(derog);
	}

	@Override
	public boolean run(IController controller) throws ClientException, ClientInterruption {
		boolean success = true;
		if(getPn() != null && !getPn().isEmpty() && getDerog() != null && !getDerog().isEmpty()){

			ModelDerogationMarksService modelDerogationService = (ModelDerogationMarksService) getModelProvider()
					.getModelService(ModelWrapperDerogationMarksService.DEROGATION_ID);
			ModelWrapperDerogationMarksService modelWrapperService = (ModelWrapperDerogationMarksService) modelDerogationService
					.getWrapperService();
			DerogationMark derogation = null;
			DerogationMarks derogations = modelWrapperService.getDerogationMarks();
			if (derogations == null) {
				derogations = new DerogationMarks();
				derogations.setId(ModelWrapperDerogationMarksService.DEROGATION_ID);
				modelWrapperService.setDerogationMarks(derogations);
			}

			if (!modelWrapperService.isPnAlreadyExist(getPn())) {
				derogation = new DerogationMark();
				derogation.setId(ModelWrapperDerogationMarksService.generateIdDerogMarks());
				populateInfromationForDerogationMark(derogation);
				derogations.addDerogationMark(derogation);
				AAssemblyScheduleService schedule = (AAssemblyScheduleService)modelDerogationService.getParent();
				schedule.setDerogationsMarks(derogations);
				controller.getNotificationsService().notifyServiceChanged(modelDerogationService);
			} else {
				getLoggerHmi().info(AssemblyPropertyConstants.PROPERTY_INFO_DEROGATION_MARK_ALREADY_EXIST);
			}
		}
		else{
			getLoggerHmi().info(AssemblyPropertyConstants.PROPERTY_INFO_PN_DEROGATION_REQUIRED);
			success = false;
		}
		return success;
	}

	/**
	 * Populate information in Derogation Marks
	 * 
	 * @param derogation
	 */

	private void populateInfromationForDerogationMark(DerogationMark derogation) {
		derogation.setPN(getPn());
		derogation.setSN(getSn());
		derogation.setDerogation(getDerog());
	}

	public String getPn() {
		return pn;
	}

	public void setPn(String pn) {
		this.pn = pn;
	}

	public String getSn() {
		return sn;
	}

	public void setSn(String sn) {
		this.sn = sn;
	}

	public String getDerog() {
		return derog;
	}

	public void setDerog(String derog) {
		this.derog = derog;
	}

	public void setIdDerogation(String idDerogation) {
		this.idDerogation = idDerogation;
	}

	public String getIdDerogation() {
		return idDerogation;
	}
}
