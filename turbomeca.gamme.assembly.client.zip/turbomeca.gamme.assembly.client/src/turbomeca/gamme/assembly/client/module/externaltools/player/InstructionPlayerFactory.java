package turbomeca.gamme.assembly.client.module.externaltools.player;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskActionMeasureService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskActionService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskPilotingService;
import turbomeca.gamme.assembly.client.module.externaltools.player.measure.PlayerTaskMeasure;
import turbomeca.gamme.assembly.client.module.externaltools.player.piloting.BackgroundPlayer;
import turbomeca.gamme.assembly.client.module.externaltools.player.piloting.PlayerTaskPiloting;
import turbomeca.gamme.assembly.client.module.externaltools.player.piloting.PlayerTaskPilotingBackground;
import turbomeca.gamme.assembly.services.model.data.TaskPiloting;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.module.externaltools.player.IPlayerInstruction;
import turbomeca.gamme.ecran.client.module.externaltools.player.PlayerDefault;
import turbomeca.gamme.ecran.services.model.tool.TaskPilotingConstants;

/**
 * Factory that performs data acquisition player creation that suits the input
 * model service provided.
 * 
 * @author ademartin
 *
 */
public class InstructionPlayerFactory {
	
	public static IPlayerInstruction createPlayer(IModelObjectService modelService,boolean forceMode,boolean toolsAcquistion) {
		if (modelService instanceof ModelTaskActionMeasureService) {
			return new PlayerTaskMeasure(modelService,forceMode,toolsAcquistion);
		} 
		// Creates specific taskPiloting acquisition player for screw drivers taskPiloting
		else if (modelService instanceof ModelTaskPilotingService &&
				TaskPilotingConstants.TOOL_TYPE_SCREW_DRIVER.equals(
						((TaskPiloting)modelService.getWrapperService().getObject()).getTool())) {
			// Wraps the taskPiloting acquisition player into a background player to enable HMI modal window
			// Please note that the taskPiloting data insertion is delegated to the background player, not the acquisition player
			return new BackgroundPlayer(new PlayerTaskPilotingBackground(modelService), modelService);
		} else if (modelService instanceof ModelTaskPilotingService) {
			return new PlayerTaskPiloting(modelService);
		} else if (modelService instanceof ModelTaskActionService) {
			return new PlayerDefault(modelService);
		}
		return null;
	}
}
