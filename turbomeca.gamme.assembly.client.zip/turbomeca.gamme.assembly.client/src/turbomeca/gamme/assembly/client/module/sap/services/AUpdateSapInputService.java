package turbomeca.gamme.assembly.client.module.sap.services;

import java.lang.reflect.InvocationTargetException;

import turbomeca.gamme.assembly.client.config.AssemblyConstants;
import turbomeca.gamme.assembly.client.model.edit.instructions.AModelTaskActionService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.client.model.edit.schedule.AAssemblyScheduleService;
import turbomeca.gamme.assembly.services.model.data.InputValue;
import turbomeca.gamme.assembly.services.model.data.SapValue;
import turbomeca.gamme.assembly.services.model.data.TaskAction;
import turbomeca.gamme.assembly.services.utils.SapUtils;
import turbomeca.gamme.ecran.client.AClientInstancesProvider;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.server.ws.sap.client.model.ExtractUfi.SapExtractUFIResponseContext;

public abstract class AUpdateSapInputService extends AClientInstancesProvider {
	
	protected boolean hasDifference(String newValue, SapValue sapValue, String inputValue, boolean completion) {
		return (sapValue == null && newValue != null && !newValue.isEmpty()) || (sapValue != null && !newValue.equals(sapValue.getValue())) || (completion && inputValue == null);
	}

	protected boolean hasDifference(String newValue, SapValue sapValue, InputValue inputValue, boolean completion) {
		return (sapValue == null) || (!newValue.equals(sapValue.getValue())) || (completion && inputValue == null);
	}

	public boolean update(AModelTaskActionService taskActionService, SapExtractUFIResponseContext sapContext, boolean update) throws Exception {
		boolean hasDifference = false;
		hasDifference = updateInstance(taskActionService, sapContext, update);
		return hasDifference;
	}

	protected boolean updateInstance(AModelTaskActionService taskActionService, SapExtractUFIResponseContext sapContext, boolean update) throws Exception {
		boolean hasDifference = false;

		boolean isTaskActionCompletion = isCompletion(taskActionService);
		TaskAction taskAction = taskActionService.getTaskAction();
		String inputValue = taskActionService.getValue();

		IModelObjectService subPhaseService = taskActionService.getAncestor(ModelSubPhaseService.class);
		if (!subPhaseService.getWrapperService().isArchived()) {
			String value = getSapValue(taskActionService, sapContext, null);
			SapValue sapValue = taskAction.getSapValue();

			hasDifference = hasDifference(value, sapValue, inputValue, isTaskActionCompletion);
			if (hasDifference && update) {
				if (sapValue == null) {
					taskAction.setSapValue(new SapValue());
				}
				taskAction.getSapValue().setValue(value);

				if (taskActionService.getRunnableService().isRunnable()) {
					if (!taskActionService.getStatusService().isAlterable()) {
						taskActionService.getParent().getStatusService().reactive(true, null, true);
					} else {
						taskActionService.getParent().getStatusService().updateActivity(true, true, null);
					}

					if (isTaskActionCompletion) {
						taskActionService.setValue(value, false);
						taskActionService.getParent().getStatusService().computeStatus(false);
					} else {
						taskActionService.setServiceModified(true);
					}
				}
			}
		}
		return hasDifference;
	}

	/**
	 * 
	 * @param taskActionService
	 * @param key
	 * @return
	 * @throws SecurityException
	 * @throws IllegalArgumentException
	 * @throws NoSuchMethodException
	 * @throws IllegalAccessException
	 * @throws InvocationTargetException
	 */
	public abstract String getSapValue(AModelTaskActionService taskActionService, SapExtractUFIResponseContext sapContext, String key) throws SecurityException,
			IllegalArgumentException, NoSuchMethodException, IllegalAccessException, InvocationTargetException;

	/**
	 * 
	 * @param taskActionService
	 * @return
	 */
	public abstract boolean isCompletion(AModelTaskActionService taskActionService);
	
    protected String getLang() {
        return SapUtils.convertLangToSapFormat(getScheduleService().getWrapperService().getInstantiation().getLanguage());
    }
	
    protected boolean isAssemblyRepaired() {
    	return AssemblyConstants.ASSEMBLY_REPAIRED.equals(getScheduleService().getSubOfficialRangeName());
    }

	protected AAssemblyScheduleService getScheduleService() {
		return (AAssemblyScheduleService) getModelProvider().getModelScheduleService();
	}
    
	
	
}
