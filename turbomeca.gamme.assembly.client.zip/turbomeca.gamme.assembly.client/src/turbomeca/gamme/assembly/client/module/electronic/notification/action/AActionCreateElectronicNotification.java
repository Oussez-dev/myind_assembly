package turbomeca.gamme.assembly.client.module.electronic.notification.action;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.model.edit.IModelAssemblyWrapperScheduleService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelOperationService;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelSubPhaseService;
import turbomeca.gamme.assembly.client.model.edit.notifications.AModelNotificationService;
import turbomeca.gamme.assembly.client.model.edit.notifications.ModelNotificationsService;
import turbomeca.gamme.assembly.client.model.edit.provider.ModelNotificationProvider;
import turbomeca.gamme.assembly.services.model.data.ElectronicNotification;
import turbomeca.gamme.assembly.services.model.data.Geode;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.constants.PropertyConstants;
import turbomeca.gamme.ecran.client.interfaces.server.notification.NotificationServerInterfaceService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.module.action.AActionModify;

public abstract class AActionCreateElectronicNotification extends AActionModify {

    /** logger for current class */
    private static Logger logger = Logger.getLogger(AActionCreateElectronicNotification.class);
    
    public boolean createNotification(AModelNotificationService notificationService, IModelObjectService serviceObject) throws ClientException {
    	String operationId =null;
    	String displayOperrationId = null;
    	String subPhaseId =null;
    	String displaySubPhaseId =null;
    	String order = null;
    	String geode = null;
    	
		IModelAssemblyWrapperScheduleService serviceSchedule = (IModelAssemblyWrapperScheduleService)getModelProvider().getModelScheduleService().getWrapperService();
		order = serviceSchedule.getInstantiation().getOrder();
		Geode currentGeode = serviceSchedule.getIdentification().getGeode(0);
		geode = currentGeode.getReference() + " - "+ currentGeode.getVersion();
		ModelSubPhaseService subPhaseService = (ModelSubPhaseService) serviceObject.getAncestor(ModelSubPhaseService.class);
		if( subPhaseService !=null ){
			subPhaseId = subPhaseService.getWrapperService().getSubPhase().getId();
			displaySubPhaseId = subPhaseService.getWrapperService().getSubPhase().getDisplayId();
			ModelOperationService operationService = (ModelOperationService) subPhaseService.getAncestor(ModelOperationService.class);
    		if( operationService !=null ){
    			operationId = operationService.getWrapperService().getOperation().getId();		
    			displayOperrationId = operationService.getWrapperService().getOperation().getDisplayId();	
    		}
    	}
    	
        logger.info("createNotification : " + notificationService.getIdentifier() + " - " + notificationService.getElectronicNotification().getRequest().getComment());
        ElectronicNotification electNotif = notificationService.getElectronicNotification();
        boolean isCreated = getServerInterface().createNotification( electNotif.getId(), order, geode, operationId,displayOperrationId, subPhaseId, displaySubPhaseId,
        		electNotif.getType().value(),
        		electNotif.getRequest().getComment(), 
        		electNotif.getStatusNotification().value(),
        		electNotif.getRequest().getOptionnalComment());
        
        if (!isCreated) {
            getLoggerHmi().error(PropertyConstants.PROPERTY_ERROR_NOTIFICATION_CREATED);
        }
        
        return isCreated;
    }
    
    public boolean synchronizeOnServer(boolean deleteNcr) throws ClientException {
    	boolean success = true;
    	Set<String> listToErase = getNotificationProvider().getNotificationsToErase();
    	if (listToErase.size() != 0) {
        	String [] arraysToErase = listToErase.toArray(new String[0]);
        	if (getServerInterface().deleteNotification(arraysToErase)) {
        		Iterator<String> it = listToErase.iterator();
    	    	while(it.hasNext()) {
    	    	      String notificationId = it.next();
    	    		 List<AModelNotificationService> notifications = getNotificationProvider().getNotifications().get(notificationId);
    	                if (notifications != null) {
    	                    for (AModelNotificationService notifcationService : notifications) {
    	                        logger.debug("deleteNotification : " + notifcationService.getIdentifier());
    	                        ((ModelNotificationsService) notifcationService.getParent()).removeInactiveNotifications();
    	                    }
    	                    if(!deleteNcr){
    	                    	getNotificationProvider().getNotifications().remove(notificationId);
    	                    }
    	                }
    	                else {
    	                    logger.error("Failed to remove notification " + notificationId + ", not exist in provider");
    	                }
    	    	}
        	}
        	else{
        		success = false;
        	}
            getNotificationProvider().getNotificationsToErase().clear();
    	}
        return success;
    }
    
    
    protected ModelNotificationProvider getNotificationProvider() {
        return ModelNotificationProvider.getInstance();
    }
    
    private NotificationServerInterfaceService getServerInterface() {
        return NotificationServerInterfaceService.getInstance();
    }
}