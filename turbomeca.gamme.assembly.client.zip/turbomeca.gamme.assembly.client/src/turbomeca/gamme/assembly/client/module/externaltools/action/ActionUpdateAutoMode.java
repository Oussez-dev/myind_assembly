package turbomeca.gamme.assembly.client.module.externaltools.action;

import turbomeca.gamme.assembly.client.model.edit.instructions.ModelTaskPilotingService;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.model.provider.ModelXmlProvider;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.client.module.action.AActionModify;

public class ActionUpdateAutoMode extends AActionModify{
	
	private String taskPilotingId;
	private boolean autoMode;

	public ActionUpdateAutoMode(String taskPilotingId, boolean autoMode) {
		this.taskPilotingId = taskPilotingId;
		this.autoMode = autoMode;
	}

	@Override
	public boolean run(IController controller) throws ClientException, ClientInterruption {
		ModelTaskPilotingService taskPilotingService = (ModelTaskPilotingService) getModelProvider().getModelService(taskPilotingId);
		taskPilotingService.setAutoMode(autoMode);
		getModelProvider().setModelStatus(ModelXmlProvider.MODEL_STATUS_MODIFIED);
		return false;
	}
	
}
