package turbomeca.gamme.assembly.client.module.sap.action.comparator;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.services.model.data.Identification;
import turbomeca.gamme.assembly.services.model.data.Instanciation;
import turbomeca.gamme.assembly.services.utils.SapUtils;
import turbomeca.gamme.ecran.client.module.sap.SapAnalyse;
import turbomeca.gamme.ecran.server.ws.sap.client.model.ASapContext;
import turbomeca.gamme.ecran.server.ws.sap.client.model.ExtractUfi.SapExtractUFIResponseContext;


public class ActionSapComparatorIntervention extends AActionScheduleComparator {
	
	private static Logger logger = Logger.getLogger(ActionSapComparatorIntervention.class);
	
	public static final String MAP_KEY = "intervention.analyse.key";

	@Override
	protected List<SapAnalyse> compare(Instanciation instanciation, Identification identification,
			ASapContext<?> sapContext) {
		
		logger.info("[SAP] Analyse change intervention from SAP");

		SapExtractUFIResponseContext sContext = (SapExtractUFIResponseContext) sapContext;
		
		List<SapAnalyse> result = new ArrayList<SapAnalyse>();
		
		String sapIntervention = SapUtils.getTypeIntervention(sContext.getEntetes().get(0).getTypeIntervention());
		String iIntervention = instanciation.getInterventionType();
		
		if (sapIntervention.compareTo(iIntervention) != 0) {
			logger.info("[SAP] Intervention changed as SAP: " + sapIntervention + " whereas " + iIntervention);
			result.add(SapAnalyse.updateValue(Arrays.asList(iIntervention), Arrays.asList(sapIntervention)));
		}
		
		return result;
	}
	
	@Override
	protected String getMapKey() {
		return MAP_KEY;
	}

}
