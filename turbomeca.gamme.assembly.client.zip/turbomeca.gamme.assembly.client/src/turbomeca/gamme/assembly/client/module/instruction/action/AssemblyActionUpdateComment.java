package turbomeca.gamme.assembly.client.module.instruction.action;

import turbomeca.gamme.assembly.client.ClientAssemblyException;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.client.module.instruction.action.ActionNotApplicatedSubPhase;
import turbomeca.gamme.ecran.client.module.instruction.action.ActionUpdateComment;

public class AssemblyActionUpdateComment extends ActionUpdateComment {

	private String comment;
	private String objectId;
	
	public AssemblyActionUpdateComment(String objectId, String comment){
		super(objectId, comment);
	}

	@Override
	public boolean run(IController controller) throws ClientException, ClientInterruption {
		if(comment != null && !comment.equals("")) {
			super.run(controller);
			new ActionNotApplicatedSubPhase(getObjectId()).run(controller);
			return true;
		}
		else {
			throw new ClientAssemblyException(ClientAssemblyException.EXCEPTION_EMPTY_COMMENT);
		}
	}

	/**
	 * @param comment the comment to set
	 */
	public void setComment(String comment) {
		this.comment = comment;
	}

	/**
	 * @return the comment
	 */
	public String getComment() {
		return comment;
	}

	public String getObjectId() {
		return objectId;
	}

	public void setObjectId(String objectId) {
		this.objectId = objectId;
	}
}
