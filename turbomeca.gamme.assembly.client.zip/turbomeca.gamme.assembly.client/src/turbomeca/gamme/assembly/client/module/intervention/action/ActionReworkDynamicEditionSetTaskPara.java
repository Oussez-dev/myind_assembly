package turbomeca.gamme.assembly.client.module.intervention.action;

import turbomeca.gamme.assembly.client.module.intervention.InterventionReworkDynamicManager;
import turbomeca.gamme.assembly.services.model.data.Task;
import turbomeca.gamme.assembly.services.model.data.TaskChoiceItem;
import turbomeca.gamme.assembly.services.model.data.TaskPara;
import turbomeca.gamme.assembly.services.model.data.TasksItem;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.module.IController;

public class ActionReworkDynamicEditionSetTaskPara extends AActionReworkDynamic {

    private String taskId;
    private String taskParaId;
    private String value;
    
    public ActionReworkDynamicEditionSetTaskPara(InterventionReworkDynamicManager reworkManager,
            String taskId, String taskParaId, String value) {
        super(reworkManager);
        setTaskId(taskId);
        setTaskParaId(taskParaId);
        setValue(value);
    }

    @Override
    public boolean run(IController controller) throws ClientException {
        for(TasksItem tasksItem : getReworkManager().getSubPhaseEdited().getTasks().getTasksItem()) {
            Task task = tasksItem.getTask();
            if (task.getId().equals(getTaskId())) {
                for(TaskChoiceItem taskChoiceItem : task.getTaskChoice().getTaskChoiceItem()) {
                    TaskPara taskPara = taskChoiceItem.getTaskPara(); 
                    if (taskPara != null && taskPara.getId().equals(getTaskParaId())) {
                        taskPara.getTaskParaTypeItem(0).getPara().setContent(getValue());
                    }
                }
            }
        }
        return true;
    }

    /**
     * @return the taskId
     */
    public String getTaskId() {
        return taskId;
    }

    /**
     * @param taskId the taskId to set
     */
    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    /**
     * @return the taskParaId
     */
    public String getTaskParaId() {
        return taskParaId;
    }

    /**
     * @param taskParaId the taskParaId to set
     */
    public void setTaskParaId(String taskParaId) {
        this.taskParaId = taskParaId;
    }

    /**
     * @return the value
     */
    public String getValue() {
        return value;
    }

    /**
     * @param value the value to set
     */
    public void setValue(String value) {
        this.value = value;
    }
}