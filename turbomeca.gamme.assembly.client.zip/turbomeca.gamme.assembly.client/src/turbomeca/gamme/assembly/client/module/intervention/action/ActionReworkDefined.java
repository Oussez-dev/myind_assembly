package turbomeca.gamme.assembly.client.module.intervention.action;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.rits.cloning.Cloner;

import turbomeca.gamme.assembly.client.model.edit.IModelAssemblyWrapperScheduleService;
import turbomeca.gamme.assembly.services.constants.AssemblyXsltConstants;
import turbomeca.gamme.assembly.services.model.data.Operation;
import turbomeca.gamme.assembly.services.model.data.Operations;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.constants.PropertyConstants;
import turbomeca.gamme.ecran.client.interfaces.server.runtime.RuntimeServerInterfaceService;
import turbomeca.gamme.ecran.client.model.interfaces.IModelObjectService;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.services.common.constants.GlobalConstants;
import turbomeca.gamme.ecran.services.common.utils.transformer.ModelTransformation;
import turbomeca.gamme.ecran.services.common.utils.xml.ModelXmlDaoService;
import turbomeca.gamme.ecran.services.constants.XsltConstants;

public class ActionReworkDefined extends AActionRework {

    /** The rework operations identifiers */
    private String operationsId;
    
    private static Cloner cloner = new Cloner();
    
    /**
     * 
     * @param operationsId
     */
    public ActionReworkDefined(String operationsId) {
        setOperationsId(operationsId);
        cloner.dontClone(Operations.class);
    }

    @Override
    public boolean run(IController controller) throws ClientException, ClientInterruption {
    	boolean success = true;
        if (getOperationsId() == null || getOperationsId().isEmpty()) {
            throw new ClientException();
        }

        try {
            // Disable notification
            controller.getNotificationsService().setDisableNotifications(true);
            
            boolean isAlive = RuntimeServerInterfaceService.getInstance().isAlive();
			if (isAlive) {
            // Increase passing identifier
            IModelObjectService modelScheduleService = getModelProvider().getModelScheduleService();
            IModelAssemblyWrapperScheduleService wrapper = (IModelAssemblyWrapperScheduleService) modelScheduleService.getWrapperService();
            int passingId = wrapper.getPassingId() + 1;
            
            // Build temporary operations object with all operations to add
            List<String> operationsIdToAdd = new ArrayList<String>(Arrays.asList(getOperationsId().split(GlobalConstants.SEPARATOR_DOT_COMA)));
            Operations operationsReworkSelected = new Operations();
            for(Operation operation : wrapper.getRework().getOperation()) {
                if (operationsIdToAdd.contains(operation.getId())) {
                    Operation operationCloned = cloner.deepClone(operation);
                    operationsReworkSelected.addOperation(operationCloned);
                }
            }
            
            // Apply XSLT transformation to build new identifiers and their references
            ModelTransformation transformer = null;
            try {
                transformer = new ModelTransformation(XsltConstants.XSLT_TRANSFORM_REWORK_DEFINED.value());
                transformer.addParameter(AssemblyXsltConstants.XSLT_PARAMETER_PASSING_ID.value(), passingId);
                if (!transformer.transformToStream(operationsReworkSelected)) {
                    throw new ClientException();
                }
            } catch(Exception e) {
                throw new ClientException();
            }
            
            // Load XSLT transformations
            ModelXmlDaoService modelXmlDaoService = new ModelXmlDaoService();
            modelXmlDaoService.setObjectClass(Operations.class);
            if (!modelXmlDaoService.setXmlModel(transformer.getResultStream())) {
                throw new ClientException();
            }
            
            addReworkOperations((Operations) modelXmlDaoService.getObject(), passingId);
            (new ActionUpdateScheduleTopStartOperation()).run(controller);
            controller.getNotificationsService().setModelReload();
			}
			else{
				getLoggerHmi().error(PropertyConstants.PROPERTY_ERROR_COMMUNICATION);
			}
        } finally {
            controller.getNotificationsService().setDisableNotifications(false);
            success = false;
        }
        return success;
    }

    /**
     * @return the operationsId
     */
    public String getOperationsId() {
        return operationsId;
    }

    /**
     * @param operationsId the operationsId to set
     */
    public void setOperationsId(String operationsId) {
        this.operationsId = operationsId;
    }
}