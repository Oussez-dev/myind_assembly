package turbomeca.gamme.assembly.client.module.instruction;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.engine.EngineConfigAssembly;
import turbomeca.gamme.assembly.client.model.edit.schedule.AAssemblyScheduleService;
import turbomeca.gamme.assembly.client.model.edit.schedule.AssemblyScheduleService;
import turbomeca.gamme.assembly.client.module.instruction.action.ActionAlterableSubPhase;
import turbomeca.gamme.assembly.client.module.instruction.action.ActionCheckValidateScheduleAssembly;
import turbomeca.gamme.assembly.client.module.instruction.action.ActionDuplicateInput;
import turbomeca.gamme.assembly.client.module.instruction.action.AssemblyActionNotApplicatedSubPhase;
import turbomeca.gamme.assembly.client.module.instruction.action.AssemblyActionUpdateComment;
import turbomeca.gamme.assembly.client.module.instruction.action.ActionSetInput;
import turbomeca.gamme.assembly.client.module.instruction.action.ActionSetInputChoiceManual;
import turbomeca.gamme.assembly.client.module.instruction.action.ActionSetInputDocument;
import turbomeca.gamme.assembly.client.module.instruction.action.ActionSetPictureInSchedule;
import turbomeca.gamme.assembly.client.module.instruction.action.ActionSwitchAlternative;
import turbomeca.gamme.ecran.client.module.instruction.action.ActionUpdateComment;
import turbomeca.gamme.assembly.client.module.instruction.action.ActionUpdateReferences;
import turbomeca.gamme.assembly.client.module.instruction.action.ActionValidateInput;
import turbomeca.gamme.assembly.client.module.instruction.action.ActionValidateSchedule;
import turbomeca.gamme.assembly.client.module.instruction.view.ChangeInputChoiceManualView;
import turbomeca.gamme.assembly.client.module.instruction.view.InstructionView;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.IClientControllersProvider;
import turbomeca.gamme.ecran.client.constants.PropertyConstants;
import turbomeca.gamme.ecran.client.context.ContextRequest;
import turbomeca.gamme.ecran.client.engine.AModelServiceEngineConfig;
import turbomeca.gamme.ecran.client.engine.IModelServiceEngineListener;
import turbomeca.gamme.ecran.client.model.provider.ModelXmlProvider;
import turbomeca.gamme.ecran.client.module.instruction.ADefaultInstructionController;
import turbomeca.gamme.ecran.client.module.instruction.IInstructionNotificationListener;
import turbomeca.gamme.ecran.client.module.instruction.action.ActionCheckValidateSchedule;
import turbomeca.gamme.ecran.client.module.instruction.view.IInstructionView;
import turbomeca.gamme.ecran.services.common.config.RepositoryService;
import turbomeca.gamme.ecran.services.common.constants.OpenMode;

/**
 * 
 * @author Sopra Group
 */
public class InstructionController extends ADefaultInstructionController {

	/** logger for current class */
	private static Logger logger = Logger.getLogger(InstructionController.class);

	/** Save input Picture value */
	private String valuePictureFromCheck = null;


	/**
	 * Constructor
	 */
	public InstructionController(IClientControllersProvider provider) {
		super(provider);
	}

	@Override
	public boolean init() throws ClientException, ClientInterruption {

		if (    (getConfiguration().getConfigRange().getWritingMode() == OpenMode.OPEN_MODE_MULTI_EDIT
				||  getConfiguration().getConfigRange().getWritingMode() == OpenMode.OPEN_MODE_EDIT)
				&& getModelProvider().getModelStatus() != ModelXmlProvider.MODEL_STATUS_INVALID) {
			getNotificationsService().setDisableNotifications(true);
			getContext().getContextRequest().setRequestType(ContextRequest.STARTUP_CLEAR);
			try {
				boolean deleteInstructionNotFinished = getContext().getContextConfig().getDeleteInstructionsNotFinished();
				if(deleteInstructionNotFinished) {
					getLoggerHmi().info(PropertyConstants.PROPERTY_RANGE_SUBPHASE_DELETE);
				}
				((AAssemblyScheduleService) getModelProvider().getModelScheduleService()).prepareModel(deleteInstructionNotFinished);
			} catch (ClientException e) {
				logger.debug("InstructionController - prepareModel - ", e);
			} catch (ClientInterruption e) {
				logger.debug("InstructionController - prepareModel - ", e);
			}

			getContext().getContextRequest().clear();
			getNotificationsService().setDisableNotifications(false);
		}

		return super.init();
	}
	
	
	@Override
	protected IInstructionView createInstructionView() {
		return new InstructionView(getScheduleService());
	}

	@Override
	protected IModelServiceEngineListener createEngineListener() {
		AModelServiceEngineConfig engineConfig = new EngineConfigAssembly();
		engineConfig.setManageDomain(false);
		getEngine().setEngineConfig(engineConfig);
		return new InstructionEngineListener(this);
	}

	@Override
	protected IInstructionNotificationListener createNotificationListener() {
		return new InstructionNotificationListener(getView());
	}

	/**
	 * 
	 * @return true in succeed, false otherwise
	 */
	@Override
	public void actionCheckInput(String taskActionId, String value) {
		logger.info("actionCheckInput : id=" + taskActionId + " - value=" + value);
		execute(new ActionSetInput(taskActionId, value));
	}
	
	/**
	 * 
	 * @return true in succeed, false otherwise
	 */
	public void actionCheckInputWithOutErrorModal(String taskActionId, String value) {
		logger.info("actionCheckInput : id=" + taskActionId + " - value=" + value);
		execute(new ActionSetInput(taskActionId, value, true));
	}
	
	/**
	 * 
	 * @param taskActionId
	 * @param value
	 * @param groupId
	 * @param itemsId
	 */
	@Override
	public void actionSetInput(String taskActionId, String value) {
		logger.info("actionSetInput : id=" + taskActionId + " - value=" + value);
		execute(new ActionValidateInput(taskActionId, value));
	}
	
	/**
     * 
     * @param taskActionId
     */
	@Override
    public void actionDisplayEnterManualValue(String taskActionId) {
        logger.info("actionDisplayEnterManualValue : [ id=" + taskActionId +" ]");
        execute(new ChangeInputChoiceManualView(taskActionId));
    }
    
	/**
	 * 
	 * @return true in succeed, false otherwise
	 */
	public void actionSetInputChoiceManual(String taskActionId, String value) {
		logger.info("actionSetInputChoiceManual : id=" + taskActionId + " - value=" + value);
		execute(new ActionSetInputChoiceManual(taskActionId, value));
	}

	/**
	 * 
	 * @param comment
	 */
	@Override
	public void actionValidateSchedule(String comment) {
		logger.info("actionValidateSchedule : comment=" + comment);
		execute(new ActionValidateSchedule(comment));
	}


	/**
	 * @param valuePictureFromCheck
	 *            the valuePictureFromCheck to set
	 */
	public void setValuePictureFromCheck(String valuePictureFromCheck) {
		this.valuePictureFromCheck = valuePictureFromCheck;
	}

	/**
	 * @return the valuePictureFromCheck
	 */
	public String getValuePictureFromCheck() {
		return valuePictureFromCheck;
	}

	/**
	 * 
	 * @param subPhaseId
	 * @param alternativeSubPhaseId
	 */
	public void actionSwitchAlternative(String subPhaseId, String alternativeSubPhaseId) {
		logger.info("actionSwitchAlternative : current=" + subPhaseId + " - new="
				+ alternativeSubPhaseId);
		execute(new ActionSwitchAlternative(subPhaseId, alternativeSubPhaseId));
	}
	
	/**
	 * 
	 * @param taskActionId
	 */
	public void actionSetPictureInSchedule(String taskActionId) {
		 logger.info("actionSetPictureInSchedule : taskActionId=" + taskActionId);
	        execute(new ActionSetPictureInSchedule(taskActionId));
	}
	
	/**
     * 
     * @param subPhaseId
     * @param comment
     * @param itemsId
     */
	@Override
    public void actionUnValidateSubPhase(String subPhaseId) {
        logger.info("actionUnValidateSubPhase : id=" + subPhaseId);
        execute(new ActionAlterableSubPhase(subPhaseId));
    }
    
	/**
     * 
     * @param taskActionId
     * @param value
     * @param groupId
     */
    @Override
    public void actionSetInputDocument(String taskActionId, String value) {
        logger.info("actionSetInputDocument : id=" + taskActionId + " - value=" + value);
        execute(new ActionSetInputDocument(taskActionId, value));
    }
   
    /**
     * 
     */
    public void actionUpdateReferences(String subPhaseId) {
        logger.info("actionUpdateReferences element : " + subPhaseId);
        execute(new ActionUpdateReferences(subPhaseId));
    }
    
    /**
     * Duplicate a taskAction
     * 
     * @param taskActionId taskAction identifier to duplicate
     */
    public boolean actionDuplicateInput(String taskActionId) {
        logger.info("actionDuplicateInput : id=" + taskActionId);
        return execute(new ActionDuplicateInput(taskActionId));
    }
    

    @Override
    public void actionNotApplicatedSubPhase(String subPhaseId) {
        logger.info("actionNotApplicatedSubPhase : id=" + subPhaseId);
        execute(new AssemblyActionNotApplicatedSubPhase(subPhaseId));
    }
    
    /**
	 * 
	 * @param objectId
	 * @param groupId
	 * @param itemsId
	 */
    @Override
	public void actionUpdateCommentNonApplicableSubphase(String objectId, String comment) {
		logger.info("actionUpdateComment : id=" + objectId);
		execute(new AssemblyActionUpdateComment(objectId, comment));
	}
    
    /**
	 * 
	 * @param objectId
	 * @param groupId
	 * @param itemsId
	 */
    @Override
	public void actionUpdateComment(String objectId, String comment) {
    	logger.info("actionUpdateComment : id=" + objectId);
		if (execute(new ActionUpdateComment(objectId, comment))) {
			logger.info("actionRefreshPage");
			execute(getView());
		};
	}
    
    @Override
    protected ActionCheckValidateSchedule createActionCheckValidateSchedule() {
    	return new ActionCheckValidateScheduleAssembly();
    }
    
    @Override
    protected boolean isActionCheckValidationApplicable() {
    	if (getModelProvider().getModelScheduleService() instanceof AssemblyScheduleService) {
    		// Specific validation action only in Official context
    		int configIndex = getContext().getContextUser().getConfigIndex();
    		boolean isOfficial = configIndex == RepositoryService.REPOSITORY_OFFICIAL_INDEX;
    		return isOfficial;
    	} else {
    		return false;
    	}
    }
}
