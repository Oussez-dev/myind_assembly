package turbomeca.gamme.assembly.client.module.intervention.action;

import turbomeca.gamme.assembly.client.ClientAssemblyControllersProvider;
import turbomeca.gamme.assembly.client.model.edit.instructions.ModelDerogationMarksService;
import turbomeca.gamme.assembly.client.model.edit.runnable.ModelRunnableScheduleService;
import turbomeca.gamme.assembly.client.model.edit.schedule.AAssemblyScheduleService;
import turbomeca.gamme.assembly.client.model.edit.wrappers.ModelWrapperDerogationMarksService;
import turbomeca.gamme.assembly.client.module.edition.AssemblyEditionController;
import turbomeca.gamme.assembly.services.model.data.DerogationMark;
import turbomeca.gamme.assembly.services.model.data.DerogationMarks;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.interfaces.server.editing.EditingServerInterfaceService;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.client.module.action.AActionModify;

public class ActionDeleteDerogationMark extends AActionModify {

	private String idDerogation;

	public ActionDeleteDerogationMark(String id) {
		setIdDerogation(id);
	}

	@Override
	@Deprecated // Adapt with Jax WS
	public boolean run(IController controller) throws ClientException, ClientInterruption {
		boolean success = true;
		AssemblyEditionController editionController =  (AssemblyEditionController) controller.getControllersProvider().
				getController(ClientAssemblyControllersProvider.INTERFACE_EDITION);
		EditingServerInterfaceService.getInstance().loadEditing();

		if(((ModelRunnableScheduleService)getModelProvider().getModelScheduleService().getRunnableService()).
				canRunForMultiEdition(editionController, getContext().getContextEditing().isOutOfDate())){
			ModelDerogationMarksService modelDerogationService = (ModelDerogationMarksService) getModelProvider()
					.getModelService(ModelWrapperDerogationMarksService.DEROGATION_ID);

			ModelWrapperDerogationMarksService modelWrapperService = (ModelWrapperDerogationMarksService) modelDerogationService
					.getWrapperService();

			DerogationMarks  derogations = modelWrapperService.getDerogationMarks();
			if( derogations !=null ) {
				DerogationMark currentDerogation = modelWrapperService.getDerogationMark(getIdDerogation());

				if(currentDerogation !=null){
					derogations.removeDerogationMark(currentDerogation);
					AAssemblyScheduleService schedule = (AAssemblyScheduleService)modelDerogationService.getParent();
					if( derogations.getDerogationMark().length == 0 ){
						schedule.setDerogationsMarks(null);
					} else {
						schedule.setDerogationsMarks(derogations);
					}
					controller.getNotificationsService().notifyServiceChanged(modelDerogationService);
					controller.getNotificationsService().applyNotifications();
				}else{
					getLoggerHmi().error("No PN Found From Id");
				}
			}
		}
		else{
			success = false;
		}
		return success;
	}
	public void setIdDerogation(String idDerogation) {
		this.idDerogation = idDerogation;
	}

	public String getIdDerogation() {
		return idDerogation;
	}
}
