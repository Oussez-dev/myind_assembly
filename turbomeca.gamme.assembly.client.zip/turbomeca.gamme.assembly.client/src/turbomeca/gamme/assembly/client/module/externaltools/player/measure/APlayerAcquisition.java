package turbomeca.gamme.assembly.client.module.externaltools.player.measure;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.services.model.data.State;
import turbomeca.gamme.assembly.services.model.data.types.StatusType;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.constants.PropertyConstants;
import turbomeca.gamme.ecran.client.context.Context;
import turbomeca.gamme.ecran.client.hmi.HmiLogger;
import turbomeca.gamme.ecran.client.module.externaltools.measure.IPlayerAcquisition;
import turbomeca.gamme.ecran.services.devices.ExternalsToolsExceptions;
import turbomeca.gamme.ecran.services.devices.config.IConfigurationMeasure;

public abstract class APlayerAcquisition implements IPlayerAcquisition {
	
	/**
	 * 
	 */
	private State state;
	
	private ServiceType serviceType;
	
	/**
	 * 
	 */
	private IConfigurationMeasure configurationMeasure;
	
	/**
	 * 
	 */
	private static Logger logger = Logger.getLogger(APlayerAcquisition.class);

	public APlayerAcquisition(ServiceType serviceType) {
		this.serviceType=serviceType;
	}
	
	/**
	 * 
	 * @return
	 * @throws Exception
	 * @throws ClientInterruption 
	 * @throws ExternalsToolsExceptions 
	 */
	public String acquire() throws ExternalsToolsExceptions, ClientInterruption {
		String value = null;
		try {
			value = acquireAcquistion();
			if ("ERR_COMM_TIMEOUT".equals(value)) {
				getState().setStatus(StatusType.KO);
				getLoggerHmi().error(PropertyConstants.PROPERTY_ERROR_TOOLS_MESSAGE_CANT_RUN_PLAYER);
			}
			if (value == null) {
				getState().setStatus(StatusType.KO);
			} else {
				getState().setStatus(StatusType.OK);
			}
		}
		catch (ExternalsToolsExceptions e) {
			logger.error("[PILOTING] : APlayerAcquisition - acquire", e);
			state.setStatus(StatusType.KO);
			getLoggerHmi().error(e.getPropertyKey());
		} 
		catch (Exception e) {
			logger.error("[PILOTING] : APlayerAcquisition - acquire", e);
			state.setStatus(StatusType.KO);
			getLoggerHmi().error(PropertyConstants.PROPERTY_ERROR_INTERNAL_UNKNOWN);
		}
		return value;
	}

	public State getState() {
		return state;
	}

	public void setState(State state) {
		this.state = state;
	}

	public ServiceType getServiceType() {
		return serviceType;
	}

	public IConfigurationMeasure getConfigurationMeasure() {
		return configurationMeasure;
	}

	public void setConfigurationMeasure(
			IConfigurationMeasure configurationMeasure) {
		this.configurationMeasure = configurationMeasure;
	}

	public Context getContext() {
		return Context.getInstance();
	}
	public HmiLogger getLoggerHmi() {
		return HmiLogger.getInstance();
	}
}
