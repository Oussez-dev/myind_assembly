package turbomeca.gamme.assembly.client.module.sap.services;

import java.util.List;

import turbomeca.gamme.assembly.client.model.edit.schedule.AAssemblyScheduleService;
import turbomeca.gamme.ecran.client.AClientInstancesProvider;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.server.ws.sap.client.model.ExtractUfi.SapExtractUFIResponseContext;
import turbomeca.gamme.ecran.server.ws.sap.client.model.ExtractUfi.SapUfiAffaireEntete;

public class UpdateSapScheduleService extends AClientInstancesProvider {

	public void update(AAssemblyScheduleService scheduleService, SapExtractUFIResponseContext sapContext) throws ClientException {
		boolean updated = false;

		List<SapUfiAffaireEntete> entetes = sapContext.getEntetes();
		if (entetes != null && !entetes.isEmpty()) {
//			String property = entetes.get(0).getProperty();//ZDS_CLT_DO();
//			String customer = entetes.get(0).getCustomer();//ZDS_CLT_UT();
//			String snMaterial = entetes.get(0).getSnMaterial();//ZCD_SNAFFAIRE();


//			Instanciation instantiation = scheduleService.getWrapperService().getInstantiation();
			// FIXME Update instanciation
//			updated = false;
		}

//		if (updated) {
//			scheduleService.setModified();
//		}
	}

}
