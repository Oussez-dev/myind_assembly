package turbomeca.gamme.assembly.client.module.sap.action.executor;

import java.util.List;

import org.apache.log4j.Logger;

import turbomeca.gamme.assembly.client.ClientAssemblyException;
import turbomeca.gamme.assembly.client.model.edit.schedule.AAssemblyScheduleService;
import turbomeca.gamme.assembly.client.module.sap.action.comparator.ActionSapComparatorTU;
import turbomeca.gamme.assembly.client.module.sap.action.comparator.ActionSapComparatorVariant;
import turbomeca.gamme.assembly.services.utils.DocTypeUtils;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.ClientInterruption;
import turbomeca.gamme.ecran.client.context.Context;
import turbomeca.gamme.ecran.client.interfaces.server.editing.EditingServerInterfaceService;
import turbomeca.gamme.ecran.client.interfaces.server.runtime.CreateAndSynchronizeScheduleInterfaceService;
import turbomeca.gamme.ecran.client.interfaces.server.schedule.ScheduleServerInterfaceService;
import turbomeca.gamme.ecran.client.model.provider.ModelXmlProvider;
import turbomeca.gamme.ecran.client.module.IController;
import turbomeca.gamme.ecran.client.module.sap.ASapController;
import turbomeca.gamme.ecran.client.module.sap.SapAnalyse;
import turbomeca.gamme.ecran.client.module.sap.action.ASapExecutorAction;
import turbomeca.gamme.ecran.services.common.constants.GlobalConstants;
import turbomeca.gamme.ecran.services.common.utils.string.StringUtil;

public class ActionSapExecutorEffectivity extends ASapExecutorAction {

	/** logger for current class */
	private static Logger logger = Logger.getLogger(ActionSapExecutorEffectivity.class);

	@Override
	public boolean run(IController controller) throws ClientException, ClientInterruption {
		boolean result = false;
		if (super.run(controller)) {
			execute(null, controller);
			result = true;
		}
		return result;
	}


	@Override
	protected void execute(SapAnalyse analyses, IController controller) {
		logger.info("[SAP] Schedule effectivity may changed changed, update schedule");

		ASapController sapController = (ASapController) controller;

		List<SapAnalyse> variantAnalyses = sapController.getSapAnalyse().get(ActionSapComparatorVariant.MAP_KEY);
		List<SapAnalyse> modifAnalyses = sapController.getSapAnalyse().get(ActionSapComparatorTU.MAP_KEY);

		if (!variantAnalyses.isEmpty() || !modifAnalyses.isEmpty()) {
			// Identification des parametres d'instanciation de la gamme
			logger.info("[SAP] Schedule effectivity has changed, update schedule");

			// Update instanciation context
			String docType = updateContext(modifAnalyses != null && !modifAnalyses.isEmpty() ? modifAnalyses.get(0) : null,
					variantAnalyses != null && !variantAnalyses.isEmpty() ? variantAnalyses.get(0) : null);

			// Instantiate new schedule with merge
			String streamResult = CreateAndSynchronizeScheduleInterfaceService.getInstance().createAndSynchronize(docType);

			logger.info("[SAP] WebService Result " + streamResult);
			if (streamResult != null && !streamResult.isEmpty()) {
				// Update and reload model
				AAssemblyScheduleService scheduleModelService = (AAssemblyScheduleService) getModelProvider().getModelScheduleService();

				try {
					if (! ModelXmlProvider.getInstance().setXmlModel(streamResult)) {
						throw new ClientAssemblyException();
					}

					scheduleModelService.getWrapperService().setObject(ModelXmlProvider.getInstance().getObject());
					scheduleModelService.getChildren().clear();
					scheduleModelService.getLoaderService().load(controller.getModelProvider());
					scheduleModelService.setModified();
					scheduleModelService.getStatusService().computeStatus(true);

					ScheduleServerInterfaceService.getInstance().synchronize(true, null);

					EditingServerInterfaceService.getInstance().reload();
				} catch (Exception e) {
					logger.error("change context error", e);
					//			throw new ClientAssemblyException(ClientAssemblyException.EXCEPTION_INTERNAL);
				}

			} else {
				logger.error("Unable to change modification");
			}
		}
	}

	protected String updateContext(SapAnalyse modifAnalyse, SapAnalyse variantAnalyse) {
		List<String> variants = null;
		if (variantAnalyse != null) {
			variants = variantAnalyse.getNewValue();
		}

		String modification = null;
		if (modifAnalyse != null) {
			List<String> modifications = modifAnalyse.getNewValue();
			modification = StringUtil.joinValues(modifications, GlobalConstants.SEPARATOR_DOT_COMA);
		}

		Context contextInstance = CreateAndSynchronizeScheduleInterfaceService.getInstance().getContext();
		if (modification != null) { 
			contextInstance.getContextApplicabilities().setModifications(modification);
		}
		if (variants != null) {
			contextInstance.getContextApplicabilities().setVariant(variants.get(0));
		}

		return DocTypeUtils.getDoctype(contextInstance.getContextRange().getContext(), contextInstance.getContextRange().getType());
	}

	//	protected boolean isEffectivtyChanged(List<String> newModifications, List<String> newVariants) {
	//		AAssemblyScheduleService scheduleService = (AAssemblyScheduleService) getModelProvider().getModelScheduleService();
	//		Parameters parameters = scheduleService.getWrapperService().getParameters();
	//		Instanciation instanciation = scheduleService.getWrapperService().getInstantiation();
	//		
	//		String variant = newVariants != null && !newVariants.isEmpty() ? newVariants.get(0) : instanciation.getVariant();
	//		List<String> modifications = newModifications != null ? newModifications : Arrays.asList(instanciation.getModifications().getModification());
	//		
	//		String currentEffectivity = instanciation.getEffectivity();
	//		String newEffectivity = null;
	//		
	//		Effectivity[] effectivities = parameters.getEffectivities().getEffectivity();
	//		for (Effectivity effectivity : effectivities) {
	//			EffectivityVariant[] evs = effectivity.getEffectivityVariant();
	//			for (EffectivityVariant ev : evs) {
	//				if (ev.getVariant().compareTo(variant) == 0) {
	//					List<String> modifs = Arrays.asList(ev.getModifications().getModification());
	//					if (modifs.containsAll(modifications)) {
	//						newEffectivity = effectivity.getEffectivity();
	//					}
	//				}
	//			}
	//		}
	//		
	//		if (newEffectivity != null && currentEffectivity.compareTo(newEffectivity) == 0) {
	//			logger.error("Effectivity from sap is the same ");
	//			//			throw new 
	//		}
	//
	//		return newEffectivity == null || currentEffectivity.compareTo(newEffectivity) != 0;
	//	}

	@Override
	protected String getMapKey() {
		return ActionSapComparatorTU.MAP_KEY;
	}

}
