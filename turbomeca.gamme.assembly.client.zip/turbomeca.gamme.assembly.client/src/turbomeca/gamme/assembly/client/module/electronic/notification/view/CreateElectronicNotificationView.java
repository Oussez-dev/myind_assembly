package turbomeca.gamme.assembly.client.module.electronic.notification.view;

import turbomeca.gamme.assembly.client.ClientAssemblyException;
import turbomeca.gamme.ecran.client.ClientException;
import turbomeca.gamme.ecran.client.constants.PropertyConstants;
import turbomeca.gamme.ecran.client.module.action.AActionServiceView;
import turbomeca.gamme.ecran.services.constants.XsltConstants;

public class CreateElectronicNotificationView extends AActionServiceView {

    public CreateElectronicNotificationView(String subPhaseId) {
        super(subPhaseId, XsltConstants.XSLT_CREATE_NOTIFICATION_ELECTRONIC_USER.value());
    }

    @Override
    public boolean run() throws ClientException {
        if (!getModelService().getRunnableService().canRun()) {
            throw new ClientAssemblyException(ClientAssemblyException.EXCEPTION_PREDECESSOR_SEQUENCE);
        }
        getView().addParameter(XsltConstants.XSLT_PARAMETER_SUBPHASE_ID.value(), getServiceId());
        return getView().displayModal(PropertyConstants.PROPERTY_MODAL_TITLE_ELECTRONIC_NOTIFICATION, true);
    }
}
