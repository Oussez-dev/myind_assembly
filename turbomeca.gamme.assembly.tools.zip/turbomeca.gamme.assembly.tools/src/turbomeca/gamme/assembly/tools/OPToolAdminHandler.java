package turbomeca.gamme.assembly.tools;

// TMDI

/**
 * Cette classe g�re l'appel au processus de manipulation des fichier et folder
 */

//public class OPToolAdminHandler extends Handler {
//
//	/**
//	 * Constructeur de la classe
//	 * 
//	 * @param _params
//	 *            Objet de la classe "tmdi.server.servlet.RequestParams" qui
//	 *            d�finit les param�tres de la requ�te HTTP qui a �t� re�ue.
//	 */
//	public OPToolAdminHandler(RequestParams _params, HttpServletRequest _request) {
//		this.params = _params;
//		JournalServletPAO.getJournal().log(
//				"== Utilisation du OPToolAdminHandler ==");
//
//	}
//
//	/** M�thode d'ex�cution du processus */
//	public void run() {
//		String toolname = this.params.getParameter("toolname");
//		String action = this.params.getParameter("action");
//		String ip = this.params.getParameter("ip");
//
//		String retval = "";
//
//		JournalServletPAO.getJournal().log(
//				"execution : OPToolAdminHandler.run() " + toolname + " "
//						+ action + " " + ip);
//
//		if (action.equalsIgnoreCase("addTool")) {
//			JournalServletPAO.getJournal().log("OPToolAdminHandler : addTool");
//
//			if (ProcessServlet.toolManager.existsTool(toolname)) {
//
//				this.returnedContent = "OPToolAdminHandler " + action + " "
//						+ toolname + " allready exists";
//				JournalServletPAO.getJournal().log(this.returnedContent);
//				return;
//			}
//			if (ip.length() == 0) {
//				this.returnedContent = "OPToolAdminHandler " + action + " "
//						+ toolname + " no ip specified";
//				JournalServletPAO.getJournal().log(this.returnedContent);
//				return;
//			}
//
//			ProcessServlet.toolManager.addTool(toolname, ip, (short) 4545);
//
//			this.returnedContent = "OPToolAdminHandler " + action + " "
//					+ toolname + " added with ip " + ip;
//			JournalServletPAO.getJournal().log(this.returnedContent);
//			return;
//		} else if (action.equalsIgnoreCase("removeTool")) {
//			JournalServletPAO.getJournal().log(
//					"OPToolAdminHandler : removeTool");
//
//			if (!ProcessServlet.toolManager.existsTool(toolname)) {
//
//				this.returnedContent = "OPToolAdminHandler " + action + " "
//						+ toolname + " does not exist";
//				JournalServletPAO.getJournal().log(this.returnedContent);
//				return;
//			}
//			ProcessServlet.toolManager.removeTool(toolname);
//
//			this.returnedContent = "OPToolAdminHandler " + action + " "
//					+ toolname + " removed";
//			JournalServletPAO.getJournal().log(this.returnedContent);
//			return;
//		} else if (action.equalsIgnoreCase("listTools")) {
//			JournalServletPAO.getJournal()
//					.log("OPToolAdminHandler : listTools");
//
//			LinkedList l = ProcessServlet.toolManager.getToolNames();
//			Iterator it = l.iterator();
//			String name = "";
//			int psets[];
//
//			this.returnedContent = "";
//			while (it.hasNext()) {
//				name = (String) it.next();
//
//				psets = ProcessServlet.toolManager.getToolPSets(name);
//
//				this.returnedContent += "" + name + ","
//						+ ProcessServlet.toolManager.getToolAddress(name) + ","
//						+ ProcessServlet.toolManager.isToolConnected(name)
//						+ ",";
//
//				if (psets != null) {
//					for (int i = 0; i < psets.length; i++) {
//						this.returnedContent += "P" + psets[i] + " ";
//					}
//				} else {
//					this.returnedContent += "?";
//				}
//				this.returnedContent += ";";
//			}
//
//			JournalServletPAO.getJournal().log(this.returnedContent);
//			return;
//		} else {
//			this.returnedContent = "OPToolAdminHandler " + action
//					+ " not supported";
//			JournalServletPAO.getJournal().log(this.returnedContent);
//			return;
//		}
//	} // fin run
//
//	/**
//	 * Cette m�thode retourne le contenu HTML r�sultat du processus et � envoyer
//	 * dans l'objet r�ponse de la servlet
//	 * 
//	 * @return La cha�ne de caract�res g�n�r� � l'ex�cution de la requ�te par le
//	 *         serveur.
//	 */
//	public String getReturnedContent() {
//		return this.returnedContent;
//	}
//
//}
