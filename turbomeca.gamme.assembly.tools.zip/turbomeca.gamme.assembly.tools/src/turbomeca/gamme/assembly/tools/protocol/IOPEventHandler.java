package turbomeca.gamme.assembly.tools.protocol;

/** Interface IOPEventHandler */
public interface IOPEventHandler {
	/** Called by the OPToolManager, when a new pset was selected in the PF tool */
	public void PSetSelected(String toolname, int pset);

	/**
	 * Called by the OPToolManager, when a new vin was received from the PF tool
	 */
	public void NewVIN(String toolname, String vin);

	/**
	 * Called by the OPToolManager, when a tightening at the PF tool was
	 * performed
	 */
	public void NewTGTResult(String toolname, String vin, int pset,
			boolean status, int batch_size, int batch_count,
			boolean batch_status);

	/** Called by the OPToolManager, when the connection to the PF tool was lost */
	public void ConnectionLost(String toolname);

	/**
	 * Called by the OPToolManager, when a pset can not be selected in the PF
	 * tool
	 */
	public void PSetCannotBeSet(String toolname);

}
