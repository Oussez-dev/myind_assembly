package turbomeca.gamme.assembly.tools.protocol;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.LinkedList;

/** class for handling the connection to one tool */
public class OPTool {
	/** TIMEOUT constants */
	public static final int ACK_TIMEOUT = 3500;
	public static final int ALIVE_TIMEOUT = 8000;
	public static final int CONNECT_DELAY = 5000;

	/** Message Identifier */
	public static final int MID_COM_START = 1;
	public static final int MID_COM_ACK = 2;
	public static final int MID_CMD_ERROR = 4;
	public static final int MID_CMD_ACCEPTED = 5;
	public static final int MID_UPLOAD_PSETS = 10;
	public static final int MID_PSET_UPLOAD = 11;
	public static final int MID_PSET_SUBSCRIBE = 14;
	public static final int MID_PSET = 15;
	public static final int MID_PSET_ACK = 16;
	public static final int MID_SELECT_PSET = 18;
	public static final int MID_SET_PSET_BATCH_SIZE = 19;
	public static final int MID_RESET_PSET_BATCH_COUNTER = 20;
	public static final int MID_DISABLE_TOOL = 42;
	public static final int MID_ENABLE_TOOL = 43;
	public static final int MID_VIN_DOWNLOAD = 50;
	public static final int MID_VIN_SUBSCRIBE = 51;
	public static final int MID_VIN_UPLOAD = 52;
	public static final int MID_VIN_UPLOAD_ACK = 53;
	public static final int MID_RESULT_SUBSCRIBE = 60;
	public static final int MID_RESULT_UPLOAD = 61;
	public static final int MID_RESULT_UPLOAD_ACK = 62;
	public static final int MID_DISPLAY_USER_TEXT = 110;
	public static final int MID_KEEP_ALIVE = 9999;

	/** handled Error Codes */
	public static final int ERR_PSET_SUBSCRIBTION_EXISTS = 13;
	public static final int ERR_VIN_SUBSCRIBTION_EXISTS = 6;
	public static final int ERR_RESULT_SUBSCRIBTION_EXISTS = 9;
	public static final int ERR_PSET_CANNOT_BE_SET = 3;

	/** member variables */
	private SocketChannel m_SocketChannel = null;
	/** network connection to the tool */
	private String m_Name;
	private String m_IpAddr;
	private short m_Port;
	private long m_lLastConnectTry = 0;
	/** timestamp of last connect try */
	private ByteBuffer m_InputBuffer;
	/** received bytes */
	private OPTelegram m_WaitingForAckTel = null;
	/** Tel that needs to get a ACK from the tool */
	private LinkedList m_JobList = new LinkedList();
	/** Tel. to send */
	private long m_LastResponseTime;
	/** timestamp of last received tel */
	private LinkedList m_Handlers = new LinkedList();
	/** list of all handlers */
	private int[] m_PSets = null;

	/** array of psets available in the tool */

	/** Constructor of one OPTool */
	OPTool(String name, String ip, short port) {
		m_Name = name;
		m_IpAddr = ip;
		m_Port = port;

		m_InputBuffer = ByteBuffer.allocate(8 * 1024); // 8k input buffer
	}

	/** returns a String with the name, address and connection status */
	public String toString() {
		return "Name: " + getName() + ", Addr: " + getIpAddr() + ", State: "
				+ (isConnected() ? "CONNECTED" : "DISCONNECTED");
	}

	/** returns true if the tool is connected */
	boolean isConnected() {
		return (m_SocketChannel != null && m_SocketChannel.isConnected()) ? true
				: false;
	}

	/** returns the Tool Address */
	String getIpAddr() {
		return m_IpAddr;
	}

	/** returns the tool port */
	short getPort() {
		return m_Port;
	}

	/** returns the tool name */
	String getName() {
		return m_Name;
	}

	/**
	 * returns an array of all available psets in the tool or null if there
	 * where no connection yet
	 */
	public int[] getPSets() {
		return m_PSets;
	}

	/** add a EventHandler for this tool */
	void addHandler(IOPEventHandler h) {
		m_Handlers.add(h);
	}

	/** remove a previously added EventHandler */
	void removeHandler(IOPEventHandler h) {
		m_Handlers.remove(h);
	}

	/** try to connect to the tool */
	private void connect(Selector sel) {
		SelectionKey key;

		m_lLastConnectTry = System.currentTimeMillis();
		m_InputBuffer.clear();

		m_WaitingForAckTel = null;
		m_JobList.clear();

		// initial telegrams -> they will be sended after the connection is
		// established

		m_JobList.add(new OPTelegram(MID_COM_START, true, null, 0)); // ComStart
		m_JobList.add(new OPTelegram(MID_PSET_SUBSCRIBE, true, null, 0)); // PsetSelectedSubscribe
		m_JobList.add(new OPTelegram(MID_VIN_SUBSCRIBE, true, null, 0)); // VinSubscribe
		m_JobList.add(new OPTelegram(MID_RESULT_SUBSCRIBE, true, null, 0)); // ResultSubscribe
		m_JobList.add(new OPTelegram(MID_DISABLE_TOOL, true, null, 0)); // DisableTool
		m_JobList.add(new OPTelegram(MID_UPLOAD_PSETS, true, null, 0)); // Request
																		// a
																		// List
																		// of
																		// available
																		// PSets

		try {
			m_SocketChannel = SocketChannel.open();
			m_SocketChannel.configureBlocking(false); // !!! async !!! (do not
														// block other tools)
			// m_SocketChannel.connect( new InetSocketAddress(m_IpAddr, m_Port)
			// );
			InetSocketAddress isa = new InetSocketAddress(m_IpAddr, m_Port);
			// Test pour savoir si la visseuse est connue sur le r�seau
			// Car si elle n'est pas connue, la boucle plante et on ne voit
			// aucune visseuse
			if (!isa.isUnresolved()) {
				m_SocketChannel.connect(isa);
				key = m_SocketChannel.register(sel, SelectionKey.OP_CONNECT); // register
																				// for
																				// a
																				// CONNECT
																				// event
				key.attach(this);
			} else {
				m_SocketChannel = null;
			}

		} catch (IOException e) {
			e.printStackTrace();
			m_SocketChannel = null; // try again later
		}
	}

	/** called just before the tool is removed from the Manager */
	void finish(Selector sel) {
		// tool is about to be removed, deregister from the selector
		SelectionKey key;

		if (m_SocketChannel != null) {
			key = m_SocketChannel.keyFor(sel);
			if (key != null) {
				key.cancel();
				key.attach(null);
			}

			try {
				m_SocketChannel.close();
			} catch (IOException e2) {
			}
			m_SocketChannel = null;
		}
	}

	/** called from the Manager to ask the tool "what do you want to do next?" */
	int fillSelector(Selector sel) {
		int timeout = 500;
		SelectionKey key;
		long now;
		int mask;

		try {
			if (m_SocketChannel != null
					&& !m_SocketChannel.isConnectionPending()
					&& !m_SocketChannel.isOpen()) {
				// channel is now closed
				// System.err.println( getName() + ": socket closed" );

				key = m_SocketChannel.keyFor(sel);
				if (key != null) {
					key.cancel();
				}
				m_SocketChannel = null;

				// inform the handlers
				IOPEventHandler h;
				Iterator it = m_Handlers.iterator();
				while (it.hasNext()) {
					h = (IOPEventHandler) it.next();
					h.ConnectionLost(getName());
				}
			}

			if (m_SocketChannel == null) {
				// (re-) connect
				now = System.currentTimeMillis();
				if (now > m_lLastConnectTry + CONNECT_DELAY) {
					connect(sel);
				} else {
					// wait before trying to reconnect
					timeout = (int) ((m_lLastConnectTry + CONNECT_DELAY) - now) + 20;
				}
			} else if (m_SocketChannel.isConnected()) {
				// calc max timeout
				now = System.currentTimeMillis();
				if (m_WaitingForAckTel == null) {
					timeout = (int) (m_LastResponseTime + ALIVE_TIMEOUT - now);
					if (timeout < 500) {

						if (m_JobList.size() == 0) {
							m_JobList.add(0, new OPTelegram(MID_KEEP_ALIVE,
									true, null, 0)); // enqueue alive tel
						}
						timeout = 500;
					}
				} else {
					timeout = (int) (m_WaitingForAckTel.getSendTime()
							+ ACK_TIMEOUT - now);
				}

				if (timeout < 0) {
					// a request has not been answered
					try {
						m_SocketChannel.close();
					} catch (IOException e2) {
					}
					return 500;
				}

				// connected wait for readable
				mask = SelectionKey.OP_READ;

				// and wait for writable if nessesary
				if (m_JobList.size() != 0) {
					OPTelegram tel = (OPTelegram) m_JobList.get(0);
					// if tel needs no ACK it can be written even if we are
					// waiting
					// for another ACK tel
					if ((!tel.needsAck() || m_WaitingForAckTel == null)
							&& tel.needsToBeWritten())
						mask |= SelectionKey.OP_WRITE;
				}

				// System.out.println( getName() + ": register mask " + mask );
				key = m_SocketChannel.register(sel, mask);
				key.attach(this);

			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return timeout;
	}

	/** called by the manager, when the socket is connectable */
	void connectable() {
		try {
			m_SocketChannel.finishConnect();
		} catch (IOException e) {
			// async connect failed, retry in fillSelector
			// System.out.println( getName() + ": " + e.toString() );
		}
	}

	/** called by the manager, when the socket is readable */
	void readable() {
		int num;
		int pos;

		try {
			num = m_SocketChannel.read(m_InputBuffer);

			if (num == -1) {
				// System.out.println( getName() +
				// ": connection closed by peer");
				m_SocketChannel.close();
			}
			// System.out.println( getName() + ": read "+ num + " bytes");

		} catch (IOException e) {
			// System.out.println( getName() + ": " + e.toString() );
			try {
				m_SocketChannel.close();
			} catch (IOException e2) {
			}
		}

		// handle all complete tels
		pos = m_InputBuffer.position();
		for (int i = 0; i < pos; i++) {
			if (m_InputBuffer.get(i) == 0) {
				if (!handleTelegram(m_InputBuffer.array(), i)) {
					// Tel ERROR, close and reconnect
					try {
						m_SocketChannel.close();
					} catch (IOException e2) {
					}
					return;
				}
				m_InputBuffer.position(i + 1);
				m_InputBuffer.compact();
				pos -= (i + 1);
				m_InputBuffer.position(pos);
				i = -1;
			}
		}
	}

	/** called by the manager, when the socket is writable */
	void writable() {
		if (m_JobList.size() == 0)
			return;

		OPTelegram tel = (OPTelegram) m_JobList.get(0);

		if (tel.needsAck() && m_WaitingForAckTel != null)
			return;

		if (tel.needsToBeWritten()) {
			// System.out.println( getName() + ": S: " + tel.toString() );
			tel.write(m_SocketChannel);
		}

		if (!tel.needsToBeWritten()) {
			// completely written so remove it from JobList
			if (tel.needsAck())
				m_WaitingForAckTel = tel;
			m_JobList.remove(0);
		}
	}

	/** handles a CMD_ERROR message */
	private boolean _handle_tel_cmd_error(byte[] tel, int bytes) {
		if (bytes < 26)
			return false; // Invalid Tel, close connection

		int mid = ((char) tel[20] - '0') * 1000 + ((char) tel[21] - '0') * 100
				+ ((char) tel[22] - '0') * 10 + ((char) tel[23] - '0');

		int err = ((char) tel[24] - '0') * 10 + ((char) tel[25] - '0');

		switch (mid) {
		case MID_PSET_SUBSCRIBE:

			if (m_WaitingForAckTel != null
					&& m_WaitingForAckTel.getMID() == MID_PSET_SUBSCRIBE)
				m_WaitingForAckTel = null;

			if (err != ERR_PSET_SUBSCRIBTION_EXISTS) {
				// System.out.println( getName() +
				// ": Got CmdError with unknown errcode " + err +
				// " for PSET_SUBSCRIBE" );
				return false; // close connection
			}
			// System.out.println( getName() +
			// ": Got CmdError for PSET_SUBSCRIBE: allready subscribed" );
			return true;

		case MID_VIN_SUBSCRIBE:

			if (m_WaitingForAckTel != null
					&& m_WaitingForAckTel.getMID() == MID_VIN_SUBSCRIBE)
				m_WaitingForAckTel = null;

			if (err != ERR_VIN_SUBSCRIBTION_EXISTS) {
				// System.out.println( getName() +
				// ": Got CmdError with unknown errcode " + err +
				// " for VIN_SUBSCRIBE" );
				return false; // close connection
			}
			// System.out.println( getName() +
			// ": Got CmdError for VIN_SUBSCRIBE: allready subscribed" );
			return true;

		case MID_RESULT_SUBSCRIBE:

			if (m_WaitingForAckTel != null
					&& m_WaitingForAckTel.getMID() == MID_RESULT_SUBSCRIBE)
				m_WaitingForAckTel = null;

			if (err != ERR_RESULT_SUBSCRIBTION_EXISTS) {
				// System.out.println( getName() +
				// ": Got CmdError with unknown errcode " + err +
				// " for RESULT_SUBSCRIBE" );
				return false; // close connection
			}
			// System.out.println( getName() +
			// ": Got CmdError for RESULT_SUBSCRIBE: allready subscribed" );
			return true;

		case MID_SELECT_PSET:

			if (m_WaitingForAckTel != null
					&& m_WaitingForAckTel.getMID() == MID_SELECT_PSET)
				m_WaitingForAckTel = null;

			if (err != ERR_PSET_CANNOT_BE_SET) {
				// System.out.println( getName() +
				// ": Got CmdError with unknown errcode " + err +
				// " for SELECT_PSET" );
				return false; // close connection
			}

			// Inform the handlers
			IOPEventHandler h;
			Iterator it = m_Handlers.iterator();
			while (it.hasNext()) {
				h = (IOPEventHandler) it.next();
				h.PSetCannotBeSet(getName());
			}

			// System.out.println( getName() +
			// ": Got CmdError for SELECT_PSET: pset cannot be set" );
			return false; // close connection

		default:
			// System.out.println( getName() +
			// ": Got CmdError for unknown request" );
			return false; // close connection
		}
	}

	/** handles a CMD_ACCEPTED message */
	private boolean _handle_tel_cmd_accepted(byte[] tel, int bytes) {
		if (bytes < 24)
			return false; // Invalid Tel, close connection

		int mid = ((char) tel[20] - '0') * 1000 + ((char) tel[21] - '0') * 100
				+ ((char) tel[22] - '0') * 10 + ((char) tel[23] - '0');

		switch (mid) {
		case MID_PSET_SUBSCRIBE:
			// System.out.println( getName() +
			// ": Got CmdAccepted for PSET_SUBSCRIBE" );
			if (m_WaitingForAckTel != null
					&& m_WaitingForAckTel.getMID() == MID_PSET_SUBSCRIBE)
				m_WaitingForAckTel = null;
			return true;
		case MID_VIN_SUBSCRIBE:
			// System.out.println( getName() +
			// ": Got CmdAccepted for VIN_SUBSCRIBE" );
			if (m_WaitingForAckTel != null
					&& m_WaitingForAckTel.getMID() == MID_VIN_SUBSCRIBE)
				m_WaitingForAckTel = null;
			return true;
		case MID_RESULT_SUBSCRIBE:
			// System.out.println( getName() +
			// ": Got CmdAccepted for RESULT_SUBSCRIBE" );
			if (m_WaitingForAckTel != null
					&& m_WaitingForAckTel.getMID() == MID_RESULT_SUBSCRIBE)
				m_WaitingForAckTel = null;
			return true;
		case MID_SELECT_PSET:
			// System.out.println( getName() +
			// ": Got CmdAccepted for SELECT_PSET" );
			if (m_WaitingForAckTel != null
					&& m_WaitingForAckTel.getMID() == MID_SELECT_PSET)
				m_WaitingForAckTel = null;
			return true;
		case MID_SET_PSET_BATCH_SIZE:
			// System.out.println( getName() +
			// ": Got CmdAccepted for SET_PSET_BATCH_SIZE" );
			if (m_WaitingForAckTel != null
					&& m_WaitingForAckTel.getMID() == MID_SET_PSET_BATCH_SIZE)
				m_WaitingForAckTel = null;
			return true;
		case MID_RESET_PSET_BATCH_COUNTER:
			// System.out.println( getName() +
			// ": Got CmdAccepted for RESET_PSET_BATCH_COUNTER" );
			if (m_WaitingForAckTel != null
					&& m_WaitingForAckTel.getMID() == MID_RESET_PSET_BATCH_COUNTER)
				m_WaitingForAckTel = null;
			return true;
		case MID_DISABLE_TOOL:
			// System.out.println( getName() +
			// ": Got CmdAccepted for DISABLE_TOOL" );
			if (m_WaitingForAckTel != null
					&& m_WaitingForAckTel.getMID() == MID_DISABLE_TOOL)
				m_WaitingForAckTel = null;
			return true;
		case MID_ENABLE_TOOL:
			// System.out.println( getName() +
			// ": Got CmdAccepted for ENABLE_TOOL" );
			if (m_WaitingForAckTel != null
					&& m_WaitingForAckTel.getMID() == MID_ENABLE_TOOL)
				m_WaitingForAckTel = null;
			return true;
		case MID_VIN_DOWNLOAD:
			// System.out.println( getName() +
			// ": Got CmdAccepted for VIN_DOWNLOAD" );
			if (m_WaitingForAckTel != null
					&& m_WaitingForAckTel.getMID() == MID_VIN_DOWNLOAD)
				m_WaitingForAckTel = null;
			return true;
		case MID_DISPLAY_USER_TEXT:
			// System.out.println( getName() +
			// ": Got CmdAccepted for DISPLAY_USER_TEXT" );
			if (m_WaitingForAckTel != null
					&& m_WaitingForAckTel.getMID() == MID_DISPLAY_USER_TEXT)
				m_WaitingForAckTel = null;
			return true;

		default:
			// System.out.println( getName() +
			// ": Got CmdAccepted for unknown request" );
			return false; // close connection
		}
	}

	/** handles a PSET_SELECTED message */
	private boolean _handle_tel_pset_selected(byte[] tel, int bytes) {
		if (bytes < 42)
			return false; // Invalid Tel, close connection

		int pset = ((char) tel[20] - '0') * 100 + ((char) tel[21] - '0') * 10
				+ ((char) tel[22] - '0');

		// Inform the handlers
		IOPEventHandler h;
		Iterator it = m_Handlers.iterator();
		while (it.hasNext()) {
			h = (IOPEventHandler) it.next();
			h.PSetSelected(getName(), pset);
		}

		// System.out.println( getName() + ": Got PSet selected " + pset );

		// send an ACK to the tool
		int index = 0;
		if (m_JobList.size() != 0
				&& ((OPTelegram) m_JobList.get(0)).getSendTime() != 0)
			index = 1;
		m_JobList.add(index, new OPTelegram(MID_PSET_ACK, false, null, 0));

		return true;
	}

	/** handles a VIN_UPLOAD message */
	private boolean _handle_tel_vin_upload(byte[] tel, int bytes) {
		if (bytes < 45)
			return false; // Invalid Tel, close connection

		String vin = new String(tel, 20, 25);

		// Inform the handlers
		IOPEventHandler h;
		Iterator it = m_Handlers.iterator();
		while (it.hasNext()) {
			h = (IOPEventHandler) it.next();
			h.NewVIN(getName(), vin);
		}

		// System.out.println( getName() + ": Got VIN '" + vin + "'");

		// send an ACK to the tool
		int index = 0;
		if (m_JobList.size() != 0
				&& ((OPTelegram) m_JobList.get(0)).getSendTime() != 0)
			index = 1;
		m_JobList
				.add(index, new OPTelegram(MID_VIN_UPLOAD_ACK, false, null, 0));

		return true;
	}

	/** handles a RESULT_UPLOAD message */
	private boolean _handle_tel_result_upload(byte[] tel, int bytes) {
		if (bytes < 231)
			return false; // Invalid Tel, close connection

		int offset = 20;

		// Cell ID
		offset += 2 + 4;
		// Channel id
		offset += 2 + 2;
		// TC Nane
		offset += 2 + 25;
		// vin
		String vin = new String(tel, offset + 2, 25);
		offset += 2 + 25;
		// Job No
		offset += 2 + 2;
		// PSet
		int pset = ((char) tel[offset + 2] - '0') * 100
				+ ((char) tel[offset + 3] - '0') * 10
				+ ((char) tel[offset + 4] - '0');
		offset += 2 + 3;
		// Batch Size
		int batch_size = ((char) tel[offset + 2] - '0') * 1000
				+ ((char) tel[offset + 3] - '0') * 100
				+ ((char) tel[offset + 4] - '0') * 10
				+ ((char) tel[offset + 5] - '0');
		offset += 2 + 4;
		// Batch Counter
		int batch_count = ((char) tel[offset + 2] - '0') * 1000
				+ ((char) tel[offset + 3] - '0') * 100
				+ ((char) tel[offset + 4] - '0') * 10
				+ ((char) tel[offset + 5] - '0');
		offset += 2 + 4;
		// Status
		boolean status = ((char) tel[offset + 2] == '1');
		offset += 2 + 1;
		// Torque Status
		offset += 2 + 1;
		// Angle Status
		offset += 2 + 1;
		// Torque min
		offset += 2 + 6;
		// Torque max
		offset += 2 + 6;
		// Torque Final Target
		offset += 2 + 6;
		// Torque
		offset += 2 + 6;
		// Angle min
		offset += 2 + 5;
		// Angle max
		offset += 2 + 5;
		// Angle Final Target
		offset += 2 + 5;
		// Angle
		offset += 2 + 5;
		// Timestamp
		offset += 2 + 19;
		// Timestamp PSet
		offset += 2 + 19;
		// Batch Status
		boolean batch_status = ((char) tel[offset + 2] == '1');
		offset += 2 + 1;
		// TGT ID
		offset += 2 + 10;

		// Inform the handlers
		IOPEventHandler h;
		Iterator it = m_Handlers.iterator();
		while (it.hasNext()) {
			h = (IOPEventHandler) it.next();
			h.NewTGTResult(getName(), vin, pset, status, batch_size,
					batch_count, batch_status);
		}

		// System.out.println( getName() + ": Got RESULT:");
		// System.out.println( "\tVIN:         " + vin);
		// System.out.println( "\tPSet:        " + pset);
		// System.out.println( "\tBatchSize:   " + batch_size);
		// System.out.println( "\tBatchCount:  " + batch_count);
		// System.out.println( "\tBatchStatus: " + batch_status);
		// System.out.println( "\tStatus:      " + status);

		// Send an ACK to the tool
		int index = 0;
		if (m_JobList.size() != 0
				&& ((OPTelegram) m_JobList.get(0)).getSendTime() != 0)
			index = 1;
		m_JobList.add(index, new OPTelegram(MID_RESULT_UPLOAD_ACK, false, null,
				0));

		return true;
	}

	/** handles a PSET_UPLOAD message */
	private boolean _handle_tel_pset_upload(byte[] tel, int bytes) {
		if (m_WaitingForAckTel != null
				&& m_WaitingForAckTel.getMID() == MID_UPLOAD_PSETS)
			m_WaitingForAckTel = null;

		if (bytes < 23)
			return false; // Invalid Tel, close connection

		int offset = 20;

		int number = ((char) tel[offset] - '0') * 100
				+ ((char) tel[offset + 1] - '0') * 10
				+ ((char) tel[offset + 2] - '0');
		offset += 3;

		if (bytes < 23 + number * 3)
			return false; // Invalid Tel, close connection

		m_PSets = new int[number];
		for (int i = 0; i < number; i++) {
			m_PSets[i] = ((char) tel[offset] - '0') * 100
					+ ((char) tel[offset + 1] - '0') * 10
					+ ((char) tel[offset + 2] - '0');

			offset += 3;
		}

		// System.out.print( getName() + ": Got PSET UPLOAD: ");
		// for ( int i = 0; i < number ; i++ )
		// {
		// System.out.print( " " + m_PSets[i]);
		// }
		// System.out.println( "" );

		return true;
	}

	/** handles a full received telegramm */
	public boolean handleTelegram(byte[] tel, int bytes) {
		m_LastResponseTime = System.currentTimeMillis();

		// System.out.print( getName() + ": R: " );
		// for ( int i=0; i<bytes; i++ ) {
		// System.out.print( (char)tel[i] );
		// }
		// System.out.println();

		if (bytes < 20)
			return false; // Invalid Tel, close connection

		int len = ((char) tel[0] - '0') * 1000 + ((char) tel[1] - '0') * 100
				+ ((char) tel[2] - '0') * 10 + ((char) tel[3] - '0');

		int mid = ((char) tel[4] - '0') * 1000 + ((char) tel[5] - '0') * 100
				+ ((char) tel[6] - '0') * 10 + ((char) tel[7] - '0');

		switch (mid) {
		case MID_COM_ACK:
			// System.out.println( getName() + ": Got ComStart ACK" );
			if (m_WaitingForAckTel != null
					&& m_WaitingForAckTel.getMID() == MID_COM_START)
				m_WaitingForAckTel = null;
			break;
		case MID_CMD_ERROR:
			return _handle_tel_cmd_error(tel, bytes);
		case MID_CMD_ACCEPTED:
			return _handle_tel_cmd_accepted(tel, bytes);
		case MID_PSET:
			return _handle_tel_pset_selected(tel, bytes);
		case MID_VIN_UPLOAD:
			return _handle_tel_vin_upload(tel, bytes);
		case MID_RESULT_UPLOAD:
			return _handle_tel_result_upload(tel, bytes);
		case MID_PSET_UPLOAD:
			return _handle_tel_pset_upload(tel, bytes);
		case MID_KEEP_ALIVE:
			// System.out.println( getName() + ": Got KeepAlive ACK" );
			if (m_WaitingForAckTel != null
					&& m_WaitingForAckTel.getMID() == MID_KEEP_ALIVE)
				m_WaitingForAckTel = null;
			break;
		default:
			// System.out.println( getName() + ": Got unknown tel" );
			return false; // unhandled telegram, close connection
		}

		return true;
	}

	/** enqueue a telegram to select a pset */
	public void asyncSelectPSet(int pset) {
		byte[] data = new byte[3];

		data[0] = (byte) ('0' + ((pset / 100) % 10));
		data[1] = (byte) ('0' + ((pset / 10) % 10));
		data[2] = (byte) ('0' + (pset % 10));

		OPTelegram tel = new OPTelegram(MID_SELECT_PSET, true, data, 3);

		m_JobList.add(tel);
	}

	/** enqueue a telegram to set the batchsize of a pset */
	public void asyncSetPSetBatchSize(int pset, int batch_size) {
		byte[] data = new byte[5];

		data[0] = (byte) ('0' + ((pset / 100) % 10));
		data[1] = (byte) ('0' + ((pset / 10) % 10));
		data[2] = (byte) ('0' + (pset % 10));

		data[3] = (byte) ('0' + ((batch_size / 10) % 10));
		data[4] = (byte) ('0' + (batch_size % 10));

		OPTelegram tel = new OPTelegram(MID_SET_PSET_BATCH_SIZE, true, data, 5);

		m_JobList.add(tel);
	}

	/** enqueue a telegram to reset the batchcounter of a pset */
	public void asyncResetPSetBatchCounter(int pset) {
		byte[] data = new byte[3];

		data[0] = (byte) ('0' + ((pset / 100) % 10));
		data[1] = (byte) ('0' + ((pset / 10) % 10));
		data[2] = (byte) ('0' + (pset % 10));

		OPTelegram tel = new OPTelegram(MID_RESET_PSET_BATCH_COUNTER, true,
				data, 3);

		m_JobList.add(tel);
	}

	/** enqueue a telegram to disable/lock a tool */
	public void asyncDisableTool() {
		OPTelegram tel = new OPTelegram(MID_DISABLE_TOOL, true, null, 0);

		m_JobList.add(tel);
	}

	/** enqueue a telegram to enable/unlock a tool */
	public void asyncEnableTool() {
		OPTelegram tel = new OPTelegram(MID_ENABLE_TOOL, true, null, 0);

		m_JobList.add(tel);
	}

	/** enqueue a telegram to download a VIN to the tool */
	public void asyncDownloadVIN(String vin) {

		vin = vin.trim();

		if (vin.length() > 25)
			vin = vin.substring(0, 25);

		while (vin.length() < 25)
			vin += " ";

		OPTelegram tel = new OPTelegram(MID_VIN_DOWNLOAD, true, vin.getBytes(),
				25);

		m_JobList.add(tel);
	}

	/** enqueue a telegram to set the display text to the tool */
	public void asyncDisplayText(String text) {

		text = text.trim();

		if (text.length() > 4)
			text = text.substring(0, 4);

		while (text.length() < 4)
			text += " ";

		OPTelegram tel = new OPTelegram(MID_DISPLAY_USER_TEXT, true,
				text.getBytes(), 4);

		m_JobList.add(tel);
	}

}
