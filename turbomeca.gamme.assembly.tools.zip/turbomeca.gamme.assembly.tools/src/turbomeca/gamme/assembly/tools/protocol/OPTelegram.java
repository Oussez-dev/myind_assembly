package turbomeca.gamme.assembly.tools.protocol;

import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;

/**
 * OPTelegramm - a class holding the data to send over the network for one
 * request
 */
public class OPTelegram {
	private int m_MID = 0;
	private ByteBuffer m_Telegram = null;
	private long m_SendTime = 0;
	private boolean m_NeedsAck = false;

	/** Constructor */
	OPTelegram(int mid, boolean needsAck, byte[] data, int data_len) {
		int i, tel_len;

		m_NeedsAck = needsAck;

		tel_len = data_len + 20;
		m_MID = mid;
		m_Telegram = ByteBuffer.allocate(tel_len + 1);

		// 4 byte Telegram length
		m_Telegram.put((byte) ('0' + ((tel_len / 1000) % 10)));
		m_Telegram.put((byte) ('0' + ((tel_len / 100) % 10)));
		m_Telegram.put((byte) ('0' + ((tel_len / 10) % 10)));
		m_Telegram.put((byte) ('0' + (tel_len % 10)));

		// 4 byte mid
		m_Telegram.put((byte) ('0' + ((mid / 1000) % 10)));
		m_Telegram.put((byte) ('0' + ((mid / 100) % 10)));
		m_Telegram.put((byte) ('0' + ((mid / 10) % 10)));
		m_Telegram.put((byte) ('0' + (mid % 10)));

		// 12 byte reserved
		for (i = 0; i < 12; i++)
			m_Telegram.put((byte) ' ');

		if (data_len > 0)
			m_Telegram.put(data, 0, data_len);
		m_Telegram.put((byte) 0);

		m_Telegram.flip();
	}

	/** returns the timestamp, when this telegram was sended or 0 */
	public long getSendTime() {
		return m_SendTime;
	}

	/** return the telegram as a String */
	public String toString() {
		String s = "";
		byte[] tel;

		tel = m_Telegram.array();

		for (int i = m_Telegram.position(); i < m_Telegram.limit() - 1; i++) {
			s += (char) tel[i];
		}
		return s;
	}

	/** write as much as possible from this telegramm to the socket */
	public void write(SocketChannel sock) {
		try {
			sock.write(m_Telegram);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				sock.close();
			} catch (Exception e2) {
				e.printStackTrace();
			}
		}

		m_SendTime = System.currentTimeMillis();

		return;
	}

	/** are there remaining bytes to send for this telegram ? */
	public boolean needsToBeWritten() {
		if (m_Telegram.remaining() > 0)
			return true; // async write may have sended not all data
		return false; // waiting for ACK
	}

	/** does this telegram need a answer from the tool ? */
	public boolean needsAck() {
		return m_NeedsAck;
	}

	/** returns the Message Identifier of this telegram */
	public int getMID() {
		return m_MID;
	}
}
