package turbomeca.gamme.assembly.tools.protocol;

import java.io.IOException;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Set;

/** OPToolManager - Interface class for OpenProtocol tool integration */
public class OPToolManager implements Runnable {

	private boolean m_Running = false;
	private Thread m_Thread = null;
	/** internal thread */
	private Selector m_Selector = null;
	/** Selector for waiting for network events */
	private LinkedList m_Tools = new LinkedList();

	/** List of all PF tools */

	// *************************
	// external control methods
	// *************************

	/** start the internal thread */
	public void start() {
		if (m_Thread == null) {

			if (m_Selector == null) {
				try {
					m_Selector = Selector.open();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			m_Running = true;
			m_Thread = new Thread(this, "");
			m_Thread.setDaemon(true); /*
									 * do not wait for thread termination at
									 * software shutdown
									 */
			m_Thread.start();
		}
	}

	/** stop the internal thread */
	public void stop() {
		m_Running = false;

		while (m_Thread != null)
			try {
				Thread.sleep(50);
			} catch (Exception e) {
				e.printStackTrace();
				return;
			}
	}

	/** add a PF tool */
	public synchronized void addTool(String name, String ip, short port) {
		OPTool tool;
		Iterator it;

		it = m_Tools.iterator();
		while (it.hasNext()) {
			tool = (OPTool) it.next();
			if (tool.getName().equalsIgnoreCase(name)) {
				return; /* allready there */
			}
		}

		m_Tools.add(new OPTool(name, ip, port));
	}

	/** remove a PF tool */
	public synchronized void removeTool(String name) {
		OPTool tool;
		Iterator it;

		it = m_Tools.iterator();
		while (it.hasNext()) {
			tool = (OPTool) it.next();
			if (tool.getName().equalsIgnoreCase(name)) {
				m_Tools.remove(tool); /* found the tool */

				tool.finish(m_Selector); /*
										 * deregister the socket from the
										 * selector
										 */

				break;
			}
		}
	}

	/** returns a String List of all toolnames */
	public synchronized LinkedList getToolNames() {
		OPTool tool;
		Iterator it;
		LinkedList l = new LinkedList();

		it = m_Tools.iterator();
		while (it.hasNext()) {
			tool = (OPTool) it.next();
			l.add(tool.getName());
		}
		return l;
	}

	/** returns the address of a tools */
	public synchronized String getToolAddress(String toolname) {
		OPTool tool;
		Iterator it;

		it = m_Tools.iterator();
		while (it.hasNext()) {
			tool = (OPTool) it.next();
			if (tool.getName().equalsIgnoreCase(toolname)) {
				/* found the tool */
				return ((OPTool) tool).getIpAddr();
			}
		}
		return ""; /* NO such tool */
	}

	/** checks if the given tool exists */
	public synchronized boolean existsTool(String toolname) {
		OPTool tool;
		Iterator it;

		it = m_Tools.iterator();
		while (it.hasNext()) {
			tool = (OPTool) it.next();
			if (tool.getName().equalsIgnoreCase(toolname)) {
				return true; /* yes */
			}
		}
		return false; /* no such toolname */
	}

	/** check if the tool is connected */
	public synchronized boolean isToolConnected(String toolname) {
		OPTool tool;
		Iterator it;

		it = m_Tools.iterator();
		while (it.hasNext()) {
			tool = (OPTool) it.next();
			if (tool.getName().equalsIgnoreCase(toolname)) {
				/* found the tool */
				return ((OPTool) tool).isConnected();
			}
		}
		return false; /* NO such tool */
	}

	/** check if the tool is connected */
	public synchronized int[] getToolPSets(String toolname) {
		OPTool tool;
		Iterator it;

		it = m_Tools.iterator();
		while (it.hasNext()) {
			tool = (OPTool) it.next();
			if (tool.getName().equalsIgnoreCase(toolname)) {
				/* found the tool */
				return ((OPTool) tool).getPSets();
			}
		}
		return null; /* NO such tool */
	}

	/** add a EventHandler for a tool */
	public synchronized void addToolHandler(String toolname, IOPEventHandler h) {
		OPTool tool;
		Iterator it;

		it = m_Tools.iterator();
		while (it.hasNext()) {
			tool = (OPTool) it.next();
			if (tool.getName().equalsIgnoreCase(toolname)) {
				/* found the tool */
				((OPTool) tool).addHandler(h);
				break;
			}
		}
	}

	/** remove a EventHandler */
	public synchronized void removeToolHandler(String toolname,
			IOPEventHandler h) {
		OPTool tool;
		Iterator it;

		it = m_Tools.iterator();
		while (it.hasNext()) {
			tool = (OPTool) it.next();
			if (tool.getName().equalsIgnoreCase(toolname)) {
				/* fond the tool */
				((OPTool) tool).removeHandler(h);
				break;
			}
		}
	}

	/** enqueue a SelectPset telegram */
	public synchronized void asyncSelectPSet(String toolname, int pset) {
		OPTool tool;
		Iterator it;

		it = m_Tools.iterator();
		while (it.hasNext()) {
			tool = (OPTool) it.next();

			if (tool.getName().equalsIgnoreCase(toolname)) {
				((OPTool) tool).asyncSelectPSet(pset);
				m_Selector.wakeup();
				break;
			}
		}
	}

	/** enqueue a SetPSetBatchSize telegram */
	public synchronized void asyncSetPSetBatchSize(String toolname, int pset,
			int batch_size) {
		OPTool tool;
		Iterator it;

		it = m_Tools.iterator();
		while (it.hasNext()) {
			tool = (OPTool) it.next();

			if (tool.getName().equalsIgnoreCase(toolname)) {
				((OPTool) tool).asyncSetPSetBatchSize(pset, batch_size);
				m_Selector.wakeup();
				break;
			}
		}
	}

	/** enqueue a ResetPSetBatchCounter telegram */
	public synchronized void asyncResetPSetBatchCounter(String toolname,
			int pset) {
		OPTool tool;
		Iterator it;

		it = m_Tools.iterator();
		while (it.hasNext()) {
			tool = (OPTool) it.next();

			if (tool.getName().equalsIgnoreCase(toolname)) {
				((OPTool) tool).asyncResetPSetBatchCounter(pset);
				m_Selector.wakeup();
				break;
			}
		}
	}

	/** enqueue a DisableTool telegram */
	public synchronized void asyncDisableTool(String toolname) {
		OPTool tool;
		Iterator it;

		it = m_Tools.iterator();
		while (it.hasNext()) {
			tool = (OPTool) it.next();

			if (tool.getName().equalsIgnoreCase(toolname)) {
				((OPTool) tool).asyncDisableTool();
				m_Selector.wakeup();
				break;
			}
		}
	}

	/** enqueue a EnableTool telegram */
	public synchronized void asyncEnableTool(String toolname) {
		OPTool tool;
		Iterator it;

		it = m_Tools.iterator();
		while (it.hasNext()) {
			tool = (OPTool) it.next();

			if (tool.getName().equalsIgnoreCase(toolname)) {
				((OPTool) tool).asyncEnableTool();
				m_Selector.wakeup();
				break;
			}
		}
	}

	/** enqueue a DownloadVIN telegram */
	public synchronized void asyncDownloadVIN(String toolname, String vin) {
		OPTool tool;
		Iterator it;

		it = m_Tools.iterator();
		while (it.hasNext()) {
			tool = (OPTool) it.next();

			if (tool.getName().equalsIgnoreCase(toolname)) {
				((OPTool) tool).asyncDownloadVIN(vin);
				m_Selector.wakeup();
				break;
			}
		}
	}

	/** enqueue a DisplayText telegram */
	public synchronized void asyncDisplayText(String toolname, String text) {
		OPTool tool;
		Iterator it;

		it = m_Tools.iterator();
		while (it.hasNext()) {
			tool = (OPTool) it.next();

			if (tool.getName().equalsIgnoreCase(toolname)) {
				((OPTool) tool).asyncDisplayText(text);
				m_Selector.wakeup();
				break;
			}
		}
	}

	// *************************
	// internal thread functions
	// *************************

	/** fill the selector with "waiting for events" */
	private synchronized int _fill_selector() {
		Iterator it;
		OPTool tool;
		int timeout = 10000; /* select timeout without tools */

		it = m_Tools.iterator();
		while (it.hasNext()) {
			tool = (OPTool) it.next();

			timeout = Math.min(timeout, tool.fillSelector(m_Selector));
		}

		return Math.max(timeout, 20); /* min timeout is 20 ms */
	}

	/** inform the tools about their network events */
	private synchronized void _handle_selector_events() {
		Set set;
		Iterator it;
		SelectionKey key;
		OPTool tool;
		int mask;

		set = m_Selector.selectedKeys();

		it = set.iterator();
		while (it.hasNext()) {
			key = (SelectionKey) it.next();
			tool = (OPTool) key.attachment();

			if (tool == null)
				continue; // tool removed !!!!

			mask = key.readyOps() & key.interestOps();

			if ((mask & SelectionKey.OP_CONNECT) == SelectionKey.OP_CONNECT) {
				// System.out.println( tool.getName() + ": connectable" );
				tool.connectable();
			}

			if ((mask & SelectionKey.OP_READ) == SelectionKey.OP_READ) {
				// System.out.println( tool.getName() + ": readable" );
				tool.readable();
			}

			if ((mask & SelectionKey.OP_WRITE) == SelectionKey.OP_WRITE) {
				// System.out.println( tool.getName() + ": writable" );
				tool.writable();
			}
		}
	}

	/** thread function */
	public void run() {
		int timeout = 100;
		long t1, t2;

		while (m_Running) {

			// fill selector
			timeout = _fill_selector();

			// select
			// System.out.println( "selecting with " + timeout + "ms timeout" );
			t1 = System.currentTimeMillis();
			try {
				m_Selector.select(timeout);
			} catch (IOException e) {
				e.printStackTrace();
				try {
					Thread.sleep(100);
				} catch (Exception e2) {
					e2.printStackTrace();
				}
			}
			t2 = System.currentTimeMillis();
			// System.out.println( "sleeped for " + (t2-t1) + "ms" );

			// handle events
			_handle_selector_events();
		}
		m_Thread = null;
	}
}
