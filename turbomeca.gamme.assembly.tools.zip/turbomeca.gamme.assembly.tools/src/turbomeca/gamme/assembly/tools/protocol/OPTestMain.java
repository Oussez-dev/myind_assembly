package turbomeca.gamme.assembly.tools.protocol;

public class OPTestMain implements IOPEventHandler {

	OPToolManager mgt = new OPToolManager();

	public void PSetSelected(String toolname, int pset) {
		System.err.println("PSetSelected " + toolname + " " + pset);
	}

	public void NewVIN(String toolname, String vin) {
		System.err.println("NewVIN " + toolname + " " + vin);
	}

	public void NewTGTResult(String toolname, String vin, int pset,
			boolean status, int batch_size, int batch_count,
			boolean batch_status) {
		System.err.println("NewTGTResult " + toolname + " " + vin + " " + pset
				+ " " + status + " " + batch_size + " " + batch_count + " "
				+ batch_status);

		if (batch_status) {
			mgt.asyncDisableTool(toolname);
		}
	}

	public void ConnectionLost(String toolname) {
		System.err.println("ConnectionLost " + toolname);
	}

	public void PSetCannotBeSet(String toolname) {
		System.err.println("PSetCannotBeSet " + toolname);
	}

	public static void main(String[] args) {

		OPTestMain test = new OPTestMain();

		System.out.println("started");

		test.mgt.addTool("VIS01", "156.28.96.150", (short) 4545);
		test.mgt.addTool("VIS02", "156.28.96.151", (short) 4545);
		test.mgt.start();

		test.mgt.addToolHandler("VIS01", test);
		test.mgt.addToolHandler("VIS02", test);

		try {
			Thread.sleep(5000);
		} catch (Exception e) {
			e.printStackTrace();
		}

		test.mgt.asyncDownloadVIN("VIS01", "B123456789");
		test.mgt.asyncSelectPSet("VIS01", 20);
		test.mgt.asyncSetPSetBatchSize("VIS01", 20, 3);
		test.mgt.asyncResetPSetBatchCounter("VIS01", 20);
		test.mgt.asyncEnableTool("VIS01");
		test.mgt.asyncDisplayText("VIS01", "3797");
		// test.mgt.asyncUploadPSets( "VIS01" );

		test.mgt.asyncDownloadVIN("VIS02", "B123456789");
		test.mgt.asyncSelectPSet("VIS02", 20);
		test.mgt.asyncSetPSetBatchSize("VIS02", 20, 3);
		test.mgt.asyncResetPSetBatchCounter("VIS02", 20);
		test.mgt.asyncEnableTool("VIS02");
		test.mgt.asyncDisplayText("VIS02", "3798");
		// test.mgt.asyncUploadPSets( "VIS02" );

		try {
			Thread.sleep(600000);
		} catch (Exception e) {
			e.printStackTrace();
		}

		System.out.println("exit");

	}

}
