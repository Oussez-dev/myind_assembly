package turbomeca.gamme.assembly.tools;

// TMDI

/**
 * Cette classe g�re l'appel au processus de manipulation des fichier et folder
 */

//public class OPToolHandler extends Handler implements IOPEventHandler {
//
//	private static final int TIMEOUT = 15 * 60 * 1000; // 15 mins
//
//	public String user;
//	public String retval;
//	public boolean waiting_for_complete;
//	private long start_time;
//
//	/**
//	 * Constructeur de la classe
//	 * 
//	 * @param _params
//	 *            Objet de la classe "tmdi.server.servlet.RequestParams" qui
//	 *            d�finit les param�tres de la requ�te HTTP qui a �t� re�ue.
//	 */
//	public OPToolHandler(RequestParams _params, HttpServletRequest _request) {
//		this.params = _params;
//		JournalServletPAO.getJournal()
//				.log("== Utilisation du OPToolHandler ==");
//
//	}
//
//	public void PSetSelected(String toolname, int pset) {
//		// System.err.println( "PSetSelected " + toolname + " " + pset);
//	}
//
//	public void NewVIN(String toolname, String vin) {
//		// System.err.println( "NewVIN " + toolname + " " + vin );
//	}
//
//	public void NewTGTResult(String toolname, String vin, int pset,
//			boolean status, int batch_size, int batch_count,
//			boolean batch_status) {
//		// System.err.println( "NewTGTResult " + toolname + " " + vin + " " +
//		// pset + " " + status + " " + batch_size
//		// + " " + batch_count + " " + batch_status );
//
//		if (batch_status) {
//			ProcessServlet.toolManager.asyncDisableTool(toolname);
//
//			retval = "true";
//			waiting_for_complete = false;
//		}
//	}
//
//	public void ConnectionLost(String toolname) {
//		if (waiting_for_complete)
//			retval = "Perte connexion";
//		// retval = "ConnectionToToolLost";
//		waiting_for_complete = false;
//	}
//
//	public void PSetCannotBeSet(String toolname) {
//		// retval = "PSetCannotBeSet";
//		retval = "Programme inconnu";
//		waiting_for_complete = false;
//	}
//
//	/** M�thode d'ex�cution du processus */
//	public void run() {
//		String toolname = this.params.getParameter("toolname");
//		String pset = this.params.getParameter("pset");
//		String batchsize = this.params.getParameter("batchsize");
//		String vin = this.params.getParameter("vin");
//		user = this.params.getParameter("user");
//
//		retval = "false";
//
//		JournalServletPAO.getJournal().log(
//				"execution : OPToolHandler.run() " + toolname + " " + pset
//						+ " " + batchsize + " " + vin + " " + user);
//
//		waiting_for_complete = true;
//
//		for (int i = 0; i < ProcessServlet.usedToolNames.size(); i++) {
//			if (((String) ProcessServlet.usedToolNames.get(i))
//					.equalsIgnoreCase(toolname)) {
//				ProcessServlet.usedToolHandlers.set(i, this);
//			}
//		}
//
//		ProcessServlet.toolManager.addToolHandler(toolname, this);
//
//		ProcessServlet.toolManager.asyncDownloadVIN(toolname, vin);
//		ProcessServlet.toolManager.asyncSelectPSet(toolname,
//				Integer.parseInt(pset));
//		ProcessServlet.toolManager.asyncSetPSetBatchSize(toolname,
//				Integer.parseInt(pset), Integer.parseInt(batchsize));
//		ProcessServlet.toolManager.asyncResetPSetBatchCounter(toolname,
//				Integer.parseInt(pset));
//		ProcessServlet.toolManager.asyncEnableTool(toolname);
//		ProcessServlet.toolManager.asyncDisplayText(toolname, user);
//
//		start_time = System.currentTimeMillis();
//		while (waiting_for_complete
//				&& (System.currentTimeMillis() - start_time < TIMEOUT)) {
//			try {
//				Thread.sleep(100);
//			} catch (Exception e) {
//				e.printStackTrace();
//			}
//		}
//		if (waiting_for_complete)
//			retval = "Timeout";
//
//		ProcessServlet.toolManager.asyncDisableTool(toolname);
//		ProcessServlet.toolManager.removeToolHandler(toolname, this);
//
//		this.returnedContent = retval;
//
//		for (int i = 0; i < ProcessServlet.usedToolNames.size(); i++) {
//			if (((String) ProcessServlet.usedToolNames.get(i))
//					.equalsIgnoreCase(toolname)) {
//				ProcessServlet.usedToolHandlers.set(i, null);
//			}
//		}
//
//		JournalServletPAO.getJournal().log(
//				"execution : OPToolHandler.run() finished");
//
//	} // fin run
//
//	/**
//	 * Cette m�thode retourne le contenu HTML r�sultat du processus et � envoyer
//	 * dans l'objet r�ponse de la servlet
//	 * 
//	 * @return La cha�ne de caract�res g�n�r� � l'ex�cution de la requ�te par le
//	 *         serveur.
//	 */
//	public String getReturnedContent() {
//		return this.returnedContent;
//	}
//
//}
